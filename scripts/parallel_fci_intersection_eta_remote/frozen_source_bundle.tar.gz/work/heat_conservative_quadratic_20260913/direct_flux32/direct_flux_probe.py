"""Bounded prototype for a joint transverse/parallel direct FCI flux fit.

This is a saved-field research calculation.  It does not modify DRBX or run a
simulation.  Each valid two-sided FCI source row gets one least-squares fit
over owner values on the source and mapped endpoint planes.  The z coefficient
is the connection gradient.  The resulting weak operator is assembled as
``-Mo^-1 G.T W G``; a low-order endpoint-owner return is also evaluated as an
ablation.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy import sparse
from scipy.sparse import save_npz

RUN = Path(__file__).resolve().parents[1]
ROOT = RUN.parents[1]
CASE = ROOT / "prototype_runs" / "hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_conservative_quadratic_t25_20260913"
HOST = RUN / "metric_cache_32" / "angular_rlp_host_85832e63967cf29a96d27b10.npz"
OUT = Path(__file__).resolve().parent
NNEAR = 32
CHI = 0.1


def load(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=True) as z:
        return {k: np.asarray(z[k]).copy() for k in z.files}


def endpoint_rows(maps, shape, direction):
    n = int(np.prod(shape)); nr, nt, nz = shape
    x = np.asarray(maps[direction + "_x"], float).ravel()
    y = np.asarray(maps[direction + "_y"], float).ravel()
    boundary = np.asarray(maps[direction + "_boundary"], bool).ravel()
    i = np.floor(np.nan_to_num(x, nan=0.0)).astype(int)
    j = np.floor(np.nan_to_num(y, nan=0.0)).astype(int) % nt
    valid = np.isfinite(x) & np.isfinite(y) & ~boundary & (i >= -nr) & (i < nr - 1)
    fx = np.nan_to_num(x, nan=0.0) - np.floor(np.nan_to_num(x, nan=0.0))
    fy = np.nan_to_num(y, nan=0.0) - np.floor(np.nan_to_num(y, nan=0.0))
    i0, i1 = i, i + 1
    j0, j1 = j, (j + 1) % nt
    neg0, neg1 = i0 < 0, i1 < 0
    i0 = np.where(neg0, -i0 - 1, i0); i1 = np.where(neg1, -i1 - 1, i1)
    j0 = np.where(neg0, (j0 + nt // 2) % nt, j0)
    j1 = np.where(neg0, (j1 + nt // 2) % nt, j1)
    j0_1 = np.where(neg1, (j + nt // 2) % nt, j)
    j1_1 = np.where(neg1, ((j + 1) % nt + nt // 2) % nt, (j + 1) % nt)
    k0 = np.arange(n) % nz; k = (k0 + (1 if direction == "forward" else -1)) % nz
    flat = lambda a, b, c: (a * nt + b) * nz + c
    ids = np.column_stack((flat(i0,j0,k), flat(i0,j1,k), flat(i1,j0_1,k), flat(i1,j1_1,k)))
    weights = np.column_stack(((1-fx)*(1-fy), (1-fx)*fy, fx*(1-fy), fx*fy))
    ids = np.where(valid[:, None], ids, 0)
    return ids, weights, valid, x, y


def main() -> None:
    host = load(HOST); hist = load(CASE / "history.npz")
    shape = tuple(int(v) for v in host["shape"]); nr, nt, nz = shape; n = int(np.prod(shape))
    raw_vol = np.asarray(host["host_raw_volume"], float).ravel()
    aggregate = np.asarray(host["topology_aggregate_id"], int).ravel()
    active = np.asarray(host["topology_is_active_owner"], bool).ravel()
    active_ids = np.flatnonzero(active)
    owner_ids = active_ids if np.array_equal(active_ids, aggregate[active_ids]) else np.sort(np.unique(aggregate[active]))
    lookup = {int(v): q for q, v in enumerate(owner_ids)}
    slot = np.asarray([lookup[int(v)] for v in aggregate], int)
    no = owner_ids.size
    owner_volume = np.bincount(slot, weights=raw_vol, minlength=no)
    owner_coord = np.asarray(np.unravel_index(owner_ids, shape)).T
    agg_cent = np.asarray(host["host_aggregate_chart_centroid"], float).reshape(n, 3)[owner_ids]
    agg_sec = np.asarray(host["host_aggregate_chart_second_moment"], float).reshape(n, 3, 3)[owner_ids]
    plane_owners = [np.flatnonzero(owner_coord[:,2] == k) for k in range(nz)]
    maps = {str(name): np.asarray(hist["fci_map_fields"])[..., q].ravel() for q,name in enumerate(hist["fci_map_field_names"])}
    ep = {d: endpoint_rows(maps, shape, d) for d in ("forward", "backward")}
    valid = ep["forward"][2] & ep["backward"][2]
    rows = np.flatnonzero(valid)
    q_owner = 1.0 / np.asarray(hist["magnetic_field"], float).ravel()[owner_ids]
    qfine = q_owner[slot]
    qend = {}
    for d in ("forward", "backward"):
        ids,w,_,_,_ = ep[d]; qend[d] = np.sum(w * qfine[ids], axis=1)
    # Sparse G and G0 are assembled row by row.  Each fit has at most 64
    # distinct owner columns; duplicate aliases are summed by CSR conversion.
    gr=[]; gc=[]; gd=[]; g0d=[]; g0r=[]; g0c=[]; leg_source=[]; leg_dir=[]; leg_ds=[]; leg_qface=[]
    fit_cond=[]; fit_resid=[]; fit_rank=[]; excluded_wall = 0
    for r in rows:
        i,j,k = np.unravel_index(int(r), shape)
        def xy(u, th):
            # endpoint fields store physical logical u/theta; map fields store
            # index coordinates, so use the former whenever available.
            return u*np.cos(th), u*np.sin(th)
        xs, ys = xy(hist["u"][i], hist["theta"][j])
        for d, plane, endpoint_u, endpoint_th in (
            ("forward", (k+1)%nz, maps.get("forward_endpoint_x", ep["forward"][3])[r], maps.get("forward_endpoint_y", ep["forward"][4])[r]),
            ("backward", (k-1)%nz, maps.get("backward_endpoint_x", ep["backward"][3])[r], maps.get("backward_endpoint_y", ep["backward"][4])[r]),
        ):
            # endpoint_x/y are saved logical u/theta, while fallback map x/y
            # are index coordinates.
            if d + "_endpoint_x" in maps:
                xp, yp = xy(endpoint_u, endpoint_th)
            else:
                xp, yp = xy((endpoint_u+0.5)/nr, 2*np.pi*(endpoint_th+0.5)/nt)
            ids_fit=[]; z=[]; centers=[]
            for pl, (cx,cy,zz) in ((k,(xs,ys,-.5)), (plane,(xp,yp,.5))):
                cand = plane_owners[pl]; d2=(agg_cent[cand,0]-cx)**2+(agg_cent[cand,1]-cy)**2
                take=cand[np.argsort(d2)[:NNEAR]]
                ids_fit.extend(take.tolist()); z.extend([zz]*len(take)); centers.extend([(cx,cy)]*len(take))
            ids_fit=np.asarray(ids_fit,int); z=np.asarray(z); centers=np.asarray(centers)
            dxraw=agg_cent[ids_fit,0]-centers[:,0]; dyraw=agg_cent[ids_fit,1]-centers[:,1]
            sx=max(float(np.sqrt(np.mean(dxraw*dxraw))),1e-8); sy=max(float(np.sqrt(np.mean(dyraw*dyraw))),1e-8)
            xx=dxraw/sx; yy=dyraw/sy
            xx2=agg_sec[ids_fit,0,0]/sx**2+xx*xx; xyy=agg_sec[ids_fit,0,1]/(sx*sy)+xx*yy; yy2=agg_sec[ids_fit,1,1]/sy**2+yy*yy
            D=np.column_stack((np.ones_like(xx),xx,yy,xx2,xyy,yy2,z,z*xx,z*yy))
            # Equal observation weights; physical volume enters the aggregate
            # moments themselves and the positive weak face weight W.
            U,s,Vh=np.linalg.svd(D,full_matrices=False); tol=np.finfo(float).eps*max(D.shape)*s[0]; sinv=np.where(s>tol,1.0/s,0.0)
            pinv=Vh.T @ (sinv[:,None]*U.T); rowcoeff=pinv[6]
            fit_rank.append(int(np.count_nonzero(s > tol))); fit_cond.append(float(s[0]/s[-1])); fit_resid.append(float(np.max(np.abs(rowcoeff @ D - np.eye(9)[6]))))
            if fit_rank[-1] != 9 or fit_resid[-1] > 1.0e-11:
                raise RuntimeError(f"rank-9 aggregate fit check failed: rank={fit_rank[-1]} residual={fit_resid[-1]}")
            ds=float(maps[d+"_length"][r]); vals={}
            for q,c in zip(ids_fit,rowcoeff/ds): vals[q]=vals.get(q,0.)+float(c)
            leg=len(leg_source); leg_source.append(int(r)); leg_dir.append(d); leg_ds.append(ds); leg_qface.append(.5*(qfine[r]+qend[d][r]))
            for q,c in vals.items(): gr.append(leg); gc.append(q); gd.append(c)
            src=slot[r]; ids4,w4=ep[d][0][r],ep[d][1][r]
            for q,c in zip((slot[q] for q in ids4),w4/ds): g0r.append(leg); g0c.append(int(q)); g0d.append(float(c))
            g0r.append(leg); g0c.append(int(src)); g0d.append(-1.0/ds)
    G=sparse.coo_matrix((gd,(gr,gc)),shape=(len(leg_source),no)).tocsr()
    G0=sparse.coo_matrix((g0d,(g0r,g0c)),shape=(len(leg_source),no)).tocsr()
    leg_source=np.asarray(leg_source); leg_ds=np.asarray(leg_ds); leg_qface=np.asarray(leg_qface)
    W=0.5*raw_vol[leg_source]*(1.0/qfine[leg_source])*(2*leg_ds/(maps["forward_length"][leg_source]+maps["backward_length"][leg_source]))*leg_qface
    if np.any(W<=0) or not np.all(np.isfinite(W)): raise RuntimeError("nonpositive direct-flux weight")
    save_npz(OUT/"G_direct32.npz",G); save_npz(OUT/"G0_direct32.npz",G0); np.savez(OUT/"W_direct32.npz",rows=leg_source,direction=np.asarray(leg_dir),ds=leg_ds,W=W,owner_ids=owner_ids,owner_volume=owner_volume)
    ones=np.ones(no); const=float(np.max(np.abs(G@ones))); const0=float(np.max(np.abs(G0@ones)))
    rng=np.random.default_rng(20260913); test=rng.normal(size=no); qform=-float(np.sum(W*(G@test)**2)); qform0=-float(np.sum(W*(G0@test)*(G@test)))
    targets={"(3,12,12)":(3,12,12),"(1,0,15)":(1,0,15),"(2,24,14)":(2,24,14),"(6,12,16)":(6,12,16)}
    target_rows={name:int(slot[np.ravel_multi_index(c,shape)]) for name,c in targets.items()}
    excluded = np.flatnonzero(~valid)
    excluded_source_membership = {name: int(np.count_nonzero(slot[excluded] == o)) for name,o in target_rows.items()}
    target_out={}
    # Compute only requested owner rows of A=-Mo^-1 G.TWG and mixed return.
    for name,o in target_rows.items():
        gcol=G[:,o].toarray().ravel(); hcol=G0[:,o].toarray().ravel()
        arow=-np.asarray(G.T @ (W*gcol)).ravel()/owner_volume[o]
        mrow=-np.asarray(G.T @ (W*G0[:,o].toarray().ravel())).ravel()/owner_volume[o]
        off=arow.copy(); off[o]=0.0
        target_out[name]={"owner":o,"coverage_rows":int(np.count_nonzero(gcol)),"leg_support_fraction":float(np.count_nonzero(gcol)/len(leg_source)),"A_direct_row_min":float(np.min(arow)),"A_direct_negative_offdiag":int(np.count_nonzero(off < -1e-13)),"A_mixed_row_min":float(np.min(mrow)),"A_direct_rhs":{},"A_mixed_rhs":{}}
        for t in (0.,3.5,10.5):
            ti=int(np.argmin(np.abs(hist["times"]-t))); ov=np.asarray(hist["Te"][ti],float).ravel()[owner_ids]
            target_out[name]["A_direct_rhs"][str(t)]=float(CHI*arow@ov); target_out[name]["A_mixed_rhs"][str(t)]=float(CHI*mrow@ov)
    report={"provenance":{"history":str(CASE/"history.npz"),"host":str(HOST)},"configuration":{"shape":list(shape),"nearest_owners_per_plane":NNEAR,"basis":["1","x","y","x2","xy","y2","z","zx","zy"],"fit_scope":"joint aggregate-average transverse quadratic plus linear parallel fit; equal observation weights; endpoint z=+1/2, source z=-1/2","valid_directed_rows":int(len(leg_source)),"excluded_source_rows":int(n-rows.size),"excluded_directed_rows":int(2*(n-rows.size)),"chi_rhs_only":CHI,"outer_wall_rows_omitted":True},"weights":{"positive":bool(np.all(W>0)),"min":float(np.min(W)),"max":float(np.max(W))},"fit":{"minimum_rank":int(min(fit_rank)),"maximum_condition":float(np.max(fit_cond)),"max_reproduction_residual":float(np.max(fit_resid))},"checks":{"G_constant_max":const,"G0_constant_max":const0,"energy_quadratic_form":qform,"mixed_quadratic_form":qform0,"energy_dissipation_factorized":bool(qform<=1e-12),"initial_cold_witness_direct_rhs_above_floor":bool(target_out["(2,24,14)"]["A_direct_rhs"]["0.0"] >= -1e-10)},"excluded_outer_wall_source_membership":excluded_source_membership,"targets":target_out,"artifacts":{"G":str(OUT/"G_direct32.npz"),"G0":str(OUT/"G0_direct32.npz"),"W":str(OUT/"W_direct32.npz")}}
    (OUT/"direct_flux_report.json").write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
    print(json.dumps(report,indent=2,sort_keys=True))

if __name__ == "__main__": main()
