"""Independent positive graph control for the saved direct-FCI experiment.

This file intentionally does not import the direct-flux prototype.  It uses
the saved traced interpolation legs to build a positive owner graph, so that
the signed direct fit can be compared with a conservative graph baseline.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy import sparse

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CASE = ROOT / "prototype_runs" / "hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_conservative_quadratic_t25_20260913"
HIST = CASE / "history.npz"
HOST = HERE.parent / "metric_cache_32" / "angular_rlp_host_85832e63967cf29a96d27b10.npz"
OUT = HERE / "graph_control.json"
CHI = 0.1


def load(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=True) as z:
        return {k: np.asarray(z[k]).copy() for k in z.files}


def interpolation(maps: dict[str, np.ndarray], shape: tuple[int, int, int], direction: str):
    nr, nt, nz = shape
    n = int(np.prod(shape)); flat_rows = np.arange(n, dtype=np.int64)
    x = maps[direction + "_x"].ravel().astype(float)
    y = maps[direction + "_y"].ravel().astype(float)
    boundary = maps[direction + "_boundary"].ravel().astype(bool)
    finite = np.isfinite(x) & np.isfinite(y)
    i = np.floor(np.nan_to_num(x, nan=0.0)).astype(np.int64)
    j = np.floor(np.nan_to_num(y, nan=0.0)).astype(np.int64) % nt
    valid = finite & ~boundary & (i >= -nr) & (i < nr - 1)
    fx = np.nan_to_num(x, nan=0.0) - np.floor(np.nan_to_num(x, nan=0.0))
    fy = np.nan_to_num(y, nan=0.0) - np.floor(np.nan_to_num(y, nan=0.0))
    i0, i1 = i, i + 1
    j0, j1 = j, (j + 1) % nt
    neg0, neg1 = i0 < 0, i1 < 0
    i0 = np.where(neg0, -i0 - 1, i0); i1 = np.where(neg1, -i1 - 1, i1)
    j0 = np.where(neg0, (j0 + nt // 2) % nt, j0)
    j1 = np.where(neg0, (j1 + nt // 2) % nt, j1)
    j0_1 = np.where(neg1, (j + nt // 2) % nt, j)
    j1_1 = np.where(neg1, ((j + 1) % nt + nt // 2) % nt, (j + 1) % nt)
    k0 = flat_rows % nz
    k = (k0 + (1 if direction == "forward" else -1)) % nz
    flat = lambda a, b, c: (a * nt + b) * nz + c
    ids = np.column_stack((flat(i0, j0, k), flat(i0, j1, k), flat(i1, j0_1, k), flat(i1, j1_1, k)))
    weights = np.column_stack(((1-fx)*(1-fy), (1-fx)*fy, fx*(1-fy), fx*fy))
    # Invalid/wall rows are discarded by the two-sided mask; keep harmless
    # in-range placeholders so their diagnostic map arrays remain total.
    ids = np.where(valid[:, None], ids, 0)
    if np.any(ids < 0) or np.any(ids >= n):
        raise RuntimeError("axis-reflected donor escaped fine grid")
    return ids, weights, valid, x, y


def owner_maps(host, raw_volume):
    aggregate = host["topology_aggregate_id"].ravel().astype(np.int64)
    active = host["topology_is_active_owner"].ravel().astype(bool)
    active_ids = np.flatnonzero(active)
    owner_ids = active_ids if np.array_equal(active_ids, aggregate[active_ids]) else np.sort(np.unique(aggregate[active]))
    lookup = {int(v): i for i, v in enumerate(owner_ids)}
    slot = np.asarray([lookup[int(v)] for v in aggregate], dtype=np.int64)
    owner_volume = np.bincount(slot, weights=raw_volume, minlength=owner_ids.size)
    return owner_ids, slot, owner_volume


def graph_operator(hist, host, shape, maps, slot, owner_ids, owner_volume):
    n = int(np.prod(shape)); raw_volume = host["host_raw_volume"].ravel().astype(float)
    # Native q is prepared from owner B then prolonged, matching the saved L audit.
    owner_b = hist["magnetic_field"].ravel()[owner_ids]
    qfine = np.zeros(n, float); qfine[:] = 1.0 / owner_b[slot]
    legs = {d: interpolation(maps, shape, d) for d in ("forward", "backward")}
    valid = legs["forward"][2] & legs["backward"][2]
    rows = np.flatnonzero(valid)
    dm = maps["backward_length"].ravel()[rows].astype(float)
    dp = maps["forward_length"].ravel()[rows].astype(float)
    # Match native preparation: B is owner injected before the mapped row.
    bcenter = 1.0 / qfine[rows]
    edge_src = []; edge_dst = []; edge_mass = []; edge_ds = []
    alpha_min = 1.0; alpha_sum_err = 0.0; skipped_same = 0
    for d in ("forward", "backward"):
        ids, alpha, _, _, _ = legs[d]
        ids = ids[rows]; alpha = alpha[rows]
        ds = (dp if d == "forward" else dm)
        qface = 0.5 * (qfine[rows] + np.sum(alpha * qfine[ids], axis=1))
        wleg = 0.5 * raw_volume[rows] * bcenter * (2.0 * ds / (dm + dp)) * qface
        alpha_min = min(alpha_min, float(np.min(alpha)))
        alpha_sum_err = max(alpha_sum_err, float(np.max(np.abs(np.sum(alpha, axis=1) - 1.0))))
        src = slot[rows]
        for c in range(4):
            dst = slot[ids[:, c]]; keep = dst != src
            skipped_same += int(np.count_nonzero(~keep))
            edge_src.extend(src[keep].tolist()); edge_dst.extend(dst[keep].tolist())
            edge_mass.extend((wleg[keep] * alpha[keep, c]).tolist()); edge_ds.extend(ds[keep].tolist())
    ne = len(edge_src); no = owner_volume.size
    # E has one row per directed source-to-donor leg; the quadratic form is
    # positive regardless of duplicate edges, which are summed by CSR.
    er = np.repeat(np.arange(ne, dtype=np.int64), 2)
    ec = np.column_stack((edge_src, edge_dst)).ravel()
    # E is the connection gradient, with the signed owner jump divided by ds.
    ev = np.repeat(np.asarray(edge_ds, dtype=float) ** -1, 2) * np.tile(np.array([-1.0, 1.0]), ne)
    E = sparse.coo_matrix((ev, (er, ec)), shape=(ne, no)).tocsr()
    A = (-sparse.diags(1.0 / owner_volume) @ E.T @ sparse.diags(np.asarray(edge_mass)) @ E).tocsr()
    return A, {"rows": rows, "legs": legs, "qfine": qfine, "edge_mass": np.asarray(edge_mass), "edge_ds": np.asarray(edge_ds), "E": E, "valid_count": int(rows.size), "edge_count": ne, "skipped_same_owner": skipped_same, "alpha_min": alpha_min, "alpha_sum_max_abs_error": alpha_sum_err}


def endpoint_check(hist, maps, shape, legs):
    nr, nt, _ = shape; out = {}
    for d in ("forward", "backward"):
        _, _, valid, x, y = legs[d]
        names = hist["fci_map_field_names"].tolist(); fields = hist["fci_map_fields"]
        au = fields[..., names.index(d + "_endpoint_x")].ravel()
        at = fields[..., names.index(d + "_endpoint_y")].ravel()
        ok = valid & np.isfinite(au) & np.isfinite(at)
        su = (x + 0.5) / nr; st = 2.0 * np.pi * (y + 0.5) / nt
        # The continuous traced endpoint remains at positive u near the
        # axis; reflection is applied to the negative-radial interpolation
        # node(s), where floor(map_x)<0.  Report those rows explicitly.
        axis = np.floor(x) < 0
        ue = su; te = np.mod(st, 2*np.pi)
        dt = np.angle(np.exp(1j * (te - at)))
        out[d] = {"valid_count": int(np.count_nonzero(ok)), "axis_reflected_count": int(np.count_nonzero(ok & axis)), "max_abs_u_error": float(np.max(np.abs(ue[ok] - au[ok]))), "max_abs_theta_wrapped_error": float(np.max(np.abs(dt[ok]))), "rms_u_error": float(np.sqrt(np.mean((ue[ok] - au[ok])**2))), "rms_theta_error": float(np.sqrt(np.mean(dt[ok]**2))), "convention": "signed map radius; negative radius reflected with u=-u and theta+=pi"}
    return out


def moment_check(host, slot, owner_volume):
    v = host["host_raw_volume"].ravel().astype(float); c = host["host_raw_chart_centroid"].reshape(-1, 3); s = host["host_raw_chart_second_moment"].reshape(-1, 3, 3)
    no = owner_volume.size; cv = np.zeros((no, 3)); abs2 = np.zeros((no, 3, 3))
    for i in range(3): cv[:, i] = np.bincount(slot, weights=v*c[:, i], minlength=no) / owner_volume
    for i in range(3):
        for j in range(3): abs2[:, i, j] = np.bincount(slot, weights=v*(s[:, i, j] + c[:, i]*c[:, j]), minlength=no) / owner_volume
    agg_c = host["host_aggregate_chart_centroid"].ravel().reshape(-1, 3)[np.asarray(host["topology_is_active_owner"]).ravel()]
    agg_s = host["host_aggregate_chart_second_moment"].reshape(-1, 3, 3)[np.asarray(host["topology_is_active_owner"]).ravel()]
    central = abs2 - np.einsum("ni,nj->nij", cv, cv)
    return {"centroid_max_abs_error": float(np.max(np.abs(cv - agg_c))), "second_moment_max_abs_error": float(np.max(np.abs(central - agg_s))), "volume_sum_relative_error": float(abs(np.sum(owner_volume)-np.sum(v))/np.sum(v))}


def main():
    hist = load(HIST); host = load(HOST); shape = tuple(int(x) for x in host["shape"]); raw_volume = host["host_raw_volume"].ravel().astype(float)
    owner_ids, slot, owner_volume = owner_maps(host, raw_volume)
    names = hist["fci_map_field_names"].tolist(); fields = hist["fci_map_fields"]
    maps = {str(name): fields[..., i] for i, name in enumerate(names)}
    A, meta = graph_operator(hist, host, shape, maps, slot, owner_ids, owner_volume)
    legs = meta["legs"]; endcheck = endpoint_check(hist, maps, shape, legs)
    moments = moment_check(host, slot, owner_volume)
    times = hist["times"]; targets = {"(3,12,12)":(3,12,12),"(1,0,15)":(1,0,15),"(2,24,14)":(2,24,14),"(6,12,16)":(6,12,16)}
    target_out = {}
    for name, coord in targets.items():
        o = int(slot[np.ravel_multi_index(coord, shape)]); row = A.getrow(o).toarray().ravel(); vals = {}
        for t in (0.0, 3.5, 10.5):
            ti = int(np.argmin(np.abs(times-t))); ov = hist["Te"][ti].ravel()[owner_ids]
            vals[str(t)] = {"actual_time": float(times[ti]), "delta_Te": float(ov[o]-1.0), "rhs_chi": float(CHI * row @ ov), "rhs_unscaled": float(row @ ov)}
        off = row.copy(); off[o] = 0.0
        target_out[name] = {"owner": o, "coordinate": list(coord), "graph_row_sum": float(np.sum(row)), "negative_offdiag_count": int(np.count_nonzero(off < -1e-13)), "min_offdiag": float(np.min(off)), "times": vals}
    rng = np.random.default_rng(20260913); z = rng.normal(size=owner_volume.size); energy = float(z @ (owner_volume * (A @ z)))
    factorized_energy = -float(np.sum(meta["edge_mass"] * (meta["E"] @ z) ** 2))
    offdiag = A.tocoo(); neg = offdiag.data[(offdiag.row != offdiag.col) & (offdiag.data < -1e-13)]
    report = {"provenance":{"history":str(HIST),"host":str(HOST),"independent_from":"direct_flux_probe.py"},"configuration":{"shape":list(shape),"chi_rhs_only":CHI,"operator":"Agraph=-Mo^-1 E.T diag(W_leg*alpha) E, E=(-1,+1)/ds","valid_two_sided_native_rows":meta["valid_count"],"outer_wall_rows_omitted":True,"axis_reflection_included":True,"same_owner_edges_skipped":meta["skipped_same_owner"]},"assembly":{"edge_count":meta["edge_count"],"negative_or_nonfinite_alpha":bool(meta["alpha_min"] < -1e-14),"alpha_min":meta["alpha_min"],"alpha_sum_max_abs_error":meta["alpha_sum_max_abs_error"],"weight_min":float(np.min(meta["edge_mass"])),"weight_max":float(np.max(meta["edge_mass"])),"A_nnz":int(A.nnz)},"checks":{"constant_max_abs":float(np.max(np.abs(A @ np.ones(owner_volume.size)))),"weighted_conservation_max_abs":float(np.max(np.abs(A.T @ owner_volume))),"random_energy":energy,"factorized_energy":factorized_energy,"energy_identity_abs_error":abs(energy-factorized_energy),"energy_nonpositive":bool(energy <= 1e-11),"negative_offdiag_count":int(neg.size),"negative_offdiag_max_abs":float(np.max(np.abs(neg))) if neg.size else 0.0,"offdiagonals_nonnegative":bool(np.all(neg >= -1e-13))},"targets":target_out,"endpoint_xy_map_check":endcheck,"moment_volume_average_check":moments,"interpretation":"Positive edge masses and E=(-1,+1)/ds give a conservative graph baseline with nonnegative off-diagonals and nonpositive energy. It may add transverse diffusion; do not recommend launching on this control alone."}
    OUT.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__": main()
