"""Independent checks of the saved direct-FCI weak operators."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from scipy import sparse

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CASE = ROOT / "prototype_runs" / "hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_conservative_quadratic_t25_20260913"
HIST = CASE / "history.npz"
HOST = HERE.parent / "metric_cache_32" / "angular_rlp_host_85832e63967cf29a96d27b10.npz"
G_PATH = HERE / "G_direct32.npz"; G0_PATH = HERE / "G0_direct32.npz"; W_PATH = HERE / "W_direct32.npz"
OUT = HERE / "independent_direct_check.json"; CHI = 0.1; NNEAR = 32


def load(path):
    with np.load(path, allow_pickle=True) as z: return {k: np.asarray(z[k]).copy() for k in z.files}


def sha(path):
    h = hashlib.sha256(); h.update(path.read_bytes()); return h.hexdigest()


def endpoint_fields(hist, d):
    names = hist["fci_map_field_names"].tolist(); f = hist["fci_map_fields"]
    return f[..., names.index(d+"_endpoint_x")].ravel(), f[..., names.index(d+"_endpoint_y")].ravel()


def main():
    hist, host = load(HIST), load(HOST); shape = tuple(int(x) for x in host["shape"]); nr, nt, nz = shape; n = int(np.prod(shape))
    G, G0 = sparse.load_npz(G_PATH).tocsr(), sparse.load_npz(G0_PATH).tocsr(); wd = load(W_PATH)
    rows = wd["rows"].astype(int); direction = wd["direction"].astype(str); ds = wd["ds"].astype(float); W = wd["W"].astype(float); owner_ids = wd["owner_ids"].astype(int); Mo = wd["owner_volume"].astype(float); no = owner_ids.size
    aggregate = host["topology_aggregate_id"].ravel().astype(int); active = host["topology_is_active_owner"].ravel().astype(bool); active_ids = np.flatnonzero(active)
    lookup = {int(v): i for i, v in enumerate(owner_ids)}; slot = np.asarray([lookup[int(v)] for v in aggregate])
    agg_c = host["host_aggregate_chart_centroid"].reshape(-1, 3)[owner_ids]; agg_s = host["host_aggregate_chart_second_moment"].reshape(-1, 3, 3)[owner_ids]
    maps = {str(k): hist["fci_map_fields"][..., i].ravel() for i,k in enumerate(hist["fci_map_field_names"].tolist())}
    # Saved rows are ordered forward/backward per source.  Verify their masses
    # against the stated formula, independently of the saved G construction.
    q = 1.0 / hist["magnetic_field"].ravel()[owner_ids][slot]; rawv = host["host_raw_volume"].ravel(); b = 1.0/q
    qface = np.empty(rows.size); formula_w = np.empty(rows.size)
    for d in ("forward", "backward"):
        m = direction == d; x = maps[d+"_x"]; y = maps[d+"_y"]; i = np.floor(x).astype(int); j = np.floor(y).astype(int) % nt; fx = x-np.floor(x); fy = y-np.floor(y); k = (np.arange(n)%nz + (1 if d=="forward" else -1))%nz
        i0,i1=i,i+1; j0,j1=j,(j+1)%nt; ng0=i0<0; ng1=i1<0; i0=np.where(ng0,-i0-1,i0); i1=np.where(ng1,-i1-1,i1); j0=np.where(ng0,(j0+nt//2)%nt,j0); j1=np.where(ng0,(j1+nt//2)%nt,j1); j01=np.where(ng1,(j+nt//2)%nt,j); j11=np.where(ng1,((j+1)%nt+nt//2)%nt,(j+1)%nt)
        flat=lambda a,bb,c:(a*nt+bb)*nz+c; ids=np.column_stack((flat(i0,j0,k),flat(i0,j1,k),flat(i1,j01,k),flat(i1,j11,k))); a=np.column_stack(((1-fx)*(1-fy),(1-fx)*fy,fx*(1-fy),fx*fy)); ids=np.where(np.isfinite(ids),ids,0)
        for qrow, r in enumerate(rows[m]):
            if direction[m][qrow] != d: raise RuntimeError("direction indexing failure")
            qface[np.flatnonzero(m)[qrow]] = .5*(q[r] + np.sum(a[r]*q[ids[r]]))
        idx=np.flatnonzero(m); leg=maps[d+"_length"][rows[m]]; formula_w[idx]=.5*rawv[rows[m]]*b[rows[m]]*(2*leg/(maps["forward_length"][rows[m]]+maps["backward_length"][rows[m]]))*qface[idx]
    mass_err=float(np.max(np.abs(formula_w-W))); mass_rel=float(mass_err/max(np.max(np.abs(W)),1e-300))
    # Polynomial reproduction against exact aggregate moments and traced endpoint.
    ugrid, thgrid = hist["u"], hist["theta"]
    raw_i, raw_j, _ = np.unravel_index(rows, shape)
    source_x = ugrid[raw_i] * np.cos(thgrid[raw_j]); source_y = ugrid[raw_i] * np.sin(thgrid[raw_j])
    polys=[np.ones(no),agg_c[:,0],agg_c[:,1],agg_s[:,0,0]+agg_c[:,0]**2,agg_s[:,0,1]+agg_c[:,0]*agg_c[:,1],agg_s[:,1,1]+agg_c[:,1]**2]
    reproduction={}
    for pidx,p in enumerate(polys):
        vals=np.asarray(G@p).ravel(); expected=np.empty(rows.size)
        for d in ("forward","backward"):
            m=direction==d; eu,et=endpoint_fields(hist,d); ex=eu[rows[m]]*np.cos(et[rows[m]]); ey=eu[rows[m]]*np.sin(et[rows[m]]); ifield=[1,ex,ey,ex*ex,ex*ey,ey*ey][pidx]; sfield=[np.ones(np.count_nonzero(m)),source_x[m],source_y[m],source_x[m]**2,source_x[m]*source_y[m],source_y[m]**2][pidx]; expected[m]=(ifield-sfield)/ds[m]
        reproduction[str(pidx)]={"max_abs_error":float(np.max(np.abs(vals-expected))),"rms_error":float(np.sqrt(np.mean((vals-expected)**2)))}
    MoA = -G.T @ sparse.diags(W) @ G; A = sparse.diags(1/Mo) @ MoA; mixed = sparse.diags(1/Mo) @ (-G0.T @ sparse.diags(W) @ G)
    ones=np.ones(no); const=float(np.max(np.abs(A@ones))); conservation=float(np.max(np.abs(A.T@Mo)))
    rng=np.random.default_rng(20260913); z=rng.normal(size=no); en=float(z@(Mo*(A@z))); enf=-float(np.sum(W*(G@z)**2))
    targets={"(3,12,12)":(3,12,12),"(1,0,15)":(1,0,15),"(2,24,14)":(2,24,14),"(6,12,16)":(6,12,16)}; target_o={k:int(slot[np.ravel_multi_index(v,shape)]) for k,v in targets.items()}
    times_out={}; worst=None
    for ti,t in enumerate(hist["times"]):
        if float(t) not in (0.,3.5,10.5): continue
        ov=hist["Te"][ti].ravel()[owner_ids]; rhs=CHI*(A@ov); core=(owner_ids//(nt*nz)<=8); cold=np.where((ov-1<=1e-12)&core&(rhs< -1e-10))[0]
        if cold.size and float(t)==0.:
            q0=int(cold[np.argmin(rhs[cold])]); worst={"owner":q0,"coordinate":[int(x) for x in np.unravel_index(owner_ids[q0],shape)],"delta":float(ov[q0]-1),"rhs_chi":float(rhs[q0])}
        times_out[str(float(t))]={"cold_negative_count":int(cold.size),"minimum_core_rhs_chi":float(np.min(rhs[core])),"target_rhs":{k:float(rhs[o]) for k,o in target_o.items()}}
    target_rows={}
    for k,o in target_o.items():
        row=A.getrow(o).toarray().ravel(); mrow=mixed.getrow(o).toarray().ravel(); off=row.copy(); off[o]=0
        target_rows[k]={"owner":o,"negative_offdiag_count":int(np.count_nonzero(off< -1e-13)),"most_negative_offdiag":float(np.min(off)),"direct_fit_rhs":{},"mixed_return_rhs":{}}
        for t in (0.,3.5,10.5):
            ti=int(np.argmin(np.abs(hist["times"]-t))); ov=hist["Te"][ti].ravel()[owner_ids]
            target_rows[k]["direct_fit_rhs"][str(t)]=float(CHI*row@ov); target_rows[k]["mixed_return_rhs"][str(t)]=float(CHI*mrow@ov)
    # Exact one-donor counterexample for any negative off-diagonal entry.
    witness=None
    best_pair=None
    for name,o in target_o.items():
        rr=A.getrow(o).toarray().ravel(); rr[o]=0.0; d=int(np.argmin(rr))
        if best_pair is None or rr[d] < best_pair[0]: best_pair=(float(rr[d]),o,d)
    if best_pair is not None and best_pair[0] < -1e-13:
        value,row_owner,donor=best_pair; witness={"row":int(row_owner),"donor":int(donor),"matrix_value":value,"initial_owner_value":0.0,"donor_value":1.0,"rhs_chi":float(CHI*value),"target_row":True}
    # Coverage audit for excluded source rows: nearest 32 aggregate centroids
    # on source and actual traced endpoint planes, counting target membership.
    plane=[np.flatnonzero(np.asarray(np.unravel_index(owner_ids,shape))[2]==k) for k in range(nz)]; excluded=np.setdiff1d(np.arange(n),np.unique(rows)); coverage={k:0 for k in list(target_o)+(["worst_cold"] if worst else [])}; endpoint_u={d:endpoint_fields(hist,d)[0] for d in ('forward','backward')}; endpoint_t={d:endpoint_fields(hist,d)[1] for d in ('forward','backward')}
    for r in excluded:
        i,j,k=np.unravel_index(r,shape); sx,sy=ugrid[i]*np.cos(thgrid[j]),ugrid[i]*np.sin(thgrid[j])
        for d in ('forward','backward'):
            pl=(k+(1 if d=='forward' else -1))%nz; ex,ey=endpoint_u[d][r]*np.cos(endpoint_t[d][r]),endpoint_u[d][r]*np.sin(endpoint_t[d][r]); cand=[]
            for source_plane,cx,cy in ((k,sx,sy),(pl,ex,ey)):
                c=plane[source_plane]; cand.extend(c[np.argsort((agg_c[c,0]-cx)**2+(agg_c[c,1]-cy)**2)[:NNEAR]].tolist())
            for name,o in target_o.items(): coverage[name]+=int(o in cand)
            if worst: coverage["worst_cold"]+=int(worst["owner"] in cand)
    report={"provenance":{"hashes":{"history":sha(HIST),"host":sha(HOST),"G":sha(G_PATH),"G0":sha(G0_PATH),"W":sha(W_PATH)}},"checks":{"saved_W_formula_max_abs":mass_err,"saved_W_formula_max_rel":mass_rel,"constant_max_abs":const,"weighted_conservation_max_abs":conservation,"random_energy":en,"factorized_energy":enf,"energy_identity_abs_error":abs(en-enf),"energy_nonpositive":bool(en<=1e-11),"polynomial_reproduction":reproduction},"targets":target_rows,"time_actions":times_out,"worst_cold_core_negative":worst,"one_donor_negative_witness":witness,"excluded_source_coverage":coverage,"configuration":{"G_shape":list(G.shape),"valid_directed_rows":int(G.shape[0]),"nearest_aggregate_donors":NNEAR,"chi":CHI,"full_rhs_operator":"-Mo^-1 G.T diag(W) G","mixed_operator":"-Mo^-1 G0.T diag(W) G","target_gate":"negative cold-core rate below -1e-10 or target negative off-diagonal fails"},"interpretation":"This checker validates the saved direct operator and its mixed return against an independent mass, polynomial, conservation, energy, target, and excluded-row coverage audit. It does not launch a simulation."}
    failed = worst is not None or any(v["negative_offdiag_count"] for v in target_rows.values())
    report["gate_failed"] = bool(failed)
    OUT.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
    print(json.dumps(report,indent=2,sort_keys=True))
    # Gate failure is the scientific result for this saved operator; retain
    # exit success so the JSON remains the review artifact.


if __name__ == "__main__": main()
