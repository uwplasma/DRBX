"""Straight-field separation of the existing direct-fit gradient and dual.

Research probe only. For a straight periodic field the original two-plane
nine-column fit factors as G=S D_eta. The exact midpoint finite-difference
factor in eta is removed from all reported errors. Thus S tests the gradient,
Mo^-1 S.T Mf tests the divergence, and Mo^-1 S.T Mf S tests their composition.
No metric/tracing interpolation or radial physical-wall flux is involved.
"""
import json
from pathlib import Path
import numpy as np
from scipy import sparse
from scipy.spatial import cKDTree


def raw_geometry(n):
    i,j=np.indices((n,n)); a=i.ravel()/n; b=(i.ravel()+1)/n
    lo=j.ravel()*2*np.pi/n; hi=(j.ravel()+1)*2*np.pi/n; dt=hi-lo
    v=(b*b-a*a)*dt/2
    r=2*(b**3-a**3)/(3*(b*b-a*a)); r2=(b**4-a**4)/(2*(b*b-a*a))
    c=np.column_stack((r*(np.sin(hi)-np.sin(lo))/dt,r*(np.cos(lo)-np.cos(hi))/dt))
    m=np.empty((n*n,2,2)); trig=(np.sin(2*hi)-np.sin(2*lo))/(4*dt)
    m[:,0,0]=r2*(.5+trig); m[:,1,1]=r2*(.5-trig)
    m[:,0,1]=m[:,1,0]=r2*(np.cos(2*lo)-np.cos(2*hi))/(4*dt)
    q=2**np.floor(np.log2(np.maximum(1,n/np.maximum(4,1.5*(np.arange(n)+.5))))).astype(int);q[0]=n
    owner=i.ravel()*n+(j.ravel()//q[i.ravel()])*q[i.ravel()]
    ids,slot=np.unique(owner,return_inverse=True); nv=len(ids)
    V=np.bincount(slot,weights=v,minlength=nv)
    C=np.column_stack([np.bincount(slot,weights=v*c[:,k],minlength=nv)/V for k in range(2)])
    M=np.stack([np.bincount(slot,weights=v*m[:,k,l],minlength=nv)/V for k in range(2) for l in range(2)],axis=1).reshape(nv,2,2)
    point=np.column_stack(((a+b)/2*np.cos((lo+hi)/2),(a+b)/2*np.sin((lo+hi)/2)))
    return v,c,m,ids,slot,V,C,M,point,q


def run(n):
    v,c,m,ids,slot,V,C,M,point,q=raw_geometry(n); central=M-C[:,:,None]*C[:,None,:]
    tree=cKDTree(C); _,donors=tree.query(point,k=32); vals=[]; residual=0.; anti=0.; condition=0.
    for p,ix in zip(point,donors):
        d=C[ix]-p; scale=np.maximum(np.sqrt(np.mean(d*d,axis=0)),1e-8); x=d/scale
        raw=(central[ix]+d[:,:,None]*d[:,None,:])/scale[None,:,None]/scale[None,None,:]
        x=np.tile(x,(2,1)); raw=np.tile(raw,(2,1,1)); z=np.repeat([-.5,.5],32)
        B=np.column_stack((np.ones(64),x[:,0],x[:,1],raw[:,0,0],raw[:,0,1],raw[:,1,1],z,z*x[:,0],z*x[:,1]))
        U,s,Vh=np.linalg.svd(B,full_matrices=False); target=np.eye(9)[6]
        w=(Vh.T @ ((U.T)/s[:,None]))[6]
        assert s[-1]>s[0]*1e-12
        residual=max(residual,float(np.max(abs(w@B-target)))); condition=max(condition,float(s[0]/s[-1]))
        anti=max(anti,float(np.max(abs(w[:32]+w[32:])))); vals.extend(w[32:])
    S=sparse.csr_matrix((vals,(np.repeat(np.arange(n*n),32),donors.ravel())),shape=(n*n,len(ids)))
    P=sparse.csr_matrix((np.ones(n*n),(np.arange(n*n),slot)),shape=S.shape)
    plain=q[np.arange(n*n)//n]==1
    Sp=(sparse.diags((~plain).astype(float))@S+sparse.diags(plain.astype(float))@P).tocsr()
    masks={'all':np.ones(len(ids),bool),'axis':ids//n==0,'merged':q[ids//n]>1,'ordinary':q[ids//n]==1}
    changed=np.r_[False,q[1:]!=q[:-1]]|np.r_[q[1:]!=q[:-1],False]
    masks['transition']=changed[ids//n]
    fields={'1':(np.ones(len(ids)),np.ones(n*n),np.ones(n*n)),
            'X':(C[:,0],point[:,0],c[:,0]),'Y':(C[:,1],point[:,1],c[:,1]),
            'r2':(M[:,0,0]+M[:,1,1],np.sum(point*point,axis=1),m[:,0,0]+m[:,1,1])}
    def error(actual,reference,mass,mask):
        denominator=np.sum(mass[mask]*reference[mask]**2)
        if denominator < 1e-24*np.sum(mass[mask])*max(float(np.max(abs(reference)))**2,1e-300):
            return None  # Relative error undefined for a zero axis-average mode.
        return float(np.sqrt(np.sum(mass[mask]*(actual[mask]-reference[mask])**2)/denominator))
    results={}
    for name,(f,fp,fa) in fields.items():
        reconstructed=S@f; Dexact=np.asarray(S.T@(v*fp))/V; A=np.asarray(S.T@(v*reconstructed))/V
        results[name]={'gradient_relative_rms':error(reconstructed,fp,v,np.ones(n*n,bool)),
          'divergence_exact_point_flux':{k:error(Dexact,f,V,mask) for k,mask in masks.items()},
          'divergence_exact_raw_average_flux':{k:error(np.asarray(S.T@(v*fa))/V,f,V,mask) for k,mask in masks.items()},
          'assembled':{k:error(A,f,V,mask) for k,mask in masks.items()},
          'ordinary_volume_return':error(np.asarray(P.T@(v*fa))/V,f,V,masks['all']),
          'keep_q1_identity_assembled':{k:error(np.asarray(Sp.T@(v*(Sp@f)))/V,f,V,mask) for k,mask in masks.items()}}
    gain=np.asarray(S.T@v)/V; order=np.argsort(abs(gain-1))[::-1][:4]
    assert residual<1e-11 and anti<1e-11 and max(abs(S@np.ones(len(ids))-1))<1e-11
    assert results['1']['ordinary_volume_return']<1e-12
    assert max(abs(np.asarray(P.T@v)/V-1))<1e-12
    assert results['X']['gradient_relative_rms']<1e-11
    return {'n':n,'q':q.tolist(),'max_condition':condition,'basis_residual':residual,'plane_antisymmetry_error':anti,
      'constant_plane_divergence_gain_range':[float(gain.min()),float(gain.max())],
      'worst_gain_owners':[{'ij':[int(ids[o]//n),int(ids[o]%n)],'gain':float(gain[o])} for o in order], 'fields':results}


if __name__=='__main__':
    rows=[run(n) for n in (16,32,64)]
    out={'scope':'Straight periodic field, B=1, exact annular-sector physical moments; same joint nine-column direct-fit construction. Eta finite-difference factor divided out. No run launched.',
         'rows':rows}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    for r in rows:
        print(json.dumps({'n':r['n'],'gradient_1':r['fields']['1']['gradient_relative_rms'],'divergence_1':r['fields']['1']['divergence_exact_point_flux'],'gain_range':r['constant_plane_divergence_gain_range'],'gradient_X':r['fields']['X']['gradient_relative_rms'],'divergence_X':r['fields']['X']['divergence_exact_point_flux']}))
