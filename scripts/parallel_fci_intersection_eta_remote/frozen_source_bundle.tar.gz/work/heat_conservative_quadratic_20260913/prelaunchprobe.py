"""Check a prepared conservative-quadratic case set without launching work."""
from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[1]
CONTROLS = {"paired": "conservative-quadratic", "volume": "conservative-quadratic-volume"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--require-prepared", action="store_true")
    opts = parser.parse_args()
    driver = ROOT / "run_hsx_sanity.py"
    if not driver.exists():
        raise SystemExit(f"missing driver: {driver}")
    ast.parse(driver.read_text(), filename=str(driver))
    driver_text = driver.read_text()
    missing = [value for value in CONTROLS.values() if value not in driver_text]
    if missing:
        raise SystemExit(f"driver lacks reviewed reconstruction flags: {missing}")
    manifest = RUN / "cases.json"
    if not manifest.exists():
        if opts.require_prepared:
            raise SystemExit(f"missing prepared manifest: {manifest}")
        print(json.dumps({"prepared": False, "driver": str(driver), "status": "ready-for-prepare"}, indent=2))
        return
    cases = json.loads(manifest.read_text())
    expected = {(resolution, control) for resolution in (32, 64) for control in CONTROLS}
    actual = {(int(case["resolution"]), str(case["control"])) for case in cases}
    if actual != expected or len(cases) != len(expected):
        raise SystemExit(f"case control matrix mismatch: expected {sorted(expected)}, got {sorted(actual)}")
    outputs = [Path(case["output"]).resolve() for case in cases if case.get("output") is not None]
    if len(set(outputs)) != len(outputs):
        raise SystemExit("duplicate full output paths in cases.json")
    checks = []
    for case in cases:
        for key in ("baseline", "metric_file", "host_reference", "source"):
            if not Path(case[key]).exists():
                raise SystemExit(f"missing {key} for {case['resolution']} {case['control']}: {case[key]}")
        if case["conduction_reconstruction"] != CONTROLS[case["control"]]:
            raise SystemExit(f"flag mismatch for case {case['resolution']} {case['control']}")
        output_value = case.get("output")
        if output_value is not None:
            output = Path(str(output_value)).resolve()
            forbidden = [name for name in ("process_status.json", "history.npz", "metadata.json") if (output / name).exists()]
            if forbidden:
                raise SystemExit(f"full output already contains run artifacts: {output} {forbidden}")
            output_text = str(output)
        else:
            output_text = "smoke-only"
        checks.append({"resolution": case["resolution"], "control": case["control"], "output": output_text, "status": "clear"})
    print(json.dumps({"prepared": True, "status": "launch-ready", "checks": checks}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
