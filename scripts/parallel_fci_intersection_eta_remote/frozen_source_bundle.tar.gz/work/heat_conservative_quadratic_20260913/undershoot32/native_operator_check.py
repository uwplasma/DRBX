"""Independent check of the saved mapped FCI sparse operator.

This is deliberately separate from ``operator_audit.py``.  It rebuilds the
saved bilinear endpoint interpolation and calls the frozen native operator
with a small layout-only ``LocalFciGeometry3D`` test double.  The resulting
native values are compared with an independently assembled sparse matrix for
random and reconstructed fields; no geometry is rebuilt and no simulation is
run.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import sys

os.environ.setdefault("JAX_ENABLE_X64", "1")

import jax.numpy as jnp
import numpy as np
from scipy import sparse

RUN = Path(__file__).resolve().parents[1]
ROOT = RUN.parents[1]
SOURCE = RUN / "source" / "DRBX" / "src"
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))

from drbx.geometry import HaloLayout3D, LocalFciGeometry3D, StencilBuilderContext  # noqa: E402
from drbx.native import fci_operators  # noqa: E402
from drbx.native.fci_boundaries import LocalStencil1D  # noqa: E402

if not Path(fci_operators.__file__).resolve().is_relative_to(SOURCE):
    raise RuntimeError("native operator import escaped the frozen source snapshot")

CASE = ROOT / "prototype_runs" / "hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_conservative_quadratic_t25_20260913"
HOST = RUN / "metric_cache_32" / "angular_rlp_host_85832e63967cf29a96d27b10.npz"
H_PATH = RUN / "host_H_32.npz"
OUT = RUN / "undershoot32" / "native_operator_check.json"


def _archive(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=True) as payload:
        return {name: np.asarray(payload[name]).copy() for name in payload.files}


def _maps(history: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
    names = [str(name) for name in history["fci_map_field_names"].tolist()]
    fields = history["fci_map_fields"]
    return {name: np.asarray(fields[..., index], dtype=np.float64) for index, name in enumerate(names)}


def _owner_projection(host: dict[str, np.ndarray], raw_volume: np.ndarray) -> tuple[sparse.csr_matrix, np.ndarray, np.ndarray]:
    active = np.asarray(host["topology_is_active_owner"], dtype=bool).ravel()
    aggregate = np.asarray(host["topology_aggregate_id"], dtype=np.int64).ravel()
    active_ids = np.flatnonzero(active)
    if np.array_equal(active_ids, aggregate[active_ids]):
        owner_ids = active_ids
    else:
        owner_ids = np.sort(np.unique(aggregate[active]))
    lookup = {int(value): index for index, value in enumerate(owner_ids.tolist())}
    slots = np.asarray([lookup[int(value)] for value in aggregate], dtype=np.int64)
    rows = np.arange(raw_volume.size, dtype=np.int64)
    projection = sparse.coo_matrix(
        (np.ones(raw_volume.size), (rows, slots)),
        shape=(raw_volume.size, owner_ids.size),
    ).tocsr()
    return projection, slots, owner_ids


def _endpoint_interpolation(maps: dict[str, np.ndarray], shape: tuple[int, int, int], direction: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return mapped endpoint IDs, bilinear weights, and valid-row mask.

    The negative radial nodes use the same half-turn axis reflection as the
    native map filler.  This retains axis rows in the check while excluding
    only rows whose map is an outer-wall/invalid endpoint.
    """

    size = int(np.prod(shape))
    x = np.asarray(maps[f"{direction}_x"], dtype=np.float64).ravel()
    y = np.asarray(maps[f"{direction}_y"], dtype=np.float64).ravel()
    boundary = np.asarray(maps[f"{direction}_boundary"], dtype=bool).ravel()
    i = np.floor(np.nan_to_num(x, nan=0.0)).astype(np.int64)
    j = np.floor(np.nan_to_num(y, nan=0.0)).astype(np.int64) % shape[1]
    valid = np.isfinite(x) & np.isfinite(y) & ~boundary
    valid &= (i >= -shape[0]) & (i < shape[0] - 1)
    fx = np.nan_to_num(x, nan=0.0) - np.floor(np.nan_to_num(x, nan=0.0))
    fy = np.nan_to_num(y, nan=0.0) - np.floor(np.nan_to_num(y, nan=0.0))
    i0, i1 = i, i + 1
    j0, j1 = j, (j + 1) % shape[1]
    neg0, neg1 = i0 < 0, i1 < 0
    i0 = np.where(neg0, -i0 - 1, i0)
    i1 = np.where(neg1, -i1 - 1, i1)
    j0 = np.where(neg0, (j0 + shape[1] // 2) % shape[1], j0)
    j1 = np.where(neg0, (j1 + shape[1] // 2) % shape[1], j1)
    j0_1 = np.where(neg1, (j + shape[1] // 2) % shape[1], j)
    j1_1 = np.where(neg1, ((j + 1) % shape[1] + shape[1] // 2) % shape[1], (j + 1) % shape[1])
    k0 = np.arange(size, dtype=np.int64) % shape[2]
    k = (k0 + (1 if direction == "forward" else -1)) % shape[2]
    flat = lambda ii, jj, kk: (ii * shape[1] + jj) * shape[2] + kk
    ids = np.column_stack((flat(i0, j0, k), flat(i0, j1, k), flat(i1, j0_1, k), flat(i1, j1_1, k)))
    weights = np.column_stack(((1.0 - fx) * (1.0 - fy), (1.0 - fx) * fy, fx * (1.0 - fy), fx * fy))
    if np.any(ids[valid] < 0) or np.any(ids[valid] >= size):
        raise RuntimeError("axis-reflected endpoint interpolation escaped the fine grid")
    # Invalid/outer-wall rows are replaced by their center value by the
    # native builder, so their placeholder IDs are never dereferenced.
    ids = np.where(valid[:, None], ids, 0)
    return ids, weights, valid


def _endpoint_values(field: np.ndarray, ids: np.ndarray, weights: np.ndarray, valid: np.ndarray) -> np.ndarray:
    values = np.sum(weights * np.asarray(field).ravel()[ids], axis=1)
    center = np.asarray(field).ravel()
    return np.where(valid, values, center)


def _stencil(field: np.ndarray, maps: dict[str, np.ndarray], shape: tuple[int, int, int], endpoints: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]], *, q_field: np.ndarray | None = None) -> LocalStencil1D:
    values = np.asarray(field if q_field is None else q_field, dtype=np.float64).reshape(shape)
    f_ids, f_weights, f_valid = endpoints["forward"]
    b_ids, b_weights, b_valid = endpoints["backward"]
    valid = f_valid & b_valid
    plus = _endpoint_values(values, f_ids, f_weights, f_valid).reshape(shape)
    minus = _endpoint_values(values, b_ids, b_weights, b_valid).reshape(shape)
    fp = np.maximum(np.asarray(maps["forward_length"], dtype=np.float64), 1.0e-30)
    bm = np.maximum(np.asarray(maps["backward_length"], dtype=np.float64), 1.0e-30)
    return LocalStencil1D(
        center=values,
        minus=np.where(valid.reshape(shape), minus, values),
        plus=np.where(valid.reshape(shape), plus, values),
        dx_min=np.where(valid.reshape(shape), bm, 1.0),
        dx_plus=np.where(valid.reshape(shape), fp, 1.0),
    )


def _sparse_operator(field_shape: tuple[int, int, int], endpoints, maps, q: np.ndarray, *, diffusivity: np.ndarray | None = None) -> sparse.csr_matrix:
    size = int(np.prod(field_shape))
    f_ids, f_weights, f_valid = endpoints["forward"]
    b_ids, b_weights, b_valid = endpoints["backward"]
    valid = f_valid & b_valid
    q = np.asarray(q, dtype=np.float64).ravel()
    k = np.ones(size, dtype=np.float64) if diffusivity is None else np.asarray(diffusivity, dtype=np.float64).ravel()
    fp = np.maximum(np.asarray(maps["forward_length"], dtype=np.float64).ravel(), 1.0e-30)
    bm = np.maximum(np.asarray(maps["backward_length"], dtype=np.float64).ravel(), 1.0e-30)
    b_center = 1.0 / np.maximum(q, 1.0e-30)
    q_plus = np.sum(f_weights * q[f_ids], axis=1)
    q_minus = np.sum(b_weights * q[b_ids], axis=1)
    b_plus = 1.0 / np.maximum(0.5 * (q + q_plus), 1.0e-30)
    b_minus = 1.0 / np.maximum(0.5 * (q + q_minus), 1.0e-30)
    k_plus = 0.5 * (k + np.sum(f_weights * k[f_ids], axis=1))
    k_minus = 0.5 * (k + np.sum(b_weights * k[b_ids], axis=1))
    factor = b_center * 2.0 / (fp + bm)
    c = factor * (-k_plus / (fp * b_plus) - k_minus / (bm * b_minus))
    cf = factor * k_plus / (fp * b_plus)
    cb = factor * k_minus / (bm * b_minus)
    rows = np.flatnonzero(valid)
    row_ids = np.repeat(rows, 9)
    cols = np.column_stack((rows, f_ids[rows], b_ids[rows])).reshape(-1)
    # Reorder coefficients to match [center, forward 4 nodes, backward 4 nodes].
    data = np.column_stack((c[rows], cf[rows, None] * f_weights[rows], cb[rows, None] * b_weights[rows])).reshape(-1)
    return sparse.coo_matrix((data, (row_ids, cols)), shape=(size, size)).tocsr()


def _native_apply(field: np.ndarray, maps, shape, endpoints, q: np.ndarray) -> np.ndarray:
    layout = HaloLayout3D(shape, 0)
    fake = object.__new__(LocalFciGeometry3D)
    object.__setattr__(fake, "layout", layout)
    object.__setattr__(fake, "active_cell_mask", None)
    context = StencilBuilderContext(layout)
    calls = {"count": 0}

    def builder(values, _geometry, _context, **_kwargs):
        index = calls["count"]
        calls["count"] += 1
        if index == 0:
            return _stencil(np.asarray(values), maps, shape, endpoints)
        if index == 1:
            return _stencil(np.ones(shape), maps, shape, endpoints)
        return _stencil(np.asarray(values), maps, shape, endpoints)

    return np.asarray(fci_operators.local_parallel_diffusion_fci_op(
        jnp.asarray(field.reshape(shape)), fake, context=context,
        diffusivity_halo_full=jnp.ones(shape, dtype=jnp.float64),
        inverse_b_halo_full=jnp.asarray(q.reshape(shape)),
        fci_stencil_builder=builder,
    )).ravel()


def main() -> None:
    host = _archive(HOST)
    history = _archive(CASE / "history.npz")
    shape = tuple(int(v) for v in host["shape"])
    size = int(np.prod(shape))
    raw_volume = np.asarray(host["host_raw_volume"], dtype=np.float64).ravel()
    projection, slots, owner_ids = _owner_projection(host, raw_volume)
    H = sparse.load_npz(H_PATH).tocsr()
    if H.shape != (size, owner_ids.size):
        raise RuntimeError(f"H shape {H.shape} does not match {(size, owner_ids.size)}")
    maps = _maps(history)
    endpoints = {direction: _endpoint_interpolation(maps, shape, direction) for direction in ("forward", "backward")}
    valid = endpoints["forward"][2] & endpoints["backward"][2]
    q_owner = 1.0 / np.asarray(history["magnetic_field"], dtype=np.float64).ravel()[owner_ids]
    q = np.asarray(projection @ q_owner).ravel()
    sparse_l = _sparse_operator(shape, endpoints, maps, q)
    # The saved owner slots already carry the owner-injected initial state.
    # Applying P.T here would sum every alias into its owner and inflate the
    # field by the aggregate multiplicity.
    owner_initial = np.asarray(history["Te"][0], dtype=np.float64).ravel()[owner_ids]
    h_initial = np.asarray(H @ owner_initial).ravel()
    rng = np.random.default_rng(20260913)
    random_field = rng.normal(size=size)
    checks = {}
    for name, field in (("random", random_field), ("H_initial", h_initial), ("constant", np.ones(size))):
        native = _native_apply(field, maps, shape, endpoints, q)
        expected = np.asarray(sparse_l @ field).ravel()
        error = float(np.max(np.abs(native[valid] - expected[valid]))) if np.any(valid) else 0.0
        checks[name] = {"max_abs_error_on_covered_rows": error, "native_max_abs": float(np.max(np.abs(native))), "sparse_max_abs": float(np.max(np.abs(expected))), "native_finite": bool(np.all(np.isfinite(native))), "sparse_finite": bool(np.all(np.isfinite(expected)))}
        if error > 2.0e-12:
            raise RuntimeError(f"native/sparse mismatch for {name}: {error}")
    offdiag = sparse_l - sparse.diags(sparse_l.diagonal())
    offdiag_data = np.asarray(offdiag.data)
    negative_offdiag = offdiag_data[offdiag_data < -2.0e-14]
    weight_errors = {direction: float(np.max(np.abs(np.sum(endpoints[direction][1][valid], axis=1) - 1.0))) for direction in endpoints}
    saved_matrix_path = RUN / "undershoot32" / "L_native_interior_32.npz"
    saved_matrix_check = {"available": saved_matrix_path.is_file(), "path": str(saved_matrix_path)}
    if saved_matrix_path.is_file():
        saved_l = sparse.load_npz(saved_matrix_path).tocsr()
        if saved_l.shape != sparse_l.shape:
            raise RuntimeError(f"saved audit L shape {saved_l.shape} does not match {sparse_l.shape}")
        matrix_delta = (sparse_l - saved_l).tocsr()
        saved_matrix_check.update({"shape": list(saved_l.shape), "nnz": int(saved_l.nnz), "difference_nnz": int(matrix_delta.nnz), "max_abs_difference": float(np.max(np.abs(matrix_delta.data))) if matrix_delta.nnz else 0.0})
        if matrix_delta.nnz and float(np.max(np.abs(matrix_delta.data))) > 2.0e-12:
            raise RuntimeError("independent sparse L does not reproduce saved audit L")
    report = {
        "provenance": {"frozen_source": str(SOURCE), "native_module": str(Path(fci_operators.__file__).resolve()), "history": str(CASE / "history.npz"), "host_payload": str(HOST), "H_matrix": str(H_PATH)},
        "configuration": {"shape": list(shape), "jax_enable_x64": True, "scope": "saved mapped endpoint interpolation and native arithmetic; no geometry rebuild or simulation", "covered_rows": int(np.count_nonzero(valid)), "masked_rows": int(size - np.count_nonzero(valid)), "axis_reflection_rows": int(np.count_nonzero(valid & ((np.floor(maps["forward_x"]).ravel() < 0) | (np.floor(maps["backward_x"]).ravel() < 0))))},
        "validation": {"fields": checks, "endpoint_weight_max_abs_sum_error": weight_errors, "constant_rows_zero": checks["constant"]["native_max_abs"] < 2.0e-12, "saved_audit_matrix": saved_matrix_check, "fine_sparse_offdiag_min": float(np.min(offdiag_data)) if offdiag_data.size else 0.0, "fine_sparse_negative_offdiag_count": int(negative_offdiag.size), "sparse_L_nnz": int(sparse_l.nnz)},
        "interpretation": "The frozen native mapped diffusion arithmetic agrees with an independently assembled sparse operator for random and H-reconstructed initial fields on all covered two-sided rows. Axis-reflected interpolation rows are included; outer-wall/invalid rows are excluded from the comparison.",
    }
    OUT.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
