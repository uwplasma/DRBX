"""Bounded operator audit for the completed 32^3 conservative run.

The audit is an interior, saved-field calculation.  It rebuilds the native
mapped FCI second derivative from the frozen map fields, including scalar
even-axis reflection, then composes it with the saved conservative
prolongation H and its mass adjoint.  Outer and wall closure rows are excluded
explicitly; no trajectory is integrated.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from scipy import sparse
from scipy.sparse import save_npz

RUN = Path(__file__).resolve().parents[1]
ROOT = RUN.parents[1]
SOURCE = RUN / "source" / "DRBX" / "src"
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))

# Importing the frozen native module is a provenance guard.  The sparse
# construction below is the algebra in local_parallel_diffusion_fci_op for
# valid interior rows, with its prepared inverse-B owner-slot convention.
import drbx.native.fci_operators as native_fci_operators  # noqa: E402
import jax.numpy as jnp  # noqa: E402
from drbx.geometry import (  # noqa: E402
    HaloLayout3D,
    LocalFciGeometry3D,
    LocalFciStencilBuilder,
    StencilBuilderContext,
)
from drbx.native.fci_boundaries import LocalStencil1D  # noqa: E402

if not Path(native_fci_operators.__file__).resolve().is_relative_to(SOURCE):
    raise RuntimeError("native FCI operator escaped frozen source snapshot")

CASE = Path(
    ROOT
    / "prototype_runs"
    / "hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_conservative_quadratic_t25_20260913"
)
BASELINE = ROOT / "prototype_runs" / "hsx_parallel_heat_spot_qhs_1T_main_only_32_t25"
HOST = RUN / "metric_cache_32" / "angular_rlp_host_85832e63967cf29a96d27b10.npz"
H_PATH = RUN / "host_H_32.npz"
OUT = RUN / "undershoot32"
OUT.mkdir(parents=True, exist_ok=True)
CHI_PARALLEL = 0.1


def native_arithmetic_validation() -> dict[str, object]:
    """Check the frozen native routine against its scalar stencil formula.

    This deliberately uses a small layout-only geometry test double and an
    injected stencil builder.  It validates the arithmetic and inverse-B
    branch without pretending to validate halo/map closure construction.
    """
    shape = (3, 4, 5)
    layout = HaloLayout3D(shape, 0)
    fake = object.__new__(LocalFciGeometry3D)
    object.__setattr__(fake, "layout", layout)
    object.__setattr__(fake, "active_cell_mask", None)
    context = StencilBuilderContext(layout)
    rng = np.random.default_rng(20260913)
    center = jnp.asarray(rng.normal(size=shape), dtype=jnp.float64)
    minus = jnp.asarray(rng.normal(size=shape), dtype=jnp.float64)
    plus = jnp.asarray(rng.normal(size=shape), dtype=jnp.float64)
    dm = jnp.asarray(0.4 + rng.random(size=shape), dtype=jnp.float64)
    dp = jnp.asarray(0.4 + rng.random(size=shape), dtype=jnp.float64)
    q = jnp.asarray(0.8 + rng.random(size=shape), dtype=jnp.float64)
    qminus = jnp.asarray(0.8 + rng.random(size=shape), dtype=jnp.float64)
    qplus = jnp.asarray(0.8 + rng.random(size=shape), dtype=jnp.float64)
    stencil = LocalStencil1D(center=center, minus=minus, plus=plus, dx_min=dm, dx_plus=dp)
    qstencil = LocalStencil1D(center=q, minus=qminus, plus=qplus, dx_min=dm, dx_plus=dp)
    unit_stencil = LocalStencil1D(center=jnp.ones(shape), minus=jnp.ones(shape), plus=jnp.ones(shape), dx_min=dm, dx_plus=dp)
    calls = {"count": 0}

    def build(_field: jnp.ndarray, _geometry: object, _context: object, **_kwargs: object) -> LocalStencil1D:
        index = calls["count"]
        calls["count"] += 1
        return (stencil, unit_stencil, qstencil)[min(index, 2)]

    builder = LocalFciStencilBuilder(build)
    native = native_fci_operators.local_parallel_diffusion_fci_op(
        field_halo_full=center,
        geometry=fake,
        context=context,
        diffusivity_halo_full=jnp.ones(shape, dtype=jnp.float64),
        inverse_b_halo_full=q,
        fci_stencil_builder=builder,
    )
    bcenter = 1.0 / q
    bminus = 1.0 / (0.5 * (q + qminus))
    bplus = 1.0 / (0.5 * (q + qplus))
    expected = bcenter * 2.0 * (
        (plus - center) / (dp * bplus) - (center - minus) / (dm * bminus)
    ) / (dm + dp)
    error = float(np.max(np.abs(np.asarray(native) - np.asarray(expected))))
    if error > 2.0e-13:
        raise RuntimeError(f"native arithmetic validation failed: {error}")
    return {"max_abs_error": error, "scope": "native arithmetic with injected LocalStencil1D; map/halo closure excluded"}


def archive(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=True) as z:
        return {key: np.asarray(z[key]).copy() for key in z.files}


def map_dict(history: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
    names = history["fci_map_field_names"].tolist()
    fields = history["fci_map_fields"]
    return {str(name): np.asarray(fields[..., i]) for i, name in enumerate(names)}


def compact_maps(host: dict[str, np.ndarray], raw_volume: np.ndarray) -> tuple[sparse.csr_matrix, sparse.csr_matrix, np.ndarray, np.ndarray, np.ndarray]:
    """Return raw-to-owner injection P, volume return R, owner slots/volumes."""
    nraw = raw_volume.size
    active_ids = np.flatnonzero(host["topology_is_active_owner"].ravel())
    if not np.array_equal(active_ids, np.asarray(host["topology_aggregate_id"].ravel()[active_ids])):
        # Aggregate IDs are normally owner flat IDs; retain an explicit map
        # for caches that use another global ID numbering.
        owner_ids = np.sort(np.unique(host["topology_aggregate_id"][host["topology_is_active_owner"]]))
    else:
        owner_ids = active_ids
    owner_lookup = {int(value): i for i, value in enumerate(owner_ids.tolist())}
    aggregate_id = host["topology_aggregate_id"].ravel().astype(np.int64)
    slot = np.asarray([owner_lookup[int(value)] for value in aggregate_id], dtype=np.int64)
    rows = np.arange(nraw, dtype=np.int64)
    P = sparse.coo_matrix((np.ones(nraw), (rows, slot)), shape=(nraw, owner_ids.size)).tocsr()
    owner_volume = np.bincount(slot, weights=raw_volume.ravel(), minlength=owner_ids.size)
    if np.any(owner_volume <= 0.0) or not np.all(np.isfinite(owner_volume)):
        raise RuntimeError("nonpositive/nonfinite owner volume")
    R = sparse.diags(1.0 / owner_volume).dot(P.T).dot(sparse.diags(raw_volume.ravel())).tocsr()
    return P, R, slot, owner_volume, owner_ids


def mapped_interpolation_rows(
    maps: dict[str, np.ndarray], shape: tuple[int, int, int], direction: str, rows: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return four-point target flat IDs/weights for each selected source row."""
    x = np.asarray(maps[direction + "_x"], dtype=float).ravel()[rows]
    y = np.asarray(maps[direction + "_y"], dtype=float).ravel()[rows]
    i = np.floor(np.nan_to_num(x, nan=0.0)).astype(np.int64)
    j = np.floor(np.nan_to_num(y, nan=0.0)).astype(np.int64) % shape[1]
    k0 = rows % shape[2]
    k = (k0 + (1 if direction == "forward" else -1)) % shape[2]
    fx = np.nan_to_num(x, nan=0.0) - np.floor(np.nan_to_num(x, nan=0.0))
    fy = np.nan_to_num(y, nan=0.0) - np.floor(np.nan_to_num(y, nan=0.0))
    jp = (j + 1) % shape[1]
    flat = lambda ii, jj, kk: (ii * shape[1] + jj) * shape[2] + kk
    # Match PolarAxisTopologyGhostFiller: each negative-radial ghost cell is
    # reflected with ii -> -ii-1 and receives a half-turn theta roll.  Apply
    # this independently to the two radial interpolation nodes.
    i0, i1 = i, i + 1
    base_j0, base_j1 = j, jp
    neg0, neg1 = i0 < 0, i1 < 0
    i0 = np.where(neg0, -i0 - 1, i0)
    i1 = np.where(neg1, -i1 - 1, i1)
    j0 = np.where(neg0, (base_j0 + shape[1] // 2) % shape[1], base_j0)
    j1 = np.where(neg0, (base_j1 + shape[1] // 2) % shape[1], base_j1)
    j0_1 = np.where(neg1, (base_j0 + shape[1] // 2) % shape[1], base_j0)
    j1_1 = np.where(neg1, (base_j1 + shape[1] // 2) % shape[1], base_j1)
    ids = np.column_stack((flat(i0, j0, k), flat(i0, j1, k), flat(i1, j0_1, k), flat(i1, j1_1, k)))
    weights = np.column_stack(((1.0 - fx) * (1.0 - fy), (1.0 - fx) * fy, fx * (1.0 - fy), fx * fy))
    if np.any(ids < 0) or np.any(ids >= int(np.prod(shape))):
        raise RuntimeError("axis-reflected interpolation node escaped fine grid")
    return ids, weights, x, y


def build_native_L(host: dict[str, np.ndarray], history: dict[str, np.ndarray], slot: np.ndarray, P: sparse.csr_matrix, owner_ids: np.ndarray) -> tuple[sparse.csr_matrix, dict[str, object]]:
    """Build the exact native interior mapped diffusion matrix on fine rows."""
    shape = tuple(int(v) for v in host["shape"])
    nraw = int(np.prod(shape))
    maps = map_dict(history)
    # RLP owner activity is a storage mask, not the native fine-domain mask.
    # The conservative driver prolongs aliases and then calls the native FCI
    # operator on every raw cell; only invalid/wall map rows are omitted here.
    rows_all = np.arange(nraw, dtype=np.int64)
    common = np.ones(rows_all.size, dtype=bool)
    invalid_reasons = {"axis_or_outer_endpoint": np.zeros(rows_all.size, dtype=bool), "physical_boundary": np.zeros(rows_all.size, dtype=bool)}
    for direction in ("forward", "backward"):
        x = np.asarray(maps[direction + "_x"], dtype=float).ravel()[rows_all]
        y = np.asarray(maps[direction + "_y"], dtype=float).ravel()[rows_all]
        valid = np.isfinite(x) & np.isfinite(y) & ~np.asarray(maps[direction + "_boundary"], dtype=bool).ravel()[rows_all]
        i = np.floor(np.nan_to_num(x, nan=0.0)).astype(np.int64)
        invalid_reasons["axis_or_outer_endpoint"] |= (i < -shape[0]) | (i >= shape[0] - 1)
        invalid_reasons["physical_boundary"] |= np.asarray(maps[direction + "_boundary"], dtype=bool).ravel()[rows_all]
        valid &= (i >= -shape[0]) & (i < shape[0] - 1)
        common &= valid
    rows = rows_all[common]
    # Prepared inverse-B follows _fci_prepare_inverse_b: q=1/B is injected
    # from active owner slots before native map interpolation.
    b = np.asarray(history["magnetic_field"], dtype=float).ravel()
    owner_b = b[owner_ids]
    if not np.all(np.isfinite(owner_b)) or np.any(owner_b <= 0.0):
        raise RuntimeError("invalid owner B field")
    qfine = np.asarray(P @ (1.0 / owner_b)).ravel()
    qcenter = qfine[rows]
    bcenter = 1.0 / qcenter
    fp = np.asarray(maps["forward_length"], dtype=float).ravel()[rows]
    fm = np.asarray(maps["backward_length"], dtype=float).ravel()[rows]
    if np.any(~np.isfinite(fp)) or np.any(~np.isfinite(fm)) or np.any(fp <= 0) or np.any(fm <= 0):
        raise RuntimeError("invalid native connection lengths")

    center_factor = bcenter * 2.0 / (fp + fm)
    # Center coefficient is minus the sum of both endpoint coefficients.
    fids, fw, _, _ = mapped_interpolation_rows(maps, shape, "forward", rows)
    bids, bw, _, _ = mapped_interpolation_rows(maps, shape, "backward", rows)
    fq = np.sum(fw * qfine[fids], axis=1)
    bq = np.sum(bw * qfine[bids], axis=1)
    cf = center_factor * (0.5 * (qcenter + fq)) / fp
    cb = center_factor * (0.5 * (qcenter + bq)) / fm
    source_ids = np.column_stack((rows, fids, bids)).ravel()
    source_values = np.column_stack((-(np.sum(cf[:, None] * fw, axis=1) + np.sum(cb[:, None] * bw, axis=1)), cf[:, None] * fw, cb[:, None] * bw)).ravel()
    source_rows = np.repeat(np.arange(rows.size, dtype=np.int64), 9)
    L_active = sparse.coo_matrix((source_values, (source_rows, source_ids)), shape=(rows.size, nraw)).tocsr()
    L = sparse.coo_matrix((L_active.data, (rows[L_active.nonzero()[0]], L_active.indices)), shape=(nraw, nraw)).tocsr()
    return L, {"fine_rows": int(nraw), "valid_two_sided_rows": int(rows.size), "masked_rows": int(nraw - rows.size), "axis_or_outer_endpoint_rows": int(np.count_nonzero(invalid_reasons["axis_or_outer_endpoint"])), "physical_boundary_rows": int(np.count_nonzero(invalid_reasons["physical_boundary"])), "formula": "native local_parallel_diffusion_fci_op interior mapped flux difference"}


def owner_target(slot: np.ndarray, shape: tuple[int, int, int], coord: tuple[int, int, int]) -> int:
    return int(slot[np.ravel_multi_index(coord, shape)])


def row_offdiag(matrix: sparse.csr_matrix, row: int) -> dict[str, object]:
    start, stop = matrix.indptr[row], matrix.indptr[row + 1]
    cols = matrix.indices[start:stop]
    vals = matrix.data[start:stop]
    mask = (cols != row) & (vals < 0.0)
    order = np.argsort(np.abs(vals[mask]))[::-1]
    return {"negative_count": int(np.count_nonzero(mask)), "negative_max_abs": float(np.max(np.abs(vals[mask]))) if np.any(mask) else 0.0, "top": [{"owner_col": int(c), "value": float(v)} for c, v in zip(cols[mask][order[:10]], vals[mask][order[:10]], strict=False)]}


def main() -> None:
    host = archive(HOST)
    history = archive(CASE / "history.npz")
    baseline = archive(BASELINE / "history.npz")
    shape = tuple(int(v) for v in host["shape"])
    raw_volume = np.asarray(host["host_raw_volume"], dtype=float)
    H_z = sparse.load_npz(H_PATH).tocsr()
    P_GLOBAL, R, slot, owner_volume, owner_ids = compact_maps(host, raw_volume)
    if H_z.shape[0] != raw_volume.size or H_z.shape[1] != owner_volume.size:
        raise RuntimeError("saved H shape does not match host payload")
    L, lmeta = build_native_L(host, history, slot, P_GLOBAL, owner_ids)
    Mf = sparse.diags(raw_volume.ravel())
    Moadj = sparse.diags(1.0 / owner_volume)
    Radj = Moadj @ H_z.T @ Mf
    LH = (L @ H_z).tocsr()
    LP = (L @ P_GLOBAL).tocsr()
    A_adj = (Radj @ LH).tocsr()
    A_vol = (R @ LH).tocsr()
    A_piece = (R @ LP).tocsr()
    A_piece_adj = (Radj @ LP).tocsr()
    save_npz(OUT / "L_native_interior_32.npz", L)
    save_npz(OUT / "A_adjoint_32.npz", A_adj)
    save_npz(OUT / "A_volume_32.npz", A_vol)
    save_npz(OUT / "A_piecewise_32.npz", A_piece)

    times = np.asarray(history["times"], dtype=float)
    targets = {"eventual_worst_owner_(1,0,15)": (1, 0, 15), "initial_near_zero_(2,24,14)": (2, 24, 14), "initial_near_zero_hotspot_(3,12,12)": (3, 12, 12), "initial_H_min_(6,12,16)": (6, 12, 16)}
    target_coords = dict(targets)
    owner_targets = {name: owner_target(slot, shape, coord) for name, coord in targets.items()}
    # Include the most negative saved perturbation (Te-1) cell at each
    # requested time as an explicit early/worst target, preserving its owner
    # alias resolution.
    for t in (0.5, 3.5, 10.5):
        ti = int(np.argmin(np.abs(times - t)))
        coord = tuple(int(x) for x in np.unravel_index(int(np.argmin(history["Te"][ti] - 1.0)), shape))
        owner_targets[f"minimum_delta_Te_from_background_at_t={t:g}"] = owner_target(slot, shape, coord)
        target_coords[f"minimum_delta_Te_from_background_at_t={t:g}"] = coord

    records: dict[str, object] = {}
    for t in (0.0, 0.5, 3.5, 10.5):
        ti = int(np.argmin(np.abs(times - t)))
        owner_values = np.asarray(R @ history["Te"][ti].ravel()).ravel()
        y_h = np.asarray(LH @ owner_values).ravel()
        y_p = np.asarray(LP @ owner_values).ravel()
        rhs_adj_h = CHI_PARALLEL * np.asarray(Radj @ y_h).ravel()
        rhs_vol_h = CHI_PARALLEL * np.asarray(R @ y_h).ravel()
        rhs_adj_p = CHI_PARALLEL * np.asarray(Radj @ y_p).ravel()
        rhs_vol_p = CHI_PARALLEL * np.asarray(R @ y_p).ravel()
        records[str(t)] = {"actual_time": float(times[ti]), "targets": {}}
        perturbation = np.asarray(history["Te"][ti], dtype=float) - 1.0
        minimum_flat = int(np.argmin(perturbation))
        records[str(t)]["undershoot"] = {
            "negative_count": int(np.count_nonzero(perturbation < 0.0)),
            "minimum_delta_Te": float(perturbation.ravel()[minimum_flat]),
            "minimum_coordinate": [int(x) for x in np.unravel_index(minimum_flat, shape)],
        }
        for name, owner in owner_targets.items():
            coord = target_coords[name]
            coord_flat = int(np.ravel_multi_index(coord, shape))
            support = H_z.getcol(owner)
            valid_output = np.asarray(L.getnnz(axis=1)).ravel() > 0
            support_coo = support.tocoo()
            support_rows = support_coo.row
            signed_weights = support_coo.data * raw_volume.ravel()[support_rows] / owner_volume[owner]
            support_mass = np.abs(signed_weights)
            covered = valid_output[support_rows]
            adjoint_contribution = CHI_PARALLEL * signed_weights * y_h[support_rows]
            p_support = P_GLOBAL.getcol(owner).tocoo()
            volume_contribution = CHI_PARALLEL * raw_volume.ravel()[p_support.row] / owner_volume[owner] * y_h[p_support.row]
            if not np.isclose(np.sum(adjoint_contribution), rhs_adj_h[owner], rtol=2.0e-12, atol=2.0e-13):
                raise RuntimeError(f"signed H^T return decomposition does not close for owner {owner}")
            records[str(t)]["targets"][name] = {
                "coordinate": list(coord), "owner_row": int(owner), "adjoint_H": float(rhs_adj_h[owner]), "volume_H": float(rhs_vol_h[owner]), "adjoint_piecewise": float(rhs_adj_p[owner]), "volume_piecewise": float(rhs_vol_p[owner]), "source_effect_H_minus_piecewise": float(rhs_vol_h[owner] - rhs_vol_p[owner]), "return_effect_adjoint_minus_volume": float(rhs_adj_h[owner] - rhs_vol_h[owner]), "return_effect_piecewise": float(rhs_adj_p[owner] - rhs_vol_p[owner]), "delta_Te_from_background": float(history["Te"][ti].ravel()[coord_flat] - 1.0), "H_output_support_rows": int(support_rows.size), "H_output_support_covered_rows": int(np.count_nonzero(covered)), "H_output_support_covered_abs_weight_fraction": float(np.sum(support_mass[covered]) / max(np.sum(support_mass), 1e-300)), "offdiagonal": row_offdiag(A_adj, owner),
                "adjoint_H_unscaled": float(rhs_adj_h[owner] / CHI_PARALLEL), "volume_H_unscaled": float(rhs_vol_h[owner] / CHI_PARALLEL),
                "adjoint_return_positive_contribution": float(np.sum(adjoint_contribution[adjoint_contribution > 0.0])), "adjoint_return_negative_contribution": float(np.sum(adjoint_contribution[adjoint_contribution < 0.0])), "volume_return_positive_contribution": float(np.sum(volume_contribution[volume_contribution > 0.0])), "volume_return_negative_contribution": float(np.sum(volume_contribution[volume_contribution < 0.0])),
            }
        # Saved runtime metric is a strong validation of L/H/R composition.
        runtime_norm = float(history["parallel_rhs_l2"][ti])
        runtime_weights = np.asarray(history["volume_weights"], dtype=float)
        computed_norm = float(np.sqrt(np.sum(runtime_weights * (P_GLOBAL @ np.asarray(rhs_adj_h)).reshape(shape) ** 2) / np.sum(runtime_weights)))
        records[str(t)]["validation"] = {"runtime_parallel_rhs_l2": runtime_norm, "audit_parallel_rhs_l2": computed_norm, "relative_difference": abs(runtime_norm - computed_norm) / max(abs(runtime_norm), 1e-300), "comparison_scope": "saved full native norm versus this audit's valid two-sided map rows; the residual is reported without assigning it to a specific closure mechanism"}

    # Global signed off-diagonal statistics quantify the maximum-principle
    # failure of the assembled effective owner operator.
    acoo = A_adj.tocoo()
    neg = acoo.data[(acoo.data < 0.0) & (acoo.row != acoo.col)]
    diagonal = A_adj.diagonal()
    support_checks = {}
    for name in ("eventual_worst_owner_(1,0,15)", "initial_near_zero_(2,24,14)", "initial_near_zero_hotspot_(3,12,12)", "initial_H_min_(6,12,16)"):
        fractions = [float(records[t]["targets"][name]["H_output_support_covered_abs_weight_fraction"]) for t in records]
        support_checks[name] = {"minimum_covered_abs_weight_fraction": float(min(fractions)), "all_rows_covered": bool(min(fractions) >= 1.0 - 1.0e-13)}
        if not support_checks[name]["all_rows_covered"]:
            raise RuntimeError(f"target H^T support is incomplete after axis reflection: {name}: {fractions}")
    results: dict[str, object] = {
        "provenance": {"frozen_source": str(SOURCE), "native_module": str(Path(native_fci_operators.__file__).resolve()), "case_history": str(CASE / "history.npz"), "baseline_history": str(BASELINE / "history.npz"), "host_payload": str(HOST), "H_matrix": str(H_PATH)},
        "configuration": {"resolution": 32, "shape": list(shape), "chi_parallel": CHI_PARALLEL, "operator": "A = Mo^-1 H.T Mf L H", "piecewise_diagnostic": "P injection with the same mapped L", "scope": "all fine rows with valid two-sided maps; axis reflection included; outer/wall closure rows omitted", "matrix_scale": "saved L/A matrices are chi-unscaled; reported RHS values are chi-scaled"},
        "matrix": {"L_shape": list(L.shape), "L_nnz": int(L.nnz), "A_adjoint_shape": list(A_adj.shape), "A_adjoint_nnz": int(A_adj.nnz), "A_volume_nnz": int(A_vol.nnz), "A_piecewise_nnz": int(A_piece.nnz), "scale": "chi-unscaled", **lmeta},
        "validation": {"RH_max_abs": float(np.max(np.abs((R @ H_z - sparse.eye(owner_volume.size, format="csr")).data))) if (R @ H_z - sparse.eye(owner_volume.size, format="csr")).nnz else 0.0, "L_finite": bool(np.all(np.isfinite(L.data))), "native_arithmetic": native_arithmetic_validation(), "target_support": support_checks, "runtime_rhs": records},
        "negative_offdiagonal": {"count": int(neg.size), "max_abs": float(np.max(np.abs(neg))) if neg.size else 0.0, "median_abs": float(np.median(np.abs(neg))) if neg.size else 0.0, "p95_abs": float(np.quantile(np.abs(neg), 0.95)) if neg.size else 0.0, "min_diagonal": float(np.min(diagonal)), "max_diagonal": float(np.max(diagonal))},
        "interpretation": "The mapped interior operator is validated against the saved native parallel RHS norm. H and its mass adjoint are separated from volume return and piecewise-constant injection. Negative owner off-diagonals establish loss of a semidiscrete maximum principle, but this partial operator audit does not establish a growing eigenmode or attribute wall/closure behavior.",
    }
    (OUT / "operator_audit.json").write_text(json.dumps(results, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"output": str(OUT / "operator_audit.json"), "L_nnz": int(L.nnz), "A_nnz": int(A_adj.nnz), "validation": records}, indent=2))


if __name__ == "__main__":
    main()
