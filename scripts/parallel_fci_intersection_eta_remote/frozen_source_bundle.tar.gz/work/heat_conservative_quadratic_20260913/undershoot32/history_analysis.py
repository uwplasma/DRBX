"""Bounded undershoot analysis for the saved 32^3 conservative run.

This script only reads the completed history, its no-RLP control, and the
saved angular-RLP host payload. Fine-cell counts are reported separately from
active owner counts because one owner can represent several repeated theta
entries. Negative heat is a signed raw-volume integral; it is not a claim of
global conservation or positivity.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import numpy as np


ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
RUN = ROOT / "prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_conservative_quadratic_t25_20260913"
NO_RLP = ROOT / "prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_no_rlp_t25_20260913"
HOST = ROOT / "work/heat_aggregate_quadratic_20260913/metric_cache_32/angular_rlp_host_85832e63967cf29a96d27b10.npz"
PLOT_TIMES = (0.0, 0.5, 3.5, 10.5, 25.0)
ETA_INDEX = 15
APPRECIABLE_THRESHOLD = -1.0e-8
EVENTUAL_WORST = (1, 0, 15)
FIRST_SAVED_WORST = (3, 12, 12)
INITIAL_H_NEGATIVE = (6, 12, 16)


def load_history(path: Path) -> dict[str, np.ndarray]:
    with np.load(path / "history.npz", allow_pickle=False) as archive:
        result = {name: np.asarray(archive[name]).copy() for name in archive.files}
    required = {"times", "Te", "u", "theta", "eta", "Cartesian_position", "angular_group_sizes"}
    missing = sorted(required.difference(result))
    if missing:
        raise ValueError(f"{path} history is missing {missing}")
    shape = tuple(int(value) for value in result["Te"].shape[1:])
    if result["Cartesian_position"].shape != shape + (3,):
        raise ValueError(
            f"{path} Cartesian_position has shape {result['Cartesian_position'].shape}; "
            f"expected {shape + (3,)}"
        )
    if not np.all(np.isfinite(result["Cartesian_position"])):
        raise ValueError(f"{path} Cartesian_position contains non-finite values")
    if result["angular_group_sizes"].shape != (shape[0],):
        raise ValueError(f"{path} angular_group_sizes does not match radial shape")
    return result


def load_host(path: Path, shape: tuple[int, int, int]) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        names = {
            "host_raw_volume",
            "topology_aggregate_volume",
            "topology_owner_index",
            "topology_is_active_owner",
            "topology_aggregate_id",
        }
        missing = sorted(names.difference(archive.files))
        if missing:
            raise ValueError(f"host payload is missing {missing}")
        result = {name: np.asarray(archive[name]).copy() for name in names}
    if result["host_raw_volume"].shape != shape:
        raise ValueError("host_raw_volume does not match the saved history")
    if result["topology_owner_index"].shape != shape + (3,):
        raise ValueError("topology_owner_index does not match the saved history")
    if result["topology_is_active_owner"].shape != shape:
        raise ValueError("topology_is_active_owner does not match the saved history")
    if result["topology_aggregate_id"].shape != shape:
        raise ValueError("topology_aggregate_id does not match the saved history")
    if result["topology_aggregate_volume"].shape != shape:
        raise ValueError("topology_aggregate_volume does not match the saved history")
    aggregate_id = np.asarray(result["topology_aggregate_id"], dtype=np.int64)
    if np.any(aggregate_id < 0) or np.any(aggregate_id >= int(np.prod(shape))):
        raise ValueError("topology_aggregate_id is outside the owner grid")
    raw_volume = np.asarray(result["host_raw_volume"], dtype=np.float64)
    derived_owner_volume = np.bincount(
        aggregate_id.ravel(), weights=raw_volume.ravel(), minlength=int(np.prod(shape))
    ).reshape(shape)
    if not np.allclose(
        derived_owner_volume,
        np.asarray(result["topology_aggregate_volume"], dtype=np.float64),
        rtol=2.0e-12,
        atol=2.0e-14,
    ):
        raise ValueError("raw-volume owner aggregation disagrees with host aggregate volumes")
    result["derived_owner_volume"] = derived_owner_volume
    return result


def nearest_time(times: np.ndarray, value: float) -> int:
    index = int(np.argmin(np.abs(times - value)))
    if abs(float(times[index]) - value) > 1.0e-10:
        raise ValueError(f"requested time {value} is not saved")
    return index


def physical_corners(values: np.ndarray) -> np.ndarray:
    """Build periodic-theta, half-cell-extrapolated corners from centers."""

    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 2 or min(values.shape) < 1:
        raise ValueError("physical centers must be a nonempty 2-D array")
    radial = np.empty((values.shape[0] + 1, values.shape[1]), dtype=np.float64)
    if values.shape[0] == 1:
        radial[0] = radial[1] = values[0]
    else:
        radial[1:-1] = 0.5 * (values[:-1] + values[1:])
        radial[0] = values[0] - 0.5 * (values[1] - values[0])
        radial[-1] = values[-1] + 0.5 * (values[-1] - values[-2])
    corners = np.empty((values.shape[0] + 1, values.shape[1] + 1), dtype=np.float64)
    corners[:, 1:-1] = 0.5 * (radial[:, :-1] + radial[:, 1:])
    corners[:, 0] = corners[:, -1] = 0.5 * (radial[:, -1] + radial[:, 0])
    return corners


def first_crossing(times: np.ndarray, values: np.ndarray, threshold: float) -> dict[str, object] | None:
    mask = np.asarray(values) < threshold
    indices = np.flatnonzero(mask)
    if indices.size == 0:
        return None
    first = int(indices[0])
    return {"time_index": first, "time": float(times[first]), "value": float(values[first])}


def track_cell(
    name: str,
    history: dict[str, np.ndarray],
    no_rlp: dict[str, np.ndarray],
    host: dict[str, np.ndarray],
    cell: tuple[int, int, int],
) -> dict[str, object]:
    i, j, k = cell
    owner_index = np.asarray(host["topology_owner_index"], dtype=np.int64)
    aggregate_id = np.asarray(host["topology_aggregate_id"], dtype=np.int64)
    raw_volume = np.asarray(host["host_raw_volume"], dtype=np.float64)
    owner = tuple(int(value) for value in owner_index[i, j, k])
    stored = np.asarray(history["Te"][:, i, j, k] - 1.0, dtype=np.float64)
    no_rlp_cell = np.asarray(no_rlp["Te"][:, i, j, k] - 1.0, dtype=np.float64)
    no_rlp_owner = np.asarray(no_rlp["Te"][:, owner[0], owner[1], owner[2]] - 1.0, dtype=np.float64)
    aggregate_mask = aggregate_id == aggregate_id[i, j, k]
    aggregate_weights = raw_volume[aggregate_mask]
    no_rlp_owner_volume_average = (
        np.asarray(no_rlp["Te"][:, aggregate_mask], dtype=np.float64)
        * aggregate_weights[None, :]
    ).sum(axis=1) / float(np.sum(aggregate_weights)) - 1.0
    return {
        "name": name,
        "ijk": [i, j, k],
        "owner_ijk": list(owner),
        "radial_index": i,
        "q_group_size": int(history["angular_group_sizes"][i]),
        "u": float(history["u"][i]),
        "theta_phase": float(np.mod(history["theta"][j] / (2.0 * np.pi), 1.0)),
        "eta_phase": float(np.mod(history["eta"][k] / (2.0 * np.pi), 1.0)),
        "stored_deltaTe": stored.tolist(),
        "no_rlp_same_cell_deltaTe": no_rlp_cell.tolist(),
        "no_rlp_representative_deltaTe": no_rlp_owner.tolist(),
        "no_rlp_same_owner_projected_deltaTe": no_rlp_owner_volume_average.tolist(),
        "no_rlp_same_owner_volume_average_deltaTe": no_rlp_owner_volume_average.tolist(),
        "stored_first_appreciable_undershoot": first_crossing(
            history["times"], stored, APPRECIABLE_THRESHOLD
        ),
        "no_rlp_same_owner_first_appreciable_undershoot": first_crossing(
            no_rlp["times"], no_rlp_owner_volume_average, APPRECIABLE_THRESHOLD
        ),
    }


def ring_metrics(
    history: dict[str, np.ndarray],
    host: dict[str, np.ndarray],
) -> list[dict[str, object]]:
    delta = np.asarray(history["Te"] - 1.0, dtype=np.float64)
    raw_volume = np.asarray(host["host_raw_volume"], dtype=np.float64)
    owner_volume = np.asarray(host["derived_owner_volume"], dtype=np.float64)
    active = np.asarray(host["topology_is_active_owner"], dtype=bool)
    q_by_radial = np.asarray(history["angular_group_sizes"], dtype=np.int64)
    metrics: list[dict[str, object]] = []
    for time_index, time in enumerate(np.asarray(history["times"], dtype=np.float64)):
        frame = delta[time_index]
        for q in np.unique(q_by_radial):
            ring = np.broadcast_to(q_by_radial[:, None, None] == q, frame.shape)
            negative = frame < 0.0
            owner_negative = negative & active
            metrics.append(
                {
                    "time_index": int(time_index),
                    "time": float(time),
                    "q_group_size": int(q),
                    "fine_cell_count": int(np.count_nonzero(ring)),
                    "fine_negative_cell_count": int(np.count_nonzero(ring & negative)),
                    "active_owner_count": int(np.count_nonzero(ring & active)),
                    "negative_owner_count": int(np.count_nonzero(ring & owner_negative)),
                    "fine_negative_heat_signed": float(
                        np.sum(raw_volume * np.minimum(frame, 0.0) * ring)
                    ),
                    "owner_negative_heat_signed": float(
                        np.sum(owner_volume * np.minimum(frame, 0.0) * ring * active)
                    ),
                }
            )
    return metrics


def radial_metrics(
    history: dict[str, np.ndarray],
    host: dict[str, np.ndarray],
) -> list[dict[str, object]]:
    """Report the same signed measures per radial index, retaining q labels."""

    delta = np.asarray(history["Te"] - 1.0, dtype=np.float64)
    raw_volume = np.asarray(host["host_raw_volume"], dtype=np.float64)
    owner_volume = np.asarray(host["derived_owner_volume"], dtype=np.float64)
    active = np.asarray(host["topology_is_active_owner"], dtype=bool)
    q_by_radial = np.asarray(history["angular_group_sizes"], dtype=np.int64)
    metrics: list[dict[str, object]] = []
    for time_index, time in enumerate(np.asarray(history["times"], dtype=np.float64)):
        frame = delta[time_index]
        negative = frame < 0.0
        for radial_index, q in enumerate(q_by_radial):
            ring = np.zeros_like(frame, dtype=bool)
            ring[radial_index] = True
            owner_negative = negative & active
            metrics.append(
                {
                    "time_index": int(time_index),
                    "time": float(time),
                    "radial_index": int(radial_index),
                    "q_group_size": int(q),
                    "fine_cell_count": int(np.count_nonzero(ring)),
                    "fine_negative_cell_count": int(np.count_nonzero(ring & negative)),
                    "active_owner_count": int(np.count_nonzero(ring & active)),
                    "negative_owner_count": int(np.count_nonzero(ring & owner_negative)),
                    "fine_negative_heat_signed": float(
                        np.sum(raw_volume * np.minimum(frame, 0.0) * ring)
                    ),
                    "owner_negative_heat_signed": float(
                        np.sum(owner_volume * np.minimum(frame, 0.0) * ring * active)
                    ),
                }
            )
    return metrics


def signed_rz_plot(
    history: dict[str, np.ndarray],
    output: Path,
) -> dict[str, object]:
    positions = np.asarray(history["Cartesian_position"][:, :, ETA_INDEX, :], dtype=np.float64)
    radius = np.hypot(positions[..., 0], positions[..., 1])
    z = positions[..., 2]
    delta = np.asarray(history["Te"] - 1.0, dtype=np.float64)
    frame_indices = [nearest_time(history["times"], time) for time in PLOT_TIMES]
    eta_values = np.asarray(delta[frame_indices, :, :, ETA_INDEX], dtype=np.float64)
    scale = max(float(-np.nanmin(eta_values)), np.finfo(np.float64).tiny)
    core = np.asarray(history["u"], dtype=np.float64) <= 0.35
    if not np.any(core):
        raise ValueError("saved radial grid has no cells in the requested u<=0.35 core")
    core_radius = radius[core]
    core_z = z[core]
    radius_span = max(float(np.nanmax(core_radius) - np.nanmin(core_radius)), 1.0e-6)
    z_span = max(float(np.nanmax(core_z) - np.nanmin(core_z)), 1.0e-6)
    x_limits = (float(np.nanmin(core_radius) - 0.06 * radius_span), float(np.nanmax(core_radius) + 0.06 * radius_span))
    y_limits = (float(np.nanmin(core_z) - 0.06 * z_span), float(np.nanmax(core_z) + 0.06 * z_span))
    core_boundary_index = int(np.flatnonzero(core)[-1])
    figure, axes = plt.subplots(1, len(frame_indices), figsize=(18.0, 4.2), sharex=True, sharey=True, layout="constrained")
    if len(frame_indices) == 1:
        axes = [axes]
    for axis, time, values in zip(axes, PLOT_TIMES, eta_values, strict=True):
        signed_negative = np.where(values < 0.0, values, np.nan)
        image = axis.pcolormesh(
            physical_corners(radius),
            physical_corners(z),
            signed_negative,
            shading="flat",
            cmap="Blues_r",
            norm=Normalize(vmin=-scale, vmax=0.0),
            rasterized=True,
        )
        axis.set_aspect("equal", adjustable="box")
        axis.set_xlim(*x_limits)
        axis.set_ylim(*y_limits)
        axis.plot(
            radius[core_boundary_index],
            z[core_boundary_index],
            color="0.35",
            linewidth=0.7,
            linestyle="--",
            alpha=0.65,
            label="u≈0.35 boundary",
        )
        axis.set_title(f"t={time:g}")
        axis.set_xlabel("R [m]")
        axis.grid(alpha=0.15, linewidth=0.35)
        i, j, _ = EVENTUAL_WORST
        axis.plot(radius[i, j], z[i, j], marker="x", color="crimson", markersize=6, markeredgewidth=1.2)
    axes[0].set_ylabel("Z [m]")
    figure.suptitle(
        "32³ conservative quadratic signed undershoot, eta index 15\n"
        "negative ΔTe only; crimson x tracks stored cell (1, 0, 15)"
    )
    figure.colorbar(image, ax=axes, label="negative ΔTe", shrink=0.85)
    figure.savefig(output, dpi=180, facecolor="white")
    plt.close(figure)
    return {
        "path": str(output),
        "eta_index": ETA_INDEX,
        "times": list(PLOT_TIMES),
        "negative_scale": scale,
        "color_policy": "dedicated negative scale shared across requested eta-15 times",
        "physical_coordinates": "saved Cartesian_position -> R=hypot(X,Y), Z; structured periodic-theta corners",
        "zoom": "shared physical R/Z extent enclosing saved cells with u<=0.35, with dashed outer-core boundary",
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    history = load_history(RUN)
    no_rlp = load_history(NO_RLP)
    if history["Te"].shape != no_rlp["Te"].shape:
        raise ValueError("conservative and no-RLP histories have different shapes")
    host = load_host(HOST, tuple(int(value) for value in history["Te"].shape[1:]))
    owner_index = np.asarray(host["topology_owner_index"], dtype=np.int64)
    active = np.asarray(host["topology_is_active_owner"], dtype=bool)
    delta = np.asarray(history["Te"] - 1.0, dtype=np.float64)
    first = np.flatnonzero(np.any(delta < APPRECIABLE_THRESHOLD, axis=(1, 2, 3)))
    first_index = int(first[0]) if first.size else None
    worst = []
    for index, time in enumerate(history["times"]):
        cell = tuple(int(value) for value in np.unravel_index(np.argmin(delta[index]), delta[index].shape))
        worst.append(
            {
                "time_index": int(index),
                "time": float(time),
                "ijk": list(cell),
                "value": float(delta[(index,) + cell]),
                "q_group_size": int(history["angular_group_sizes"][cell[0]]),
                "owner_ijk": [int(value) for value in owner_index[cell]],
            }
        )
    summary = {
        "run": str(RUN),
        "no_rlp_control": str(NO_RLP),
        "host_cache": str(HOST),
        "shape": list(history["Te"].shape[1:]),
        "threshold": APPRECIABLE_THRESHOLD,
        "first_appreciable_undershoot": (
            None
            if first_index is None
            else {
                "time_index": first_index,
                "time": float(history["times"][first_index]),
                "minimum": float(np.min(delta[first_index])),
                "minimum_ijk": [int(value) for value in np.unravel_index(np.argmin(delta[first_index]), delta[first_index].shape)],
            }
        ),
        "global_stored_minimum": {
            "value": float(np.min(delta)),
            "time_index": int(np.unravel_index(np.argmin(delta), delta.shape)[0]),
            "time": float(history["times"][np.unravel_index(np.argmin(delta), delta.shape)[0]]),
            "ijk": [int(value) for value in np.unravel_index(np.argmin(delta), delta.shape)[1:]],
        },
        "worst_cell_by_saved_time": worst,
        "tracks": {
            "eventual_worst_cell": track_cell("eventual stored worst", history, no_rlp, host, EVENTUAL_WORST),
            "first_saved_worst_cell": track_cell("first saved stored worst", history, no_rlp, host, FIRST_SAVED_WORST),
            "initial_H_negative_location": track_cell("initial H-reconstruction negative location", history, no_rlp, host, INITIAL_H_NEGATIVE),
        },
        "active_owner_total": int(np.count_nonzero(active)),
        "ring_metrics": ring_metrics(history, host),
        "radial_metrics": radial_metrics(history, host),
        "plot": signed_rz_plot(history, OUT / "signed_core_rz.png"),
        "interpretation": {
            "counts": "fine_negative_cell_count includes repeated raw entries; negative_owner_count counts active owner representatives only",
            "heat": "fine_negative_heat_signed uses full raw host volume; owner_negative_heat_signed uses aggregate owner volume",
            "comparison": "no-RLP values are reported at the same raw cell and at its RLP owner representative coordinate",
            "H_location": "the initial H negative location comes from the independent reconstruction audit; this saved history stores owner values, so its stored value can remain nonnegative",
        },
    }
    heat_differences = [
        abs(float(row["fine_negative_heat_signed"] - row["owner_negative_heat_signed"]))
        for row in summary["ring_metrics"]
    ]
    max_heat_difference = max(heat_differences, default=0.0)
    if max_heat_difference > 1.0e-12:
        raise RuntimeError(
            "owner and repeated fine negative heat integrals disagree after raw-volume aggregation: "
            f"{max_heat_difference:.6e}"
        )
    summary["owner_volume_invariant"] = {
        "owner_volume_source": "bincount(topology_aggregate_id, host_raw_volume)",
        "matches_host_topology_aggregate_volume": True,
        "max_abs_fine_vs_owner_negative_heat_difference": max_heat_difference,
    }
    output = OUT / "history_analysis.json"
    output.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "plot": summary["plot"], "first": summary["first_appreciable_undershoot"]}, indent=2))


if __name__ == "__main__":
    main()
