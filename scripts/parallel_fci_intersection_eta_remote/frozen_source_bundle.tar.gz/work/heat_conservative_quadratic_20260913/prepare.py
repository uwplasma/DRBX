"""Prepare immutable conservative-quadratic HSX conduction cases.

Preparation snapshots the reviewed current driver/package and copies the
baseline metric plus RLP host-moment references into this run directory.  It
only creates new case directories and refuses every overwrite or duplicate.
It never launches an integration.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
RUN = Path(__file__).resolve().parent
SOURCE = RUN / "source"
DRIVER = ROOT / "run_hsx_sanity.py"
HOST_CACHE_ROOT = ROOT / ".hsx_metric_cache"

CONTROLS = {
    "paired": "conservative-quadratic",
    "volume": "conservative-quadratic-volume",
}
BASELINES = {
    32: ROOT / "prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_32_t25",
    64: ROOT / "prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_64x64x32_t25",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _host_reference(resolution: int, baseline: Path) -> Path:
    """Select the frozen historical host moments by shape and known volume.

    Cache filenames are implementation hashes and may change when the cache
    schema changes.  The references remain identified by their raw and
    aggregate moments, which the runner compares after rebuilding geometry.
    """
    expected_groups = None
    with np.load(baseline / "history.npz") as history:
        if "angular_group_sizes" in history.files:
            expected_groups = np.asarray(history["angular_group_sizes"])
    candidates: list[Path] = []
    for path in sorted(HOST_CACHE_ROOT.glob("angular_rlp_host_*.npz")):
        try:
            with np.load(path) as archive:
                groups = np.asarray(archive["angular_group_size"])
                shape = tuple(np.asarray(archive["shape"]).tolist())
        except (OSError, KeyError, ValueError):
            continue
        if shape == (resolution, resolution, 32) and (
            expected_groups is None
            or (groups.shape == expected_groups.shape and np.array_equal(groups, expected_groups))
        ):
            candidates.append(path)
    # Historical baseline references are preferred when available.  Their
    # names are not used as a runtime cache identity.
    preferred = {
        32: "angular_rlp_host_5180c3964f2704f3a5beb5fc.npz",
        64: "angular_rlp_host_2b02c6728ab3c3d2ad9af823.npz",
    }[resolution]
    preferred_path = HOST_CACHE_ROOT / preferred
    if preferred_path in candidates:
        return preferred_path
    if len(candidates) != 1:
        raise SystemExit(
            f"expected one host-moment reference for {resolution}, found "
            f"{[str(path) for path in candidates]}"
        )
    return candidates[0]


def _snapshot_source() -> dict[str, str]:
    if SOURCE.exists():
        raise SystemExit(f"source snapshot already exists: {SOURCE}; refusing to overwrite")
    required_markers = (
        "conservative-quadratic",
        "conservative-quadratic-volume",
    )
    driver_text = DRIVER.read_text()
    missing = [marker for marker in required_markers if marker not in driver_text]
    if missing:
        raise SystemExit(f"driver is missing reviewed reconstruction markers: {missing}")
    (SOURCE / "DRBX").mkdir(parents=True)
    for relative in ("run_hsx_sanity.py", "run_hsx_perpendicular_convergence.py"):
        shutil.copy2(ROOT / relative, SOURCE / relative)
    shutil.copy2(ROOT / "DRBX" / "simulate_hsx_blob.py", SOURCE / "DRBX" / "simulate_hsx_blob.py")
    shutil.copytree(
        ROOT / "DRBX" / "src",
        SOURCE / "DRBX" / "src",
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
    )
    return {
        str(path.relative_to(SOURCE)): sha256(path)
        for path in SOURCE.rglob("*")
        if path.is_file()
    }


def main() -> None:
    argparse.ArgumentParser(description=__doc__).parse_args()
    if (RUN / "cases.json").exists():
        raise SystemExit(f"case manifest already exists: {RUN / 'cases.json'}; refusing duplicate preparation")
    source_hashes = _snapshot_source()
    cases: list[dict[str, object]] = []
    seen_outputs: set[str] = set()
    try:
        for resolution in (32, 64):
            baseline = BASELINES[resolution]
            for required in (baseline / "metadata.json", baseline / "history.npz", baseline / "makegrid_poincare_theta_u.npz"):
                if not required.exists():
                    raise SystemExit(f"missing baseline artifact: {required}")
            metadata = json.loads((baseline / "metadata.json").read_text())
            metric_source = Path(metadata["geometry_contract"]["metric_cache_path"]).resolve()
            if not metric_source.exists():
                raise SystemExit(f"missing baseline metric cache: {metric_source}")
            host_source = _host_reference(resolution, baseline)
            metric_dir = RUN / f"metric_cache_{resolution}"
            host_dir = RUN / f"host_reference_{resolution}"
            if metric_dir.exists() or host_dir.exists():
                raise SystemExit(f"reference directory already exists for {resolution}")
            metric_dir.mkdir()
            host_dir.mkdir()
            metric_file = metric_dir / metric_source.name
            host_file = host_dir / host_source.name
            shutil.copy2(metric_source, metric_file)
            shutil.copy2(host_source, host_file)
            for control, flag_value in CONTROLS.items():
                suffix = "conservative_quadratic" if control == "paired" else "conservative_quadratic_volume"
                output = ROOT / f"prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_{resolution}x{resolution}x32_{suffix}_t25_20260913"
                if control == "paired":
                    if str(output) in seen_outputs or output.exists():
                        raise SystemExit(f"output already exists or is duplicated: {output}")
                    seen_outputs.add(str(output))
                    output.mkdir(parents=True)
                    contour = baseline / "makegrid_poincare_theta_u.npz"
                    shutil.copy2(contour, output / contour.name)
                    output_value: str | None = str(output)
                else:
                    # Conservative volume control is a three-step diagnostic
                    # gate; full t=25 outputs are paired H-return only.
                    output_value = None
                case = {
                    "resolution": resolution,
                    "control": control,
                    "conduction_reconstruction": flag_value,
                    "baseline": str(baseline),
                    "output": output_value,
                    "metric_cache": str(metric_dir),
                    "metric_file": str(metric_file),
                    "host_reference": str(host_file),
                    "source": str(SOURCE),
                    "final_time": 25.0,
                    "num_steps": 37500,
                    "dt": 1.0 / 1500.0,
                    "save_every": 750,
                    "initial_condition": "heat-spot",
                    "geometry_provenance": "baseline maps, coordinates, B, volume weights, and RLP raw/aggregate moments",
                }
                cases.append(case)
                if output_value is not None:
                    (output / "control_plan.json").write_text(json.dumps(case, indent=2, sort_keys=True) + "\n")
    except BaseException:
        # Keep the guard meaningful if preparation fails midway.  No old case
        # output is touched; the caller can remove this new run directory and
        # retry after fixing the reviewed inputs.
        raise
    git = lambda *args: subprocess.check_output(["git", "-C", str(ROOT / "DRBX"), *args], text=True).strip()
    manifest = {
        "git_head": git("rev-parse", "HEAD"),
        "git_status": git("status", "--short"),
        "integration_driver": str(DRIVER),
        "integration_driver_sha256": sha256(DRIVER),
        "controls": CONTROLS,
        "source_files_sha256": source_hashes,
    }
    (RUN / "source_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    (RUN / "cases.json").write_text(json.dumps(cases, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"source": str(SOURCE), "cases": cases}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
