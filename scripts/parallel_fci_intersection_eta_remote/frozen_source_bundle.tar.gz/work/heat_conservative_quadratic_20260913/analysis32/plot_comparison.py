"""Plot stored 32^2 x 32 heat histories for four conduction controls.

The plots use the fine-shaped Te arrays written by each run.  RLP histories
are already owner-expanded by the production driver; no H-prolongation is
introduced here.  Physical integrals use the frozen raw host cell volumes.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / "mpl_cache"))
import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import RegularGridInterpolator

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
N = 32
ETA_INDEX = 25
CASES = {
    "new paired": ROOT / "prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_conservative_quadratic_t25_20260913",
    "old point": ROOT / "prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_aggregate_quadratic_t25_20260913",
    "no RLP": ROOT / "prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_no_rlp_t25_20260913",
    "legacy": ROOT / "prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_32_t25",
}
HOST = ROOT / "work/heat_aggregate_quadratic_20260913/metric_cache_32/angular_rlp_host_85832e63967cf29a96d27b10.npz"
TIMES = (0.0, 3.5, 10.0, 25.0)
Q_BOUNDARY = 0.34375


def load_history(path: Path) -> dict[str, np.ndarray]:
    with np.load(path / "history.npz") as archive:
        result = {name: np.asarray(archive[name]) for name in archive.files}
    if result["Te"].shape[1:] != (N, N, N):
        raise ValueError(f"unexpected field shape in {path}: {result['Te'].shape}")
    return result


def nearest_time(history: dict[str, np.ndarray], value: float) -> int:
    times = np.asarray(history["times"], dtype=float)
    index = int(np.argmin(np.abs(times - value)))
    if abs(float(times[index]) - value) > 1.0e-10:
        raise ValueError(f"requested time {value} is not saved in the history")
    return index


def load_host() -> dict[str, np.ndarray]:
    if not HOST.exists():
        raise FileNotFoundError(HOST)
    with np.load(HOST) as archive:
        names = archive.files
        required = {"host_raw_volume", "host_aggregate_chart_volume", "topology_is_active_owner"}
        missing = sorted(required.difference(names))
        if missing:
            raise ValueError(f"host reference lacks {missing}")
        return {name: np.asarray(archive[name]).copy() for name in names}


def verify_poincare() -> dict[str, object]:
    path = CASES["legacy"] / "makegrid_poincare_theta_u.npz"
    with np.load(path) as archive:
        required = {"eta", "contour_theta", "contour_u", "valid_surfaces", "traces_theta_u", "valid_counts", "nfp", "tracing_method"}
        missing = sorted(required.difference(archive.files))
        if missing:
            raise ValueError(f"Poincare artifact lacks {missing}")
        eta = np.asarray(archive["eta"])
        theta = np.asarray(archive["contour_theta"])
        contour_u = np.asarray(archive["contour_u"])
        valid = np.asarray(archive["valid_surfaces"], dtype=bool)
        traces = np.asarray(archive["traces_theta_u"])
        counts = np.asarray(archive["valid_counts"])
        if contour_u.shape != (N, 25, theta.size) or valid.shape != (N, 25):
            raise ValueError(f"unexpected Poincare contour shape: {contour_u.shape}, {valid.shape}")
        if not (np.all(np.isfinite(theta)) and np.all((theta >= 0.0) & (theta <= 1.0))):
            raise ValueError("Poincare contour theta coordinate is invalid")
        if not np.all(np.isfinite(contour_u[valid])):
            raise ValueError("valid Poincare contours contain non-finite values")
        result = {
            "artifact": str(path),
            "eta_planes": int(eta.size),
            "eta_index": ETA_INDEX,
            "seed_count": int(valid.shape[1]),
            "valid_surface_count_at_eta25": int(np.count_nonzero(valid[ETA_INDEX])),
            "contour_points": int(theta.size),
            "theta_normalized_range": [float(theta.min()), float(theta.max())],
            "u_range_at_eta25": [float(np.nanmin(contour_u[ETA_INDEX])), float(np.nanmax(contour_u[ETA_INDEX]))],
            "trace_shape": list(traces.shape),
            "valid_count_range": [int(counts.min()), int(counts.max())],
            "nfp": int(np.asarray(archive["nfp"]).item()),
            "tracing_method": str(np.asarray(archive["tracing_method"]).item()),
            "verified": True,
        }
    (OUT / "poincare_verification.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    return result


def physical_contours(history: dict[str, np.ndarray], poincare_path: Path) -> list[tuple[np.ndarray, np.ndarray]]:
    with np.load(poincare_path) as archive:
        contour_theta = np.asarray(archive["contour_theta"], dtype=float) * 2.0 * np.pi
        contour_u = np.asarray(archive["contour_u"], dtype=float)[ETA_INDEX]
        valid = np.asarray(archive["valid_surfaces"], dtype=bool)[ETA_INDEX]
    u = np.asarray(history["u"], dtype=float)
    theta = np.asarray(history["theta"], dtype=float)
    positions = np.asarray(history["Cartesian_position"], dtype=float)[:, :, ETA_INDEX, :]
    radius = np.hypot(positions[..., 0], positions[..., 1])
    z = positions[..., 2]
    # Make theta periodic before interpolation.  The contour artifact uses
    # the full normalized [0,1] seam, while stored theta values are cell
    # centers and do not include 0 or 2*pi.
    theta_extended = np.concatenate(([theta[-1] - 2.0 * np.pi], theta, [theta[0] + 2.0 * np.pi]))
    radius_extended = np.concatenate((radius[:, -1:], radius, radius[:, :1]), axis=1)
    z_extended = np.concatenate((z[:, -1:], z, z[:, :1]), axis=1)
    r_interp = RegularGridInterpolator((u, theta_extended), radius_extended, bounds_error=False, fill_value=np.nan)
    z_interp = RegularGridInterpolator((u, theta_extended), z_extended, bounds_error=False, fill_value=np.nan)
    curves = []
    for seed, is_valid in enumerate(valid):
        if not is_valid:
            continue
        query = np.stack([contour_u[seed], contour_theta], axis=-1)
        curves.append((r_interp(query), z_interp(query)))
    return curves


def physical_corners(center_values: np.ndarray) -> np.ndarray:
    """Approximate structured R/Z corners from cell centers.

    Radial edges use half-cell extrapolation and theta edges use periodic
    averaging. This keeps each logical cell filled without triangulating over
    the folded vessel geometry.
    """
    values = np.asarray(center_values, dtype=float)
    radial = np.empty((values.shape[0] + 1, values.shape[1]), dtype=float)
    radial[1:-1] = 0.5 * (values[:-1] + values[1:])
    radial[0] = values[0] - 0.5 * (values[1] - values[0])
    radial[-1] = values[-1] + 0.5 * (values[-1] - values[-2])
    corners = np.empty((values.shape[0] + 1, values.shape[1] + 1), dtype=float)
    corners[:, 1:-1] = 0.5 * (radial[:, :-1] + radial[:, 1:])
    seam = 0.5 * (radial[:, -1] + radial[:, 0])
    corners[:, 0] = seam
    corners[:, -1] = seam
    return corners


def positive_scales(histories: dict[str, dict[str, np.ndarray]]) -> dict[float, float]:
    return {
        time_value: max(
            float(np.max(np.maximum(np.asarray(history["Te"][nearest_time(history, time_value)], dtype=float) - 1.0, 0.0)))
            for history in histories.values()
        )
        for time_value in TIMES
    }


def cell_edges(centers: np.ndarray, upper: float) -> np.ndarray:
    centers = np.asarray(centers, dtype=float)
    return np.concatenate(([0.0], 0.5 * (centers[:-1] + centers[1:]), [upper]))


def save_physical(histories: dict[str, dict[str, np.ndarray]], contours: list[tuple[np.ndarray, np.ndarray]], scales: dict[float, float]) -> Path:
    fig, axes = plt.subplots(4, 4, figsize=(13.5, 11.0), sharex=True, sharey=True, layout="constrained")
    for row, (label, history) in enumerate(histories.items()):
        positions = np.asarray(history["Cartesian_position"], dtype=float)[:, :, ETA_INDEX, :]
        radius = np.hypot(positions[..., 0], positions[..., 1])
        z = positions[..., 2]
        for col, time_value in enumerate(TIMES):
            index = nearest_time(history, time_value)
            values = np.maximum(np.asarray(history["Te"][index], dtype=float) - 1.0, 0.0)[:, :, ETA_INDEX]
            ax = axes[row, col]
            ax.pcolormesh(physical_corners(radius).T, physical_corners(z).T, values.T, cmap="magma", vmin=0.0, vmax=scales[time_value], shading="flat", rasterized=True)
            for contour_r, contour_z in contours:
                ax.plot(contour_r, contour_z, color="black", linewidth=0.32, alpha=0.35)
            ax.set_aspect("equal", adjustable="box")
            ax.grid(alpha=0.12, linewidth=0.3)
            if row == 0:
                ax.set_title(f"t={time_value:g}")
            if col == 0:
                ax.set_ylabel(f"{label}\nZ")
            if row == 3:
                ax.set_xlabel("R")
    fig.suptitle(r"Stored fine Te owner-expanded field, eta index 25 (positive $\Delta T_e$; interpolated cell geometry)")
    for col, time_value in enumerate(TIMES):
        mappable = plt.cm.ScalarMappable(cmap="magma", norm=plt.Normalize(0.0, scales[time_value]))
        mappable.set_array([])
        fig.colorbar(mappable, ax=axes[:, col], label=r"positive $\Delta T_e$", shrink=0.74)
    path = OUT / "physical_poloidal_eta25.png"
    fig.savefig(path, dpi=170)
    plt.close(fig)
    return path


def save_physical_final(histories: dict[str, dict[str, np.ndarray]], contours: list[tuple[np.ndarray, np.ndarray]]) -> Path:
    scale = max(
        float(np.max(np.maximum(np.asarray(history["Te"][nearest_time(history, 25.0)], dtype=float) - 1.0, 0.0)))
        for history in histories.values()
    )
    fig, axes = plt.subplots(1, 4, figsize=(13.5, 3.8), sharex=True, sharey=True, layout="constrained")
    for ax, (label, history) in zip(axes, histories.items(), strict=True):
        positions = np.asarray(history["Cartesian_position"], dtype=float)[:, :, ETA_INDEX, :]
        radius = np.hypot(positions[..., 0], positions[..., 1])
        z = positions[..., 2]
        index = nearest_time(history, 25.0)
        values = np.maximum(np.asarray(history["Te"][index], dtype=float) - 1.0, 0.0)[:, :, ETA_INDEX]
        ax.pcolormesh(physical_corners(radius).T, physical_corners(z).T, values.T, cmap="magma", vmin=0.0, vmax=scale, shading="flat", rasterized=True)
        for contour_r, contour_z in contours:
            ax.plot(contour_r, contour_z, color="black", linewidth=0.35, alpha=0.38)
        ax.set_title(label)
        ax.set_aspect("equal", adjustable="box")
        ax.set_xlabel("R")
        ax.grid(alpha=0.12, linewidth=0.3)
    axes[0].set_ylabel("Z")
    fig.suptitle(r"Final physical poloidal field, eta index 25 ($\Delta T_e$; shared scale; interpolated cell geometry)")
    mappable = plt.cm.ScalarMappable(cmap="magma", norm=plt.Normalize(0.0, scale))
    mappable.set_array([])
    fig.colorbar(mappable, ax=axes, label=r"positive $\Delta T_e$", shrink=0.84)
    path = OUT / "physical_poloidal_eta25_final.png"
    fig.savefig(path, dpi=190)
    plt.close(fig)
    return path


def save_logical(histories: dict[str, dict[str, np.ndarray]], scales: dict[float, float] | float, *, negative: bool = False) -> Path:
    cmap = "Blues_r" if negative else "magma"
    fig, axes = plt.subplots(4, 4, figsize=(13.5, 10.5), sharex=True, sharey=True, layout="constrained")
    for row, (label, history) in enumerate(histories.items()):
        u = np.asarray(history["u"], dtype=float)
        theta = np.asarray(history["theta"], dtype=float)
        for col, time_value in enumerate(TIMES):
            index = nearest_time(history, time_value)
            values = np.asarray(history["Te"][index], dtype=float)[:, :, ETA_INDEX] - 1.0
            if negative:
                values = np.where(values < 0.0, values, np.nan)
                vmin, vmax = -float(scales), 0.0
            else:
                values = np.maximum(values, 0.0)
                vmin, vmax = 0.0, float(scales[time_value])
            u_edges = cell_edges(u, 1.0)
            theta_edges = cell_edges(theta, 2.0 * np.pi)
            ax = axes[row, col]
            ax.imshow(values.T, origin="lower", extent=(u_edges[0], u_edges[-1], theta_edges[0], theta_edges[-1]), aspect="auto", cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            ax.axvline(Q_BOUNDARY, color="black", linewidth=0.75, linestyle="--")
            if row == 0:
                ax.set_title(f"t={time_value:g}")
            if col == 0:
                ax.set_ylabel(f"{label}\n$\theta$")
            if row == 3:
                ax.set_xlabel("u")
    title = r"Negative $\Delta T_e$ only, eta index 25" if negative else r"Positive logical field, eta index 25"
    fig.suptitle(title + r"; q=2$\rightarrow$q=1 at u=0.34375")
    if negative:
        mappable = plt.cm.ScalarMappable(cmap=cmap, norm=plt.Normalize(vmin, vmax))
        mappable.set_array([])
        fig.colorbar(mappable, ax=axes, label=r"negative $\Delta T_e$", shrink=0.76)
    else:
        for col, time_value in enumerate(TIMES):
            mappable = plt.cm.ScalarMappable(cmap=cmap, norm=plt.Normalize(0.0, float(scales[time_value])))
            mappable.set_array([])
            fig.colorbar(mappable, ax=axes[:, col], label=r"positive $\Delta T_e$", shrink=0.74)
    path = OUT / ("logical_negative_eta25.png" if negative else "logical_eta25.png")
    fig.savefig(path, dpi=170)
    plt.close(fig)
    return path


def weighted_mass_width(history: dict[str, np.ndarray], raw_volume: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    delta = np.asarray(history["Te"], dtype=float) - 1.0
    u = np.asarray(history["u"], dtype=float)[:, None, None]
    mass = np.sum(raw_volume[None, ...] * delta, axis=(1, 2, 3))
    positive = np.maximum(delta, 0.0)
    norm = np.sum(raw_volume[None, ...] * positive, axis=(1, 2, 3))
    centroid = np.sum(raw_volume[None, ...] * positive * u, axis=(1, 2, 3)) / np.maximum(norm, np.finfo(float).tiny)
    width = np.sqrt(np.sum(raw_volume[None, ...] * positive * (u - centroid[:, None, None, None]) ** 2, axis=(1, 2, 3)) / np.maximum(norm, np.finfo(float).tiny))
    return mass, width


def save_global(histories: dict[str, dict[str, np.ndarray]], raw_volume: np.ndarray) -> tuple[Path, dict[str, object]]:
    fig, axes = plt.subplots(2, 2, figsize=(11.5, 7.8), sharex=True, layout="constrained")
    metrics: dict[str, object] = {"raw_volume_sum": float(raw_volume.sum()), "cases": {}}
    for label, history in histories.items():
        delta = np.asarray(history["Te"], dtype=float) - 1.0
        mass, width = weighted_mass_width(history, raw_volume)
        initial_mass = mass[0]
        finite = np.isfinite(delta).all(axis=(1, 2, 3))
        metrics["cases"][label] = {
            "mass_fraction": (mass / initial_mass).tolist(),
            "mass_loss_percent_final": float(100.0 * (mass[-1] / initial_mass - 1.0)),
            "min_deltaTe": float(np.min(delta)),
            "max_deltaTe": float(np.max(delta)),
            "final_min_deltaTe": float(np.min(delta[-1])),
            "final_max_deltaTe": float(np.max(delta[-1])),
            "width_u_final": float(width[-1]),
            "all_finite": bool(np.all(finite)),
        }
        axes[0, 0].plot(history["times"], mass / initial_mass, label=label)
        axes[0, 1].plot(history["times"], np.min(delta, axis=(1, 2, 3)), label=label)
        axes[1, 0].plot(history["times"], np.max(delta, axis=(1, 2, 3)), label=label)
        axes[1, 1].plot(history["times"], width, label=label)
    axes[0, 0].set_ylabel("raw-volume mass / initial")
    axes[0, 1].set_ylabel("global min $\\Delta T_e$")
    axes[1, 0].set_ylabel("global max $\\Delta T_e$")
    axes[1, 1].set_ylabel("positive-pulse width in u")
    for ax in axes.flat:
        ax.grid(alpha=0.25)
        ax.set_xlabel("t")
    axes[0, 0].legend(fontsize=8, frameon=False)
    fig.suptitle("Global raw-volume diagnostics; stored fine fields")
    path = OUT / "global_curves.png"
    fig.savefig(path, dpi=170)
    plt.close(fig)
    metrics["times"] = np.asarray(next(iter(histories.values()))["times"]).tolist()
    (OUT / "metrics.json").write_text(json.dumps(metrics, indent=2, sort_keys=True) + "\n")
    return path, metrics


def save_core_negative(history: dict[str, np.ndarray], scale: float) -> Path:
    eta_index = 15
    requested = (10.5, 25.0)
    local_scale = max(
        float(-np.nanmin(np.asarray(history["Te"][nearest_time(history, t)], dtype=float)[:, :, eta_index] - 1.0))
        for t in requested
    )
    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.0), sharex=True, sharey=True, layout="constrained")
    u = np.asarray(history["u"])
    theta = np.asarray(history["theta"])
    for ax, time_value in zip(axes, requested, strict=True):
        index = nearest_time(history, time_value)
        values = np.asarray(history["Te"][index], dtype=float)[:, :, eta_index] - 1.0
        values = np.where(values < 0.0, values, np.nan)
        u_edges = cell_edges(u, 1.0)
        theta_edges = cell_edges(theta, 2.0 * np.pi)
        ax.imshow(values.T, origin="lower", extent=(u_edges[0], u_edges[-1], theta_edges[0], theta_edges[-1]), aspect="auto", cmap="Blues_r", vmin=-local_scale, vmax=0.0, interpolation="nearest")
        ax.axvline(Q_BOUNDARY, color="black", linewidth=0.75, linestyle="--")
        minimum = np.unravel_index(np.nanargmin(values), values.shape)
        ax.plot(u[minimum[0]], theta[minimum[1]], marker="x", color="red", markersize=6)
        ax.set_title(f"t={time_value:g}, eta index {eta_index}")
        ax.set_xlabel("u")
        ax.grid(alpha=0.15)
    axes[0].set_ylabel(r"$\theta$")
    fig.suptitle(r"New paired: local negative $\Delta T_e$; q=2$\rightarrow$q=1 at u=0.34375")
    mappable = plt.cm.ScalarMappable(cmap="Blues_r", norm=plt.Normalize(-local_scale, 0.0))
    mappable.set_array([])
    fig.colorbar(mappable, ax=axes, label=r"negative $\Delta T_e$", shrink=0.83)
    path = OUT / "new_paired_core_negative_eta15.png"
    fig.savefig(path, dpi=180)
    plt.close(fig)
    return path


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    histories = {label: load_history(path) for label, path in CASES.items()}
    host = load_host()
    raw_volume = np.asarray(host["host_raw_volume"], dtype=float)
    if raw_volume.shape != (N, N, N) or np.any(~np.isfinite(raw_volume)) or np.any(raw_volume <= 0.0):
        raise ValueError("raw host volume is not finite and positive")
    poincare = verify_poincare()
    contours = physical_contours(histories["legacy"], CASES["legacy"] / "makegrid_poincare_theta_u.npz")
    scales = positive_scales(histories)
    negative_scale = max(
        float(-np.min(np.asarray(history["Te"], dtype=float) - 1.0))
        for history in histories.values()
    )
    paths = {
        "physical": str(save_physical(histories, contours, scales)),
        "physical_final": str(save_physical_final(histories, contours)),
        "logical": str(save_logical(histories, scales)),
        "logical_negative": str(save_logical(histories, negative_scale, negative=True)),
        "global": str(save_global(histories, raw_volume)[0]),
        "core_negative": str(save_core_negative(histories["new paired"], negative_scale)),
    }
    summary = {
        "cases": {label: str(path) for label, path in CASES.items()},
        "history_field": "stored Te fine-grid owner-expanded average; no H-prolongation",
        "physical_weight": str(HOST),
        "eta_index": ETA_INDEX,
        "q_boundary_u": Q_BOUNDARY,
        "positive_scales_by_time": scales,
        "negative_scale_all_cases": negative_scale,
        "poincare": poincare,
        "plots": paths,
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
