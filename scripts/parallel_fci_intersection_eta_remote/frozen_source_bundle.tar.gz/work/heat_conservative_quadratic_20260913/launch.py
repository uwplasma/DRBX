"""Launch conservative-quadratic HSX cases after three-step smoke gates.

Processes are detached with bounded BLAS/OpenMP threads and append-only logs.
This script performs duplicate and overwrite checks before every launch.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[1]
CONTROLS = ("paired", "volume")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--smoke", action="store_true", help="launch three-step gates")
    result.add_argument("--control", choices=("paired", "volume", "legacy"), action="append")
    result.add_argument("--legacy-control", action="store_true", help="launch the optional native legacy gate")
    result.add_argument("--resolution", type=int, choices=(32, 64), action="append")
    result.add_argument("--steps", type=int, default=None)
    result.add_argument("--final-time", type=float, default=None)
    return result


def read_status(path: Path) -> dict[str, object] | None:
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return None


def atomic_json(path: Path, value: object) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def _case(cases: list[dict[str, object]], resolution: int, control: str) -> dict[str, object]:
    matches = [item for item in cases if int(item["resolution"]) == resolution and item["control"] == control]
    if control == "legacy":
        # Legacy is an optional smoke comparison and reuses the paired case's
        # frozen geometry/host references.
        matches = [item for item in cases if int(item["resolution"]) == resolution and item["control"] == "paired"]
    if len(matches) != 1:
        raise SystemExit(f"expected one case for resolution={resolution}, control={control}; found {len(matches)}")
    return matches[0]


def _output(case: dict[str, object], resolution: int, control: str, smoke: bool) -> Path:
    if smoke:
        return RUN / f"smoke{resolution}_{control}"
    if control == "legacy":
        return ROOT / (
            f"prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_"
            f"{resolution}x{resolution}x32_conservative_quadratic_legacy_t25_20260913"
        )
    return Path(str(case["output"])).resolve()


def _guard_output(output: Path) -> None:
    if not output.exists():
        return
    forbidden = {
        "process_status.json", "history.npz", "metadata.json",
        "geometry_verification.json", "rlp_geometry_verification.json",
        "launch.json", "run.log", "preflight_metadata.json",
    }
    present = sorted(name for name in forbidden if (output / name).exists())
    if present:
        raise SystemExit(f"refusing duplicate or overwrite of {output}: {present}")
    if read_status(output / "process_status.json") is not None:
        raise SystemExit(f"refusing output with existing status: {output}")


def main() -> None:
    opts = parser().parse_args()
    manifest = RUN / "cases.json"
    if not manifest.exists():
        raise SystemExit(f"missing case manifest: {manifest}; run prepare.py after review")
    cases = json.loads(manifest.read_text())
    resolutions = opts.resolution or [32, 64]
    if opts.control:
        controls = list(dict.fromkeys(opts.control))
    elif opts.legacy_control:
        controls = ["legacy"]
    elif opts.smoke:
        controls = list(CONTROLS)
    else:
        controls = ["paired"]
    if not opts.smoke and "legacy" in controls:
        raise SystemExit("legacy is an optional smoke gate; full launch controls are paired and volume")
    if not opts.smoke and controls != ["paired"]:
        raise SystemExit("full launch is reserved for the paired conservative-quadratic control")
    if opts.steps is not None and opts.steps < 1:
        raise SystemExit("--steps must be positive")
    if opts.final_time is not None and opts.final_time <= 0.0:
        raise SystemExit("--final-time must be positive")

    selected: list[tuple[dict[str, object], int, str, Path]] = []
    seen: set[str] = set()
    for resolution in resolutions:
        for control in controls:
            case = _case(cases, resolution, control)
            output = _output(case, resolution, control, opts.smoke)
            if str(output) in seen:
                raise SystemExit(f"duplicate selected output: {output}")
            seen.add(str(output))
            selected.append((case, resolution, control, output))

    if not opts.smoke:
        for resolution in resolutions:
            for control in CONTROLS:
                smoke_status = read_status(RUN / f"smoke{resolution}_{control}" / "process_status.json")
                if not smoke_status or smoke_status.get("state") != "completed" or smoke_status.get("steps") != 3 or smoke_status.get("mode") != control:
                    raise SystemExit(f"three-step smoke gate is incomplete for {resolution} {control}")

    launched: list[dict[str, object]] = []
    for case, resolution, control, output in selected:
        _guard_output(output)
        output.mkdir(parents=True, exist_ok=True)
        command = [sys.executable, "-u", str(RUN / "run_case.py"), str(resolution), "--control", control]
        if opts.smoke:
            command.append("--smoke")
        if opts.steps is not None:
            command += ["--steps", str(opts.steps)]
        if opts.final_time is not None:
            command += ["--final-time", str(opts.final_time)]
        log = output / "run.log"
        env = os.environ.copy()
        env.update({
            "DRBX_CACHE_DIR": str(RUN / "jax_cache"),
            "DRBX_HOST_DEVICE_COUNT": "1",
            "OMP_NUM_THREADS": "4",
            "OPENBLAS_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1",
            "NUMEXPR_NUM_THREADS": "1",
            "PYTHONUNBUFFERED": "1",
        })
        env.pop("DRBX_SOURCE_ROOT", None)
        with log.open("ab", buffering=0) as stream:
            process = subprocess.Popen(
                command,
                stdin=subprocess.DEVNULL,
                stdout=stream,
                stderr=subprocess.STDOUT,
                cwd=ROOT,
                env=env,
                start_new_session=True,
            )
        record = {
            "resolution": resolution,
            "control": control,
            "pid": process.pid,
            "command": command,
            "log": str(log),
            "output": str(output),
            "source": str(case["source"]),
            "launched_at": time.time(),
        }
        atomic_json(output / "launch.json", record)
        launched.append(record)
    atomic_json(RUN / f"launch_{'smoke' if opts.smoke else 'full'}_{int(time.time())}.json", launched)
    print(json.dumps(launched, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
