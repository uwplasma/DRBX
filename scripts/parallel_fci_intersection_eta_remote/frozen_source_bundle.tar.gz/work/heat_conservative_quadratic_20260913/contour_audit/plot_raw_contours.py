"""Audit saved raw Poincare traces against their fitted contour curves.

The audit deliberately uses only the completed run-owned
``makegrid_poincare_theta_u.npz`` artifact. The main panels use the regular
logical chart ``X = u cos(theta), Y = u sin(theta)``; they do not claim to be
physical R/Z contours or retrace the magnetic field.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
RUN = ROOT / "prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_conservative_quadratic_t25_20260913"
CONTOUR_PATH = RUN / "makegrid_poincare_theta_u.npz"
ETA_INDICES = (21, 15)
SEED_INDICES = (0, 1, 2)
CORE_SEED = 0


def load_contours(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        required = {
            "eta",
            "seed_u",
            "traces_theta_u",
            "valid_counts",
            "contour_theta",
            "contour_u",
            "valid_surfaces",
        }
        missing = sorted(required.difference(archive.files))
        if missing:
            raise ValueError(f"contour artifact is missing {missing}: {path}")
        result = {name: np.asarray(archive[name]).copy() for name in required}
    traces = result["traces_theta_u"]
    if traces.ndim != 4 or traces.shape[-1] != 2:
        raise ValueError(f"unexpected raw trace shape: {traces.shape}")
    if result["contour_u"].shape[:2] != traces.shape[:2]:
        raise ValueError("fitted contour and raw trace eta/seed shapes differ")
    if result["valid_counts"].shape != traces.shape[:2]:
        raise ValueError("valid_counts does not match raw trace eta/seed shape")
    if not np.all(np.isfinite(result["eta"])):
        raise ValueError("eta planes contain non-finite values")
    return result


def _finite_raw(trace: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    values = np.asarray(trace, dtype=np.float64)
    mask = np.all(np.isfinite(values), axis=1)
    return values[mask, 0], values[mask, 1]


def _circular_gaps(theta: np.ndarray) -> np.ndarray:
    angles = np.sort(np.mod(np.asarray(theta, dtype=np.float64), 2.0 * np.pi))
    if angles.size < 2:
        return np.array([], dtype=np.float64)
    return np.diff(np.concatenate((angles, angles[:1] + 2.0 * np.pi)))


def _fit_periodic(theta_query: np.ndarray, fit_theta: np.ndarray, fit_u: np.ndarray) -> np.ndarray:
    fit_theta = np.mod(np.asarray(fit_theta, dtype=np.float64), 2.0 * np.pi)
    fit_u = np.asarray(fit_u, dtype=np.float64)
    if fit_theta.ndim != 1 or fit_u.ndim != 1 or fit_theta.size != fit_u.size:
        raise ValueError("fitted contour theta/u arrays must be one-dimensional and aligned")
    order = np.argsort(fit_theta)
    fit_theta = fit_theta[order]
    fit_u = fit_u[order]
    extended_theta = np.concatenate((fit_theta[-1:] - 2.0 * np.pi, fit_theta, fit_theta[:1] + 2.0 * np.pi))
    extended_u = np.concatenate((fit_u[-1:], fit_u, fit_u[:1]))
    query = np.mod(np.asarray(theta_query, dtype=np.float64), 2.0 * np.pi)
    return np.interp(query, extended_theta, extended_u)


def _xy(u: np.ndarray, theta: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    return np.asarray(u) * np.cos(theta), np.asarray(u) * np.sin(theta)


def trace_shape_metrics(
    artifact: dict[str, np.ndarray], eta_index: int, seed_index: int
) -> dict[str, object]:
    raw_u, raw_theta = _finite_raw(artifact["traces_theta_u"][eta_index, seed_index])
    if raw_u.size == 0:
        raise ValueError(f"eta {eta_index}, seed {seed_index} has no finite raw trace points")
    fit_theta = np.asarray(artifact["contour_theta"], dtype=np.float64) * 2.0 * np.pi
    fit_u = np.asarray(artifact["contour_u"][eta_index, seed_index], dtype=np.float64)
    fit_finite = np.isfinite(fit_theta) & np.isfinite(fit_u)
    if np.count_nonzero(fit_finite) < 3:
        raise ValueError(f"eta {eta_index}, seed {seed_index} has too few finite fitted points")
    fit_theta = fit_theta[fit_finite]
    fit_u = fit_u[fit_finite]
    gaps = _circular_gaps(raw_theta)
    nearest = np.minimum(gaps, np.roll(gaps, 1)) if gaps.size else gaps
    fit_at_raw = _fit_periodic(raw_theta, fit_theta, fit_u)
    residual = raw_u - fit_at_raw
    raw_x, raw_y = _xy(raw_u, raw_theta)
    fit_x, fit_y = _xy(fit_u, fit_theta)
    valid_count = int(artifact["valid_counts"][eta_index, seed_index])
    return {
        "eta_index": int(eta_index),
        "seed_index": int(seed_index),
        "seed_u": float(artifact["seed_u"][seed_index]),
        "raw_point_count": int(raw_u.size),
        "saved_valid_count": valid_count,
        "raw_nan_or_invalid_point_count": int(artifact["traces_theta_u"].shape[2] - raw_u.size),
        "raw_theta_range_rad": [float(np.min(np.mod(raw_theta, 2.0 * np.pi))), float(np.max(np.mod(raw_theta, 2.0 * np.pi)))],
        "raw_u_range": [float(np.min(raw_u)), float(np.max(raw_u))],
        "fit_u_range": [float(np.min(fit_u)), float(np.max(fit_u))],
        "angular_max_gap_deg": float(np.max(gaps) * 180.0 / np.pi) if gaps.size else None,
        "nearest_angle_spacing_deg": {
            "min": float(np.min(nearest) * 180.0 / np.pi) if nearest.size else None,
            "median": float(np.median(nearest) * 180.0 / np.pi) if nearest.size else None,
            "max": float(np.max(nearest) * 180.0 / np.pi) if nearest.size else None,
        },
        "fit_raw_residual_u": {
            "rmse": float(np.sqrt(np.mean(residual**2))),
            "mean_abs": float(np.mean(np.abs(residual))),
            "max_abs": float(np.max(np.abs(residual))),
            "signed_min": float(np.min(residual)),
            "signed_max": float(np.max(residual)),
        },
        "raw_xy_centroid": [float(np.mean(raw_x)), float(np.mean(raw_y))],
        "fit_xy_centroid": [float(np.mean(fit_x)), float(np.mean(fit_y))],
        "xy_centroid_difference": [float(np.mean(raw_x) - np.mean(fit_x)), float(np.mean(raw_y) - np.mean(fit_y))],
        "raw_radius_mean": float(np.mean(raw_u)),
        "fit_radius_mean": float(np.mean(fit_u)),
        "shape_comparison_note": "fit residual is evaluated at every finite raw theta using periodic interpolation; large angular gaps or multi-valued raw radial samples can make a single fitted graph misleading",
    }


def core_quarter_drift(artifact: dict[str, np.ndarray], eta_index: int) -> dict[str, object]:
    trace = np.asarray(artifact["traces_theta_u"][eta_index, CORE_SEED], dtype=np.float64)
    turns = trace.shape[0]
    quarter_edges = np.linspace(0, turns, 5, dtype=int)
    quarters = []
    previous_centroid = None
    for quarter in range(4):
        chunk = trace[quarter_edges[quarter] : quarter_edges[quarter + 1]]
        finite = np.all(np.isfinite(chunk), axis=1)
        chunk = chunk[finite]
        if chunk.size == 0:
            quarters.append({"quarter": quarter + 1, "turn_range": [int(quarter_edges[quarter]), int(quarter_edges[quarter + 1])], "point_count": 0})
            continue
        x, y = _xy(chunk[:, 0], chunk[:, 1])
        centroid = np.array([np.mean(x), np.mean(y)])
        quarters.append(
            {
                "quarter": quarter + 1,
                "turn_range": [int(quarter_edges[quarter]), int(quarter_edges[quarter + 1])],
                "point_count": int(chunk.shape[0]),
                "radial_mean": float(np.mean(chunk[:, 0])),
                "radial_min": float(np.min(chunk[:, 0])),
                "radial_max": float(np.max(chunk[:, 0])),
                "xy_centroid": centroid.tolist(),
                "xy_centroid_drift_from_previous": None if previous_centroid is None else float(np.linalg.norm(centroid - previous_centroid)),
            }
        )
        previous_centroid = centroid
    return {
        "eta_index": int(eta_index),
        "seed_index": CORE_SEED,
        "definition": "raw trajectory divided into four equal saved-turn quarters",
        "quarters": quarters,
    }


def plot_raw_vs_fit(artifact: dict[str, np.ndarray], output: Path) -> dict[str, object]:
    figure, axes = plt.subplots(2, 3, figsize=(13.5, 8.4), sharex=True, sharey=True, layout="constrained")
    scatter = None
    for row, eta_index in enumerate(ETA_INDICES):
        for col, seed_index in enumerate(SEED_INDICES):
            axis = axes[row, col]
            raw_u, raw_theta = _finite_raw(artifact["traces_theta_u"][eta_index, seed_index])
            turns = np.flatnonzero(np.all(np.isfinite(artifact["traces_theta_u"][eta_index, seed_index]), axis=1))
            scatter = axis.scatter(*_xy(raw_u, raw_theta), c=turns, s=3.0, cmap="viridis", alpha=0.55, linewidths=0, rasterized=True)
            fit_theta = np.asarray(artifact["contour_theta"], dtype=np.float64) * 2.0 * np.pi
            fit_u = np.asarray(artifact["contour_u"][eta_index, seed_index], dtype=np.float64)
            finite = np.isfinite(fit_theta) & np.isfinite(fit_u)
            fit_x, fit_y = _xy(fit_u[finite], fit_theta[finite])
            axis.plot(fit_x, fit_y, color="crimson", linewidth=1.15, label="fit")
            # The inset makes the fitted graph and any raw multi-valued/gapped
            # theta sampling visible without replacing the regular XY chart.
            inset = axis.inset_axes((0.05, 0.05, 0.43, 0.28))
            inset.scatter(np.mod(raw_theta, 2.0 * np.pi) / (2.0 * np.pi), raw_u, c=turns, s=1.0, cmap="viridis", alpha=0.4, linewidths=0)
            # Keep the saved contour coordinate in [0, 1] here.  Applying
            # modulo to the 2π endpoint maps it back to zero and draws an
            # artificial horizontal closing segment in the inset.
            fit_theta_fraction = np.asarray(artifact["contour_theta"], dtype=np.float64)[finite]
            inset.plot(fit_theta_fraction, fit_u[finite], color="crimson", linewidth=0.55)
            inset.set_xlim(0.0, 1.0)
            inset.set_title("u(θ)", fontsize=7)
            inset.tick_params(labelsize=6)
            metrics = trace_shape_metrics(artifact, eta_index, seed_index)
            axis.set_title(f"eta {eta_index}, seed {seed_index}\nmax gap {metrics['angular_max_gap_deg']:.1f}°; max |res| {metrics['fit_raw_residual_u']['max_abs']:.4g}")
            axis.set_aspect("equal", adjustable="box")
            axis.grid(alpha=0.18, linewidth=0.35)
            axis.set_xlabel("X = u cos θ")
            if col == 0:
                axis.set_ylabel("Y = u sin θ")
    if scatter is not None:
        figure.colorbar(scatter, ax=axes, label="raw trace turn", shrink=0.82)
    figure.suptitle("Saved raw Poincaré traces versus fitted contours in the regular logical chart")
    figure.savefig(output, dpi=190, facecolor="white")
    plt.close(figure)
    return {"path": str(output), "coordinate_chart": "X=u cos(theta), Y=u sin(theta)", "raw_points_color": "saved trace turn", "fit_style": "crimson curve", "panels": [[{"eta_index": int(eta), "seed_index": int(seed)} for seed in SEED_INDICES] for eta in ETA_INDICES]}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    artifact = load_contours(CONTOUR_PATH)
    shape_metrics = [trace_shape_metrics(artifact, eta, seed) for eta in ETA_INDICES for seed in SEED_INDICES]
    summary = {
        "source_artifact": str(CONTOUR_PATH),
        "source_history": str(RUN / "history.npz"),
        "eta_indices": list(ETA_INDICES),
        "seed_indices": list(SEED_INDICES),
        "core_seed_index": CORE_SEED,
        "raw_trace_shape": list(artifact["traces_theta_u"].shape),
        "fit_shape": list(artifact["contour_u"].shape),
        "valid_surfaces_selected": {str(eta): [bool(value) for value in artifact["valid_surfaces"][eta, list(SEED_INDICES)]] for eta in ETA_INDICES},
        "shape_metrics": shape_metrics,
        "core_quarter_turn_drift": [core_quarter_drift(artifact, eta) for eta in ETA_INDICES],
        "plot": plot_raw_vs_fit(artifact, OUT / "raw_vs_fit.png"),
        "interpretation": {
            "coordinates": "regular logical planar X=u cos(theta), Y=u sin(theta); not physical R/Z",
            "raw_trace": "raw saved theta/u points are plotted with their saved turn index; NaN points are omitted",
            "fit_comparison": "periodic interpolation evaluates fitted u at each finite raw theta; this can expose a non-graph-like raw trace through residuals and angular gaps",
            "centroid_drift": "core-seed drift is grouped by four equal saved-turn quarters, not inferred from an assumed physical orbit",
        },
    }
    output = OUT / "summary.json"
    output.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "plot": summary["plot"], "shape_metrics": shape_metrics}, indent=2))


if __name__ == "__main__":
    main()
