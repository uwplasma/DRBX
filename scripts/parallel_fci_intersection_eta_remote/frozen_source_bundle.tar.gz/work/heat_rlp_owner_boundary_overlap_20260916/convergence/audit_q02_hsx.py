"""Localize owner-overlap diffusion error on one real-HSX artifact."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from drbx.geometry.fci_simulation_geometry import load_fci_simulation_geometry
from drbx.native.fci_rlp_overlap import assemble_rlp_parallel_overlap_generator, lower_rlp_parallel_overlap_geometry
from mms import ManufacturedField, aggregate_owner_means, load_source_reference, weighted_l2_linf


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--geometry", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser


def main() -> int:
    options = _parser().parse_args()
    artifact = load_fci_simulation_geometry(options.geometry.resolve())
    shape = tuple(int(value) for value in artifact.geometry.shape)
    n = shape[0]
    host_graph = artifact.owner_overlap
    graph = lower_rlp_parallel_overlap_geometry(host_graph)
    owner_ids = np.asarray(graph.owner_flat_ids, dtype=np.int64)
    owner_volume = np.asarray(graph.owner_volume, dtype=np.float64)
    owner_map = np.asarray(artifact.polar_angular_geometry.topology.aggregate_id, dtype=np.int64)
    raw_volume = np.asarray(artifact.polar_angular_geometry.raw_volume, dtype=np.float64)
    lookup = np.full(max(int(owner_map.max()), int(owner_ids.max())) + 1, -1, dtype=np.int64)
    lookup[owner_ids] = np.arange(owner_ids.size)
    compact = lookup[owner_map.ravel()]
    owner_size = np.bincount(compact, minlength=owner_ids.size)
    radial_index = np.broadcast_to(np.arange(n)[:, None, None], shape).ravel()
    owner_radial = np.bincount(compact, weights=radial_index, minlength=owner_ids.size) / owner_size
    eta_index = np.broadcast_to(np.arange(shape[2])[None, None, :], shape).ravel()
    owner_eta = np.rint(np.bincount(compact, weights=eta_index, minlength=owner_ids.size) / owner_size).astype(np.int64)
    region = np.full(owner_ids.size, "ordinary_interior", dtype="U24")
    region[owner_size > 1] = "rlp_transition"
    region[owner_radial <= 1.5] = "axis"
    region[owner_radial >= n - 2.5] = "boundary"
    region_names = ("axis", "rlp_transition", "ordinary_interior", "boundary")
    report = {
        "shape": list(shape),
        "geometry": str(options.geometry.resolve()),
        "topology": {
            "owners": int(graph.n_owner),
            "links": int(graph.n_link),
            "owner_size_min_median_max": [int(np.min(owner_size)), float(np.median(owner_size)), int(np.max(owner_size))],
            "region_owner_counts": {name: int(np.sum(region == name)) for name in region_names},
            "interface_count": int(np.unique(np.asarray(host_graph.link_interface)).size),
        },
        "producer_overlap_diagnostics": host_graph.diagnostics,
        "fields": {},
    }
    for kind in ("radial_eta", "angular_x", "mixed_y_eta", "constant"):
        source_root = options.source_root / kind / str(n)
        source = load_source_reference(source_root, artifact.geometry, shape)
        meta = source["manifest"]["field"]
        field = ManufacturedField(m=int(meta["m"]), amplitude=float(meta["amplitude"]), lam=float(meta["lambda"]), chi=float(meta["chi"]), eta_period=float(meta["eta_period"]), radial_profile=meta.get("radial_profile", "smooth_axis"), field_kind=meta.get("field_kind", kind))
        raw_initial = np.asarray(source["initial"], dtype=np.float64)
        initial = aggregate_owner_means(raw_initial, raw_volume, owner_map, owner_volume, owner_ids)
        exact_rhs = aggregate_owner_means(np.asarray(source["time_derivative0"]), raw_volume, owner_map, owner_volume, owner_ids)
        owner_source = aggregate_owner_means(np.asarray(source["source0"]), raw_volume, owner_map, owner_volume, owner_ids)
        matrix = assemble_rlp_parallel_overlap_generator(graph, field.chi)
        discrete_diffusion = np.asarray(matrix @ initial).reshape(-1)
        continuum_diffusion = exact_rhs - owner_source
        residual = discrete_diffusion + owner_source - exact_rhs
        denominator = float(np.sum(owner_volume * discrete_diffusion * discrete_diffusion))
        best_scale = float(np.sum(owner_volume * discrete_diffusion * continuum_diffusion) / denominator) if denominator > np.finfo(float).tiny else 1.0
        scaled_residual = best_scale * discrete_diffusion - continuum_diffusion
        representation = raw_initial.ravel() - initial[compact]
        total_squared = float(np.sum(owner_volume * residual * residual))
        regional = {}
        for name in region_names:
            mask = region == name
            squared = float(np.sum(owner_volume[mask] * residual[mask] ** 2))
            regional[name] = {
                "physical_volume": float(np.sum(owner_volume[mask])),
                "residual": weighted_l2_linf(residual[mask], owner_volume[mask]),
                "global_squared_error_fraction": squared / max(total_squared, np.finfo(float).tiny),
            }
        a = np.asarray(graph.link_owner_a, dtype=np.int64)
        b = np.asarray(graph.link_owner_b, dtype=np.int64)
        link_flux = field.chi * np.asarray(graph.transmissibility) * (initial[b] - initial[a])
        interfaces = np.asarray(host_graph.link_interface, dtype=np.int64)
        interface_budget = {}
        for interface in np.unique(interfaces):
            mask = interfaces == interface
            interface_budget[str(int(interface))] = {"links": int(np.sum(mask)), "integrated_flux_L1": float(np.sum(np.abs(link_flux[mask]))), "integrated_flux_signed": float(np.sum(link_flux[mask]))}
        eta_residual = []
        for plane in range(shape[2]):
            mask = owner_eta == plane
            eta_residual.append(weighted_l2_linf(residual[mask], owner_volume[mask])["L2"])
        diagnostics_by_interface = {int(record["interface"]): record for record in host_graph.diagnostics.get("interfaces", []) if record.get("direction") == "forward"}
        mismatch = np.asarray([diagnostics_by_interface[k].get("forward_backward_conductance_mismatch", 0.0) for k in range(shape[2])])
        closure = np.asarray([max(record.get("max_relative_closure_error", 0.0) for record in host_graph.diagnostics.get("interfaces", []) if int(record["interface"]) == k) for k in range(shape[2])])
        adjacent_mismatch = 0.5 * (mismatch + np.roll(mismatch, 1))
        adjacent_closure = np.maximum(closure, np.roll(closure, 1))
        def correlation(values):
            return float(np.corrcoef(np.asarray(eta_residual), values)[0, 1]) if np.std(values) > 0.0 and np.std(eta_residual) > 0.0 else 0.0
        report["fields"][kind] = {
            "formula": field.formula,
            "owner_representation_raw_L2": weighted_l2_linf(representation, raw_volume),
            "completed_residual": weighted_l2_linf(residual, owner_volume),
            "positive_global_conductance_scale_control": {"best_scale": best_scale, "residual": weighted_l2_linf(scaled_residual, owner_volume), "preserves_graph_sign_structure": bool(best_scale > 0.0)},
            "regional_completed_residual": regional,
            "integrated_link_flux": {"L1": float(np.sum(np.abs(link_flux))), "maximum": float(np.max(np.abs(link_flux), initial=0.0)), "interfaces": interface_budget},
            "integrated_flux_conservation_residual": float(abs(np.dot(owner_volume, discrete_diffusion))),
            "eta_plane_residual_L2": eta_residual,
            "eta_correlation": {"adjacent_forward_backward_conductance_mismatch": correlation(adjacent_mismatch), "adjacent_overlap_closure_error": correlation(adjacent_closure)},
        }
    options.output.parent.mkdir(parents=True, exist_ok=True)
    options.output.write_text(json.dumps(report, indent=2, sort_keys=True, default=float) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
