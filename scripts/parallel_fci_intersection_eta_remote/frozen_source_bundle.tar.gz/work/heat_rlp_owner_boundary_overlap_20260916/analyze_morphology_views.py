"""Compact logical/Cartesian audit for the lean t=0.5 morphology gate."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import run_owner_boundary_overlap as run  # noqa: E402


OUTPUT = ROOT / "outputs" / "morphology_t0p5"
METRIC_CACHE = (
    ROOT.parent / "heat_conservative_quadratic_20260913" / "metric_cache_32"
    / "hsx_metric_a70ddee0ce9aa336469e0e66.npz"
)


def isolated_extrema(field: np.ndarray, threshold: float = 1.0e-10) -> dict[str, int]:
    """Count strict four-neighbor extrema on each periodic-theta eta slice."""
    value = np.asarray(field, dtype=float)
    maxima = minima = 0
    for k in range(value.shape[2]):
        plane = value[:, :, k]
        for i in range(1, plane.shape[0] - 1):
            center = plane[i]
            neighbors = np.stack(
                (plane[i - 1], plane[i + 1], np.roll(center, 1), np.roll(center, -1))
            )
            maxima += int(np.count_nonzero((center > np.max(neighbors, axis=0) + threshold) & (center > threshold)))
            minima += int(np.count_nonzero(center < np.min(neighbors, axis=0) - threshold))
    return {"strict_positive_maxima": maxima, "strict_minima": minima}


def main() -> None:
    sanity, _ = run.support_harness._import_frozen_source()
    geometry, owner_host, _host, graph, _args = run._build_hsx_graph(sanity, None)
    lean = np.asarray(np.load(OUTPUT / "history.npz")["Te"][-1], dtype=float)

    def project(path: Path) -> np.ndarray:
        reference = run.support_harness._reference_at(path, 0.5)
        return run.support_harness._project_reference_to_owner_materialization(
            reference, owner_host, graph
        )

    fields = {
        "No RLP": project(run.NO_RLP_REFERENCE),
        "Legacy RLP": project(run.LEGACY_REFERENCE),
        "Conservative H": project(run.H_REFERENCE),
        "Owner support": project(run.OWNER_SUPPORT_REFERENCE),
        "Lean overlap": lean,
    }
    eta_index = int(np.unravel_index(np.argmax(lean - 1.0), lean.shape)[2])
    with np.load(METRIC_CACHE, allow_pickle=False) as metric:
        position = np.asarray(metric["cell_position"], dtype=float)
    xyz = position[:, :, eta_index]
    major_radius = np.hypot(xyz[..., 0], xyz[..., 1])
    vertical = xyz[..., 2]

    peak = max(float(np.max(value[:, :, eta_index] - 1.0)) for value in fields.values())
    figure, axes = plt.subplots(2, len(fields), figsize=(17, 7), constrained_layout=True)
    image = None
    for column, (name, value) in enumerate(fields.items()):
        delta = value[:, :, eta_index] - 1.0
        image = axes[0, column].imshow(
            delta,
            origin="lower",
            aspect="auto",
            cmap="magma",
            vmin=0.0,
            vmax=peak,
            interpolation="nearest",
        )
        axes[0, column].set_title(name)
        axes[0, column].set_xlabel(r"$\theta$ index")
        if column == 0:
            axes[0, column].set_ylabel(r"$u$ index")
        scatter = axes[1, column].scatter(
            major_radius.ravel(), vertical.ravel(), c=delta.ravel(),
            s=7, marker="s", linewidths=0, cmap="magma", vmin=0.0, vmax=peak,
        )
        axes[1, column].set_aspect("equal")
        axes[1, column].set_xlabel("R")
        if column == 0:
            axes[1, column].set_ylabel("Z")
    figure.colorbar(image, ax=axes, label=r"$\delta T_e$")
    figure.suptitle(f"t=0.5, eta index {eta_index}: logical and Cartesian sections")
    figure.savefig(OUTPUT / "logical_cartesian_comparison.png", dpi=180)
    plt.close(figure)

    baseline = fields["No RLP"]
    figure, axes = plt.subplots(1, len(fields) - 1, figsize=(14, 3.3), constrained_layout=True)
    differences = {name: value - baseline for name, value in fields.items() if name != "No RLP"}
    scale = max(float(np.max(np.abs(value[:, :, eta_index]))) for value in differences.values())
    image = None
    for axis, (name, difference) in zip(axes, differences.items(), strict=True):
        image = axis.imshow(
            difference[:, :, eta_index], origin="lower", aspect="auto",
            cmap="RdBu_r", vmin=-scale, vmax=scale, interpolation="nearest",
        )
        axis.set_title(name)
        axis.set_xlabel(r"$\theta$ index")
    axes[0].set_ylabel(r"$u$ index")
    figure.colorbar(image, ax=axes, label=r"$\delta T_e-\delta T_{e,\mathrm{no\ RLP}}$")
    figure.suptitle(f"t=0.5 difference from projected no-RLP, eta index {eta_index}")
    figure.savefig(OUTPUT / "difference_from_no_rlp.png", dpi=180)
    plt.close(figure)

    audit = {
        "eta_index": eta_index,
        "isolated_extrema": {
            name: isolated_extrema(value - 1.0) for name, value in fields.items()
        },
        "slice_l2_error_from_no_rlp": {
            name: float(np.sqrt(np.mean((value[:, :, eta_index] - baseline[:, :, eta_index]) ** 2)))
            for name, value in fields.items() if name != "No RLP"
        },
        "slice_linf_error_from_no_rlp": {
            name: float(np.max(np.abs(value[:, :, eta_index] - baseline[:, :, eta_index])))
            for name, value in fields.items() if name != "No RLP"
        },
    }
    (OUTPUT / "view_audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
