"""Build all 32 direct owner-boundary interfaces in recoverable subprocesses."""

from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np


ROOT = Path(__file__).resolve().parent
DRIVER = ROOT / "run_owner_boundary_overlap.py"
OUTPUT = ROOT / "outputs" / "interface_cache_sweep"
STATUS = OUTPUT / "process_status.json"
LOG = OUTPUT / "run.log"
CONSTRUCTION_MODE = "lean_second_order"
QUADRATURE_MODE = "centroid"
LEAN_CACHE_TEMPLATE = ROOT / "cache" / "hsx32_lean_interfaces_{interface}.npz"


def atomic_json(payload: object) -> None:
    temporary = STATUS.with_name(f".{STATUS.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, STATUS)


def log(event: str, **fields: object) -> None:
    with LOG.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps({"time": time.time(), "event": event, **fields}) + "\n")


def valid_lean_cache(interface: int, child_output: Path) -> bool:
    """Return true only for a completed child with an explicitly lean cache."""
    status_path = child_output / "process_status.json"
    cache_path = Path(str(LEAN_CACHE_TEMPLATE).format(interface=interface))
    if not status_path.is_file() or not cache_path.is_file():
        return False
    try:
        status = json.loads(status_path.read_text(encoding="utf-8"))
        if status.get("state") != "completed" or status.get("mode") != "interface-preflight":
            return False
        if status.get("construction_mode") != CONSTRUCTION_MODE or status.get("quadrature_mode") != QUADRATURE_MODE:
            return False
        with np.load(cache_path, allow_pickle=False) as payload:
            identity = json.loads(str(payload["identity_json"].item()))
        return identity.get("selector") == "owner-boundary-overlap" and identity.get("interfaces") == [interface] and identity.get("construction_mode") == CONSTRUCTION_MODE and identity.get("quadrature_mode") == QUADRATURE_MODE
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError):
        return False


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    started = time.time()
    completed: list[int] = []
    atomic_json({"state": "running", "pid": os.getpid(), "construction_mode": CONSTRUCTION_MODE, "quadrature_mode": QUADRATURE_MODE, "completed_interfaces": completed})
    log("started", pid=os.getpid(), construction_mode=CONSTRUCTION_MODE, quadrature_mode=QUADRATURE_MODE)
    for interface in range(32):
        child_output = OUTPUT / f"interface_{interface:02d}"
        child_output.mkdir(parents=True, exist_ok=True)
        if valid_lean_cache(interface, child_output):
            completed.append(interface)
            log("interface_resumed", interface=interface, cache=str(LEAN_CACHE_TEMPLATE).format(interface=interface))
            atomic_json({"state": "running", "construction_mode": CONSTRUCTION_MODE, "quadrature_mode": QUADRATURE_MODE, "current_interface": interface, "completed_interfaces": completed, "elapsed_seconds": time.time() - started})
            continue
        command = [
            sys.executable,
            str(DRIVER),
            "--mode",
            "interface-preflight",
            "--interface-indices",
            str(interface),
            "--output-dir",
            str(child_output),
        ]
        log("interface_started", interface=interface)
        with (child_output / "launcher.log").open("a", encoding="utf-8") as stream:
            result = subprocess.run(command, cwd=ROOT.parents[1], stdout=stream, stderr=subprocess.STDOUT)
        child_status_path = child_output / "process_status.json"
        child_status = json.loads(child_status_path.read_text(encoding="utf-8")) if child_status_path.is_file() else {}
        if result.returncode != 0 or child_status.get("state") != "completed":
            payload = {
                "state": "failed",
                "construction_mode": CONSTRUCTION_MODE,
                "quadrature_mode": QUADRATURE_MODE,
                "failed_interface": interface,
                "returncode": result.returncode,
                "child_status": child_status,
                "completed_interfaces": completed,
                "elapsed_seconds": time.time() - started,
            }
            atomic_json(payload)
            log("failed", **payload)
            raise SystemExit(result.returncode or 2)
        completed.append(interface)
        payload = {
            "state": "running",
            "construction_mode": CONSTRUCTION_MODE,
            "quadrature_mode": QUADRATURE_MODE,
            "current_interface": interface,
            "completed_interfaces": completed,
            "elapsed_seconds": time.time() - started,
        }
        atomic_json(payload)
        log("interface_completed", interface=interface, elapsed_seconds=payload["elapsed_seconds"])
    payload = {
        "state": "completed",
        "construction_mode": CONSTRUCTION_MODE,
        "quadrature_mode": QUADRATURE_MODE,
        "completed_interfaces": completed,
        "elapsed_seconds": time.time() - started,
    }
    atomic_json(payload)
    log("completed", **payload)


if __name__ == "__main__":
    main()
