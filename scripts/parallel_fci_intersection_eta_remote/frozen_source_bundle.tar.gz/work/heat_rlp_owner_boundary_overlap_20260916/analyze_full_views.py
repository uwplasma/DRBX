"""Matched-time logical and Cartesian audit for the completed lean run."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import run_owner_boundary_overlap as run  # noqa: E402
from analyze_morphology_views import isolated_extrema  # noqa: E402


RUN = ROOT.parents[1] / "prototype_runs" / "hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_owner_boundary_overlap_lean_t25_20260916"
METRIC_CACHE = ROOT.parent / "heat_conservative_quadratic_20260913" / "metric_cache_32" / "hsx_metric_a70ddee0ce9aa336469e0e66.npz"
TIMES = (0.5, 5.0, 10.0, 25.0)


def main() -> None:
    sanity, _ = run.support_harness._import_frozen_source()
    geometry, owner_host, _host, graph, _args = run._build_hsx_graph(sanity, None)
    weights = np.asarray(sanity._weights(geometry), dtype=float)
    with np.load(RUN / "history.npz", allow_pickle=False) as history:
        lean_times = np.asarray(history["times"], dtype=float)
        lean_fields = np.asarray(history["Te"], dtype=float)
    with np.load(METRIC_CACHE, allow_pickle=False) as metric:
        positions = np.asarray(metric["cell_position"], dtype=float)

    paths = {
        "No RLP": run.NO_RLP_REFERENCE,
        "Legacy RLP": run.LEGACY_REFERENCE,
        "Conservative H": run.H_REFERENCE,
        "Owner support": run.OWNER_SUPPORT_REFERENCE,
    }
    by_time: dict[float, dict[str, np.ndarray]] = {}
    audit: dict[str, object] = {}
    for time_value in TIMES:
        index = int(np.argmin(np.abs(lean_times - time_value)))
        fields = {"Lean overlap": lean_fields[index]}
        raw_minimum = {"Lean overlap": float(np.min(lean_fields[index] - 1.0))}
        for name, path in paths.items():
            raw = np.asarray(run.support_harness._reference_at(path, time_value), dtype=float)
            raw_minimum[name] = float(np.min(raw - 1.0))
            fields[name] = run.support_harness._project_reference_to_owner_materialization(raw, owner_host, graph)
        fields = {name: fields[name] for name in ("No RLP", "Legacy RLP", "Conservative H", "Owner support", "Lean overlap")}
        by_time[time_value] = fields
        baseline = fields["No RLP"]
        record = {}
        for name, field in fields.items():
            diagnostics = sanity.heat_spot_diagnostics(field, geometry, weights)
            record[name] = {
                "peak_delta": float(diagnostics["Te_max"] - 1.0),
                "radial_width_u": float(diagnostics["radial_width_u"]),
                "eta_spread": float(diagnostics["eta_spread"]),
                "weighted_l2_error_to_no_rlp": float(np.sqrt(np.sum(weights * (field - baseline) ** 2) / np.sum(weights))),
                "raw_min_delta": raw_minimum[name],
                "isolated_extrema": isolated_extrema(field - 1.0),
            }
        audit[str(time_value)] = record

    figure, axes = plt.subplots(len(TIMES), 5, figsize=(17, 12), constrained_layout=True)
    for row, time_value in enumerate(TIMES):
        fields = by_time[time_value]
        lean = fields["Lean overlap"]
        eta_index = int(np.unravel_index(np.argmax(lean - 1.0), lean.shape)[2])
        scale = max(float(np.max(field[:, :, eta_index] - 1.0)) for field in fields.values())
        image = None
        for column, (name, field) in enumerate(fields.items()):
            image = axes[row, column].imshow(field[:, :, eta_index] - 1.0, origin="lower", aspect="auto", cmap="magma", vmin=0.0, vmax=scale, interpolation="nearest")
            if row == 0:
                axes[row, column].set_title(name)
            axes[row, column].set_xlabel(r"$\theta$ index")
            if column == 0:
                axes[row, column].set_ylabel(f"t={time_value:g}\n$u$ index")
        figure.colorbar(image, ax=axes[row], label=r"$\delta T_e$", shrink=0.8)
    figure.suptitle("Matched-time logical hotspot sections")
    figure.savefig(RUN / "matched_time_logical.png", dpi=180)
    plt.close(figure)

    figure, axes = plt.subplots(len(TIMES), 5, figsize=(17, 12), constrained_layout=True)
    for row, time_value in enumerate(TIMES):
        fields = by_time[time_value]
        lean = fields["Lean overlap"]
        eta_index = int(np.unravel_index(np.argmax(lean - 1.0), lean.shape)[2])
        xyz = positions[:, :, eta_index]
        major_radius = np.hypot(xyz[..., 0], xyz[..., 1])
        vertical = xyz[..., 2]
        scale = max(float(np.max(field[:, :, eta_index] - 1.0)) for field in fields.values())
        image = None
        for column, (name, field) in enumerate(fields.items()):
            image = axes[row, column].scatter(major_radius.ravel(), vertical.ravel(), c=(field[:, :, eta_index] - 1.0).ravel(), s=7, marker="s", linewidths=0, cmap="magma", vmin=0.0, vmax=scale)
            axes[row, column].set_aspect("equal")
            if row == 0:
                axes[row, column].set_title(name)
            axes[row, column].set_xlabel("R")
            if column == 0:
                axes[row, column].set_ylabel(f"t={time_value:g}\nZ")
        figure.colorbar(image, ax=axes[row], label=r"$\delta T_e$", shrink=0.8)
    figure.suptitle("Matched-time Cartesian hotspot sections")
    figure.savefig(RUN / "matched_time_cartesian.png", dpi=180)
    plt.close(figure)

    (RUN / "matched_time_audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
