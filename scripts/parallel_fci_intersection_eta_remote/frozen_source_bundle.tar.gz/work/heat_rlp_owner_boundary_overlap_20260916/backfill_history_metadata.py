"""Backfill plotting coordinates for a completed owner-boundary heat history.

The compact owner-boundary prototype intentionally saved only its state and
owner diagnostics.  The Jarvis parallel-heat-surfaces view requires the
structured logical coordinates and Cartesian positions as well.  This small
utility copies *only* those four coordinate arrays from the frozen 32^3
conservative-H reference and writes the result atomically.  In particular,
``times``, ``Te``, and every existing diagnostic array are never replaced.

The metadata written beside the history is deliberately minimal: the exact
Jarvis heat-equation selector plus the frozen geometry and heat-spot contracts
needed to identify the data.  No simulation or geometry construction occurs.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
import tempfile
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_TARGET = (
    ROOT
    / "prototype_runs"
    / "hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_owner_boundary_overlap_lean_t25_20260916"
)
DEFAULT_REFERENCE = (
    ROOT
    / "prototype_runs"
    / "hsx_parallel_heat_spot_qhs_1T_main_only_32x32x32_conservative_quadratic_t25_20260913"
)
HEAT_EQUATION = "dTe/dt = chi_parallel * L_parallel_FCI(Te)"
COORDINATE_FIELDS = ("u", "theta", "eta", "Cartesian_position")


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object in {path}")
    return value


def _atomic_replace_npz(path: Path, arrays: dict[str, np.ndarray]) -> None:
    """Write an NPZ beside *path* and replace it only after it is complete."""

    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".npz", dir=path.parent
    )
    os.close(fd)
    temporary = Path(temporary_name)
    try:
        np.savez_compressed(temporary, **arrays)
        with temporary.open("rb") as stream:
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    """Atomically write UTF-8 JSON, retaining a complete old file on error."""

    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _load_arrays(path: Path) -> dict[str, np.ndarray]:
    if not path.is_file():
        raise FileNotFoundError(path)
    with np.load(path, allow_pickle=False) as archive:
        return {name: np.asarray(archive[name]).copy() for name in archive.files}


def _validate_coordinate_source(
    arrays: dict[str, np.ndarray], *, label: str
) -> None:
    missing = [name for name in COORDINATE_FIELDS if name not in arrays]
    if missing:
        raise ValueError(f"{label} is missing required coordinate fields: {missing}")
    u, theta, eta = (np.asarray(arrays[name]) for name in ("u", "theta", "eta"))
    position = np.asarray(arrays["Cartesian_position"])
    if any(value.ndim != 1 for value in (u, theta, eta)):
        raise ValueError(f"{label} logical coordinates must be one-dimensional")
    expected = (u.size, theta.size, eta.size, 3)
    if position.shape != expected:
        raise ValueError(
            f"{label} Cartesian_position has shape {position.shape}; expected {expected}"
        )
    if any(value.size != 32 for value in (u, theta, eta)):
        raise ValueError(f"{label} must be the frozen 32^3 reference")
    if not all(np.all(np.isfinite(value)) for value in (u, theta, eta, position)):
        raise ValueError(f"{label} contains non-finite coordinates")


def _validate_target_shape(arrays: dict[str, np.ndarray], target: Path) -> None:
    for required in ("times", "Te"):
        if required not in arrays:
            raise ValueError(f"Target history is missing {required!r}: {target}")
    times = np.asarray(arrays["times"])
    temperature = np.asarray(arrays["Te"])
    if times.ndim != 1 or temperature.ndim != 4 or temperature.shape[0] != times.size:
        raise ValueError(
            f"Target history has incompatible times/Te shapes: {times.shape}, {temperature.shape}"
        )
    if temperature.shape[1:] != (32, 32, 32):
        raise ValueError(
            f"Target history is not the compact 32^3 case: Te shape {temperature.shape}"
        )


def _minimal_metadata(reference_metadata: dict[str, Any]) -> dict[str, Any]:
    for name in ("geometry_contract", "heat_spot"):
        if not isinstance(reference_metadata.get(name), dict):
            raise ValueError(f"Frozen reference metadata has no object {name!r}")
    return {
        "equation": HEAT_EQUATION,
        "geometry_contract": copy.deepcopy(reference_metadata["geometry_contract"]),
        "heat_spot": copy.deepcopy(reference_metadata["heat_spot"]),
    }


def backfill_history(
    target_run: str | Path,
    reference_run: str | Path,
) -> dict[str, Any]:
    """Backfill one completed history and return a compact audit report."""

    target_run = Path(target_run).expanduser().resolve()
    reference_run = Path(reference_run).expanduser().resolve()
    target_history = target_run / "history.npz"
    reference_history = reference_run / "history.npz"
    reference_metadata_path = reference_run / "metadata.json"
    target_arrays = _load_arrays(target_history)
    reference_arrays = _load_arrays(reference_history)
    reference_metadata = _read_json(reference_metadata_path)
    _validate_target_shape(target_arrays, target_history)
    _validate_coordinate_source(reference_arrays, label="Frozen reference history")

    added: list[str] = []
    preserved_coordinates: list[str] = []
    for name in COORDINATE_FIELDS:
        if name in target_arrays:
            preserved_coordinates.append(name)
        else:
            target_arrays[name] = reference_arrays[name].copy()
            added.append(name)
    _validate_coordinate_source(target_arrays, label="Backfilled target history")

    metadata = _minimal_metadata(reference_metadata)
    _atomic_replace_npz(target_history, target_arrays)
    _atomic_write_json(target_run / "metadata.json", metadata)
    return {
        "target": str(target_run),
        "reference": str(reference_run),
        "added_fields": added,
        "preserved_coordinate_fields": preserved_coordinates,
        "history_fields": sorted(target_arrays),
        "equation": metadata["equation"],
        "metadata_fields": sorted(metadata),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", type=Path, default=DEFAULT_TARGET)
    parser.add_argument("--reference", type=Path, default=DEFAULT_REFERENCE)
    args = parser.parse_args(argv)
    report = backfill_history(args.target, args.reference)
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
