"""Read-only destination-aggregate audit on saved HSX FCI maps.

No production operator is changed. Interior endpoint rows only; axis and wall
closures are deliberately outside this audit. 'Aware' is a diagnostic angular
centroid interpolation, not a proposed production diffusion discretization.
"""
from pathlib import Path
import os, json, hashlib
import numpy as np

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
os.environ.setdefault('MPLCONFIGDIR', str(OUT/'mpl_cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HOSTS = {32:'angular_rlp_host_5180c3964f2704f3a5beb5fc.npz',
         64:'angular_rlp_host_2b02c6728ab3c3d2ad9af823.npz'}
wrap = lambda x: (x+np.pi)%(2*np.pi)-np.pi

def load(N):
    case = next(c for c in json.loads((ROOT/'work/heat_no_rlp_20260913/cases.json').read_text()) if c['resolution']==N)
    with np.load(Path(case['baseline'])/'history.npz') as a:
        h={k:a[k] for k in a.files if k != 'Te'}
        h['initial'] = a['Te'][0]
    with np.load(ROOT/'.hsx_metric_cache'/HOSTS[N]) as a:
        host={k:a[k] for k in a.files}
    meta=json.loads((Path(case['baseline'])/'metadata.json').read_text())
    return case,h,host,meta

def pulse(u,t,e,h):
    return h['amplitude']*np.exp(-.5*(((u-h['center_u'])/h['width_u'])**2+
        (h['center_u']*wrap(t-h['center_v'])/h['width_v'])**2+
        (wrap(e-h['center_eta'])/h['width_eta'])**2))

class Sampler:
    def __init__(self,h,host):
        self.h=h; self.host=host; self.shape=h['volume_weights'].shape
        self.ids=host['topology_aggregate_id'].ravel()
        self.v=host['host_raw_volume'].ravel()
        self.vol=np.bincount(self.ids,weights=self.v,minlength=self.v.size)
        self.q=host['angular_group_size']
        self.maps={n:h['fci_map_fields'][...,i] for i,n in enumerate(h['fci_map_field_names'])}
        self.u,self.t,self.e=np.meshgrid(h['u'],h['theta'],h['eta'],indexing='ij')
        self.tc=self.project(self.t)
    def project(self,f):
        sums=np.bincount(self.ids,weights=self.v*np.broadcast_to(f,self.shape).ravel(),minlength=self.v.size)
        return (sums[self.ids]/self.vol[self.ids]).reshape(self.shape)
    def row(self,d):
        x=self.maps[d+'_x']; y=self.maps[d+'_y']; i=np.floor(x).astype(int); j=np.floor(y).astype(int)
        k=np.broadcast_to((np.arange(self.shape[2])+(1 if d=='forward' else -1))%self.shape[2],self.shape)
        valid=(~self.maps[d+'_boundary'].astype(bool))&(i>=0)&(i<self.shape[0]-1)
        return np.clip(i,0,self.shape[0]-2),j%self.shape[1],k,x-np.floor(x),y-np.floor(y),valid
    def sample(self,f,d):
        i,j,k,x,y,_=self.row(d); jp=(j+1)%self.shape[1]
        return (1-x)*((1-y)*f[i,j,k]+y*f[i,jp,k])+x*((1-y)*f[i+1,j,k]+y*f[i+1,jp,k])
    def aware(self,f,d):
        # Each owner mean is located at its discrete volume-weighted angular
        # centroid. Interpolate neighboring distinct owners in each donor ring,
        # then use the unchanged radial interpolation weight. This exactly
        # reproduces theta-affine data away from its periodic seam.
        i,j,k,x,y,valid=self.row(d)
        theta=self.maps[d+'_endpoint_y']%(2*np.pi)
        out=[]
        for rr in [i,i+1]:
            val=np.empty(self.shape)
            for r in range(self.shape[0]):
                owners=np.arange(0,self.shape[1],int(self.q[r]))
                for kk in range(self.shape[2]):
                    sel=(rr==r)&(k==kk)
                    if np.any(sel):val[sel]=np.interp(theta[sel],self.tc[r,owners,kk],f[r,owners,kk],period=2*np.pi)
            out.append(val)
        return (1-x)*out[0]+x*out[1]

def stats(x,mask,w):
    z=x[mask]; weights=w[mask]
    return dict(rms=float(np.sqrt(np.sum(z*z*weights)/weights.sum())),
                max_abs=float(np.max(abs(z))),p95_abs=float(np.quantile(abs(z),.95)),count=int(z.size))

def main():
    results=[]
    for N in [32,64]:
        case,h,host,meta=load(N);s=Sampler(h,host);par=meta['heat_spot'];f=pulse(s.u,s.t,s.e,par);pf=s.project(f)
        initerr=float(np.max(abs(1+pf-h['initial'])))
        assert initerr<1e-14,initerr
        m=s.maps;w=host['host_raw_volume'];ep={};bias={};directions=[]
        for d in ['forward','backward']:
            i,j,k,x,y,valid=s.row(d)
            eu,et,ee=[m[d+'_endpoint_'+axis] for axis in 'xyz']
            exact=pulse(eu,et,ee,par)
            values={'fine':s.sample(f,d),'rlp':s.sample(pf,d),'aware':s.aware(pf,d),'exact':exact}
            ep[d]=values
            # Local theta is affine on this patch, so fine interpolation must
            # reproduce it exactly. Owner averages shift its effective sample.
            tb={'fine':wrap(s.sample(s.t,d)-et),'rlp':wrap(s.sample(s.tc,d)-et),'aware':wrap(s.aware(s.tc,d)-et)}
            bias[d]=tb
            qlo=s.q[i];qhi=s.q[i+1]
            patch=valid&(s.u>.20)&(s.u<.50)&(s.t>np.pi*.5)&(s.t<np.pi*1.5)&(et>np.pi*.4)&(et<np.pi*1.6)
            groups={'patch':patch,'merged_dest':patch&((qlo>1)|(qhi>1)),
                    'unmerged_dest':patch&(qlo==1)&(qhi==1),
                    'transition_dest':patch&(qlo!=qhi)}
            assert np.max(abs(s.sample(np.ones(s.shape),d)[valid]-1))<1e-14
            assert np.max(abs(tb['fine'][patch]))<1e-13
            assert np.max(abs(tb['aware'][patch]))<1e-13
            assert np.max(abs(values['fine'][groups['unmerged_dest']]-values['rlp'][groups['unmerged_dest']]))<1e-14
            ds=dict(direction=d,regions={})
            for name,mask in groups.items():
                if not mask.any():continue
                ds['regions'][name]={'temperature_error':{key:stats(value-exact,mask,w) for key,value in values.items() if key!='exact'},
                    'angular_bias_fine_cells':{key:stats(value/(2*np.pi/N),mask,w) for key,value in tb.items()},
                    'exact_temperature_rms':stats(exact,mask,w)['rms']}
            # Exact J-weighted aggregate means for chart-linear fields from
            # stored geometric moments, not a midpoint approximation to them.
            chart={}
            oi=host['topology_owner_index'];idx=tuple(np.moveaxis(oi,-1,0))
            for a,name in enumerate(['u_cos_theta','u_sin_theta']):
                raw=host['host_raw_chart_centroid'][...,a]
                owner=host['host_aggregate_chart_centroid'][...,a][idx]
                truth=eu*(np.cos(et) if a==0 else np.sin(et))
                chart[name]={key:stats(value-truth,groups['merged_dest'],w) for key,value in
                    {'fine_cell_averages':s.sample(raw,d),'owner_averages':s.sample(owner,d)}.items()}
            ds['exact_volume_average_chart_test']=chart
            directions.append(ds)
        # Isolate destination error with source-center values held identical.
        # Its contribution to the fine diffusion residual is linear in endpoint
        # errors. Then apply the actual physical-volume restriction R.
        b=h['magnetic_field'];inv=1/b
        lp=m['forward_length'];lm=m['backward_length']
        cp=.1*b*(inv+s.sample(inv,'forward'))/(lp*(lp+lm))
        cm=.1*b*(inv+s.sample(inv,'backward'))/(lm*(lp+lm))
        rerrors={key:s.project(cp*(ep['forward'][key]-ep['forward']['exact'])+
                               cm*(ep['backward'][key]-ep['backward']['exact'])) for key in ['fine','rlp','aware']}
        mask=s.row('forward')[-1]&s.row('backward')[-1]&(s.u>.2)&(s.u<.5)&(s.t>np.pi*.5)&(s.t<np.pi*1.5)
        rhsstats={key:stats(value,mask,w) for key,value in rerrors.items()}
        rec=dict(N=N,case=case,host_cache=str(ROOT/'.hsx_metric_cache'/HOSTS[N]),initial_reproduction_max_abs=initerr,
            angular_profile=s.q.tolist(),directions=directions,destination_only_owner_rhs_error=rhsstats)
        results.append(rec)
        # Selected source plane and hotspot patch; both forward/backward shown.
        fig,axs=plt.subplots(2,3,figsize=(13,7),layout='constrained')
        for row,d in enumerate(['forward','backward']):
            for col,key in enumerate(['fine','rlp','aware']):
                ax=axs[row,col];z=(ep[d][key]-ep[d]['exact'])[:,:,25]
                im=ax.pcolormesh(h['theta']/(2*np.pi),h['u'],z,cmap='RdBu_r',vmin=-.008,vmax=.008,shading='nearest')
                ax.axhline(.34375,color='black',linestyle='--',linewidth=.8)
                ax.set(xlim=(.25,.75),ylim=(.2,.5),title=f'{d}: {key}',xlabel='source theta / (2 pi)',ylabel='source u')
        fig.colorbar(im,ax=axs.ravel().tolist(),label='Endpoint temperature error; initial peak = 0.1',shrink=.85)
        fig.suptitle(f'{N}×{N}×32: identical traced endpoints, different destination sampling (eta index 25)')
        fig.savefig(OUT/f'endpoint_error_{N}.png',dpi=150);plt.close(fig)
        fig,axs=plt.subplots(1,2,figsize=(11,4),layout='constrained')
        for col,d in enumerate(['forward','backward']):
            z=bias[d]['rlp'][:,:,25]/(2*np.pi/N)
            im=axs[col].pcolormesh(h['theta']/(2*np.pi),h['u'],z,cmap='RdBu_r',vmin=-.5,vmax=.5,shading='nearest')
            axs[col].axhline(.34375,color='black',ls='--',lw=.8)
            axs[col].set(xlim=(.25,.75),ylim=(.2,.5),title=d,xlabel='source theta / (2 pi)',ylabel='source u')
        fig.colorbar(im,ax=axs.tolist(),label='Effective angular sampling bias / fine-cell width')
        fig.suptitle(f'{N} grid: affine-theta reproduction defect from destination aggregation')
        fig.savefig(OUT/f'angular_bias_{N}.png',dpi=150);plt.close(fig)
        print(json.dumps({'N':N,'initial_error':initerr,'forward_merged':directions[0]['regions']['merged_dest'],'rhs':rhsstats}),flush=True)
    (OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')

if __name__=='__main__':main()
