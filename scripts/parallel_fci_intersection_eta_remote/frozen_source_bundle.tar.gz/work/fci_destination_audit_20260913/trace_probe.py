"""Sparse interior RK4 convergence probe using the frozen run's evaluator.

Reproduce the production interior stepping formulas; verify four-substep
endpoints against the saved maps before using refined traces as a reference.
No wall/axis trajectories and no production histories are written.
"""
import sys, os, json
from pathlib import Path
import numpy as np
from audit import OUT, ROOT, load, Sampler, pulse, wrap
sys.path.insert(0,str(ROOT/'work/heat_no_rlp_20260913/source/DRBX/src'))
os.environ.setdefault('DRBX_DISABLE_COMPILATION_CACHE','1')
from drbx.geometry import MetricEvaluator, bfield_evaluator_from_makegrid

results=[]
for N in [32,64]:
    case,h,host,meta=load(N);s=Sampler(h,host);gc=meta['geometry_contract']
    with np.load(case['metric_file']) as a:
        metric=MetricEvaluator.from_cache_payload(a,prefix='metric_evaluator_')
    bf=bfield_evaluator_from_makegrid(Path(gc['makegrid_path']),currents=np.asarray(gc['makegrid_currents']),method='cubic')
    # 96 reproducible seeds, distributed over radial/theta hotspot patch and
    # four eta planes, including the visually inspected plane 25.
    selected=np.argwhere((s.u>.24)&(s.u<.44)&(s.t>.7*np.pi)&(s.t<1.3*np.pi)&np.isin(np.indices(s.shape)[2],[1,9,17,25]))
    rng=np.random.default_rng(718);selected=selected[rng.choice(len(selected),min(96,len(selected)),replace=False)]
    idx=tuple(selected.T);seeds=np.stack([s.u[idx],s.t[idx],s.e[idx]],axis=-1)
    def normalize(q):
        q=q.copy();q[:,1:]=q[:,1:]%(2*np.pi)
        assert np.all((q[:,0]>0)&(q[:,0]<1)), 'Sparse probe encountered a wall/axis; unsupported'
        return q
    def rhs(q):
        b=metric.evaluate_magnetic_field(normalize(q),bf)
        return np.column_stack([b.B_contravariant[:,:2]/b.B_contravariant[:,2,None],np.ones(len(q))])
    def trace(direction,n):
        q=seeds.copy();step=direction*(2*np.pi/len(h['eta']))/n
        for _ in range(n):
            k1=rhs(q);k2=rhs(q+.5*step*k1);k3=rhs(q+.5*step*k2);k4=rhs(q+step*k3)
            q=normalize(q+step*(k1+2*k2+2*k3+k4)/6)
        return q
    f=pulse(s.u,s.t,s.e,meta['heat_spot']);pf=s.project(f)
    for direction,d in [(1,'forward'),(-1,'backward')]:
        traces={}
        for n in [4,8,16,32]:
            traces[n]=trace(direction,n)
            print(f'N={N} {d} substeps={n} completed',flush=True)
        saved=np.stack([s.maps[d+'_endpoint_'+a][idx] for a in 'xyz'],axis=-1)
        def diff(a,b):
            z=a-b;z[:,1:]=wrap(z[:,1:]);return z
        saved_error=np.max(abs(diff(saved,traces[4])),axis=0)
        assert max(saved_error)<1e-10, saved_error
        refined=traces[32];p=lambda q:pulse(*q.T,meta['heat_spot'])
        entry=dict(N=N,direction=d,count=len(seeds),saved_vs_replayed4_max_abs=saved_error.tolist(),convergence={})
        for n in [4,8,16]:
            z=diff(traces[n],refined);te=p(traces[n])-p(refined)
            entry['convergence'][n]=dict(radial_rms_fine_cells=float(np.sqrt(np.mean(z[:,0]**2))*N),
                theta_rms_fine_cells=float(np.sqrt(np.mean(z[:,1]**2))*N/(2*np.pi)),
                temperature_rms=float(np.sqrt(np.mean(te**2))),temperature_max_abs=float(max(abs(te))))
        entry['sampling_temperature_rms_against_32step_exact']={key:float(np.sqrt(np.mean((vals[idx]-p(refined))**2))) for key,vals in
            {'fine':s.sample(f,d),'rlp':s.sample(pf,d),'aware':s.aware(pf,d)}.items()}
        results.append(entry)
        np.savez(OUT/f'trace_probe_{N}_{d}.npz',seed_indices=selected,seeds=seeds,saved=saved,**{f'endpoints_{n}':v for n,v in traces.items()})
        (OUT/'trace_results.json').write_text(json.dumps(results,indent=2)+'\n')
        print(json.dumps(entry),flush=True)
