"""Count endpoint rows with no angular response inside their donor interval."""
import json
import numpy as np
from audit import load, Sampler, OUT

results=[]
for N in [32,64]:
    _,h,host,_=load(N);s=Sampler(h,host)
    for d in ['forward','backward']:
        i,j,k,x,y,valid=s.row(d);jp=(j+1)%N
        oi=host['topology_owner_index'][...,1]
        same=(oi[i,j,k]==oi[i,jp,k])&(oi[i+1,j,k]==oi[i+1,jp,k])
        et=s.maps[d+'_endpoint_y']
        patch=valid&(s.u>.2)&(s.u<.5)&(s.t>np.pi*.5)&(s.t<np.pi*1.5)&(et>np.pi*.4)&(et<np.pi*1.6)&((s.q[i]>1)|(s.q[i+1]>1))
        w=host['host_raw_volume']
        results.append(dict(N=N,direction=d,merged_endpoint_count=int(patch.sum()),
            zero_theta_slope_count=int((patch&same).sum()),weighted_fraction=float(w[patch&same].sum()/w[patch].sum())))
(OUT/'plateau_rows.json').write_text(json.dumps(results,indent=2)+'\n')
