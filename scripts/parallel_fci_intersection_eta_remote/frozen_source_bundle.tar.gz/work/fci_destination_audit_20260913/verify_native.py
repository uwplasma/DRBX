"""Check the independent audit sampler against frozen native endpoint rows."""
import sys, os, json
import numpy as np
from audit import ROOT, OUT, load, Sampler, pulse
sys.path.insert(0,str(ROOT/'work/heat_no_rlp_20260913/source/DRBX/src'))
os.environ['DRBX_DISABLE_COMPILATION_CACHE']='1'
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
from drbx.geometry import HaloLayout3D, ShardSpec3D, LocalDomain3D
from drbx.native.fci_sharding import _lower_local_fci_maps, _UniformAxisMeta, _MAP_FIELD_NAMES
from drbx.native.fci_operators import _sample_fci_endpoint_rows

results=[]
for N in [32,64]:
    case,h,host,meta=load(N);s=Sampler(h,host);layout=HaloLayout3D(s.shape,2)
    spec=ShardSpec3D(global_shape=s.shape,owned_start=(0,0,0),owned_stop=s.shape,
        shard_index=(0,0,0),shard_counts=(1,1,1),periodic_axes=(False,True,True),
        axis_regular_axes=(True,False,False),halo_width=2)
    domain=LocalDomain3D(shard_spec=spec,layout=layout,mesh_axis_names=(None,None,None))
    axes=tuple(_UniformAxisMeta(float(h[k][0]),float(h[k][0]-(h[k][1]-h[k][0])/2),float(h[k][1]-h[k][0])) for k in ['u','theta','eta'])
    # Added endpoint B channels do not enter interior interpolation geometry.
    channels=np.stack([s.maps.get(k,np.zeros(s.shape)) for k in _MAP_FIELD_NAMES],axis=-1)
    maps=_lower_local_fci_maps(jnp.asarray(channels),domain=domain,axis_meta=axes)
    f=pulse(s.u,s.t,s.e,meta['heat_spot']);rng=np.random.default_rng(991)
    for label,values in [('pulse',f),('owner_pulse',s.project(f)),('random',rng.normal(size=s.shape))]:
        # Compared rows have no radial ghosts; periodic theta/eta halos are
        # sufficient. Radial wrapped placeholders are excluded by the mask.
        halo=jnp.asarray(np.pad(values,2,mode='wrap'))
        for d in ['forward','backward']:
            direction=getattr(maps,d)
            actual=np.asarray(_sample_fci_endpoint_rows(halo,direction,remote_values=None,
                cut_wall_values=jnp.zeros((0,)),n_owned=values.size)).reshape(s.shape)
            mask=s.row(d)[-1];err=float(np.max(abs(actual[mask]-s.sample(values,d)[mask])))
            assert err<1e-12,(N,label,d,err)
            results.append(dict(N=N,field=label,direction=d,max_abs=err))
    print(f'N={N} native sampler verified',flush=True)
(OUT/'native_verification.json').write_text(json.dumps(results,indent=2)+'\n')
