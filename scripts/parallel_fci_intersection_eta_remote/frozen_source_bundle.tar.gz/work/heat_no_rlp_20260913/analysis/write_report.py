from pathlib import Path
import json
P=Path(__file__).resolve().parent
rows=json.loads((P/'summary.json').read_text())
text='''# No-RLP heat controls: findings

Both requested controls completed to t=25: 32×32×32 in 23.4 minutes and 64×64×32 in 68.4 minutes. They were checked at scheduled intervals rather than continuously.

**The control supports RLP as a contributor to the local shear-like distortion and inner-surface filling. Removing it smooths the change in hotspot shape across the former angular-resolution transition and substantially reduces inward redistribution, particularly at 64 resolution. It does not remove all deformation, and it worsens global perturbation-heat conservation. This is not a general validation of the remaining FCI leakage.**

## What was held fixed and checked

Each control retained its baseline's resolution, chi_parallel=0.1, dt=1/1500, 37,500 RK4 steps, analytic initial-condition parameters, and 51 saved times. Polar axis topology remained enabled. Physical perpendicular diffusivity remained zero. All cell coordinates, Jacobian, cell B magnitude, Cartesian positions, volume weights, and all 14 saved FCI map channels matched their corresponding baseline exactly (maximum absolute differences zero).

RLP owner aggregation, projection, restriction and output materialization were bypassed, with all angular group sizes equal to one. All saved temperatures were finite and positive; both controls had Te≥1 throughout the saved histories. Non-Te RHS and final state changes were exactly zero. Perturbation L2 decreased between every saved frame. Frozen source hashes still matched the launch manifest.

The current cache had changed at some wall endpoints, so the wrapper replayed maps from each baseline history instead of regenerating them. New required wall-endpoint magnetic-field metadata were evaluated at those fixed coordinates; this metadata is not consumed by the isolated heat lane.

## Apparent shear

At eta index 25 and t=3.5, the RLP baseline's lower part is displaced toward larger theta relative to the no-RLP control. The difference is concentrated below and around u=0.34375, the 64-grid transition from paired angular cells to single cells. Without RLP, the hotspot still moves and becomes tilted, but the local backward bend of its poloidal centroid around the transition is absent in the inspected rows.

A direct shape diagnostic makes this visible. For each radial row, compute the delta-Te-weighted theta centroid inside 0.25<theta/(2pi)<0.75. This measures local shape; it is not a flow or shear-rate estimate.

| u | RLP centroid theta/(2pi), t=3.5 | No-RLP centroid |
|---|---:|---:|
| 0.3046875 | 0.54198 | 0.50196 |
| 0.3203125 | 0.54230 | 0.50644 |
| 0.3359375 | 0.53864 | 0.51024 |
| 0.3515625 | 0.52794 | 0.51385 |
| 0.3671875 | 0.52645 | 0.51777 |
| 0.3828125 | 0.52724 | 0.52249 |

Across the two rows bracketing the transition, the centroid changes by -0.01071 turns with RLP and +0.00360 turns without it. The remaining smooth tilt can include legitimate parallel redistribution and numerical errors; this control alone does not separate those.

'''
text+=f'![Hotspot detail]({P}/hotspot_detail_64.png)\n\n'
text+='''## Whole-torus surface budgets

Each surface is the same prepared continuous-MAKEGRID contour used by Jarvis. Heat is integrated over the full torus with saved physical volume weights and approximate fractional radial-cell overlap. Surface labels below are seed-u labels, not VMEC normalized flux.

The table reports change in the fraction of total perturbation heat inside a surface, in percentage points. Positive means a larger fraction inside.

| Grid | Seed u | RLP fraction change (pp) | No-RLP fraction change (pp) |
|---|---:|---:|---:|
'''
for N in [32,64]:
 a=next(x for x in rows if x['N']==N and x['run']=='RLP baseline');b=next(x for x in rows if x['N']==N and x['run']=='No RLP')
 for x,y in zip(a['surface_budgets'],b['surface_budgets']):text+=f"| {N} | {x['seed']:.2f} | {x['final_fraction_percent']-x['initial_fraction_percent']:+.3f} | {y['final_fraction_percent']-y['initial_fraction_percent']:+.3f} |\n"
text+='''
At seed u=0.19, the 64-grid fraction changes 10.11%→21.50% with RLP, versus 10.07%→11.71% without RLP. The change in enclosed heat itself, normalized to initial total heat, falls from +11.42% to +2.18%; thus the difference is not solely caused by the changing denominator. At 32 resolution those absolute changes are +14.14% and +4.89%.

This is a substantial reduction in inner filling. It is not uniform improvement across all surfaces: at 32 resolution the normalized fractions inside u=0.37 and u=0.46 decrease more without RLP. At 64 the fraction change inside u=0.37 is almost unchanged. These results do not support the claim that disabling RLP eliminates cross-surface redistribution everywhere.

## Conservation and amplitude

| Grid | Run | Final heat drift | Maximum absolute heat excursion | Final/initial L2 | Final peak delta Te |
|---|---|---:|---:|---:|---:|
'''
for x in rows:text+=f"| {x['N']} | {x['run']} | {x['final_heat_drift_percent']:+.3f}% | {x['max_heat_excursion_percent']:.3f}% | {x['final_l2_ratio']:.5f} | {x['final_peak']:.6g} |\n"
text+='''
No-RLP controls remain more peaked at late time, but the global heat drift is worse: -3.25% at 32 and +4.57% at 64. The sign changes under refinement, and the magnitude does not improve. Thus their better inner-surface confinement cannot be treated as proof of overall operator accuracy. The mapped support-form diffusion does not enforce exact global shared-flux conservation; this observation is consistent with that known limitation but does not identify its detailed cause.

'''
text+=f'![Budgets]({P}/budget_comparison.png)\n\n'
text+='''## Scope of the inference

1. The controls remove initial owner averaging as well as owner-space evolution. At seed u=0.19, their initial enclosed fractions differ from baseline by only about 0.27 percentage points at 32 and 0.05 points at 64, much smaller than the eventual differences. Nonetheless this is an RLP-on/off comparison including initialization, not a separation of initialization and evolution errors.
2. Geometry/maps are matched exactly within each pair, but baselines are historical and controls use the launch-time source snapshot. This is strong practical evidence implicating RLP, not a strict same-build causal ablation. A same-snapshot RLP replay would be needed to exclude every intervening source change.
3. The 32 and 64 cases use different fitted metrics and initial physical profiles. Their differences are not a fixed-geometry convergence-order measurement.
4. Prepared contours are fitted approximations; no new contour-invariance or quadrature-convergence study was performed. These budgets measure redistribution relative to those surfaces, not an exact flux-surface transport coefficient.
5. The heat spot has real parallel gradients. Its saved RHS/perpendicular-Laplacian norm ratio is not an isolated numerical perpendicular diffusivity.

**Decision:** the original suspicion about the RLP transition is supported for the local distortion and excess inner filling. The control does not establish that all remaining leakage is reasonable, and the worse heat conservation should be investigated before choosing no-RLP as the preferred production discretization. A verified flux-function null test and fixed-geometry refinement would calibrate the remaining interpolation error; a matched-source RLP replay would strengthen attribution.

Artifacts: summary.json contains complete quantitative budgets; shape_rows.json contains the row centroids. compare_32_t0.5.png, compare_32_t3.5.png, compare_32_t25.png and the corresponding 64 images compare both plot orientations with matched scales. hotspot_detail_32.png and hotspot_detail_64.png include t=0, 0.5, 3.5 and 25. The new histories and prepared contours are discoverable by Jarvis's existing Parallel heat and flux surfaces diagnostic.
'''
(P/'report.md').write_text(text)
print(P/'report.md')
