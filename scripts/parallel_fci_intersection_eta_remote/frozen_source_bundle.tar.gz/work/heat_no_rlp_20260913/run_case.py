"""Replay the baseline geometry/maps exactly and evolve with RLP disabled."""
from pathlib import Path
import os,sys,json,argparse,time,traceback,hashlib
import numpy as np
RUN=Path(__file__).resolve().parent
os.environ['DRBX_CACHE_DIR']=str(RUN/'jax_cache')
p=argparse.ArgumentParser();p.add_argument('resolution',type=int,choices=[32,64]);p.add_argument('--smoke',action='store_true');opts=p.parse_args()
case=next(c for c in json.loads((RUN/'cases.json').read_text()) if c['resolution']==opts.resolution)
sys.path.insert(0,case['source']);import run_hsx_sanity as sanity
baseline=Path(case['baseline']);meta=json.loads((baseline/'metadata.json').read_text());gc=meta['geometry_contract'];output=RUN/f'smoke_{opts.resolution}' if opts.smoke else Path(case['output']);output.mkdir(exist_ok=True)
status=output/'process_status.json'
def write_status(**kw):
 tmp=status.with_suffix('.tmp');tmp.write_text(json.dumps(dict(pid=os.getpid(),updated=time.time(),**kw),indent=2)+'\n');tmp.replace(status)
write_status(state='initializing',smoke=opts.smoke)
try:
 argv=['--experiment','heat-spot','--initial-condition','heat-spot','--no-rlp','--output-dir',str(output)]
 for key in ['resolution','fit_sample_shape','metric_mesh_shape','makegrid_currents']:
  argv+=['--'+key.replace('_','-'),','.join(map(str,gc[key]))]
 for key in ['makegrid_path','vessel_path','radial_degree','vertical_degree','toroidal_modes','metric_spline_degree','mmpde_iterations','axis_core_radius','metric_radial_degree','metric_poloidal_modes','metric_toroidal_modes','eta_projection_iterations','fci_trace_substeps']:
  arg={'makegrid_path':'makegrid','vessel_path':'vessel'}.get(key,key.replace('_','-'));argv+=['--'+arg,str(gc[key])]
 argv+=['--metric-cache-dir',case['metric_cache'],'--halo-width','2']
 for key,value in meta['heat_spot'].items():argv+=['--'+key.replace('_','-'),str(value)]
 steps=3 if opts.smoke else case['num_steps'];end=steps*case['dt']
 argv+=['--num-steps',str(steps),'--final-time',str(end),'--save-every',str(1 if opts.smoke else case['save_every'])]
 args=sanity.build_parser().parse_args(argv)
 # Reuse the saved, validated map payload without selecting a new tracer version.
 # The baseline history check below rejects any changed map channels.
 def replay_maps(**kw):
  payload=kw['cache_payload'];expected=Path(case['metric_file'])
  if kw['cache_path'] is None or Path(kw['cache_path']).resolve()!=expected.resolve():raise RuntimeError('Geometry builder did not select the frozen baseline metric cache')
  # Cached maps have since changed at some wall endpoints. The history itself
  # is the authoritative map input for this matched control.
  with np.load(baseline/'history.npz') as archive:
   names=archive['fci_map_field_names'].tolist();fields=archive['fci_map_fields']
   values={name:np.asarray(fields[...,i],dtype=bool if name.endswith('_boundary') else np.float64) for i,name in enumerate(names)}
  bf=sanity.production.bfield_evaluator_from_makegrid(Path(gc['makegrid_path']),currents=np.asarray(gc['makegrid_currents']),method='cubic')
  for direction in ['forward','backward']:
   mask=values[direction+'_boundary']
   points=np.stack([values[direction+'_endpoint_'+axis][mask] for axis in ['x','y','z']],axis=-1)
   b=kw['metric_evaluator'].evaluate_magnetic_field(points,bf)
   for i,axis in enumerate(['x','y','z']):
    channel=np.zeros(mask.shape);channel[mask]=b.B_contravariant[:,i];values[direction+'_endpoint_b_contra_'+axis]=channel
   channel=np.zeros(mask.shape);channel[mask]=b.magnitude;values[direction+'_endpoint_bmag']=channel
  maps=sanity.production.FciMaps3D(**values)
  sanity.production.validate_hsx_fci_maps(maps,kw['grid'],topology='toroidal')
  print('[control] replaying frozen baseline FCI maps',flush=True)
  return maps,payload,kw['bfield']
 sanity.production._build_or_load_hsx_fci_maps=replay_maps
 original_build=sanity.production.build_hsx_fci_geometry
 def checked_geometry(**kw):
  result=original_build(**kw);g,pos,nfp,cache,evaluator=result
  sharded=sanity.build_local_fci_geometries(g,(1,1,1),halo_width=2,periodic_axes=(False,True,True),axis_regular_axes=(True,False,False))
  checks={}
  with np.load(baseline/'history.npz') as a:
   for key,new in {'u':g.grid.x.centers,'theta':g.grid.y.centers,'eta':g.grid.z.centers,'metric_J':g.cell_metric.J,'magnetic_field':g.cell_bfield.Bmag,'Cartesian_position':pos,'fci_map_fields':sharded.map_fields,'volume_weights':sanity._weights(g)}.items():
    x=np.asarray(new);y=a[key]
    if key=='fci_map_fields':
     current_names=list(sanity.production.FCI_MAP_FIELDS);baseline_names=a['fci_map_field_names'].tolist()
     x=x[..., [current_names.index(name) for name in baseline_names]]
     checks['extra_map_channels']=[name for name in current_names if name not in baseline_names]
    checks[key]=dict(max_abs=float(np.max(np.abs(x-y))),shape=list(x.shape));np.testing.assert_allclose(x,y,rtol=1e-12,atol=1e-13,err_msg=f'baseline mismatch: {key}')
  (output/'geometry_verification.json').write_text(json.dumps(checks,indent=2)+'\n')
  print('[control] geometry, coordinates, B, weights, and all FCI map channels match baseline',flush=True)
  write_status(state='integrating',smoke=opts.smoke)
  return result
 sanity.production.build_hsx_fci_geometry=checked_geometry
 # The disabled branch must never enter the angular agglomeration builder.
 def forbidden(*a,**kw):raise AssertionError('RLP builder called in no-RLP control')
 sanity.production.build_metric_aware_polar_angular_agglomeration_geometry=forbidden
 started=time.time();history=sanity.run_heat_spot(args)
 with np.load(history) as a:
  assert np.all(a['angular_group_sizes']==1)
  assert np.isfinite(a['Te']).all() and np.min(a['Te'])>0
  assert np.isclose(a['times'][-1],end)
  u=a['u'][:,None,None];theta=a['theta'][None,:,None];eta=a['eta'][None,None,:];h=meta['heat_spot'];wrap=lambda x:(x+np.pi)%(2*np.pi)-np.pi
  expected=1+h['amplitude']*np.exp(-.5*(((u-h['center_u'])/h['width_u'])**2+(h['center_u']*wrap(theta-h['center_v'])/h['width_v'])**2+(wrap(eta-h['center_eta'])/h['width_eta'])**2))
  np.testing.assert_allclose(a['Te'][0],expected,rtol=0,atol=3e-16)
 result_meta=json.loads((output/'metadata.json').read_text());result_meta['control_provenance']=dict(baseline=str(baseline),source_manifest=str(RUN/'source_manifest.json'),geometry_replay='frozen baseline metric and FCI maps, verified against saved history',command_argv=argv)
 (output/'metadata.json').write_text(json.dumps(result_meta,indent=2)+'\n')
 # Geometry is identical: reuse prepared plotting contours, with updated source paths.
 if not opts.smoke:
  with np.load(baseline/'makegrid_poincare_theta_u.npz') as a:contours={k:a[k] for k in a.files}
  contours['source_history']=np.asarray(str(history));contours['metric_evaluator_path']=np.asarray(case['metric_file'])
  np.savez_compressed(output/'makegrid_poincare_theta_u.npz',**contours)
 write_status(state='completed',smoke=opts.smoke,elapsed_seconds=time.time()-started,history=str(history),verified_no_rlp=True)
 print('[control] completed and verified',flush=True)
except BaseException as exc:
 write_status(state='failed',smoke=opts.smoke,error=repr(exc));traceback.print_exc();raise
