from pathlib import Path
import shutil,json,hashlib,subprocess
ROOT=Path(__file__).resolve().parents[2];RUN=Path(__file__).resolve().parent;SRC=RUN/'source'
if SRC.exists():raise SystemExit('Source snapshot already exists; refusing to overwrite')
(SRC/'DRBX').mkdir(parents=True)
for f in ['run_hsx_sanity.py','run_hsx_perpendicular_convergence.py']:shutil.copy2(ROOT/f,SRC/f)
shutil.copy2(ROOT/'DRBX/simulate_hsx_blob.py',SRC/'DRBX/simulate_hsx_blob.py')
shutil.copytree(ROOT/'DRBX/src',SRC/'DRBX/src',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
files={str(p.relative_to(SRC)):hashlib.sha256(p.read_bytes()).hexdigest() for p in SRC.rglob('*') if p.is_file()}
(RUN/'source_manifest.json').write_text(json.dumps({'git_head':subprocess.check_output(['git','-C',str(ROOT/'DRBX'),'rev-parse','HEAD'],text=True).strip(),'git_status':subprocess.check_output(['git','-C',str(ROOT/'DRBX'),'status','--short'],text=True),'files_sha256':files},indent=2)+'\n')
cases=[]
for N in [32,64]:
 old=ROOT/'prototype_runs'/f'hsx_parallel_heat_spot_qhs_1T_main_only_{"32" if N==32 else "64x64x32"}_t25'
 out=ROOT/'prototype_runs'/f'hsx_parallel_heat_spot_qhs_1T_main_only_{N}x{N}x32_no_rlp_t25_20260913'
 out.mkdir(exist_ok=False)
 meta=json.loads((old/'metadata.json').read_text());cache=RUN/f'metric_cache_{N}';cache.mkdir();p=Path(meta['geometry_contract']['metric_cache_path']);shutil.copy2(p,cache/p.name)
 case={'resolution':N,'baseline':str(old),'output':str(out),'metric_cache':str(cache),'metric_file':str(cache/p.name),'source':str(SRC),'final_time':25.0,'num_steps':37500,'dt':25/37500,'save_every':750,'no_rlp':True}
 cases.append(case)
 (out/'control_plan.json').write_text(json.dumps(case,indent=2)+'\n')
(RUN/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
print('Prepared snapshots and cases',[(x['resolution'],x['output']) for x in cases])
