from pathlib import Path
import os,sys,json,subprocess,time
R=Path(__file__).resolve().parent
if (R/'launch.json').exists():raise SystemExit('Launch record exists; refusing duplicate launch')
cases=json.loads((R/'cases.json').read_text())
for c in cases:
 s=json.loads((R/f"smoke_{c['resolution']}"/'process_status.json').read_text())
 if s['state']!='completed' or not s.get('verified_no_rlp'):raise SystemExit('Both smoke checks must complete first')
launched=[]
for c in cases:
 out=Path(c['output']);log=out/'run.log';env=os.environ.copy();env.update(DRBX_CACHE_DIR=str(R/'jax_cache'),DRBX_HOST_DEVICE_COUNT='1',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',PYTHONUNBUFFERED='1')
 env.pop('DRBX_SOURCE_ROOT',None)
 command=[sys.executable,'-u',str(R/'run_case.py'),str(c['resolution'])]
 with log.open('ab',buffering=0) as stream:proc=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,cwd=R.parents[1],env=env,start_new_session=True)
 record=dict(resolution=c['resolution'],pid=proc.pid,command=command,log=str(log),output=str(out),launched_at=time.time());launched.append(record)
 (out/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
(R/'launch.json').write_text(json.dumps(launched,indent=2)+'\n');print(json.dumps(launched,indent=2))
