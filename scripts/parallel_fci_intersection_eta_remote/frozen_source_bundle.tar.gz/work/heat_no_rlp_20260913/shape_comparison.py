from pathlib import Path
import os,json
import numpy as np
R=Path(__file__).resolve().parent;OUT=R/'analysis';os.environ.setdefault('MPLCONFIGDIR',str(R/'mpl_cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import PowerNorm
allstats=[]
for case in json.loads((R/'cases.json').read_text()):
 N=case['resolution'];runs=[]
 for label,path in [('RLP baseline',case['baseline']),('No RLP',case['output'])]:
  with np.load(Path(path)/'history.npz') as a:runs.append((label,{k:a[k] for k in ['Te','times','u','theta','eta','volume_weights']}))
 with np.load(Path(case['baseline'])/'makegrid_poincare_theta_u.npz') as a:c={k:a[k] for k in a.files}
 fig,axes=plt.subplots(2,4,figsize=(16,8),layout='constrained')
 for col,t in enumerate([0,.5,3.5,25]):
  mx=max((h['Te'][int(np.argmin(abs(h['times']-t))),:,:,25]-1).max() for _,h in runs)
  for row,(label,h) in enumerate(runs):
   k=int(np.argmin(abs(h['times']-t)));z=h['Te'][k,:,:,25]-1;ax=axes[row,col]
   im=ax.pcolormesh(h['theta']/(2*np.pi),h['u'],z,shading='nearest',cmap='inferno',norm=PowerNorm(.65,vmin=0,vmax=mx))
   for seed in range(len(c['seed_u'])):
    if c['valid_surfaces'][25,seed]:ax.plot(c['contour_theta'],c['contour_u'][25,seed],color='cyan',lw=.5,alpha=.6)
   if N==64:ax.axhline(.34375,color='white',ls='--',lw=1)
   ax.set(xlim=(.3,.75),ylim=(.15,.6),xlabel='theta / (2 pi)',ylabel='u',title=f'{label}; t={t:g}')
   fig.colorbar(im,ax=ax,shrink=.65,label='delta Te')
   if t<=3.5:
    # A directly reproducible local row centroid, not a shear-rate estimator.
    mask=(h['theta']/(2*np.pi)>.25)&(h['theta']/(2*np.pi)<.75);x=h['theta'][mask]/(2*np.pi)
    selected=z[:,mask];centroid=(selected*x[None,:]).sum(axis=1)/np.maximum(selected.sum(axis=1),1e-300)
    allstats.append(dict(N=N,run=label,time=t,rows=[dict(u=float(h['u'][i]),theta_centroid=float(centroid[i])) for i in np.where((h['u']>.26)&(h['u']<.44))[0]]))
 fig.suptitle(f'{N}×{N}×32: hotspot deformation at eta index 25\nMatched color scale between rows at each time; time columns use different scales'+('; dashed line: former RLP transition' if N==64 else ''))
 fig.savefig(OUT/f'hotspot_detail_{N}.png',dpi=130);plt.close(fig)
(OUT/'shape_rows.json').write_text(json.dumps(allstats,indent=2)+'\n')
print(json.dumps([r for r in allstats if r['N']==64 and r['time']==3.5],indent=2))
