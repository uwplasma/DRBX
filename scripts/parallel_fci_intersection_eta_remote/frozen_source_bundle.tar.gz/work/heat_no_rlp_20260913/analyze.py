"""Analyze completed no-RLP controls against their saved RLP baselines."""
from pathlib import Path
import os,sys,json,importlib.util
import numpy as np
R=Path(__file__).resolve().parent;ROOT=R.parents[1];OUT=R/'analysis';OUT.mkdir(exist_ok=True)
os.environ.setdefault('MPLCONFIGDIR',str(R/'mpl_cache'))
sys.path.insert(0,str(ROOT/'.jarvis/shared'))
spec=importlib.util.spec_from_file_location('heat_visuals',ROOT/'.jarvis/diagnostics/parallel-heat-surfaces/diagnostic.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
import matplotlib.pyplot as plt
from matplotlib.colors import PowerNorm
cases=json.loads((R/'cases.json').read_text());results=[]
fig,axs=plt.subplots(2,3,figsize=(14,8),layout='constrained')
for row,case in enumerate(cases):
 N=case['resolution'];output=Path(case['output']);status=json.loads((output/'process_status.json').read_text())
 if status['state']!='completed' or not status.get('verified_no_rlp'):raise RuntimeError(f'{N} not completed/verified')
 records=[]
 for name,directory in [('RLP baseline',Path(case['baseline'])),('No RLP',output)]:
  with np.load(directory/'history.npz') as a:history={k:a[k] for k in a.files}
  T=history['Te'];d=T-1;w=history['volume_weights'];t=history['times'];Q=(d*w).sum(axis=(1,2,3));l2=np.sqrt((d*d*w).sum(axis=(1,2,3))/w.sum())
  if name=='No RLP':
   assert np.isfinite(T).all() and T.min()>0 and np.all(history['angular_group_sizes']==1) and np.isclose(t[-1],25)
  rec=m.HeatHistory(directory.name+'/history.npz',directory/'history.npz',f'{N}×{N}×32 {name}',len(t),T.shape[1:]);c=m._load_prepared_contours(rec)
  edges=m._cell_edges(history['u'],0,1);budgets=[]
  for seed in [.13,.19,.37,.46]:
   k=int(np.argmin(abs(c.seed_u-seed)));assert c.valid[:,k].all()
   radius=np.stack([np.interp(history['theta']/(2*np.pi),c.theta,c.radius[j,k]) for j in range(len(history['eta']))],axis=1)
   fraction=np.clip((radius[None,:,:]-edges[:-1,None,None])/np.diff(edges)[:,None,None],0,1)
   inside=(d*w*fraction).sum(axis=(1,2,3));percent=100*inside/Q
   budgets.append(dict(seed=float(c.seed_u[k]),initial_fraction_percent=float(percent[0]),final_fraction_percent=float(percent[-1]),enclosed_change_over_initial_total_percent=float(100*(inside[-1]-inside[0])/Q[0])))
   if seed==.19:axs[row,2].plot(t,percent,label=name)
  axs[row,0].plot(t,100*(Q/Q[0]-1),label=name);axs[row,1].plot(t,l2/l2[0],label=name)
  results.append(dict(N=N,run=name,directory=str(directory),initial_peak=float(d[0].max()),final_peak=float(d[-1].max()),final_heat_drift_percent=float(100*(Q[-1]/Q[0]-1)),max_heat_excursion_percent=float(100*np.max(abs(Q/Q[0]-1))),final_l2_ratio=float(l2[-1]/l2[0]),surface_budgets=budgets))
  records.append((rec,history,c))
  # Standard Jarvis static outputs for the new no-RLP run, in both modes.
  if name=='No RLP':
   for fixed in [True,False]:
    opts=dict(time_index=int(np.argmin(abs(t-3.5))),fixed_colorbar=fixed)
    f,*_=m.ParallelHeatSurfaces._figure(rec,t,T,history['u'],history['theta'],c,eta_index=25,**opts);f.savefig(OUT/f'no_rlp_{N}_eta_fixed{fixed}.png');plt.close(f)
    f,*_=m.ParallelHeatSurfaces._along_device_figure(rec,t,T,history['u'],history['theta'],history['eta'],c,theta_index=N//2,**opts);f.savefig(OUT/f'no_rlp_{N}_along_fixed{fixed}.png');plt.close(f)
 for target in [.5,3.5,25]:
  f,aa=plt.subplots(2,2,figsize=(10,9),layout='constrained');vmax=max((h['Te'][int(np.argmin(abs(h['times']-target)))]-1).max() for _,h,_ in records)
  for rr,(rec,h,c) in enumerate(records):
   k=int(np.argmin(abs(h['times']-target)));te=h['Te'][k]-1
   for col,values in enumerate([te[:,:,25],te[:,N//2,:]]):
    ax=aa[rr,col];x=h['theta']/(2*np.pi) if col==0 else h['eta']/(2*np.pi)
    im=ax.pcolormesh(x,h['u'],values,shading='nearest',cmap='inferno',norm=PowerNorm(.65,vmin=0,vmax=vmax))
    if col==0:m._draw_contours(ax,c,25)
    else:m._draw_along_device_contours(ax,c,h['eta'],h['theta'][N//2])
    ax.set(xlim=(0,1),ylim=(0,1),title=rec.label+(' — eta 25' if col==0 else f' — theta {N//2}'),xlabel='theta / (2 pi)' if col==0 else 'eta / (2 pi)',ylabel='u')
  f.colorbar(im,ax=aa.ravel().tolist(),label='delta Te, shared scale',shrink=.8);f.suptitle(f'RLP control comparison at t={target}: {N}×{N}×32');f.savefig(OUT/f'compare_{N}_t{target:g}.png',dpi=130);plt.close(f)
for row in range(2):
 for col,(title,ylabel) in enumerate([('Perturbation heat','Change (%)'),('Perturbation L2','L2 / initial'),('Inside seed-u 0.19 surface','Heat fraction (%)')]):
  axs[row,col].set(title=f'{cases[row]["resolution"]} grid: {title}',xlabel='t',ylabel=ylabel);axs[row,col].grid(alpha=.2);axs[row,col].legend()
fig.savefig(OUT/'budget_comparison.png',dpi=150);plt.close(fig)
(OUT/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
lines=['# No-RLP control results','', 'Computed from completed, validated histories. Surface fractions use the same prepared MAKEGRID curves with approximate fractional radial-cell overlap. Baselines are historical; controls use the recorded source snapshot. Initial owner averaging is also removed in controls.','', '| Grid | Run | Final heat drift | Max heat excursion | Final/initial L2 | Final peak delta Te |','|---|---|---:|---:|---:|---:|']
for x in results:lines.append(f'| {x["N"]} | {x["run"]} | {x["final_heat_drift_percent"]:.4f}% | {x["max_heat_excursion_percent"]:.4f}% | {x["final_l2_ratio"]:.5f} | {x["final_peak"]:.6g} |')
lines+=['',f'![Budget comparison]({OUT}/budget_comparison.png)','', 'See summary.json for the surface budgets and comparison PNGs for identical-time, identical-scale images. Scientific interpretation should be added after visual inspection.']
(OUT/'results.md').write_text('\n'.join(lines)+'\n');print(json.dumps(results,indent=2))
