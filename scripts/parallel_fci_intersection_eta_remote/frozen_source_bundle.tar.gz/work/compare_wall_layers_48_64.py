from __future__ import annotations

import gc
import json
from pathlib import Path

import numpy as np


ROOT = Path("/Users/yxie/Desktop/HSX drbx/prototype_runs")
RUNS = {
    "48": (
        ROOT / "fci_qhs_48_material_scalar_pb3_characteristic_sat_imex_allwalls_trace4_t015_640steps_26d9e506_20260901",
        "hsx_qhs_bc_characteristic_materialscalar_pb3_affinelift_pair_imex_allwalls_eta4_48_t015_640steps.npz",
    ),
    "64": (
        ROOT / "fci_qhs_64_material_scalar_pb3_characteristic_sat_imex_allwalls_trace4_rhsterms_t015_800steps_26d9e506_20260901",
        "hsx_qhs_64_materialscalar_pb3_affinelift_pair_imex_rhsterms_eta4_t015_800steps.npz",
    ),
}
FIELDS = ("density", "Te", "Ti", "Vi", "Ve", "vorticity", "phi")
EQUILIBRIUM = {"density": 1.0, "Te": 1.0, "Ti": 1.0, "Vi": 0.0, "Ve": 0.0, "vorticity": 0.0, "phi": 0.0}


def ratio(top: float, bottom: float) -> float | None:
    return float(top / bottom) if bottom else None


def analyze(run: Path, archive_name: str) -> dict[str, object]:
    metric_path = next((run / "metric_cache").glob("hsx_metric_*.npz"))
    with np.load(metric_path, allow_pickle=False) as metric:
        forward_wall = np.asarray(metric["fci_maps_forward_boundary"], dtype=bool)
        backward_wall = np.asarray(metric["fci_maps_backward_boundary"], dtype=bool)
        forward_length = np.asarray(metric["fci_maps_forward_length"], dtype=np.float64)
        backward_length = np.asarray(metric["fci_maps_backward_length"], dtype=np.float64)
    wall = forward_wall | backward_wall

    with np.load(run / archive_name, allow_pickle=False) as data:
        times = np.asarray(data["times"], dtype=np.float64)
        jacobian = np.asarray(data["jacobian"], dtype=np.float64)
        n = int(data["density"].shape[1])
        result: dict[str, object] = {
            "resolution": n,
            "steps": int(times.size - 1),
            "dt": float(times[1] - times[0]),
            "wall_cells": int(np.count_nonzero(wall)),
            "double_hit_cells": int(np.count_nonzero(forward_wall & backward_wall)),
            "fields": {},
        }
        sample_fractions = (0.75, 0.875, 0.96875, 1.0)
        for name in FIELDS:
            values = np.asarray(data[name])
            perturbation = np.asarray(values[-1], dtype=np.float64) - EQUILIBRIUM[name]
            outer = np.asarray(values[:, -1], dtype=np.float64) - EQUILIBRIUM[name]
            interior = perturbation[:-4]
            wall_values = perturbation[wall]
            nonwall_values = perturbation[~wall]

            jumps = np.roll(outer, -1, axis=1) - outer
            jump_history = np.max(np.abs(jumps), axis=(1, 2))
            jump_peak_step = int(np.argmax(jump_history))
            final_jump_index = np.unravel_index(int(np.argmax(np.abs(jumps[-1]))), jumps[-1].shape)
            theta, eta = (int(final_jump_index[0]), int(final_jump_index[1]))
            theta_next = (theta + 1) % n

            coefficients = np.fft.rfft(outer, axis=1, norm="ortho")
            power = np.sum(np.abs(coefficients) ** 2, axis=2)
            power[:, 0] = 0.0
            total = np.sum(power, axis=1)
            high_start = int(np.ceil(0.55 * (n // 2)))
            near_start = int(np.ceil(0.90 * (n // 2)))
            high_fraction = np.divide(
                np.sum(power[:, high_start:], axis=1), total,
                out=np.zeros_like(total), where=total > 0.0,
            )
            near_fraction = np.divide(
                np.sum(power[:, near_start:], axis=1), total,
                out=np.zeros_like(total), where=total > 0.0,
            )
            final_power = power[-1]
            dominant = int(np.argmax(final_power))

            filtered = coefficients.copy()
            filtered[:, :high_start, :] = 0.0
            high_values = np.fft.irfft(filtered, n=n, axis=1, norm="ortho")
            high_rms = np.sqrt(np.mean(high_values * high_values, axis=(1, 2)))
            high_peak_step = int(np.argmax(high_rms))

            result["fields"][name] = {
                "final_range": [float(np.min(values[-1])), float(np.max(values[-1]))],
                "outer_rms": float(np.sqrt(np.mean(outer[-1] * outer[-1]))),
                "interior_rms": float(np.sqrt(np.mean(interior * interior))),
                "outer_over_interior_rms": ratio(float(np.sqrt(np.mean(outer[-1] * outer[-1]))), float(np.sqrt(np.mean(interior * interior)))),
                "fci_wall_rms": float(np.sqrt(np.mean(wall_values * wall_values))),
                "nonwall_rms": float(np.sqrt(np.mean(nonwall_values * nonwall_values))),
                "wall_over_nonwall_rms": ratio(float(np.sqrt(np.mean(wall_values * wall_values))), float(np.sqrt(np.mean(nonwall_values * nonwall_values)))),
                "outer_fraction_of_weighted_radial_energy": ratio(
                    float(np.sum(jacobian[-1] * perturbation[-1] * perturbation[-1])),
                    float(np.sum(jacobian * perturbation * perturbation)),
                ),
                "dominant_outer_poloidal_mode": dominant,
                "dominant_outer_poloidal_mode_fraction": ratio(float(final_power[dominant]), float(np.sum(final_power))),
                "outer_high_fraction_final": float(high_fraction[-1]),
                "outer_near_nyquist_fraction_final": float(near_fraction[-1]),
                "outer_high_rms_final": float(high_rms[-1]),
                "outer_high_rms_peak": float(high_rms[high_peak_step]),
                "outer_high_rms_peak_step": high_peak_step,
                "outer_high_rms_final_over_peak": ratio(float(high_rms[-1]), float(high_rms[high_peak_step])),
                "maximum_outer_jump_final": float(jump_history[-1]),
                "maximum_outer_jump_peak": float(jump_history[jump_peak_step]),
                "maximum_outer_jump_peak_step": jump_peak_step,
                "maximum_outer_jump_final_over_peak": ratio(float(jump_history[-1]), float(jump_history[jump_peak_step])),
                "final_jump_pair": [[n - 1, theta, eta], [n - 1, theta_next, eta]],
                "final_jump_pair_normalized": [[1.0, theta / n, eta / n], [1.0, theta_next / n, eta / n]],
                "final_jump_signed": float(jumps[-1, theta, eta]),
                "forward_wall_flags": [bool(forward_wall[-1, theta, eta]), bool(forward_wall[-1, theta_next, eta])],
                "backward_wall_flags": [bool(backward_wall[-1, theta, eta]), bool(backward_wall[-1, theta_next, eta])],
                "forward_lengths": [float(forward_length[-1, theta, eta]), float(forward_length[-1, theta_next, eta])],
                "backward_lengths": [float(backward_length[-1, theta, eta]), float(backward_length[-1, theta_next, eta])],
                "late_samples": {
                    str(fraction): {
                        "step": int(round(fraction * (times.size - 1))),
                        "time": float(times[int(round(fraction * (times.size - 1)))]),
                        "jump": float(jump_history[int(round(fraction * (times.size - 1)))]),
                        "high_rms": float(high_rms[int(round(fraction * (times.size - 1)))]),
                        "high_fraction": float(high_fraction[int(round(fraction * (times.size - 1)))]),
                    }
                    for fraction in sample_fractions
                },
            }
            del values, perturbation, outer, jumps, coefficients, power, filtered, high_values
            gc.collect()
    return result


result = {label: analyze(*config) for label, config in RUNS.items()}
output = Path("/Users/yxie/Desktop/HSX drbx/work/wall_layers_48_64_comparison.json")
output.write_text(json.dumps(result, indent=2) + "\n")
print(output)
