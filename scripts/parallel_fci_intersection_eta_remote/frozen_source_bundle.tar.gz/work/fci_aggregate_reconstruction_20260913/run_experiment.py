"""Matched sparse experiments for aggregate consistent FCI endpoint sampling.

This file is deliberately a research runner.  It consumes the frozen maps and
host caches from the destination audit, assembles operators in owner space,
and writes diagnostics under its output directory.  No production operator or
cached geometry is modified.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import LinearOperator, expm_multiply

ROOT = Path(__file__).resolve().parents[2]
AUDIT_DIR = ROOT / "work/fci_destination_audit_20260913"
OUT = Path(__file__).resolve().parent
HOSTS = {
    32: "angular_rlp_host_5180c3964f2704f3a5beb5fc.npz",
    64: "angular_rlp_host_2b02c6728ab3c3d2ad9af823.npz",
}


def _audit_module():
    spec = importlib.util.spec_from_file_location("fci_destination_audit", AUDIT_DIR / "audit.py")
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load audit helpers from {AUDIT_DIR / 'audit.py'}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_core():
    src = ROOT / "DRBX" / "src"
    if str(src) not in sys.path:
        sys.path.insert(0, str(src))
    from drbx.geometry.fci_aggregate_reconstruction import (  # type: ignore
        AggregateGeometry,
        build_aggregate_evaluation,
    )

    return AggregateGeometry, build_aggregate_evaluation


def _jsonable(value: Any):
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(type(value).__name__)


def _stats(error: np.ndarray, mask: np.ndarray, weights: np.ndarray) -> dict[str, Any]:
    x = np.asarray(error)[mask]
    w = np.asarray(weights)[mask]
    if x.size == 0 or not np.any(w > 0):
        return {"count": int(x.size), "rms": None, "max_abs": None, "p95_abs": None}
    return {
        "count": int(x.size),
        "volume": float(w.sum()),
        "rms": float(np.sqrt(np.sum(w * x * x) / np.sum(w))),
        "max_abs": float(np.max(np.abs(x))),
        "p95_abs": float(np.quantile(np.abs(x), 0.95)),
    }


def _source_hash(*paths: Path) -> dict[str, str]:
    answer = {}
    for path in paths:
        h = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1 << 20), b""):
                h.update(chunk)
        answer[str(path)] = h.hexdigest()
    return answer


def _coerce_csr(result: Any, rows: int, columns: int) -> sparse.csr_matrix:
    """Accept the core's CSR directly or a small result wrapper."""
    candidates = [result]
    for attr in ("matrix", "csr", "evaluation", "operator"):
        if hasattr(result, attr):
            candidates.append(getattr(result, attr))
    if isinstance(result, tuple):
        candidates.extend(result)
    for candidate in candidates:
        if sparse.issparse(candidate):
            out = candidate.tocsr().astype(np.float64)
            if out.shape != (rows, columns):
                raise ValueError(f"aggregate evaluator returned {out.shape}, expected {(rows, columns)}")
            return out
        if isinstance(candidate, np.ndarray) and candidate.ndim == 2:
            out = sparse.csr_matrix(candidate, dtype=np.float64)
            if out.shape == (rows, columns):
                return out
    raise TypeError("build_aggregate_evaluation did not return a sparse matrix or CSR wrapper")


def _aggregate_eval(builder, geometry, xy, eta, degree, donors, columns):
    # ``points_xy`` are the saved logical map coordinates; eta_indices select
    # the toroidal donor plane.  Keep this call in one place so the runner is
    # easy to adapt if the experimental core adds diagnostic options.
    result = builder(geometry, np.asarray(xy, dtype=float), np.asarray(eta, dtype=int), degree=degree, donor_count=donors)
    matrix = _coerce_csr(result, len(xy), columns)
    diagnostics = getattr(result, "diagnostics", None)
    summary = None
    if diagnostics is not None:
        summary = {}
        for name in ("rank", "condition", "reproduction_residual", "l1_norm", "donor_counts"):
            if hasattr(diagnostics, name):
                values = np.asarray(getattr(diagnostics, name))
                summary[name] = {
                    "min": float(np.min(values)), "max": float(np.max(values)),
                    "p95": float(np.quantile(values, 0.95)),
                    "count": int(values.size),
                }
        for name in ("degree", "basis_size", "rank_deficient_count", "ill_conditioned_count", "reproduction_failure_count", "l1_exceeded_count"):
            if hasattr(diagnostics, name):
                summary[name] = int(getattr(diagnostics, name))
    return matrix, summary


def _injection_and_restriction(host: dict[str, np.ndarray], rawvol: np.ndarray, geometry):
    shape = rawvol.shape
    n = int(np.prod(shape))
    nowner = int(geometry.n_owner)
    ids = np.asarray(host["topology_aggregate_id"], dtype=np.int64).ravel()
    owner_slot = np.full(n, -1, dtype=np.int64)
    owner_slot[np.asarray(geometry.owner_flat_ids, dtype=np.int64)] = np.arange(nowner)
    compact_ids = owner_slot[ids]
    if np.any(compact_ids < 0):
        raise ValueError("host topology contains a cell with no active aggregate owner")
    owner_volume = np.bincount(compact_ids, weights=rawvol.ravel(), minlength=nowner).astype(float)
    rows = np.arange(n, dtype=np.int64)
    P = sparse.coo_matrix((np.ones(n), (rows, compact_ids)), shape=(n, nowner)).tocsr()
    # R is the volume-weighted restriction.  Empty storage slots have no rows
    # in practice; guarding them makes diagnostics robust to future payloads.
    invv = np.zeros_like(owner_volume)
    good = owner_volume > 0
    invv[good] = 1.0 / owner_volume[good]
    R = sparse.diags(invv).dot(P.T).dot(sparse.diags(rawvol.ravel())).tocsr()
    return P, R, owner_volume, ids


def _legacy_endpoint(P: sparse.csr_matrix, sampler, direction: str, selected: np.ndarray) -> sparse.csr_matrix:
    i, j, k, x, y, _ = sampler.row(direction)
    i, j, k, x, y = [np.asarray(z).ravel()[selected] for z in (i, j, k, x, y)]
    ny, nz = sampler.shape[1:]
    jp = (j + 1) % ny
    flat = lambda ii, jj, kk: (ii * ny + jj) * nz + kk
    rr = np.tile(np.arange(selected.size), 4)
    cc = np.concatenate([flat(i, j, k), flat(i, jp, k), flat(i + 1, j, k), flat(i + 1, jp, k)])
    ww = np.concatenate([(1 - x) * (1 - y), (1 - x) * y, x * (1 - y), x * y])
    # P has one owner column per fine cell.  Multiplication retains the exact
    # fine-bilinear-on-injection-P semantics while coalescing duplicate owners.
    fine = sparse.coo_matrix((ww, (rr, cc)), shape=(selected.size, P.shape[0])).tocsr()
    return fine.dot(P)


def _make_support_operator(Gp, Gm, Wp, Wm, mass):
    mass = np.asarray(mass, dtype=float)

    def matvec(x):
        x = np.asarray(x).ravel()
        y = Gp.T @ (Wp * (Gp @ x)) + Gm.T @ (Wm * (Gm @ x))
        return -np.asarray(y).ravel() / mass

    def rmatvec(y):
        z = np.asarray(y).ravel() / mass
        return -(Gp.T @ (Wp * (Gp @ z)) + Gm.T @ (Wm * (Gm @ z)))

    return LinearOperator((mass.size, mass.size), matvec=matvec, rmatvec=rmatvec, dtype=float)


def _evolve(name, op, x0, times, fine_from_owner, fine_weights, final_time, traceA=None):
    x0 = np.asarray(x0, dtype=float).ravel()
    # expm_multiply(start, stop, num) only supports uniformly spaced output;
    # evaluate each requested diagnostic time so .05, .1, and .5 remain exact.
    values = np.asarray([
        expm_multiply(op * float(t), x0, traceA=None if traceA is None else float(t) * traceA)
        for t in times
    ])
    fine = np.asarray([fine_from_owner(v) for v in values])
    delta = fine - 1.0
    mass = np.sum(delta * delta * fine_weights, axis=tuple(range(1, delta.ndim)))
    charge = np.sum(delta * fine_weights, axis=tuple(range(1, delta.ndim)))
    return {
        "name": name,
        "times": np.asarray(times),
        "owner": values,
        "fine": fine,
        "metrics": {
            "Q": charge,
            "L2": np.sqrt(np.maximum(mass, 0.0)),
            "peak_delta": np.max(delta, axis=tuple(range(1, delta.ndim))),
            "min_delta": np.min(delta, axis=tuple(range(1, delta.ndim))),
            "min_temperature": np.min(fine, axis=tuple(range(1, fine.ndim))),
            "max_temperature": np.max(fine, axis=tuple(range(1, fine.ndim))),
        },
    }


def run_resolution(N: int, opts, out: Path, audit, AggregateGeometry, build_aggregate_evaluation):
    case, history, host, meta = audit.load(N)
    sampler = audit.Sampler(history, host)
    shape = sampler.shape
    rawvol = np.asarray(host["host_raw_volume"], dtype=float)
    geometry = AggregateGeometry.from_host_payload(host)
    P, R, owner_volume, ids = _injection_and_restriction(host, rawvol, geometry)
    n = int(np.prod(shape))
    maps = sampler.maps
    valid_f = sampler.row("forward")[-1]
    valid_b = sampler.row("backward")[-1]
    selected_mask = valid_f & valid_b
    selected = np.flatnonzero(selected_mask.ravel())
    removed = ~selected_mask
    print(f"[{N}] loaded frozen maps/cache; selected {selected.size}/{n} interior both-leg rows", flush=True)

    print(f"[{N}] building aggregate source rows at every fine center (degree={opts.degree}, donors={opts.donors})", flush=True)
    u, theta, eta_grid = sampler.u, sampler.t, sampler.e
    source_xy = np.column_stack([(u * np.cos(theta)).ravel(), (u * np.sin(theta)).ravel()])
    source_eta = np.broadcast_to(np.arange(shape[2])[None, None, :], shape).ravel()
    S, source_diagnostics = _aggregate_eval(build_aggregate_evaluation, geometry, source_xy, source_eta, opts.degree, opts.donors, geometry.n_owner)
    print(f"[{N}] source rows ready nnz={S.nnz}", flush=True)
    print(f"[{N}] building legacy and aggregate endpoint rows", flush=True)
    endpoint = {}
    for direction in ("forward", "backward"):
        i, j, k, x, y, _ = sampler.row(direction)
        flat = selected
        endpoint_u = maps[f"{direction}_endpoint_x"].ravel()[flat]
        endpoint_theta = maps[f"{direction}_endpoint_y"].ravel()[flat]
        # Endpoint channels are physical regular-chart coordinates (u, theta),
        # while the companion ``*_x/y`` channels used by the legacy sampler
        # are logical donor indices.
        xy = np.column_stack([endpoint_u * np.cos(endpoint_theta), endpoint_u * np.sin(endpoint_theta)])
        eta = k.ravel()[flat]
        recon, diagnostics = _aggregate_eval(build_aggregate_evaluation, geometry, xy, eta, opts.degree, opts.donors, geometry.n_owner)
        endpoint[direction] = {"legacy": _legacy_endpoint(P, sampler, direction, selected), "recon": recon}
        endpoint[direction]["diagnostics"] = diagnostics
        print(f"[{N}] {direction} endpoint rows ready nnz={endpoint[direction]['recon'].nnz}", flush=True)

    f = 1.0 + audit.pulse(sampler.u, sampler.t, sampler.e, meta["heat_spot"])
    owner0 = np.asarray(R @ f.ravel())
    # The owner initial state is the same raw-volume average for all matched
    # operators.  This intentionally preserves the average-versus-point
    # initialization error for the comparison.
    baseline_initial = np.asarray(history["initial"] if "initial" in history else 1.0 + f).ravel()
    initial_reproduction_error = float(np.max(np.abs(P @ owner0 - baseline_initial)))
    invB_fine = 1.0 / np.asarray(history["magnetic_field"])
    if opts.coefficient_representation == "owner-injected":
        # Native owner q uses the frozen owner storage slots directly.  This
        # is deliberately distinct from a raw-volume average of fine 1/B.
        q_owner = invB_fine.ravel()[np.asarray(geometry.owner_flat_ids, dtype=np.int64)]
        q = (P @ q_owner).reshape(shape)
        expected_q = invB_fine.ravel()[np.asarray(host["topology_aggregate_id"], dtype=np.int64)].reshape(shape)
        if not np.allclose(q, expected_q, rtol=0.0, atol=0.0):
            raise AssertionError("owner-injected q does not match each raw topology owner slot")
        bcenter = 1.0 / q
    else:
        q_owner = np.asarray(R @ invB_fine.ravel())
        q = invB_fine
        bcenter = np.asarray(history["magnetic_field"])
    cp = 0.1 * bcenter * (q + sampler.sample(q, "forward")) / (
        maps["forward_length"] * (maps["forward_length"] + maps["backward_length"])
    )
    cm = 0.1 * bcenter * (q + sampler.sample(q, "backward")) / (
        maps["backward_length"] * (maps["forward_length"] + maps["backward_length"])
    )
    cpf, cmf = cp.ravel()[selected], cm.ravel()[selected]
    Psel = P[selected]
    Rs = R[:, selected]
    Ssel = S[selected]
    Ls = {}
    for name in ("legacy", "recon"):
        source_rows = Psel if name == "legacy" else Ssel
        bracket = sparse.diags(cpf).dot(endpoint["forward"][name] - source_rows)
        bracket = bracket + sparse.diags(cmf).dot(endpoint["backward"][name] - source_rows)
        Ls[name] = (Rs @ bracket).tocsr()
    # Support form uses the same selected rows and approximate physical-volume
    # quadrature.  It is a candidate diagnostic, with no production claim.
    Gp = endpoint["forward"]["recon"] - Ssel
    Gm = endpoint["backward"]["recon"] - Ssel
    ellp, ellm = maps["forward_length"].ravel()[selected], maps["backward_length"].ravel()[selected]
    Gp = sparse.diags(1.0 / ellp).dot(Gp).tocsr()
    Gm = sparse.diags(1.0 / ellm).dot(Gm).tocsr()
    Wp = 0.5 * rawvol.ravel()[selected] * 0.1
    Wm = Wp.copy()
    support = _make_support_operator(Gp, Gm, Wp, Wm, owner_volume)
    # Compute the explicit trace from CSR entries; no dense G.T G is formed.
    def trace_term(G, W):
        coo = G.tocoo()
        return float(np.sum(W[coo.row] * coo.data * coo.data / owner_volume[coo.col]))
    support_trace = -(trace_term(Gp, Wp) + trace_term(Gm, Wm))

    # Endpoint tests use the analytic pulse and independent legacy sampler.
    exact = {}
    endpoint_stats = {}
    endpoint_plot_errors = {}
    legacy_identity_error = {}
    for direction in ("forward", "backward"):
        m = maps
        eu, et, ee = [m[f"{direction}_endpoint_{axis}"] for axis in "xyz"]
        exact[direction] = (1.0 + audit.pulse(eu, et, ee, meta["heat_spot"])).ravel()[selected]
        fine_ep = sampler.sample(f, direction).ravel()[selected]
        owner_ep = endpoint[direction]["legacy"] @ owner0
        recon_ep = endpoint[direction]["recon"] @ owner0
        donor_min = float(np.min(owner0))
        donor_max = float(np.max(owner0))
        endpoint_stats[direction] = {
            "fine": _stats(fine_ep - exact[direction], np.ones(selected.size, bool), rawvol.ravel()[selected]),
            "legacy_owner": _stats(owner_ep - exact[direction], np.ones(selected.size, bool), rawvol.ravel()[selected]),
            "aggregate_reconstruction": _stats(recon_ep - exact[direction], np.ones(selected.size, bool), rawvol.ravel()[selected]),
            "donor_range": [donor_min, donor_max],
            "fine_endpoint_range": [float(np.min(fine_ep)), float(np.max(fine_ep))],
            "legacy_endpoint_range": [float(np.min(owner_ep)), float(np.max(owner_ep))],
            "aggregate_endpoint_range": [float(np.min(recon_ep)), float(np.max(recon_ep))],
        }
        legacy_identity_error[direction] = float(
            np.max(np.abs(owner_ep - sampler.sample((P @ owner0).reshape(shape), direction).ravel()[selected]))
        )
        endpoint_plot_errors[direction] = {
            "fine": fine_ep - exact[direction],
            "legacy_owner": owner_ep - exact[direction],
            "aggregate_reconstruction": recon_ep - exact[direction],
        }

    # A moment-polynomial diagnostic: the stored central second moments give
    # exact owner means for X^2+Y^2.  Check both source and endpoint rows
    # against the point polynomial.  This is a reproduction check, not an
    # accuracy certificate for the HSX field-line map.
    c = np.asarray(geometry.centroid_xy)
    second = np.asarray(geometry.central_second_xy)
    poly_owner = np.sum(c * c, axis=1) + np.trace(second, axis1=1, axis2=2)
    source_xy_selected = source_xy[selected]
    poly_source = np.asarray(Ssel @ poly_owner)
    poly_endpoint_plus = np.asarray(endpoint["forward"]["recon"] @ poly_owner)
    poly_endpoint_minus = np.asarray(endpoint["backward"]["recon"] @ poly_owner)
    poly_test = {
        "source_max_abs": float(np.max(np.abs(poly_source - np.sum(source_xy_selected**2, axis=1)))),
        "forward_endpoint_max_abs": float(np.max(np.abs(poly_endpoint_plus - np.sum(np.column_stack([maps["forward_endpoint_x"].ravel()[selected] * np.cos(maps["forward_endpoint_y"].ravel()[selected]), maps["forward_endpoint_x"].ravel()[selected] * np.sin(maps["forward_endpoint_y"].ravel()[selected])])**2, axis=1)))),
        "backward_endpoint_max_abs": float(np.max(np.abs(poly_endpoint_minus - np.sum(np.column_stack([maps["backward_endpoint_x"].ravel()[selected] * np.cos(maps["backward_endpoint_y"].ravel()[selected]), maps["backward_endpoint_x"].ravel()[selected] * np.sin(maps["backward_endpoint_y"].ravel()[selected])])**2, axis=1)))),
        "note": "X^2+Y^2 moment reproduction only; polynomial reproduction is not an HSX accuracy certificate",
    }

    records = {
        "legacy": Ls["legacy"],
        "reconstructed": Ls["recon"],
        "support": support,
    }
    evolution = {}
    evolution_frames = {}
    if not opts.skip_evolution:
        times = np.array([0.0, 0.05, 0.1, min(0.5, opts.final_time), opts.final_time], dtype=float)
        times = np.unique(times[times <= opts.final_time + 1e-15])
        fine_from_owner = lambda x: (P @ x).reshape(shape)
        for name, op in records.items():
            print(f"[{N}] evolving {name} through t={opts.final_time:g}", flush=True)
            traceA = float(op.diagonal().sum()) if sparse.issparse(op) else support_trace
            rec = _evolve(name, op, owner0, times, fine_from_owner, rawvol, opts.final_time, traceA)
            evolution_frames[name] = rec["fine"]
            evolution[name] = {
                "times": rec["times"],
                "metrics": {k: np.asarray(v) for k, v in rec["metrics"].items()},
                "constant": {},
            }
            # Constant perturbation is a direct null-space/conservation probe.
            constant0 = np.asarray(owner0 * 0.0 + 1.01)
            constant_residual = float(np.max(np.abs(op @ np.ones_like(constant0))))
            if constant_residual < 1.0e-11:
                const_values = np.broadcast_to(constant0, (len(times), constant0.size)).copy()
                const_fine = np.asarray([fine_from_owner(v) for v in const_values])
                const = {"Q": np.sum((const_fine - 1.0) * rawvol, axis=(1, 2, 3)),
                         "L2": np.sqrt(np.sum((const_fine - 1.0) ** 2 * rawvol, axis=(1, 2, 3))),
                         "peak_delta": np.full(len(times), 0.01), "min_delta": np.full(len(times), 0.01),
                         "min_temperature": np.full(len(times), 1.01), "max_temperature": np.full(len(times), 1.01)}
            else:
                const_rec = _evolve(name, op, constant0, times, fine_from_owner, rawvol, opts.final_time, traceA)
                const = const_rec["metrics"]
            evolution[name]["constant"] = {k: np.asarray(v) for k, v in const.items()}
            evolution[name]["constant_operator_residual_max_abs"] = constant_residual
            evolution[name]["constant_check_method"] = "operator residual; stationary values analytic, not time integrated"

    prefix = out / f"N{N}_degree{opts.degree}_donors{opts.donors}"
    np.savez_compressed(
        prefix.with_suffix(".npz"),
        selected=selected,
        selected_mask=selected_mask,
        owner_volume=owner_volume,
        **{"L_legacy_data": Ls["legacy"].data, "L_legacy_indices": Ls["legacy"].indices, "L_legacy_indptr": Ls["legacy"].indptr},
        **{"L_reconstructed_data": Ls["recon"].data, "L_reconstructed_indices": Ls["recon"].indices, "L_reconstructed_indptr": Ls["recon"].indptr},
    )
    if evolution_frames:
        np.savez_compressed(out / f"evolution_{N}.npz", times=times, **{f"{name}_fine": value for name, value in evolution_frames.items()})
    plot_payload = {"selected": selected}
    for direction, fields in endpoint_plot_errors.items():
        for name, values in fields.items():
            plot_payload[f"{direction}_{name}"] = np.asarray(values)
    np.savez_compressed(out / f"endpoint_errors_{N}.npz", **plot_payload)
    result = {
        "resolution": N,
        "degree": opts.degree,
        "donors": opts.donors,
        "coefficient_representation": opts.coefficient_representation,
        "case": case,
        "host_cache": str(ROOT / ".hsx_metric_cache" / HOSTS[N]),
        "selected_rows": int(selected.size),
        "removed_rows": int(removed.sum()),
        "removed_fraction_raw_volume": float(rawvol[removed].sum() / rawvol.sum()),
        "initial_owner_average_reproduction_max_abs": initial_reproduction_error,
        "endpoint_tests": endpoint_stats,
        "aggregate_diagnostics": {"source": source_diagnostics, **{d: endpoint[d]["diagnostics"] for d in ("forward", "backward")}},
        "legacy_sampler_identity_max_abs": legacy_identity_error,
        "endpoint_error_cache": str(out / f"endpoint_errors_{N}.npz"),
        "polynomial_tests": poly_test,
        "assembled": {
            "legacy_shape": list(Ls["legacy"].shape),
            "legacy_nnz": int(Ls["legacy"].nnz),
            "reconstructed_nnz": int(Ls["recon"].nnz),
            "support_trace": support_trace,
            "support_note": "approximate raw-volume quadrature candidate; no certified variable-B continuum claim",
            "support_coefficient_note": "support gradient form intentionally does not use the mapped variable-B coefficient; mass is unchanged",
            "coefficient_q_owner_range": [float(np.min(q_owner)), float(np.max(q_owner))],
            "coefficient_q_fine_range": [float(np.min(invB_fine)), float(np.max(invB_fine))],
            "coefficient_q_used_range": [float(np.min(q)), float(np.max(q))],
            "coefficient_fine_vs_owner_injected_max_abs": float(np.max(np.abs(invB_fine - (P @ q_owner).reshape(shape)))),
        },
        "evolution": evolution,
        "evolution_cache": str(out / f"evolution_{N}.npz") if evolution_frames else None,
    }
    return result


def _plots(results, out):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    endpoint_caches = []
    global_vmax = 0.0
    for result in results:
        cache = Path(result.get("endpoint_error_cache", ""))
        if cache.exists():
            with np.load(cache) as archive:
                endpoint_caches.append((result, {k: archive[k] for k in archive.files}))
                for key in archive.files:
                    if key == "selected":
                        continue
                    global_vmax = max(global_vmax, float(np.nanmax(np.abs(archive[key]))))
    global_vmax = max(global_vmax, 1.0e-14)
    for result, archive in endpoint_caches:
        N = int(result["resolution"])
        # The selected rows are scattered through the 3-D source grid.  Draw
        # the inspected eta=25 plane with one common symmetric scale for every
        # method and resolution in this invocation.
        selected = np.asarray(archive["selected"], dtype=int)
        nz = 32
        nx = N
        ny = N
        fig, axes = plt.subplots(2, 3, figsize=(13, 7), layout="constrained")
        labels = [("fine", "fine on centers"), ("legacy_owner", "legacy on P"), ("aggregate_reconstruction", "aggregate reconstruction")]
        for row, direction in enumerate(("forward", "backward")):
            for col, (name, title) in enumerate(labels):
                full = np.full(nx * ny * nz, np.nan)
                full[selected] = np.asarray(archive[f"{direction}_{name}"])
                image = full.reshape((nx, ny, nz))[:, :, min(25, nz - 1)]
                im = axes[row, col].pcolormesh(
                    np.arange(ny) / ny, np.arange(nx) / nx, image,
                    shading="nearest", cmap="RdBu_r", vmin=-global_vmax, vmax=global_vmax,
                )
                axes[row, col].set(xlabel="source theta / (2 pi)", ylabel="source u", title=f"{direction}: {title}")
        fig.colorbar(im, ax=axes.ravel().tolist(), label="endpoint temperature error", shrink=0.85)
        fig.suptitle(f"{N}x{N}x32 aggregate endpoint errors, eta index 25 (matching scale)")
        fig.savefig(out / f"endpoint_error_{N}_eta25.png", dpi=140)
        plt.close(fig)

    for result in results:
        if not result["evolution"]:
            continue
        fig, axes = plt.subplots(1, 2, figsize=(11, 4), layout="constrained")
        for name, rec in result["evolution"].items():
            t = np.asarray(rec["times"])
            axes[0].plot(t, np.asarray(rec["metrics"]["L2"]) / max(float(np.asarray(rec["metrics"]["L2"])[0]), 1e-300), marker="o", label=name)
            axes[1].plot(t, np.asarray(rec["metrics"]["peak_delta"]), marker="o", label=name)
        axes[0].set(xlabel="t", ylabel="L2 / initial", title=f"{result['resolution']} matched operators")
        axes[1].set(xlabel="t", ylabel="peak delta T", title="short evolution")
        for ax in axes:
            ax.grid(alpha=0.25)
            ax.legend()
        fig.savefig(out / f"evolution_{result['resolution']}.png", dpi=140)
        plt.close(fig)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--resolution", type=int, nargs="+", choices=[32, 64], default=[32, 64])
    parser.add_argument("--degree", type=int, choices=[2, 3], default=2)
    parser.add_argument("--donors", type=int, default=12)
    parser.add_argument("--final-time", type=float, default=0.5)
    parser.add_argument("--output-dir", type=Path, default=OUT)
    parser.add_argument("--skip-evolution", action="store_true")
    parser.add_argument("--coefficient-representation", choices=["owner-injected", "fine"], default="owner-injected")
    opts = parser.parse_args(argv)
    opts.output_dir.mkdir(parents=True, exist_ok=True)
    audit = _audit_module()
    AggregateGeometry, build_aggregate_evaluation = _load_core()
    results = []
    started = time.time()
    for N in opts.resolution:
        results.append(run_resolution(N, opts, opts.output_dir, audit, AggregateGeometry, build_aggregate_evaluation))
    hash_paths = [AUDIT_DIR / "audit.py", ROOT / "work/heat_no_rlp_20260913/cases.json", ROOT / "DRBX" / "src/drbx/geometry/fci_aggregate_reconstruction.py"]
    for result in results:
        hash_paths.extend([Path(result["host_cache"]), Path(result["case"]["baseline"]) / "history.npz"])
    provenance = {
        "created": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "command": sys.argv if argv is None else [__file__, *argv],
        "elapsed_seconds": time.time() - started,
        "inputs": _source_hash(*dict.fromkeys(hash_paths)),
        "limitations": [
            "interior both-leg rows only; omitted rows are a diagnostic closed/truncated boundary experiment",
            "same owner-averaged initialization retained across operators; average-versus-point error remains",
            "support form is an exploratory approximate volume-quadrature candidate, with no certified variable-B convergence claim",
            "no full HSX flux-function invariant is asserted",
        ],
    }
    payload = {"provenance": provenance, "results": results}
    (opts.output_dir / "metrics.json").write_text(json.dumps(payload, indent=2, default=_jsonable) + "\n")
    _plots(results, opts.output_dir)
    print(json.dumps({"output": str(opts.output_dir / "metrics.json"), "resolutions": opts.resolution}, indent=2), flush=True)


if __name__ == "__main__":
    main()
