"""Compare the completed aggregate operators on a common interior mask.

The analyzer reads only saved runner artifacts and frozen baseline geometry.
Its surface fractions are the same approximate radial-cell overlap diagnostic
used by ``work/heat_no_rlp_20260913/analyze.py``; they are not production
conservation measurements.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CASES = json.loads((ROOT / "work/heat_no_rlp_20260913/cases.json").read_text())


def _load_run(N):
    candidates = [HERE / f"native_owner{N}_t3p5", HERE / f"matched{N}_t3p5", HERE / f"quadratic{N}_t3p5", HERE / f"quadratic{N}"]
    for directory in candidates:
        metrics = directory / "metrics.json"
        if metrics.exists() and (directory / f"evolution_{N}.npz").exists():
            return directory, json.loads(metrics.read_text())
    raise FileNotFoundError(f"no completed quadratic run found for {N}")


def _mask(history):
    names = history["fci_map_field_names"].tolist()
    shape = history["volume_weights"].shape
    valid = []
    for direction in ("forward", "backward"):
        x = history["fci_map_fields"][..., names.index(f"{direction}_x")]
        boundary = history["fci_map_fields"][..., names.index(f"{direction}_boundary")].astype(bool)
        i = np.floor(x).astype(int)
        valid.append((~boundary) & (i >= 0) & (i < shape[0] - 1))
    return valid[0] & valid[1]


def _surface_fraction(delta, weights, u, theta_norm, contour_path, seed=0.19):
    with np.load(contour_path) as archive:
        seed_u = np.asarray(archive["seed_u"])
        j = int(np.argmin(np.abs(seed_u - seed)))
        contour_theta = np.asarray(archive["contour_theta"])
        contour_u = np.asarray(archive["contour_u"][:, j, :])
        valid = np.asarray(archive["valid_surfaces"][:, j], dtype=bool)
    theta = np.asarray(theta_norm)
    radii = np.stack([np.interp(theta, contour_theta, contour_u[k]) for k in range(weights.shape[2])], axis=1)
    edges = np.empty(len(u) + 1)
    edges[1:-1] = 0.5 * (u[:-1] + u[1:])
    edges[0], edges[-1] = 0.0, 1.0
    fraction = np.clip((radii[None, :, :] - edges[:-1, None, None]) / np.diff(edges)[:, None, None], 0.0, 1.0)
    fraction *= valid[None, None, :]
    inside = float(np.sum(delta * weights * fraction))
    total = float(np.sum(delta * weights))
    return {
        "seed_u": float(seed_u[j]),
        "valid_eta_planes": int(np.count_nonzero(valid)),
        "initial_fraction_percent": None if total == 0 else float(100.0 * inside / total),
        "weighted_inside": inside,
        "weighted_total": total,
    }


def _angular_centroid(signal, theta_phase):
    """Unweighted signed delta-T centroid on the common quarter-torus patch."""
    keep = (theta_phase > 0.25) & (theta_phase < 0.75)
    denominator = float(np.sum(np.asarray(signal)[keep]))
    if abs(denominator) <= 1.0e-14:
        return None
    return float(np.sum(np.asarray(signal)[keep] * theta_phase[keep]) / denominator)


def main():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    loaded = {}
    all_plot_values = []
    for N in (32, 64):
        directory, metrics = _load_run(N)
        result = metrics["results"][0]
        case = next(c for c in CASES if c["resolution"] == N)
        with np.load(Path(case["baseline"]) / "history.npz") as archive:
            history = {k: archive[k] for k in archive.files}
        with np.load(Path(result["host_cache"])) as host:
            raw_weights = np.asarray(host["host_raw_volume"], dtype=float)
        with np.load(directory / f"evolution_{N}.npz") as archive:
            times = np.asarray(archive["times"])
            fields = {name[:-5]: np.asarray(archive[name]) for name in archive.files if name.endswith("_fine")}
        selected = _mask(history)
        loaded[N] = (directory, metrics, result, history, times, fields, selected, raw_weights)
        for values in fields.values():
            all_plot_values.append(values - 1.0)

    scale = max(float(np.max(np.abs(np.concatenate([v.reshape(-1) for v in all_plot_values])))), 1.0e-12)
    column_scales = {}
    for target in (0.0, 0.5, 3.5):
        values = []
        for _, _, _, _, times, fields, _, _ in loaded.values():
            index = int(np.argmin(np.abs(times - target)))
            values.extend((v[index] - 1.0).reshape(-1) for v in fields.values())
        column_scales[target] = max(float(np.max(np.abs(np.concatenate(values)))), 1.0e-12)
    summary = {"runs": {}, "limitations": [
        "operator source and endpoint rows use the saved both-leg interior mask; full-field budgets use host raw volume",
        "surface budgets use approximate fractional radial-cell overlap from prepared contours and full stored fields",
        "polynomial local-centroid curves diagnose aggregate moments and do not certify HSX flux-surface accuracy",
    ]}

    for N, (directory, metrics, result, history, times, fields, selected, weights) in loaded.items():
        case = next(c for c in CASES if c["resolution"] == N)
        u, theta = history["u"], history["theta"]
        targets = [0.0, 0.5, 3.5]
        indices = [int(np.argmin(np.abs(times - t))) for t in targets]
        fig, axes = plt.subplots(3, 3, figsize=(13, 10), layout="constrained")
        images = []
        for row, name in enumerate(("legacy", "reconstructed", "support")):
            arr = fields[name] - 1.0
            for col, (target, index) in enumerate(zip(targets, indices)):
                image = arr[index, :, :, min(25, arr.shape[3] - 1)]
                im = axes[row, col].pcolormesh(theta / (2.0 * np.pi), u, image, shading="nearest", cmap="RdBu_r", vmin=-column_scales[target], vmax=column_scales[target])
                axes[row, col].axhline(0.34375, color="black", ls="--", lw=0.7)
                axes[row, col].set_xlim(0.25, 0.75); axes[row, col].set_ylim(0.15, 0.6)
                axes[row, col].set(xlabel="theta / (2 pi)", ylabel="u", title=f"{name}, t={times[index]:g}")
                if row == 0: images.append(im)
        for col, image in enumerate(images):
            fig.colorbar(image, ax=axes[:, col].tolist(), label=f"delta T; shared t={targets[col]} scale", shrink=0.85)
        fig.suptitle(f"{N}x{N}x32 aggregate operators, eta index 25")
        fig.savefig(HERE / f"comparison_shapes_{N}.png", dpi=140)
        plt.close(fig)

        # Compare the actual hotspot angular centroid versus u at eta=25.
        # The numerator remains signed; the positive heat mass is only the
        # denominator guard requested for rows with nearly vanished signal.
        eta_index = min(25, weights.shape[2] - 1)
        phase = theta / (2.0 * np.pi)
        centroids = {}
        for name, arr in fields.items():
            d = arr[int(np.argmin(np.abs(times - 3.5)))] - 1.0
            rows = []
            for i in range(len(u)):
                signal = d[i, :, eta_index]
                rows.append(_angular_centroid(signal, phase))
            centroids[name] = np.asarray(rows)
        fig, ax = plt.subplots(figsize=(7, 4), layout="constrained")
        for name, values in centroids.items(): ax.plot(u, values, marker="o", ms=2, label=name)
        ax.set(xlabel="u", ylabel="signed delta-T angular centroid / (2 pi)", title=f"{N}: hotspot centroid versus u, eta index 25, t=3.5")
        ax.grid(alpha=0.25); ax.legend()
        fig.savefig(HERE / f"hotspot_centroid_{N}.png", dpi=140)
        plt.close(fig)

        transition_rows = {}
        transition_centroids = {}
        if N == 64:
            # Inspect the two saved cell-center rows straddling the angular
            # grouping transition against both historical controls.
            controls = {
                "historical_RLP": Path(case["baseline"]) / "history.npz",
                "no_RLP_control": Path(case["output"]) / "history.npz",
            }
            profiles = {}
            for control_name, control_path in controls.items():
                with np.load(control_path) as control:
                    ct = np.asarray(control["times"])
                    profiles[control_name] = (np.asarray(control["Te"])[int(np.argmin(np.abs(ct - 3.5)))], np.asarray(control["volume_weights"]))
            for name, arr in fields.items():
                profiles[name] = (arr[int(np.argmin(np.abs(times - 3.5)))], weights)
            row_indices = [21, 22]
            theta_phase = theta / (2.0 * np.pi)
            profile_scale = max(float(np.max(np.abs(temp[i, :, 25] - 1.0))) for i in row_indices for temp, _ in profiles.values())
            figure, row_axes = plt.subplots(2, 1, figsize=(9, 7), sharex=True, layout="constrained")
            for axis, i in zip(np.atleast_1d(row_axes), row_indices):
                for name, (temperature, _) in profiles.items():
                    axis.plot(theta_phase, temperature[i, :, 25] - 1.0, label=name)
                axis.axvspan(0.25, 0.75, color="0.8", alpha=0.15)
                axis.set_ylim(-profile_scale * 1.05, profile_scale * 1.05)
                axis.set_ylabel(f"delta T (u={u[i]:.7f})")
                axis.grid(alpha=0.25)
                axis.legend(ncol=3, fontsize=8)
                transition_rows[str(u[i])] = {
                    name: [float(v) for v in temperature[i, :, 25] - 1.0]
                    for name, (temperature, _) in profiles.items()
                }
                transition_centroids[str(u[i])] = {
                    name: _angular_centroid(temperature[i, :, 25] - 1.0, theta_phase)
                    for name, (temperature, _) in profiles.items()
                }
            row_axes[-1].set_xlabel("theta / (2 pi)")
            figure.suptitle("64 t=3.5 angular transition rows, eta index 25")
            figure.savefig(HERE / "angular_transition_rows_64_t3p5.png", dpi=140)
            plt.close(figure)

        contour = Path(case["baseline"]) / "makegrid_poincare_theta_u.npz"
        per_method = {}
        for name, arr in fields.items():
            d = arr - 1.0
            q = np.sum(d * weights[None, ...], axis=(1, 2, 3))
            l2 = np.sqrt(np.sum(d * d * weights[None, ...], axis=(1, 2, 3)))
            runner_q = np.asarray(metrics["results"][0]["evolution"][name]["metrics"]["Q"], dtype=float)
            if runner_q.shape == q.shape and not np.allclose(q, runner_q, rtol=1.0e-12, atol=1.0e-15):
                raise AssertionError(f"{N} {name}: analyzer Q disagrees with runner metrics")
            surface = _surface_fraction(d[0], weights, u, theta / (2.0 * np.pi), contour)
            at_times = {}
            for target, index in zip(targets, indices):
                dm = d[index]
                surface_t = _surface_fraction(dm, weights, u, theta / (2.0 * np.pi), contour)
                at_times[str(target)] = {
                    "time_used": float(times[index]),
                    "Q": float(q[index]),
                    "Q_drift_percent_from_t0": float(100.0 * (q[index] / q[0] - 1.0)),
                    "L2_over_initial": float(l2[index] / max(l2[0], 1.0e-300)),
                    "min_delta": float(np.min(dm[selected])),
                    "min_temperature": float(np.min((dm + 1.0)[selected])),
                    "max_delta": float(np.max(dm[selected])),
                    "surface_seed_019": surface_t,
                }
            per_method[name] = {"at_times": at_times, "surface_initial": surface}
        summary["runs"][str(N)] = {
            "directory": str(directory),
            "coefficient_representation": result.get("coefficient_representation", "fine (pre-flag artifact; rerun for owner-injected matched control)"),
            "selected_rows": int(np.count_nonzero(selected)),
            "removed_rows": int(selected.size - np.count_nonzero(selected)),
            "removed_fraction_volume_weights": float(np.sum(weights[~selected]) / np.sum(weights)),
            "shape_scale_by_time": column_scales,
            "transition_rows_angular_profiles": transition_rows,
            "transition_rows_angular_centroids": transition_centroids,
            "operators": per_method,
        }

    (HERE / "comparison_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"summary": str(HERE / "comparison_summary.json"), "resolutions": sorted(loaded)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
