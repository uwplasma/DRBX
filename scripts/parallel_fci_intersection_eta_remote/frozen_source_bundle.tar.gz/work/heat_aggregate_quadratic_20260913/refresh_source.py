"""Refresh the frozen source snapshot after integration, before any launch.

The refresh is deliberately separate from ``prepare.py`` so an already
reviewed case plan can keep its output directories while the source snapshot
is replaced.  It refuses to run once any case has been started.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
RUN = Path(__file__).resolve().parent
SOURCE = RUN / "source"
DRIVER = ROOT / "run_hsx_sanity.py"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _case_outputs() -> list[Path]:
    result: list[Path] = []
    cases_path = RUN / "cases.json"
    if not cases_path.exists():
        return result
    for case in json.loads(cases_path.read_text()):
        for key in ("output", "legacy_output"):
            if case.get(key):
                result.append(Path(case[key]).resolve())
    return result


def _launch_artifacts() -> list[Path]:
    roots = [RUN, *_case_outputs()]
    found: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            if path.name in {"process_status.json", "launch.json"} or path.name.startswith("launch_") and path.suffix == ".json":
                found.append(path)
    return sorted(set(found))


def _snapshot() -> None:
    if "--conduction-reconstruction" not in DRIVER.read_text() or "aggregate-quadratic" not in DRIVER.read_text():
        raise SystemExit("run_hsx_sanity.py does not contain the aggregate-quadratic integration marker")
    staging = RUN / ".source_refreshing"
    if staging.exists():
        raise SystemExit(f"stale staging directory exists: {staging}")
    (staging / "DRBX").mkdir(parents=True)
    for relative in ("run_hsx_sanity.py", "run_hsx_perpendicular_convergence.py"):
        shutil.copy2(ROOT / relative, staging / relative)
    shutil.copy2(ROOT / "DRBX" / "simulate_hsx_blob.py", staging / "DRBX" / "simulate_hsx_blob.py")
    shutil.copytree(ROOT / "DRBX" / "src", staging / "DRBX" / "src", ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    files = {
        str(path.relative_to(staging)): sha256(path)
        for path in staging.rglob("*") if path.is_file()
    }
    git = lambda *args: subprocess.check_output(["git", "-C", str(ROOT / "DRBX"), *args], text=True).strip()
    manifest = {
        "git_head": git("rev-parse", "HEAD"),
        "git_status": git("status", "--short"),
        "integration_driver": str(DRIVER),
        "integration_driver_sha256": sha256(DRIVER),
        "aggregate_flag": ["--conduction-reconstruction", "aggregate-quadratic"],
        "refreshed_at": datetime.now(timezone.utc).isoformat(),
        "files_sha256": files,
    }
    if SOURCE.exists():
        shutil.rmtree(SOURCE)
    os.replace(staging, SOURCE)
    old_manifest = RUN / "source_manifest.json"
    if old_manifest.exists():
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        shutil.copy2(old_manifest, RUN / f"source_manifest.pre_refresh_{stamp}.json")
    old_manifest.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")


def main() -> None:
    artifacts = _launch_artifacts()
    if artifacts:
        formatted = "\n".join(f"  {path}" for path in artifacts)
        raise SystemExit("refusing to refresh after launch artifacts were created:\n" + formatted)
    if not SOURCE.exists() or not (RUN / "source_manifest.json").exists():
        raise SystemExit("prepare.py must create the initial source snapshot and cases before refresh")
    _snapshot()
    print(f"refreshed {SOURCE}; archived the previous source manifest")


if __name__ == "__main__":
    main()
