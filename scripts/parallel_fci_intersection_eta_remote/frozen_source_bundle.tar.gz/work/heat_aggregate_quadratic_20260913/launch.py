"""Launch aggregate heat cases after the required short smoke gates."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[1]


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--smoke", action="store_true", help="launch the three-step gate")
    result.add_argument("--legacy-control", action="store_true", help="launch native legacy RLP instead of reconstruction")
    result.add_argument("--resolution", type=int, choices=(32, 64), action="append")
    result.add_argument("--steps", type=int, default=None)
    result.add_argument("--final-time", type=float, default=None)
    return result


def read_status(path: Path) -> dict[str, object] | None:
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return None


def atomic_json(path: Path, value: object) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def main() -> None:
    opts = parser().parse_args()
    cases = json.loads((RUN / "cases.json").read_text())
    selected = [case for case in cases if opts.resolution is None or int(case["resolution"]) in opts.resolution]
    if not selected:
        raise SystemExit("no selected cases")
    modes = ["legacy"] if opts.legacy_control else (["legacy", "reconstructed"] if opts.smoke else ["reconstructed"])
    if not opts.smoke:
        for case in selected:
            resolution = int(case["resolution"])
            for mode in ("legacy", "reconstructed"):
                status = read_status(RUN / f"smoke{resolution}_{mode}" / "process_status.json")
                if not status or status.get("state") != "completed" or status.get("steps") != 3 or status.get("mode") != mode:
                    raise SystemExit(f"three-step smoke gate is incomplete for {resolution} {mode}")

    launched = []
    for case in selected:
        resolution = int(case["resolution"])
        for mode in modes:
            output = (
                RUN / f"smoke{resolution}_{mode}"
                if opts.smoke
                else Path(case.get("legacy_output") if mode == "legacy" else case["output"]).resolve()
            )
            if (output / "process_status.json").exists():
                prior = read_status(output / "process_status.json") or {}
                if prior.get("state") in {"initializing", "integrating"}:
                    raise SystemExit(f"case already running: {output}")
                if prior.get("state") == "completed":
                    raise SystemExit(f"case already completed: {output}")
            command = [sys.executable, "-u", str(RUN / "run_case.py"), str(resolution)]
            if opts.smoke:
                command.append("--smoke")
            if mode == "legacy":
                command.append("--legacy-control")
            if opts.steps is not None:
                command += ["--steps", str(opts.steps)]
            if opts.final_time is not None:
                command += ["--final-time", str(opts.final_time)]
            log = output / "run.log"
            output.mkdir(parents=True, exist_ok=True)
            env = os.environ.copy()
            env.update({
                "DRBX_CACHE_DIR": str(RUN / "jax_cache"),
                "DRBX_HOST_DEVICE_COUNT": "1",
                "OMP_NUM_THREADS": "4",
                "OPENBLAS_NUM_THREADS": "1",
                "PYTHONUNBUFFERED": "1",
            })
            env.pop("DRBX_SOURCE_ROOT", None)
            with log.open("ab", buffering=0) as stream:
                process = subprocess.Popen(
                    command, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT,
                    cwd=ROOT, env=env, start_new_session=True,
                )
            record = {
                "resolution": resolution, "mode": mode, "pid": process.pid,
                "command": command, "log": str(log), "output": str(output), "launched_at": time.time(),
            }
            atomic_json(output / "launch.json", record)
            launched.append(record)
    atomic_json(RUN / f"launch_{'smoke' if opts.smoke else 'full'}_{int(time.time())}.json", launched)
    print(json.dumps(launched, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
