"""Run one frozen HSX conduction case with aggregate quadratic control.

The source tree and metric/map inputs are selected by ``cases.json``.  The
driver replays the baseline maps and checks the geometry before entering the
Te-only RK4 lane, so a completed directory is a matched, inspectable case.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

import numpy as np

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[1]
os.environ["DRBX_CACHE_DIR"] = str(RUN / "jax_cache")
HOST_CACHE = {
    32: ROOT / ".hsx_metric_cache/angular_rlp_host_5180c3964f2704f3a5beb5fc.npz",
    64: ROOT / ".hsx_metric_cache/angular_rlp_host_2b02c6728ab3c3d2ad9af823.npz",
}


def _status(path: Path, **fields: object) -> None:
    payload = {"pid": os.getpid(), "updated": time.time(), **fields}
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_host_reference(resolution: int) -> dict[str, np.ndarray]:
    path = HOST_CACHE[resolution]
    if not path.exists():
        raise RuntimeError(f"missing authoritative RLP host cache: {path}")
    with np.load(path) as archive:
        return {name: np.asarray(archive[name]).copy() for name in archive.files}


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("resolution", type=int, choices=(32, 64))
    parser.add_argument("--smoke", action="store_true", help="use the three-step gate")
    parser.add_argument("--legacy-control", action="store_true", help="use the native nearest-point RLP path")
    parser.add_argument("--steps", type=int, default=None, help="override the case's number of RK4 steps")
    parser.add_argument("--final-time", type=float, default=None, help="override the case's final time")
    parser.add_argument("--output-dir", type=Path, default=None, help="override the case output directory")
    return parser


def main() -> None:
    opts = _parser().parse_args()
    cases = json.loads((RUN / "cases.json").read_text())
    case = next(item for item in cases if int(item["resolution"]) == opts.resolution)
    baseline = Path(case["baseline"]).resolve()
    source = Path(case["source"]).resolve()
    if not source.is_dir():
        raise SystemExit(f"missing frozen source snapshot: {source}; run prepare.py after integration review")
    metadata = json.loads((baseline / "metadata.json").read_text())
    contract = metadata["geometry_contract"]
    host_reference = _load_host_reference(opts.resolution)
    mode = "legacy" if opts.legacy_control else "reconstructed"
    if opts.output_dir is not None:
        output = opts.output_dir.resolve()
    elif opts.smoke:
        output = RUN / f"smoke{opts.resolution}_{mode}"
    else:
        output = Path(case.get("legacy_output") if opts.legacy_control else case["output"]).resolve()
    if output.exists():
        forbidden = {"process_status.json", "history.npz", "metadata.json", "geometry_verification.json"}
        present_forbidden = sorted(name for name in forbidden if (output / name).exists())
        if present_forbidden:
            raise SystemExit(f"output contains prior run artifacts: {output} ({present_forbidden})")
        output.mkdir(parents=True, exist_ok=True)
    else:
        output.mkdir(parents=True)
    contour = output / "makegrid_poincare_theta_u.npz"
    contour_source = contour if contour.exists() else baseline / "makegrid_poincare_theta_u.npz"
    with np.load(contour_source) as archive:
        values = {key: archive[key] for key in archive.files}
    values["source_history"] = np.asarray(str(output / "history.npz"))
    values["metric_evaluator_path"] = np.asarray(str(case["metric_file"]))
    np.savez_compressed(contour, **values)
    status = output / "process_status.json"
    started = time.time()
    _status(status, state="initializing", mode=mode, smoke=opts.smoke)

    try:
        argv = ["--experiment", "heat-spot", "--initial-condition", "heat-spot", "--output-dir", str(output)]
        if not opts.legacy_control:
            argv += ["--conduction-reconstruction", "aggregate-quadratic"]
        for key in ("resolution", "fit_sample_shape", "metric_mesh_shape", "makegrid_currents"):
            argv += ["--" + key.replace("_", "-"), ",".join(map(str, contract[key]))]
        for key in (
            "makegrid_path", "vessel_path", "radial_degree", "vertical_degree", "toroidal_modes",
            "metric_spline_degree", "mmpde_iterations", "axis_core_radius", "metric_radial_degree",
            "metric_poloidal_modes", "metric_toroidal_modes", "eta_projection_iterations", "fci_trace_substeps",
        ):
            argument = {"makegrid_path": "makegrid", "vessel_path": "vessel"}.get(key, key.replace("_", "-"))
            argv += ["--" + argument, str(contract[key])]
        argv += ["--metric-cache-dir", str(case["metric_cache"]), "--halo-width", "2"]
        for key, value in metadata["heat_spot"].items():
            argv += ["--" + key.replace("_", "-"), str(value)]
        steps = int(opts.steps if opts.steps is not None else (3 if opts.smoke else case["num_steps"]))
        final_time = float(opts.final_time if opts.final_time is not None else steps * float(case["dt"]))
        save_every = 1 if opts.smoke else min(int(case["save_every"]), steps)
        argv += ["--num-steps", str(steps), "--final-time", str(final_time), "--save-every", str(save_every)]

        os.environ.pop("DRBX_SOURCE_ROOT", None)
        sys.path.insert(0, str(source))
        import run_hsx_sanity as sanity  # type: ignore
        if not str(Path(sanity.production.__file__).resolve()).startswith(str(source / "DRBX")):
            raise RuntimeError(f"production module escaped frozen source: {sanity.production.__file__}")
        import drbx  # type: ignore
        if not str(Path(drbx.__file__).resolve()).startswith(str(source / "DRBX" / "src")):
            raise RuntimeError(f"drbx package escaped frozen source: {drbx.__file__}")

        args = sanity.build_parser().parse_args(argv)

        def replay_maps(**kwargs):
            expected = Path(case["metric_file"]).resolve()
            selected = kwargs["cache_path"]
            if selected is None or Path(selected).resolve() != expected:
                raise RuntimeError("geometry builder did not select the frozen baseline metric cache")
            with np.load(baseline / "history.npz") as archive:
                names = archive["fci_map_field_names"].tolist()
                fields = archive["fci_map_fields"]
                values = {
                    name: np.asarray(fields[..., index], dtype=bool if name.endswith("_boundary") else np.float64)
                    for index, name in enumerate(names)
                }
            bfield = sanity.production.bfield_evaluator_from_makegrid(
                Path(contract["makegrid_path"]), currents=np.asarray(contract["makegrid_currents"]), method="cubic"
            )
            for direction in ("forward", "backward"):
                mask = values[direction + "_boundary"]
                points = np.stack([values[direction + "_endpoint_" + axis][mask] for axis in ("x", "y", "z")], axis=-1)
                evaluated = kwargs["metric_evaluator"].evaluate_magnetic_field(points, bfield)
                for index, axis in enumerate(("x", "y", "z")):
                    channel = np.zeros(mask.shape)
                    channel[mask] = evaluated.B_contravariant[:, index]
                    values[direction + "_endpoint_b_contra_" + axis] = channel
                channel = np.zeros(mask.shape)
                channel[mask] = evaluated.magnitude
                values[direction + "_endpoint_bmag"] = channel
            maps = sanity.production.FciMaps3D(**values)
            sanity.production.validate_hsx_fci_maps(maps, kwargs["grid"], topology="toroidal")
            print("[control] replaying frozen baseline FCI maps", flush=True)
            return maps, kwargs["cache_payload"], kwargs["bfield"]

        sanity.production._build_or_load_hsx_fci_maps = replay_maps
        original_build = sanity.production.build_hsx_fci_geometry
        original_owner_builder = sanity.production.build_metric_aware_polar_angular_agglomeration_geometry

        def checked_owner_builder(*owner_args, **owner_kwargs):
            owner_geometry, safety = original_owner_builder(*owner_args, **owner_kwargs)
            checks = {}
            topology = owner_geometry.topology
            comparisons = {
                "angular_group_size": (owner_geometry.angular_group_size, host_reference["angular_group_size"]),
                "is_active_owner": (topology.is_active_owner, host_reference["topology_is_active_owner"]),
                "aggregate_volume": (owner_geometry.aggregate_chart_volume, host_reference["host_aggregate_chart_volume"]),
                "aggregate_centroid": (owner_geometry.aggregate_chart_centroid, host_reference["host_aggregate_chart_centroid"]),
                "aggregate_second_moment": (owner_geometry.aggregate_chart_second_moment, host_reference["host_aggregate_chart_second_moment"]),
                "aggregate_third_moment": (owner_geometry.aggregate_chart_third_moment, host_reference["host_aggregate_chart_third_moment"]),
                "raw_volume": (owner_geometry.raw_volume, host_reference["host_raw_volume"]),
                "raw_chart_centroid": (owner_geometry.raw_chart_centroid, host_reference["host_raw_chart_centroid"]),
                "raw_chart_second_moment": (owner_geometry.raw_chart_second_moment, host_reference["host_raw_chart_second_moment"]),
                "raw_chart_third_moment": (owner_geometry.raw_chart_third_moment, host_reference["host_raw_chart_third_moment"]),
            }
            for name, (actual, expected) in comparisons.items():
                actual = np.asarray(actual)
                expected = np.asarray(expected)
                if actual.shape != expected.shape:
                    raise RuntimeError(f"RLP host cache shape mismatch for {name}: {actual.shape} != {expected.shape}")
                if name == "angular_group_size" or name == "is_active_owner":
                    checks[name] = {"mismatch_count": int(np.count_nonzero(actual != expected)), "shape": list(actual.shape)}
                    np.testing.assert_array_equal(actual, expected, err_msg=f"RLP host mismatch: {name}")
                else:
                    checks[name] = {"max_abs": float(np.max(np.abs(actual - expected))), "shape": list(actual.shape)}
                    np.testing.assert_allclose(actual, expected, rtol=1e-12, atol=1e-13, err_msg=f"RLP host mismatch: {name}")
            (output / "rlp_geometry_verification.json").write_text(json.dumps(checks, indent=2) + "\n")
            return owner_geometry, safety

        sanity.production.build_metric_aware_polar_angular_agglomeration_geometry = checked_owner_builder

        def checked_geometry(**kwargs):
            result = original_build(**kwargs)
            geometry, positions, _nfp, _cache, _evaluator = result
            sharded = sanity.build_local_fci_geometries(
                geometry, (1, 1, 1), halo_width=2,
                periodic_axes=(False, True, True), axis_regular_axes=(True, False, False),
            )
            checks = {}
            with np.load(baseline / "history.npz") as archive:
                pairs = {
                    "u": geometry.grid.x.centers,
                    "theta": geometry.grid.y.centers,
                    "eta": geometry.grid.z.centers,
                    "metric_J": geometry.cell_metric.J,
                    "magnetic_field": geometry.cell_bfield.Bmag,
                    "Cartesian_position": positions,
                    "fci_map_fields": sharded.map_fields,
                    "volume_weights": sanity._weights(geometry),
                }
                for key, current in pairs.items():
                    actual = np.asarray(current)
                    expected = archive[key]
                    if key == "fci_map_fields":
                        current_names = list(sanity.production.FCI_MAP_FIELDS)
                        baseline_names = archive["fci_map_field_names"].tolist()
                        actual = actual[..., [current_names.index(name) for name in baseline_names]]
                        checks["extra_map_channels"] = [name for name in current_names if name not in baseline_names]
                    checks[key] = {"max_abs": float(np.max(np.abs(actual - expected))), "shape": list(actual.shape)}
                    np.testing.assert_allclose(actual, expected, rtol=1e-12, atol=1e-13, err_msg=f"baseline mismatch: {key}")
            (output / "geometry_verification.json").write_text(json.dumps(checks, indent=2) + "\n")
            print("[control] geometry, coordinates, B, weights, and FCI maps match baseline", flush=True)
            _status(status, state="integrating", mode=mode, smoke=opts.smoke, steps=steps, final_time=final_time)
            return result

        sanity.production.build_hsx_fci_geometry = checked_geometry
        history = sanity.run_heat_spot(args)
        group_sizes_match = False
        initial_baseline_match = False
        finite_te = False
        endtime_match = False
        with np.load(history) as result:
            expected_group_sizes = host_reference["angular_group_size"]
            with np.load(baseline / "history.npz") as reference:
                if "angular_group_sizes" in reference.files:
                    np.testing.assert_array_equal(reference["angular_group_sizes"], expected_group_sizes)
                np.testing.assert_array_equal(result["angular_group_sizes"], expected_group_sizes)
                group_sizes_match = True
                np.testing.assert_allclose(result["Te"][0], reference["Te"][0], rtol=0.0, atol=3e-15)
                initial_baseline_match = True
            if not np.isfinite(result["Te"]).all() or float(np.min(result["Te"])) <= 0.0:
                raise RuntimeError("heat-spot integration produced a non-finite or non-positive Te")
            finite_te = True
            if not np.isclose(result["times"][-1], final_time, rtol=0.0, atol=1e-13):
                raise RuntimeError(f"history ended at {result['times'][-1]}, expected {final_time}")
            endtime_match = True
        result_metadata = json.loads((output / "metadata.json").read_text())
        result_metadata["control_provenance"] = {
            "baseline": str(baseline),
            "source_manifest": str(RUN / "source_manifest.json"),
            "source_manifest_sha256": _sha256(RUN / "source_manifest.json"),
            "geometry_replay": "frozen baseline metric and FCI maps, verified against saved history",
            "control_mode": mode,
            "command_argv": argv,
        }
        (output / "metadata.json").write_text(json.dumps(result_metadata, indent=2, sort_keys=True) + "\n")
        if not (output / "makegrid_poincare_theta_u.npz").exists():
            with np.load(baseline / "makegrid_poincare_theta_u.npz") as archive:
                np.savez_compressed(output / "makegrid_poincare_theta_u.npz", **{key: archive[key] for key in archive.files})
        _status(
            status, state="completed", mode=mode, smoke=opts.smoke, steps=steps,
            final_time=final_time, group_sizes_baseline=group_sizes_match,
            initial_baseline=initial_baseline_match, elapsed_seconds=time.time() - started,
            non_te_frozen=True, finite_te=finite_te, endtime=endtime_match,
            verified_rlp=True, history=str(history),
        )
        print(f"[{mode}] completed and verified: {history}", flush=True)
    except BaseException as exc:
        _status(status, state="failed", mode=mode, smoke=opts.smoke, error=repr(exc))
        traceback.print_exc()
        raise


if __name__ == "__main__":
    main()
