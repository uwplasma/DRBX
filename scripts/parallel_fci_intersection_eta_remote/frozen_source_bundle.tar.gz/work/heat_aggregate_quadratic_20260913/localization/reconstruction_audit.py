"""Bounded localization audit for the completed quadratic reconstructions.

This diagnostic rebuilds source and two-sided endpoint CSR rows from the
frozen source and host moment caches.  It does not evolve a new trajectory or
modify package code, caches, or completed histories.  Its operator RHS probes
are evaluations on saved frames only; boundary and wall closure rows are
explicitly outside the assembled partial-interior audit.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys

import numpy as np

RUN = Path(__file__).resolve().parents[1]
ROOT = RUN.parents[1]
FROZEN_SRC = RUN / "source" / "DRBX" / "src"
if str(FROZEN_SRC) not in sys.path:
    sys.path.insert(0, str(FROZEN_SRC))
from scipy import sparse
from scipy.sparse import save_npz

from drbx.geometry.fci_aggregate_reconstruction import (  # type: ignore
    AggregateGeometry,
    build_aggregate_evaluation,
)

if not str(Path(sys.modules["drbx.geometry.fci_aggregate_reconstruction"].__file__).resolve()).startswith(str(FROZEN_SRC)):
    raise RuntimeError("aggregate reconstruction module escaped the frozen source snapshot")

OUT = RUN / "localization"
OUT.mkdir(parents=True, exist_ok=True)
HOSTS = {
    32: RUN / "metric_cache_32" / "angular_rlp_host_85832e63967cf29a96d27b10.npz",
    64: RUN / "metric_cache_64" / "angular_rlp_host_390bee6323f1de99aafa7806.npz",
}
DEGREE = 2
DONORS = 32
MAX_DONORS = 96
CONDITION_LIMIT = 1.0e8
WEIGHT_POWER = 4.0
L1_LIMIT = 8.0


def load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path) as archive:
        return {key: np.asarray(archive[key]).copy() for key in archive.files}


def load_cases() -> list[dict[str, object]]:
    return json.loads((RUN / "cases.json").read_text())


def maps_from_history(history: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
    names = history["fci_map_field_names"].tolist()
    fields = history["fci_map_fields"]
    return {str(name): np.asarray(fields[..., i]) for i, name in enumerate(names)}


def map_rows(maps: dict[str, np.ndarray], shape: tuple[int, int, int], direction: str) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    x = np.asarray(maps[direction + "_x"], dtype=float)
    y = np.asarray(maps[direction + "_y"], dtype=float)
    finite = np.isfinite(x) & np.isfinite(y)
    ii = np.floor(np.nan_to_num(x, nan=0.0)).astype(np.int64)
    jj = np.floor(np.nan_to_num(y, nan=0.0)).astype(np.int64) % shape[1]
    kk = (np.arange(shape[2])[None, None, :] + (1 if direction == "forward" else -1)) % shape[2]
    kk = np.broadcast_to(kk, shape)
    valid = (~np.asarray(maps[direction + "_boundary"], dtype=bool)) & finite & (ii >= 0) & (ii < shape[0] - 1)
    return np.clip(ii, 0, shape[0] - 2), jj, kk, valid


def injection_restriction(host: dict[str, np.ndarray], geometry: AggregateGeometry, raw_volume: np.ndarray) -> tuple[sparse.csr_matrix, sparse.csr_matrix, np.ndarray]:
    shape = raw_volume.shape
    n = int(np.prod(shape))
    ids = np.asarray(host["topology_aggregate_id"], dtype=np.int64).ravel()
    owner_slot = np.full(n, -1, dtype=np.int64)
    owner_slot[geometry.owner_flat_ids] = np.arange(geometry.n_owner)
    compact_ids = owner_slot[ids]
    if np.any(compact_ids < 0):
        raise RuntimeError("host topology has a cell without a compact active owner")
    owner_volume = np.bincount(compact_ids, weights=raw_volume.ravel(), minlength=geometry.n_owner).astype(float)
    rows = np.arange(n, dtype=np.int64)
    P = sparse.coo_matrix((np.ones(n), (rows, compact_ids)), shape=(n, geometry.n_owner)).tocsr()
    invv = np.divide(1.0, owner_volume, out=np.zeros_like(owner_volume), where=owner_volume > 0.0)
    R = sparse.diags(invv).dot(P.T).dot(sparse.diags(raw_volume.ravel())).tocsr()
    return P, R, owner_volume


def endpoint_matrix(P: sparse.csr_matrix, maps: dict[str, np.ndarray], selected: np.ndarray, direction: str) -> sparse.csr_matrix:
    shape = maps[direction + "_x"].shape
    x = maps[direction + "_x"].ravel()[selected]
    y = maps[direction + "_y"].ravel()[selected]
    i = np.floor(np.nan_to_num(x, nan=0.0)).astype(np.int64)
    j = np.floor(np.nan_to_num(y, nan=0.0)).astype(np.int64) % shape[1]
    k = ((selected % shape[2]) + (1 if direction == "forward" else -1)) % shape[2]
    fx = x - np.floor(x)
    fy = y - np.floor(y)
    jp = (j + 1) % shape[1]
    flat = lambda ii, jj, kk: (ii * shape[1] + jj) * shape[2] + kk
    rr = np.tile(np.arange(selected.size), 4)
    cc = np.concatenate((flat(i, j, k), flat(i, jp, k), flat(i + 1, j, k), flat(i + 1, jp, k)))
    ww = np.concatenate(((1.0 - fx) * (1.0 - fy), (1.0 - fx) * fy, fx * (1.0 - fy), fx * fy))
    fine = sparse.coo_matrix((ww, (rr, cc)), shape=(selected.size, P.shape[0])).tocsr()
    return fine.dot(P)


def endpoint_eta_indices(maps: dict[str, np.ndarray], eta_centers: np.ndarray, selected: np.ndarray, direction: str) -> np.ndarray:
    """Select the periodic eta plane from the physical endpoint-z channel."""
    centers = np.asarray(eta_centers, dtype=float)
    spacing = float(np.median(np.diff(centers)))
    period = float(centers[-1] - centers[0] + spacing)
    endpoint_z = np.asarray(maps[direction + "_endpoint_z"], dtype=float).ravel()[selected]
    distance = np.abs(((endpoint_z[:, None] - centers[None, :] + 0.5 * period) % period) - 0.5 * period)
    indices = np.argmin(distance, axis=1).astype(np.int64)
    if float(np.max(distance[np.arange(indices.size), indices])) > 1.0e-10:
        raise RuntimeError(f"{direction} endpoint z is not on a saved eta plane")
    return indices


def diag_summary(values: np.ndarray, row_ids: np.ndarray, u: np.ndarray, theta: np.ndarray, eta: np.ndarray, q: np.ndarray, q_transition: np.ndarray, shape: tuple[int, int, int]) -> dict[str, object]:
    values = np.asarray(values, dtype=float)
    order = np.argsort(values)[::-1]
    p95 = float(np.quantile(values, 0.95))
    top = order[: min(20, order.size)]
    rows = []
    for index in top:
        i, j, k = np.unravel_index(int(row_ids[index]), shape)
        rows.append({"fine_flat_id": int(row_ids[index]), "value": float(values[index]), "u": float(u[index]), "theta_turns": float(theta[index]), "eta_index": int(eta[index]), "q": int(q[i]), "distance_to_q_transition_cells": int(np.min(np.abs(q_transition - i))) if q_transition.size else None})
    return {"max": float(np.max(values)), "median": float(np.median(values)), "p95": p95, "top_rows": rows, "above_p95_count": int(np.count_nonzero(values >= p95))}


def ring_summary(values: np.ndarray, row_ids: np.ndarray, q: np.ndarray, shape: tuple[int, int, int]) -> list[dict[str, object]]:
    output = []
    radial_indices = np.asarray(row_ids, dtype=np.int64) // (shape[1] * shape[2])
    for i in range(q.size):
        mask = radial_indices == i
        if not np.any(mask):
            continue
        x = np.asarray(values)[mask]
        output.append({"radial_index": i, "q": int(q[i]), "count": int(x.size), "max": float(np.max(x)), "median": float(np.median(x)), "p95": float(np.quantile(x, 0.95))})
    return output


def negative_offdiagonal_summary(matrix: sparse.csr_matrix, geometry: AggregateGeometry, q: np.ndarray, u_centers: np.ndarray, shape: tuple[int, int, int]) -> dict[str, object]:
    maxima = np.zeros(matrix.shape[0], dtype=float)
    counts = np.zeros(matrix.shape[0], dtype=np.int64)
    for row in range(matrix.shape[0]):
        start, stop = matrix.indptr[row], matrix.indptr[row + 1]
        cols = matrix.indices[start:stop]
        values = matrix.data[start:stop]
        negative = values[(cols != row) & (values < 0.0)]
        if negative.size:
            maxima[row] = float(np.max(np.abs(negative)))
            counts[row] = negative.size
    order = np.argsort(maxima)[::-1][:20]
    owner_indices = np.asarray(geometry.owner_flat_ids, dtype=np.int64)
    top = []
    for owner_row in order:
        fine = int(owner_indices[owner_row]); i, j, k = np.unravel_index(fine, shape)
        top.append({"owner_row": int(owner_row), "fine_flat_id": fine, "max_negative_offdiagonal_abs": float(maxima[owner_row]), "negative_offdiagonal_count": int(counts[owner_row]), "u": float(u_centers[i]), "radial_index": int(i), "theta_index": int(j), "eta_index": int(k), "q": int(q[i])})
    return {"rows_with_negative_offdiagonal": int(np.count_nonzero(maxima)), "max_abs": float(np.max(maxima)), "median_nonzero": float(np.median(maxima[maxima > 0.0])) if np.any(maxima > 0.0) else 0.0, "p95_nonzero": float(np.quantile(maxima[maxima > 0.0], 0.95)) if np.any(maxima > 0.0) else 0.0, "top_rows": top, "row_maxima": maxima.tolist(), "row_counts": counts.tolist()}


def compare_metadata(metadata: dict[str, object], name: str, diagnostics: object) -> dict[str, object]:
    plan = metadata["conduction_reconstruction"]["plan"]["diagnostics"][name]
    actual = diagnostics
    checks = {}
    for field in ("max_condition", "max_l1_norm", "max_reproduction_residual"):
        expected = float(plan[field]); got = float(np.max(getattr(actual, {"max_condition": "condition", "max_l1_norm": "l1_norm", "max_reproduction_residual": "reproduction_residual"}[field])))
        checks[field] = {"metadata": expected, "audit": got, "relative_difference": abs(got - expected) / max(abs(expected), 1.0e-300), "match": bool(np.isclose(got, expected, rtol=1.0e-10, atol=1.0e-12))}
    if not all(item["match"] for item in checks.values()):
        raise RuntimeError(f"reconstruction diagnostics disagree with frozen metadata for {name}: {checks}")
    return checks


def main() -> None:
    cases = load_cases()
    results: dict[str, object] = {"configuration": {"degree": DEGREE, "donor_count": DONORS, "max_donor_count": MAX_DONORS, "condition_limit": CONDITION_LIMIT, "weight_power": WEIGHT_POWER, "row_l1_limit": L1_LIMIT}, "resolutions": {}}
    for case in cases:
        n = int(case["resolution"])
        host = load_npz(HOSTS[n])
        baseline = Path(case["baseline"])
        aggregate = Path(case["output"])
        history = load_npz(aggregate / "history.npz")
        reference_history = load_npz(baseline / "history.npz")
        metadata = json.loads((aggregate / "metadata.json").read_text())
        shape = tuple(int(x) for x in host["shape"])
        geometry = AggregateGeometry.from_host_payload(host)
        raw_volume = np.asarray(host["host_raw_volume"], dtype=float)
        P, R, owner_volume = injection_restriction(host, geometry, raw_volume)
        owner_slot = np.full(int(np.prod(shape)), -1, dtype=np.int64)
        owner_slot[geometry.owner_flat_ids] = np.arange(geometry.n_owner, dtype=np.int64)
        maps = maps_from_history(reference_history)
        ii, jj, kk, valid_f = map_rows(maps, shape, "forward")
        _, _, _, valid_b = map_rows(maps, shape, "backward")
        selected_mask = valid_f & valid_b
        selected = np.flatnonzero(selected_mask.ravel())
        u_grid, theta_grid, eta_grid = np.meshgrid(history["u"], history["theta"], history["eta"], indexing="ij")
        source_xy = np.column_stack((u_grid.ravel() * np.cos(theta_grid.ravel()), u_grid.ravel() * np.sin(theta_grid.ravel())))
        source_eta = np.broadcast_to(np.arange(shape[2])[None, None, :], shape).ravel()
        source_eval = build_aggregate_evaluation(geometry, source_xy, source_eta, degree=DEGREE, donor_count=DONORS, max_donor_count=MAX_DONORS, condition_limit=CONDITION_LIMIT, weight_power=WEIGHT_POWER, row_l1_limit=L1_LIMIT)
        endpoint_evals = {}
        endpoint_matrices = {}
        eta_index_grid = np.broadcast_to(np.arange(shape[2], dtype=np.int64)[None, None, :], shape)
        for direction in ("forward", "backward"):
            endpoint_u = maps[direction + "_endpoint_x"].ravel()[selected]
            endpoint_theta = maps[direction + "_endpoint_y"].ravel()[selected]
            endpoint_xy = np.column_stack((endpoint_u * np.cos(endpoint_theta), endpoint_u * np.sin(endpoint_theta)))
            endpoint_eta = endpoint_eta_indices(maps, history["eta"], selected, direction)
            endpoint_evals[direction] = build_aggregate_evaluation(geometry, endpoint_xy, endpoint_eta, degree=DEGREE, donor_count=DONORS, max_donor_count=MAX_DONORS, condition_limit=CONDITION_LIMIT, weight_power=WEIGHT_POWER, row_l1_limit=L1_LIMIT)
            endpoint_matrices[direction] = endpoint_evals[direction].matrix.tocsr()
        S = source_eval.matrix[selected].tocsr()
        Eplus = endpoint_matrices["forward"]; Eminus = endpoint_matrices["backward"]
        selected_positions = {int(row): index for index, row in enumerate(selected)}
        save_npz(OUT / f"S_{n}.npz", S); save_npz(OUT / f"Eplus_{n}.npz", Eplus); save_npz(OUT / f"Eminus_{n}.npz", Eminus)
        q = np.asarray(host["angular_group_size"], dtype=np.int64)
        q_transition = np.flatnonzero(q[1:] != q[:-1]) + 1
        source_ids = np.arange(int(np.prod(shape)), dtype=np.int64)[selected]
        endpoint_ids = selected
        def coords(rows: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
            return u_grid.ravel()[rows], np.mod(theta_grid.ravel()[rows] / (2.0 * np.pi), 1.0), eta_index_grid.ravel()[rows], q[np.unravel_index(rows, shape)[0]]
        su, st, se, sq = coords(source_ids)
        diagnostics_rows: dict[str, object] = {
            "selected_both_valid_count": int(selected.size), "selected_both_valid_fraction": float(selected.size / np.prod(shape)),
            "source": {"condition": diag_summary(source_eval.diagnostics.condition[selected], source_ids, su, st, se, q, q_transition, shape), "l1_norm": diag_summary(source_eval.diagnostics.l1_norm[selected], source_ids, su, st, se, q, q_transition, shape), "donor_count": diag_summary(source_eval.diagnostics.donor_counts[selected], source_ids, su, st, se, q, q_transition, shape), "rank": diag_summary(source_eval.diagnostics.rank[selected], source_ids, su, st, se, q, q_transition, shape)},
            "endpoints": {}, "q_profile": q.tolist(), "q_transition_indices": q_transition.tolist(), "q_transition_u": (0.5 * (history["u"][q_transition - 1] + history["u"][q_transition])).tolist(),
        }
        np.savez_compressed(OUT / f"row_diagnostics_{n}.npz", selected_mask=selected_mask, source_row_ids=source_ids, source_condition=source_eval.diagnostics.condition[selected], source_l1=source_eval.diagnostics.l1_norm[selected], source_donor_count=source_eval.diagnostics.donor_counts[selected], forward_condition=endpoint_evals["forward"].diagnostics.condition, forward_l1=endpoint_evals["forward"].diagnostics.l1_norm, forward_donor_count=endpoint_evals["forward"].diagnostics.donor_counts, backward_condition=endpoint_evals["backward"].diagnostics.condition, backward_l1=endpoint_evals["backward"].diagnostics.l1_norm, backward_donor_count=endpoint_evals["backward"].diagnostics.donor_counts, fine_u=su, fine_theta_turns=st, fine_eta=se, fine_q=sq)
        for direction, evaluation in endpoint_evals.items():
            eu, et, ee, eq = coords(endpoint_ids)
            d = evaluation.diagnostics
            diagnostics_rows["endpoints"][direction] = {"condition": diag_summary(d.condition, endpoint_ids, eu, et, ee, q, q_transition, shape), "l1_norm": diag_summary(d.l1_norm, endpoint_ids, eu, et, ee, q, q_transition, shape), "donor_count": diag_summary(d.donor_counts, endpoint_ids, eu, et, ee, q, q_transition, shape), "rank": diag_summary(d.rank, endpoint_ids, eu, et, ee, q, q_transition, shape)}
        diagnostics_rows["metadata_comparison"] = {"source": compare_metadata(metadata, "source", source_eval.diagnostics), "forward": compare_metadata(metadata, "forward", endpoint_evals["forward"].diagnostics), "backward": compare_metadata(metadata, "backward", endpoint_evals["backward"].diagnostics)}
        diagnostics_rows["ring_summaries"] = {"source_condition": ring_summary(source_eval.diagnostics.condition[selected], source_ids, q, shape), "source_l1": ring_summary(source_eval.diagnostics.l1_norm[selected], source_ids, q, shape), "forward_condition": ring_summary(endpoint_evals["forward"].diagnostics.condition, endpoint_ids, q, shape), "backward_condition": ring_summary(endpoint_evals["backward"].diagnostics.condition, endpoint_ids, q, shape)}

        # Native owner coefficient operator, matching the standalone audit's
        # owner-slot 1/B construction and omitting wall/fallback rows.
        inv_b = 1.0 / np.asarray(reference_history["magnetic_field"], dtype=float)
        owner_inv_b = inv_b.ravel()[geometry.owner_flat_ids]
        q_fine = (P @ owner_inv_b).reshape(shape)
        b_center = 1.0 / q_fine
        fp = maps["forward_length"]; fm = maps["backward_length"]
        def bilinear(field: np.ndarray, direction: str) -> np.ndarray:
            i, j, k, valid = map_rows(maps, shape, direction)
            x = np.asarray(maps[direction + "_x"], dtype=float); y = np.asarray(maps[direction + "_y"], dtype=float)
            fx = np.nan_to_num(x, nan=0.0) - np.floor(np.nan_to_num(x, nan=0.0)); fy = np.nan_to_num(y, nan=0.0) - np.floor(np.nan_to_num(y, nan=0.0)); jp = (j + 1) % shape[1]
            return (1.0 - fx) * ((1.0 - fy) * field[i, j, k] + fy * field[i, jp, k]) + fx * ((1.0 - fy) * field[i + 1, j, k] + fy * field[i + 1, jp, k])
        cp = 0.1 * b_center * (q_fine + bilinear(q_fine, "forward")) / (fp * (fp + fm))
        cm = 0.1 * b_center * (q_fine + bilinear(q_fine, "backward")) / (fm * (fp + fm))
        cpf, cmf = cp.ravel()[selected], cm.ravel()[selected]
        source_part = R[:, selected].dot(sparse.diags(-(cpf + cmf)).dot(S)).tocsr()
        endpoint_part = R[:, selected].dot(sparse.diags(cpf).dot(Eplus) + sparse.diags(cmf).dot(Eminus)).tocsr()
        operator = (source_part + endpoint_part).tocsr()
        save_npz(OUT / f"operator_{n}.npz", operator)
        save_npz(OUT / f"operator_source_{n}.npz", source_part); save_npz(OUT / f"operator_endpoints_{n}.npz", endpoint_part)
        frames = {}
        rhs_rows = {}
        times = np.asarray(history["times"], dtype=float)
        for target in (0.0, 3.5, 25.0):
            ti = int(np.argmin(np.abs(times - target)))
            owner_value = np.asarray(R @ history["Te"][ti].ravel())
            src_rhs = source_part @ owner_value; end_rhs = endpoint_part @ owner_value; total_rhs = src_rhs + end_rhs
            frames[str(target)] = {"actual_time": float(times[ti]), "source_l2_owner": float(np.linalg.norm(src_rhs)), "endpoint_l2_owner": float(np.linalg.norm(end_rhs)), "total_l2_owner": float(np.linalg.norm(total_rhs)), "source_fraction_l2": float(np.linalg.norm(src_rhs) / max(np.linalg.norm(total_rhs), 1e-300)), "endpoint_fraction_l2": float(np.linalg.norm(end_rhs) / max(np.linalg.norm(total_rhs), 1e-300))}
            if target == 3.5:
                total_fine = np.asarray(P @ total_rhs).reshape(shape)
                source_fine = np.asarray(P @ src_rhs).reshape(shape)
                endpoint_fine = np.asarray(P @ end_rhs).reshape(shape)
                hotspot = selected_mask & (np.indices(shape)[2] == 25) & (theta_grid > 0.25 * 2 * np.pi) & (theta_grid < 0.75 * 2 * np.pi) & (u_grid > 0.20) & (u_grid < 0.50)
                candidates = np.flatnonzero(hotspot.ravel()); candidates = candidates[np.argsort(np.abs(total_fine.ravel()[candidates]))[::-1][:20]]
                if n == 64:
                    candidates = np.unique(np.concatenate((candidates, np.asarray([np.ravel_multi_index((21, 24, 25), shape), np.ravel_multi_index((21, 2, 25), shape), np.ravel_multi_index((22, 24, 25), shape)]))))
                for row in candidates:
                    row = int(row)
                    if row not in selected_positions:
                        continue
                    i, j, k = np.unravel_index(row, shape); pos = selected_positions[row]
                    source_row = S.getrow(pos)
                    # A fine row can be an inactive alias of its topology
                    # owner's compact slot; resolve through the host
                    # aggregate id rather than indexing the fine alias slot.
                    source_owner = int(owner_slot[int(np.asarray(host["topology_aggregate_id"]).ravel()[row])])
                    if source_owner < 0:
                        raise RuntimeError("hotspot row topology aggregate has no compact active owner")
                    source_self = float(source_row[0, source_owner])
                    source_negative = source_row.data[(source_row.indices != source_owner) & (source_row.data < 0.0)]
                    rhs_rows[str(row)] = {"u": float(history["u"][i]), "theta_turns": float(history["theta"][j] / (2 * np.pi)), "eta_index": int(k), "q": int(q[i]), "distance_to_q_transition_cells": int(np.min(np.abs(q_transition - i))) if q_transition.size else None, "total_rhs": float(total_fine.ravel()[row]), "source_rhs": float(source_fine.ravel()[row]), "endpoint_rhs": float(endpoint_fine.ravel()[row]), "source_condition": float(source_eval.diagnostics.condition[row]), "source_l1": float(source_eval.diagnostics.l1_norm[row]), "forward_condition": float(endpoint_evals["forward"].diagnostics.condition[pos]), "backward_condition": float(endpoint_evals["backward"].diagnostics.condition[pos]), "high_condition_source": bool(source_eval.diagnostics.condition[row] > np.quantile(source_eval.diagnostics.condition[selected], 0.95)), "source_self_weight": source_self, "source_negative_offdiagonal_max_abs": float(np.max(np.abs(source_negative))) if source_negative.size else 0.0}
        # Compare saved-frame finite changes to the assembled RHS; this is a
        # local finite-difference diagnostic, not an independent integration.
        finite = np.gradient(np.asarray(history["Te"], dtype=float), times, axis=0)
        for target in (0.0, 3.5, 25.0):
            ti = int(np.argmin(np.abs(times - target))); owner_value = np.asarray(R @ history["Te"][ti].ravel()); rhs_fine = np.asarray(P @ (operator @ owner_value)).reshape(shape)
            fd = finite[ti]
            weights = raw_volume
            dot = float(np.sum(fd * rhs_fine * weights)); norms = float(np.sqrt(np.sum(fd * fd * weights) * np.sum(rhs_fine * rhs_fine * weights)))
            frames[str(target)]["saved_frame_finite_change_l2"] = float(np.sqrt(np.sum(fd * fd * weights))); frames[str(target)]["assembled_rhs_fine_l2"] = float(np.sqrt(np.sum(rhs_fine * rhs_fine * weights))); frames[str(target)]["finite_change_rhs_cosine"] = dot / max(norms, 1e-300)
        diagnostics_rows["operator"] = {"shape": list(operator.shape), "nnz": int(operator.nnz), "source_nnz": int(source_part.nnz), "endpoint_nnz": int(endpoint_part.nnz), "negative_offdiagonal": negative_offdiagonal_summary(operator, geometry, q, np.asarray(history["u"]), shape), "saved_frame_rhs": frames, "hotspot_rows_t3.5": rhs_rows, "scope": "two-sided interior rows only; wall, axis/fallback closure omitted"}
        results["resolutions"][str(n)] = diagnostics_rows

        # Compact maps: source, endpoint max condition/L1, and q transitions.
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib.colors import LogNorm
        fig, axes = plt.subplots(2, 2, figsize=(12, 8), layout="constrained")
        eta_index = 25
        src_cond = np.full(shape, np.nan); src_cond.ravel()[selected] = source_eval.diagnostics.condition[selected]
        src_l1 = np.full(shape, np.nan); src_l1.ravel()[selected] = source_eval.diagnostics.l1_norm[selected]
        ep_cond = np.full(shape, np.nan); ep_l1 = np.full(shape, np.nan)
        ep_cond.ravel()[selected] = np.maximum(endpoint_evals["forward"].diagnostics.condition, endpoint_evals["backward"].diagnostics.condition)
        ep_l1.ravel()[selected] = np.maximum(endpoint_evals["forward"].diagnostics.l1_norm, endpoint_evals["backward"].diagnostics.l1_norm)
        panels = [(src_cond, "source condition", True), (src_l1, "source L1", False), (ep_cond, "endpoint max condition", True), (ep_l1, "endpoint max L1", False)]
        for ax, (array, title, logarithmic) in zip(axes.ravel(), panels, strict=True):
            image = ax.pcolormesh(history["theta"] / (2 * np.pi), history["u"], array[:, :, eta_index], shading="nearest", cmap="viridis", norm=LogNorm(vmin=max(float(np.nanmin(array[:, :, eta_index])), 1e-6), vmax=float(np.nanmax(array[:, :, eta_index]))) if logarithmic else None)
            for transition in q_transition:
                # q changes across the radial face between these centers.
                transition_u = 0.5 * (history["u"][transition - 1] + history["u"][transition])
                ax.axhline(transition_u, color="white", ls="--", lw=0.7)
            ax.set(xlim=(0, 1), ylim=(float(history["u"][0]), float(history["u"][-1])), title=title, xlabel="theta / (2 pi)", ylabel="u")
            fig.colorbar(image, ax=ax, shrink=0.8)
        fig.suptitle(f"{n}x{n}x32 reconstruction stability, eta index 25; dashed q transitions")
        fig.savefig(OUT / f"stability_maps_{n}.png", dpi=150)
        plt.close(fig)
    (OUT / "reconstruction_audit.json").write_text(json.dumps(results, indent=2, sort_keys=True, default=lambda value: value.item() if isinstance(value, np.generic) else value) + "\n")

    # Keep the prose report generated from the same values as the machine
    # readable artifact, while also recording the independent probes that
    # isolate positivity loss from ordinary fit conditioning.
    report = [
        "# Reconstruction localization audit",
        "",
        "This bounded audit rebuilds degree-2, donor-32 aggregate rows with max donor expansion 96 from the frozen source and host moment caches. It does not evolve new trajectories. The assembled native-owner coefficient operator covers selected two-sided interior rows; wall, axis, and fallback closure rows are omitted.",
        "",
        "## Findings",
        "",
        "The source and endpoint CSR diagnostics match the frozen source metadata exactly at relative tolerance 1e-10 for condition, L1 norm, and polynomial residual on both resolutions. The artifacts retain every selected two-sided row's condition, L1 amplification, donor count, radial q, and distance to the nearest q transition.",
        "",
        "| grid | source max condition | endpoint max condition | source max L1 | endpoint max L1 | q transitions (u) |",
        "| ---: | ---: | ---: | ---: | ---: | --- |",
    ]
    for n in (32, 64):
        item = results["resolutions"][str(n)]
        source_cond = item["source"]["condition"]["max"]
        endpoint_cond = max(item["endpoints"]["forward"]["condition"]["max"], item["endpoints"]["backward"]["condition"]["max"])
        source_l1 = item["source"]["l1_norm"]["max"]
        endpoint_l1 = max(item["endpoints"]["forward"]["l1_norm"]["max"], item["endpoints"]["backward"]["l1_norm"]["max"])
        transitions = ", ".join(f"{x:.5f}" for x in item["q_transition_u"])
        report.append(f"| {n} | {source_cond:.6g} | {endpoint_cond:.6g} | {source_l1:.6g} | {endpoint_l1:.6g} | {transitions} |")
    report += [
        "",
        "The worst condition rows are concentrated in the q=1 outer rings (the 32-grid source maximum is 1.67422e5 and the 64-grid source maximum is 8.09160e5), while the largest negative operator couplings occur near the q=2 to q=1 transition at u=0.34375. The latter is a distinct mechanism from large singular condition: the explicitly tracked 64 row (i,j,k)=(21,24,25), u=0.3359375, has source condition 21.35 and endpoint maximum condition 294. Its reconstructed-source point-value row has self coefficient 0.2813 in R*S, while the full native coefficient operator has source diagonal -0.8440 and negative couplings -1.0060 and -1.0029 to (22,24,25) and (22,25,25). The analogous row (21,2,25) has reconstructed-source self coefficient 0.2907 in R*S, native source diagonal -0.7325, and negative couplings -0.8489 and -0.8063 to (22,3,25) and (22,2,25). These are direct loss-of-positivity counterexamples, rather than evidence by themselves of a growing eigenmode.",
        "",
        "At the 64 transition rows, the source contribution to the saved t=25 RHS is positive relative to the owner-field change (about +0.01202 at (21,24,25) and +0.00546 at (21,2,25) in the same-field comparison), while endpoint contributions are smaller and negative (about -0.00067 and -0.00074). This supports source-average attenuation/deficit plus interface coupling as a local explanation for the changed RHS, while the comparison remains a same-field operator probe and is not an alternate evolution.",
        "",
        "The undershoot probe shows that conditioning is not a sufficient explanation. On the 32 grid, the global minimum at (21,16,19), u=0.671875, has endpoint condition 13--44 and L1 at most 1.432; its t=0 total reconstructed RHS is -1.30e-5 versus a same-field legacy RHS of about -4e-11, with -9.80e-6 from the endpoint change and -3.23e-6 from the source change. On the 64 grid, the global minimum at (21,16,18), u=0.3359375, has source condition 24.17--24.85, endpoint condition at most 31.24, and L1 at most 1.421; its t=3.5 total reconstructed RHS is -2.85e-5 versus same-field legacy +9.74e-5, with -8.93e-5 from source change and -3.66e-5 from endpoint change. Thus both well-conditioned outer-ring endpoint undershoot and well-conditioned transition source cooling are present.",
        "",
        "The localized symmetric raw-volume energy probes over patches around the q transition have negative maximum Rayleigh rates (-0.553 to -0.555 on 32 and -0.426 to -0.429 on 64). The negative off-diagonals demonstrate loss of positivity, but these bounded patch probes do not establish a growing linear mode or instability of the full diffusion operator.",
        "",
        "The audit records per-row details in `row_diagnostics_32.npz` and `row_diagnostics_64.npz`. Sparse source/endpoint rows and operator contributions are in `S_*.npz`, `Eplus_*.npz`, `Eminus_*.npz`, `operator_*.npz`, `operator_source_*.npz`, and `operator_endpoints_*.npz`. `reconstruction_audit.json` includes metadata-max comparisons, radial-ring summaries, hotspot operator attribution at t=3.5, and saved-frame RHS versus finite-change diagnostics.",
        "",
        "The stability maps (`stability_maps_32.png`, `stability_maps_64.png`) show source and endpoint condition/L1 against q-transition locations. The native owner-slot `1/B` operator is `A = R*(C+ E+ + C0 S + C- E-)`; saved-frame probes are at t=0, 3.5, and 25. Finite-change comparisons are local diagnostics of the completed run and are not independent time integrations.",
        "",
        "Independent cross-checks used for the interpretation: [local operator check](</Users/yxie/Desktop/HSX drbx/work/heat_aggregate_quadratic_20260913/independent_local_operator_check.json>), [local energy check](</Users/yxie/Desktop/HSX drbx/work/heat_aggregate_quadratic_20260913/independent_local_energy_check.json>), [undershoot probe](</Users/yxie/Desktop/HSX drbx/work/heat_aggregate_quadratic_20260913/independent_undershoot_probe.json>), and [root's independent verification](</Users/yxie/Desktop/HSX drbx/work/heat_aggregate_quadratic_20260913/localization/independent_verification.json>). The completed-run context is in [analysis/report.md](</Users/yxie/Desktop/HSX drbx/work/heat_aggregate_quadratic_20260913/analysis/report.md>) and [history localization report](</Users/yxie/Desktop/HSX drbx/work/heat_aggregate_quadratic_20260913/localization/reconstruction_report.md>).",
        "",
        "The conclusion is limited to the partial interior operator assembled here. Wall, axis, fallback closure, and full-evolution effects are outside this audit.",
        "",
    ]
    (OUT / "reconstruction_report.md").write_text("\n".join(report))
    print(json.dumps({"output": str(OUT), "resolutions": sorted(results["resolutions"]), "figures": sorted(path.name for path in OUT.glob("*.png"))}, indent=2))


if __name__ == "__main__":
    main()
