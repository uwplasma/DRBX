"""Localize owner-aware undershoots and small positive outliers in heat histories.

The aggregate history stores a materialized fine-shaped field, so angular
aggregates would otherwise be counted once per duplicate cell.  This analysis
selects active owner representatives from the saved host topology and uses
periodic owner-neighbor contrasts for ranking.  Full-field volume summaries
use the recorded raw host volumes and are kept separate from the owner-rank
diagnostics.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / "mpl_cache"))
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[3]
WORK = ROOT / "work"
HERE = WORK / "heat_aggregate_quadratic_20260913"
OUT = HERE / "localization"
OUT.mkdir(parents=True, exist_ok=True)


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path) as archive:
        return {name: archive[name] for name in archive.files}


def _case_paths(n: int) -> dict[str, Path]:
    aggregate_cases = json.loads((HERE / "cases.json").read_text())
    no_rlp_cases = json.loads((WORK / "heat_no_rlp_20260913" / "cases.json").read_text())
    aggregate = next(case for case in aggregate_cases if case["resolution"] == n)
    no_rlp = next(case for case in no_rlp_cases if case["resolution"] == n)
    return {
        "quadratic": Path(aggregate["output"]),
        "no_rlp": Path(no_rlp["output"]),
        "historical": Path(aggregate["baseline"]),
        "host_cache": HERE / f"metric_cache_{n}" / next(
            path.name for path in (HERE / f"metric_cache_{n}").glob("angular_rlp_host_*.npz")
        ),
    }


def _owner_ring_indices(active: np.ndarray, ntheta: int) -> list[np.ndarray]:
    """Return unique active owner theta slots for each radial ring."""

    result: list[np.ndarray] = []
    for i in range(active.shape[0]):
        masks = active[i, :, :]
        if not np.all(masks == masks[:, :1]):
            raise ValueError(f"owner topology varies with eta on radial ring {i}")
        theta = np.flatnonzero(masks[:, 0])
        if theta.size == 0:
            raise ValueError(f"radial ring {i} has no active owners")
        result.append(theta.astype(np.int64))
    return result


def _owner_series(history: dict[str, np.ndarray], host: dict[str, np.ndarray]) -> dict[str, object]:
    te = np.asarray(history["Te"], dtype=np.float64)
    active = np.asarray(host["topology_is_active_owner"], dtype=bool)
    aggregate_id = np.asarray(host["topology_aggregate_id"], dtype=np.int64)
    raw_volume = np.asarray(host["host_raw_volume"], dtype=np.float64)
    aggregate_volume = np.asarray(host["host_aggregate_chart_volume"], dtype=np.float64)
    if te.shape[1:] != active.shape or raw_volume.shape != active.shape:
        raise ValueError("history, topology, and raw volume shapes do not match")
    ring_indices = _owner_ring_indices(active, te.shape[2])
    owner_records: list[dict[str, object]] = []
    ring_values: list[np.ndarray] = []
    ring_contrasts: list[np.ndarray] = []
    ring_max_contrasts: list[np.ndarray] = []
    for i, theta_indices in enumerate(ring_indices):
        # Values are stored in fine-shaped form, but only active owner slots
        # enter this array.  Each aggregate is therefore represented once.
        values = te[:, i, theta_indices, :].transpose(0, 2, 1)  # time, eta, owner theta
        values = values.transpose(0, 2, 1)  # time, owner theta, eta
        ring_values.append(values)
        neighbors = 0.5 * (np.roll(values, 1, axis=1) + np.roll(values, -1, axis=1))
        ring_contrasts.append(values - neighbors)
        max_neighbors = np.maximum(np.roll(values, 1, axis=1), np.roll(values, -1, axis=1))
        ring_max_contrasts.append(values - max_neighbors)
        for theta_pos, theta in enumerate(theta_indices):
            for eta in range(te.shape[3]):
                owner_records.append(
                    {
                        "ring": int(i),
                        "theta_index": int(theta),
                        "eta_index": int(eta),
                        "owner_flat_id": int(aggregate_id[i, theta, eta]),
                        "u": float(history["u"][i]),
                        "theta": float(history["theta"][theta]),
                        "theta_phase": float(history["theta"][theta] / (2.0 * np.pi)),
                        "eta": float(history["eta"][eta]),
                        "raw_volume": float(raw_volume[i, theta, eta]),
                        "aggregate_volume": float(aggregate_volume[i, theta, eta]),
                        "q": int(history["angular_group_sizes"][i]),
                        "theta_position": int(theta_pos),
                    }
                )
    return {
        "values": ring_values,
        "contrasts": ring_contrasts,
        "max_contrasts": ring_max_contrasts,
        "records": owner_records,
        "active": active,
        "aggregate_id": aggregate_id,
        "raw_volume": raw_volume,
        "aggregate_volume": aggregate_volume,
        "ring_indices": ring_indices,
    }


def _flatten_owner_metric(series: dict[str, object], metric: str) -> np.ndarray:
    chunks = [np.asarray(x) for x in series[metric]]
    return np.concatenate([chunk.transpose(0, 1, 2).reshape(chunk.shape[0], -1) for chunk in chunks], axis=1)


def _records_for_metric(
    series: dict[str, object],
    history: dict[str, np.ndarray],
    no_rlp: dict[str, np.ndarray],
    *,
    kind: str,
    limit: int = 20,
    forced_coordinates: tuple[tuple[int, int, int], ...] = (),
) -> list[dict[str, object]]:
    values = _flatten_owner_metric(series, "values") - 1.0
    contrasts = _flatten_owner_metric(series, "contrasts")
    max_contrasts = _flatten_owner_metric(series, "max_contrasts")
    no_te = np.asarray(no_rlp["Te"], dtype=np.float64) - 1.0
    no_values: list[np.ndarray] = []
    for record in series["records"]:
        no_values.append(no_te[:, record["ring"], record["theta_index"], record["eta_index"]])
    no_values_array = np.asarray(no_values, dtype=np.float64).T
    initial_peak = float(np.max(values[0]))
    records = series["records"]
    if kind == "negative":
        score = -np.min(values, axis=0)
        threshold = max(1.0e-5, 1.0e-3 * max(initial_peak, 1.0e-12))
        order = np.argsort(score)[::-1]
        selected = [int(index) for index in order if score[index] >= threshold][:limit]
    elif kind == "positive_prominence":
        # A positive outlier must exceed both periodic owner neighbors.  The
        # mean-neighbor contrast remains in the record as a smoother proxy.
        score = np.max(max_contrasts, axis=0)
        threshold = max(1.0e-5, 1.0e-3 * max(initial_peak, 1.0e-12))
        order = np.argsort(score)[::-1]
        selected = [int(index) for index in order if score[index] >= threshold][:limit]
    else:
        raise ValueError(kind)
    for coordinate in forced_coordinates:
        forced = next(
            (index for index, record in enumerate(records)
             if (record["ring"], record["theta_index"], record["eta_index"]) == coordinate),
            None,
        )
        if forced is not None and forced not in selected:
            selected.append(forced)
    output: list[dict[str, object]] = []
    for flat_index in selected:
        rec = dict(records[flat_index])
        candidate = values[:, flat_index]
        contrast = contrasts[:, flat_index]
        max_contrast = max_contrasts[:, flat_index]
        if kind == "negative":
            event_index = int(np.argmin(candidate))
            peak_index = int(np.argmax(candidate))
            first_index = int(np.flatnonzero(candidate < 0.0)[0]) if np.any(candidate < 0.0) else 0
            rec.update(
                {
                    "ranking": "owner_unique_negative_deficit",
                    "negative_depth": float(-candidate[event_index]),
                    "relative_to_initial_peak": float(-candidate[event_index] / max(initial_peak, 1.0e-12)),
                    "first_negative_time": float(history["times"][first_index]),
                    "peak_deltaTe": float(candidate[peak_index]),
                    "peak_time": float(history["times"][peak_index]),
                    "minimum_deltaTe": float(candidate[event_index]),
                    "minimum_time": float(history["times"][event_index]),
                    "no_rlp_at_minimum": float(no_values_array[event_index, flat_index]),
                }
            )
        else:
            event_index = int(np.argmax(max_contrast))
            peak_index = int(np.argmax(candidate))
            first_index = int(np.flatnonzero(max_contrast > 0.0)[0]) if np.any(max_contrast > 0.0) else 0
            rec.update(
                {
                    "ranking": "owner_unique_positive_neighbor_prominence",
                    "positive_neighbor_prominence": float(contrast[event_index]),
                    "positive_max_neighbor_prominence": float(max_contrast[event_index]),
                    "relative_to_initial_peak": float(max_contrast[event_index] / max(initial_peak, 1.0e-12)),
                    "first_positive_prominence_time": float(history["times"][first_index]),
                    "first_positive_max_neighbor_time": float(history["times"][int(np.flatnonzero(max_contrast > 0.0)[0])]) if np.any(max_contrast > 0.0) else float(history["times"][0]),
                    "peak_deltaTe": float(candidate[peak_index]),
                    "peak_time": float(history["times"][peak_index]),
                    "minimum_deltaTe": float(np.min(candidate)),
                    "minimum_time": float(history["times"][np.argmin(candidate)]),
                    "no_rlp_at_peak": float(no_values_array[peak_index, flat_index]),
                }
            )
        rec["first_saved_time"] = float(history["times"][0])
        rec["no_rlp_minimum_deltaTe"] = float(np.min(no_values_array[:, flat_index]))
        rec["max_neighbor_contrast"] = float(np.max(contrast))
        rec["max_neighbor_contrast_against_larger_neighbor"] = float(np.max(max_contrast))
        ring_values = np.asarray(series["values"][rec["ring"]]) - 1.0
        neighbor_count = ring_values.shape[1]
        position = rec["theta_position"]
        left = ring_values[:, (position - 1) % neighbor_count, rec["eta_index"]]
        right = ring_values[:, (position + 1) % neighbor_count, rec["eta_index"]]
        rec["time_history"] = {
            "times": history["times"].tolist(),
            "deltaTe": candidate.tolist(),
            "no_rlp_deltaTe": no_values_array[:, flat_index].tolist(),
            "neighbor_mean_contrast": contrast.tolist(),
            "neighbor_max_contrast": max_contrast.tolist(),
            "left_owner_deltaTe": left.tolist(),
            "right_owner_deltaTe": right.tolist(),
        }
        output.append(rec)
    return output


def _global_deficit_summary(history: dict[str, np.ndarray], host: dict[str, np.ndarray]) -> dict[str, float]:
    delta = np.asarray(history["Te"], dtype=np.float64) - 1.0
    raw = np.asarray(host["host_raw_volume"], dtype=np.float64)
    negative = np.minimum(delta, 0.0)
    positive = np.maximum(delta, 0.0)
    volume = float(raw.sum())
    return {
        "initial_peak_deltaTe": float(np.max(delta[0])),
        "global_min_deltaTe": float(np.min(delta)),
        "global_min_time": float(history["times"][np.unravel_index(np.argmin(delta), delta.shape)[0]]),
        "negative_volume_weighted_mean_min": float(np.sum(raw * np.min(negative, axis=0)) / volume),
        "positive_volume_weighted_mean_max": float(np.sum(raw * np.max(positive, axis=0)) / volume),
        "final_volume_weighted_deltaTe": float(np.sum(raw * delta[-1]) / volume),
    }


def _q_boundaries(u: np.ndarray, q: np.ndarray) -> list[float]:
    return [float(0.5 * (u[i - 1] + u[i])) for i in range(1, len(u)) if q[i] != q[i - 1]]


def _plot_panels(n: int, histories: dict[str, dict[str, np.ndarray]], series: dict[str, object], q: np.ndarray) -> None:
    times = (0.0, 3.5, 10.0, 25.0)
    if n == 64:
        tracked = {(21, 2, 25), (21, 24, 25), (21, 26, 25)}
        candidate = [r for r in series["records"] if (r["ring"], r["theta_index"], r["eta_index"]) in tracked]
    else:
        ring = int(np.argmin(np.abs(np.asarray(histories["quadratic"]["u"]) - 0.34)))
        candidate = [r for r in series["records"] if r["ring"] == ring and r["eta_index"] == 25]
        candidate = sorted(candidate, key=lambda r: abs(r["theta_phase"] - 0.5))[:3]
    arrays = [histories[name]["Te"] - 1.0 for name in histories]
    fig, axes = plt.subplots(len(histories), len(times), figsize=(14, 7), sharex=True, sharey=True, squeeze=False, layout="constrained")
    column_bounds = []
    for time_value in times:
        indices = [int(np.argmin(np.abs(history["times"] - time_value))) for history in histories.values()]
        column_bounds.append(max(float(np.max(np.abs(array[index, :, :, 25]))) for array, index in zip(arrays, indices, strict=True)))
    for row, (name, history) in enumerate(histories.items()):
        delta = history["Te"] - 1.0
        for col, time_value in enumerate(times):
            index = int(np.argmin(np.abs(history["times"] - time_value)))
            ax = axes[row, col]
            image = ax.pcolormesh(history["theta"] / (2.0 * np.pi), history["u"], delta[index, :, :, 25], shading="nearest", cmap="coolwarm", vmin=-column_bounds[col], vmax=column_bounds[col])
            for boundary in _q_boundaries(history["u"], q):
                ax.axhline(boundary, color="k", lw=0.5, ls=":", alpha=0.7)
            for point in candidate:
                ax.plot(point["theta_phase"], point["u"], marker="o", ms=3.5, mfc="none", mec="k")
            ax.set_xlim(0.0, 0.6)
            ax.set_ylim(0.25, 0.45)
            ax.set_title(f"{name}, t={time_value:g}")
            if row == len(histories) - 1:
                ax.set_xlabel(r"$\theta/(2\pi)$")
            if col == 0:
                ax.set_ylabel("u")
    for col, bound in enumerate(column_bounds):
        fig.colorbar(axes[0, col].collections[0], ax=axes[:, col].tolist(), label=rf"$\Delta T_e$ (scale $\pm${bound:.3g})", shrink=0.85)
    fig.suptitle(f"N={n}: transition localization at eta index 25")
    fig.savefig(OUT / f"history_panels_N{n}_eta25.png", dpi=150)
    plt.close(fig)


def _plot_undershoot(n: int, history: dict[str, np.ndarray], series: dict[str, object], q: np.ndarray) -> None:
    values = _flatten_owner_metric(series, "values") - 1.0
    records = series["records"]
    min_values = np.min(values, axis=0)
    field = np.full(history["Te"].shape[1:], np.nan)
    for value, record in zip(min_values, records, strict=True):
        field[record["ring"], record["theta_index"], record["eta_index"]] = value
    eta_index = 25
    finite = field[:, :, eta_index][np.isfinite(field[:, :, eta_index])]
    lower = float(np.min(finite))
    fig, (ax_map, ax_radial) = plt.subplots(1, 2, figsize=(12, 5), layout="constrained")
    image = ax_map.pcolormesh(history["theta"] / (2.0 * np.pi), history["u"], field[:, :, eta_index], shading="nearest", cmap="magma", vmin=lower, vmax=0.0)
    for boundary in _q_boundaries(history["u"], q):
        ax_map.axhline(boundary, color="cyan", lw=0.7, ls="--")
    ax_map.set(xlim=(0, 1), ylim=(0, 1), xlabel=r"$\theta/(2\pi)$", ylabel="u", title="owner-unique minimum $\\Delta T_e$, eta 25")
    fig.colorbar(image, ax=ax_map, label=r"minimum $\Delta T_e$")
    radial_min = np.nanmin(field, axis=(1, 2))
    radial_p05 = np.nanpercentile(field, 5, axis=(1, 2))
    ax_radial.plot(history["u"], radial_min, label="minimum owner value")
    ax_radial.plot(history["u"], radial_p05, label="5th percentile owner value")
    for boundary in _q_boundaries(history["u"], q):
        ax_radial.axvline(boundary, color="k", lw=0.7, ls=":")
    ax_radial.set(xlabel="u", ylabel=r"$\Delta T_e$", title="owner-unique radial distribution")
    ax_radial.legend()
    ax_radial.grid(alpha=0.2)
    fig.savefig(OUT / f"undershoot_N{n}.png", dpi=150)
    plt.close(fig)


def analyze_case(n: int) -> dict[str, object]:
    paths = _case_paths(n)
    histories = {name: _load_npz(path / "history.npz") for name, path in paths.items() if name != "host_cache" and (path / "history.npz").exists()}
    host = _load_npz(paths["host_cache"])
    history = histories["quadratic"]
    if not np.array_equal(history["theta"], histories["no_rlp"]["theta"]) or not np.array_equal(history["eta"], histories["no_rlp"]["eta"]):
        raise ValueError(f"N{n}: no-RLP coordinates do not match quadratic coordinates")
    series = _owner_series(history, host)
    q = np.asarray(history["angular_group_sizes"], dtype=np.int64)
    forced_positive = ((21, 2, 25), (21, 24, 25), (21, 26, 25)) if n == 64 else ()
    negative = _records_for_metric(series, history, histories["no_rlp"], kind="negative")
    positive = _records_for_metric(series, history, histories["no_rlp"], kind="positive_prominence", forced_coordinates=forced_positive)
    _plot_panels(n, {key: histories[key] for key in ("quadratic", "no_rlp")}, series, q)
    _plot_undershoot(n, history, series, q)
    contrasts = _flatten_owner_metric(series, "contrasts")
    radial_contrast = []
    for i, ring in enumerate(series["contrasts"]):
        radial_contrast.append({"u": float(history["u"][i]), "q": int(q[i]), "max_abs_neighbor_contrast": float(np.max(np.abs(ring))), "max_positive_neighbor_contrast": float(np.max(ring))})
    return {
        "resolution": n,
        "paths": {name: str(path) for name, path in paths.items()},
        "group_sizes": q.tolist(),
        "q_change_boundaries_u": _q_boundaries(history["u"], q),
        "owner_count": len(series["records"]),
        "history_times": history["times"].tolist(),
        "no_rlp_initial_difference": {
            "max_abs_deltaTe": float(np.max(np.abs(history["Te"][0] - histories["no_rlp"]["Te"][0]))),
            "definition": "same fine coordinates, but no-RLP has a different initial representation because RLP starts from owner averages",
        },
        "global_raw_volume_diagnostics": _global_deficit_summary(history, host),
        "negative_candidates": negative,
        "positive_prominence_candidates": positive,
        "radial_neighbor_contrasts": radial_contrast,
        "method_notes": {
            "owner_peak_rule": "active aggregate owners represented once; periodic theta owner-neighbor values used for local contrast",
            "volume_rule": "full materialized field budgets use host_raw_volume from the saved angular RLP cache",
            "roughness_rule": "radial differences are a roughness proxy and are not evidence of a physical defect",
            "historical_context": "historical baseline is optional context because it predates this matched source/control pair",
        },
    }


def main() -> None:
    results = [analyze_case(n) for n in (32, 64)]
    (OUT / "candidates.json").write_text(json.dumps({"cases": results}, indent=2) + "\n")
    report_lines = [
        "# Quadratic heat-history localization",
        "",
        "The ranking uses unique active owner representatives. Fine cells inside one angular aggregate are not counted as independent peaks. Full-field volume diagnostics use `host_raw_volume` from the saved host cache.",
        "",
    ]
    for result in results:
        case_n = int(result["resolution"])
        summary = result["global_raw_volume_diagnostics"]
        panel_path = OUT / f"history_panels_N{case_n}_eta25.png"
        undershoot_path = OUT / f"undershoot_N{case_n}.png"
        report_lines.extend([
            f"## N={result['resolution']}",
            "",
            f"The owner topology has q={result['group_sizes']} by radial ring, with changes at u={result['q_change_boundaries_u']}.",
            f"The pointwise global minimum delta-Te is {summary['global_min_deltaTe']:.8g} at t={summary['global_min_time']:g}; the raw-volume weighted time-minimum mean is {summary['negative_volume_weighted_mean_min']:.8g}.",
            f"The no-RLP control has a different initial representation at the same coordinates (maximum initial absolute delta-Te difference {result['no_rlp_initial_difference']['max_abs_deltaTe']:.8g}).",
            f"The strongest owner-unique undershoot is at u={result['negative_candidates'][0]['u']:.8g} (q={result['negative_candidates'][0]['q']}) while transition candidates are tracked separately in `candidates.json`.",
            "",
            f"![transition panels](<{panel_path}>)",
            "",
            f"![undershoot map](<{undershoot_path}>)",
            "",
            "Top owner-unique negative deficits:",
            "",
        ])
        for candidate in result["negative_candidates"][:8]:
            report_lines.append(
                f"- owner {candidate['owner_flat_id']} at (u={candidate['u']:.8g}, theta/(2pi)={candidate['theta_phase']:.8g}, eta={candidate['eta_index']}): min {candidate['minimum_deltaTe']:.8g} at t={candidate['minimum_time']:g}, first negative t={candidate['first_negative_time']:g}, no-RLP at minimum {candidate['no_rlp_minimum_deltaTe']:.8g}."
            )
        report_lines.extend(["", "Top positive owner-neighbor prominence candidates:", ""])
        for candidate in result["positive_prominence_candidates"][:8]:
            report_lines.append(
                f"- owner {candidate['owner_flat_id']} at (u={candidate['u']:.8g}, theta/(2pi)={candidate['theta_phase']:.8g}, eta={candidate['eta_index']}): prominence against the larger neighbor {candidate['positive_max_neighbor_prominence']:.8g} at t={candidate['first_positive_max_neighbor_time']:g}, peak delta-Te {candidate['peak_deltaTe']:.8g}."
            )
        if case_n == 64:
            report_lines.extend(["", "Explicit eta-25 transition tracking requested for the two visible angular patches:", ""])
            for coordinate in ((21, 2, 25), (21, 24, 25), (21, 26, 25)):
                candidate = next(
                    item for item in result["positive_prominence_candidates"]
                    if (item["ring"], item["theta_index"], item["eta_index"]) == coordinate
                )
                report_lines.append(
                    f"- owner {candidate['owner_flat_id']} at (u={candidate['u']:.8g}, theta/(2pi)={candidate['theta_phase']:.8g}, eta=25): larger-neighbor prominence first becomes positive at t={candidate['first_positive_max_neighbor_time']:g}, reaches {candidate['positive_max_neighbor_prominence']:.8g}; final delta-Te={candidate['time_history']['deltaTe'][-1]:.8g}."
                )
        report_lines.extend(["", "The radial second-difference and neighbor-contrast arrays are diagnostic roughness proxies. They do not establish a numerical defect because smooth curved coordinates can produce radial variation.", ""])
    (OUT / "report.md").write_text("\n".join(report_lines))
    print(json.dumps({"output": str(OUT), "cases": [r["resolution"] for r in results]}, indent=2))


if __name__ == "__main__":
    main()
