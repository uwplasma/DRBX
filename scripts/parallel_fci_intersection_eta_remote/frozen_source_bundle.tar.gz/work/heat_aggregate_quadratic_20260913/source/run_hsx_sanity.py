#!/usr/bin/env python3
"""Production-operator sanity experiments for HSX and analytic toroidal cases.

This driver deliberately does *not* run the seven-field blob model.  It uses
the exact HSX metric/map construction used by :mod:`simulate_hsx_blob`, then
advances only the mapped FCI contribution

    d Te / dt = chi_e_parallel * div_parallel(grad_parallel Te)

with classical RK4.  Density, potential, ion temperature, parallel flows and
vorticity are fixed equilibrium fields; every physical perpendicular
diffusivity is exactly zero.  It is consequently a diagnostic of geometry,
field-line mapping, endpoint closure, and the Te parallel-diffusion operator,
not a blob/turbulence calculation.

The runner only writes reusable numerical history.  Interactive plotting and
VMEC equilibrium overlays live in ``hsx_sanity_plots.ipynb`` so inspecting or
restyling figures never rebuilds geometry or repeats the integration.

``--experiment heat-spot`` retains the historical HSX Te-only conduction run.
``--experiment polarization`` performs a continuous circular-torus
polarization inversion round trip.  ``--experiment interchange`` and
``--experiment drift-wave`` use the package's ``LocalFciDrbEBRhs`` on a flat
slab.  Their pass/fail references are continuous analytic dispersion operators
derived independently of the production RHS.  An optional finite-difference
tangent of the production RHS is retained only as a diagnostic.
"""

from __future__ import annotations

import argparse
from dataclasses import replace
import json
from pathlib import Path
import sys
import time
from typing import Sequence

import numpy as np

# The production driver and package live in the DRBX checkout.  Put that
# checkout ahead of this workspace directory so an older convenience copy of
# simulate_hsx_blob.py cannot silently select a different operator contract.
_DRBX_CHECKOUT = Path(__file__).resolve().parent / "DRBX"
try:
    sys.path.remove(str(_DRBX_CHECKOUT))
except ValueError:
    pass
sys.path.insert(0, str(_DRBX_CHECKOUT))

import simulate_hsx_blob as production
from drbx.geometry import build_open_slab_geometry, build_shifted_torus_geometry
from drbx.linear import eigenmodes, interchange_operator
from drbx.geometry.fci_geometry import FciMaps3D, interpolate_B_contravariant
from drbx.native import local_parallel_diffusion_fci_op

jax = production.jax
jnp = production.jnp
FciDrbEBRhsParameters = production.FciDrbEBRhsParameters
FciDrbEBState = production.FciDrbEBState
assemble_local_fci_geometry = production.assemble_local_fci_geometry
build_local_fci_geometries = production.build_local_fci_geometries


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT_DIR = SCRIPT_DIR / "prototype_runs" / "hsx_parallel_heat_spot_32"
PRODUCTION_GEOMETRY_DEFAULTS = {
    "resolution": (32, 32, 32),
    "fit_sample_shape": (32, 32, 32),
    "metric_mesh_shape": (32, 32, 32),
    "radial_degree": 3,
    "vertical_degree": 3,
    "toroidal_modes": 10,
    "metric_radial_degree": 17,
    "metric_poloidal_modes": 15,
    "metric_toroidal_modes": 3,
    "eta_projection_iterations": 0,
    "axis_core_radius": 0.03,
    "fci_trace_substeps": 4,
}
QHS_MAIN_CURRENT_AMPERES = production.HSX_QHS_MAIN_CURRENT_AMPERES
QHS_MAKEGRID_CURRENTS = production.DEFAULT_HSX_QHS_MAKEGRID_CURRENTS
DEFAULT_POINCARE_SEED_U = np.linspace(0.04, 0.76, 25, dtype=np.float64)
SIMPLE_TORUS_PERIODIC_AXES = (False, True, True)
SIMPLE_TORUS_AXIS_REGULAR_AXES = (False, False, False)
SIMPLE_SLAB_PERIODIC_AXES = (False, True, True)
SIMPLE_SLAB_AXIS_REGULAR_AXES = (False, False, False)


def _three_ints(value: str) -> tuple[int, int, int]:
    parts = tuple(int(part) for part in value.split(","))
    if len(parts) != 3 or any(part < 3 for part in parts):
        raise argparse.ArgumentTypeError("resolution must be three integers >= 3, e.g. 32,32,32")
    return parts


def production_geometry_kwargs(args: argparse.Namespace) -> dict[str, object]:
    """Return the deliberately explicit production geometry contract."""

    return {
        "makegrid_path": args.makegrid,
        "vessel_path": args.vessel,
        "resolution": args.resolution,
        "fit_sample_shape": args.fit_sample_shape,
        "radial_degree": args.radial_degree,
        "vertical_degree": args.vertical_degree,
        "toroidal_modes": args.toroidal_modes,
        "metric_spline_degree": args.metric_spline_degree,
        "mmpde_iterations": args.mmpde_iterations,
        "axis_core_radius": args.axis_core_radius,
        "reference_magnetic_field": None,
        "makegrid_currents": args.makegrid_currents,
        "topology": "toroidal",
        "metric_mesh_shape": args.metric_mesh_shape,
        "metric_radial_degree": args.metric_radial_degree,
        "metric_poloidal_modes": args.metric_poloidal_modes,
        "metric_toroidal_modes": args.metric_toroidal_modes,
        "eta_projection_iterations": args.eta_projection_iterations,
        "construct_fci_maps": True,
        "fci_trace_substeps": args.fci_trace_substeps,
        "metric_cache_dir": args.metric_cache_dir,
        "rebuild_metric_cache": args.rebuild_metric_cache,
        "return_metric_evaluator": False,
    }


def effective_geometry_kwargs(args: argparse.Namespace) -> dict[str, object]:
    """Geometry call used by this driver, including its evaluator request."""

    return production_geometry_kwargs(args) | {"return_metric_evaluator": True}


def _periodic_offset(values: np.ndarray, center: float, period: float) -> np.ndarray:
    return (values - center + 0.5 * period) % period - 0.5 * period


def make_heat_spot_state(
    geometry: production.FciGeometry3D,
    *,
    amplitude: float,
    center_u: float,
    center_v: float,
    center_eta: float,
    width_u: float,
    width_v: float,
    width_eta: float,
) -> FciDrbEBState:
    """Create a positive, genuinely 3-D core Te pulse over Te=1."""

    if amplitude <= 0.0 or min(width_u, width_v, width_eta) <= 0.0:
        raise ValueError("heat-spot amplitude and widths must be positive")
    u = np.asarray(geometry.grid.x.centers, dtype=np.float64)[:, None, None]
    v = np.asarray(geometry.grid.y.centers, dtype=np.float64)[None, :, None]
    eta = np.asarray(geometry.grid.z.centers, dtype=np.float64)[None, None, :]
    # Local polar Cartesian coordinates provide independently controllable
    # radial and angular widths while preserving angular periodicity.
    du = u - center_u
    ds_theta = center_u * _periodic_offset(v, center_v, 2.0 * np.pi)
    perp2 = (du / width_u) ** 2 + (ds_theta / width_v) ** 2
    # eta is a full 2pi coordinate after production's field-period lifting.
    eta2 = (_periodic_offset(eta, center_eta, 2.0 * np.pi) / width_eta) ** 2
    spot = np.exp(-0.5 * (perp2 + eta2))
    Te = jnp.asarray(1.0 + amplitude * spot, dtype=jnp.float64)
    zeros = jnp.zeros(geometry.shape, dtype=jnp.float64)
    ones = jnp.ones(geometry.shape, dtype=jnp.float64)
    return FciDrbEBState(
        density=ones,
        phi=zeros,
        Te=Te,
        Ti=ones,
        Vi=zeros,
        Ve=zeros,
        vorticity=zeros,
    )


def trace_poincare_theta_u(
    geometry: production.FciGeometry3D,
    *,
    seed_u: np.ndarray = DEFAULT_POINCARE_SEED_U,
    seed_theta: float = np.pi,
    turns: int = 160,
    substeps_per_plane: int = 4,
    minimum_abs_B_eta: float = 1.0e-8,
) -> tuple[np.ndarray, np.ndarray]:
    """Trace nested production-field Poincare sets on every eta plane."""

    seed_u = np.asarray(seed_u, dtype=np.float64)
    if seed_u.ndim != 1 or seed_u.size < 3 or not np.all(np.diff(seed_u) > 0.0):
        raise ValueError("seed_u must be a strictly increasing one-dimensional array")
    if turns < 8 or substeps_per_plane < 1:
        raise ValueError("turns must be >= 8 and substeps_per_plane must be positive")
    grid = geometry.grid
    eta_centers = np.asarray(grid.z.centers, dtype=np.float64)
    eta_lower = float(grid.z.faces[0])
    eta_upper = float(grid.z.faces[-1])
    eta_period = eta_upper - eta_lower
    plane_step = eta_period / eta_centers.size
    substep = plane_step / int(substeps_per_plane)
    u_lower = float(grid.x.faces[0])
    u_upper = float(grid.x.faces[-1])
    theta_lower = float(grid.y.faces[0])
    theta_upper = float(grid.y.faces[-1])
    theta_period = theta_upper - theta_lower
    initial = jnp.asarray(
        np.column_stack(
            (seed_u, np.full(seed_u.shape, seed_theta), np.full(seed_u.shape, eta_centers[0]))
        ),
        dtype=jnp.float64,
    )

    def normalize(points):
        radius = points[..., 0]
        angle = points[..., 1]
        reflected = radius < u_lower
        radius = jnp.where(reflected, 2.0 * u_lower - radius, radius)
        angle = jnp.where(reflected, angle + jnp.pi, angle)
        angle = jnp.mod(angle - theta_lower, theta_period) + theta_lower
        toroidal = jnp.mod(points[..., 2] - eta_lower, eta_period) + eta_lower
        return jnp.stack((radius, angle, toroidal), axis=-1)

    def fieldline_rhs(points):
        points = normalize(points)
        magnetic = interpolate_B_contravariant(
            geometry,
            points,
            periodic_axes=(False, True, True),
            boundary_value=jnp.nan,
        )
        b_eta = magnetic[..., 2]
        safe_b_eta = jnp.where(
            jnp.abs(b_eta) < minimum_abs_B_eta,
            jnp.where(b_eta < 0.0, -minimum_abs_B_eta, minimum_abs_B_eta),
            b_eta,
        )
        return jnp.stack(
            (magnetic[..., 0] / safe_b_eta, magnetic[..., 1] / safe_b_eta, jnp.ones_like(b_eta)),
            axis=-1,
        )

    def rk4_substep(points):
        k1 = fieldline_rhs(points)
        k2 = fieldline_rhs(points + 0.5 * substep * k1)
        k3 = fieldline_rhs(points + 0.5 * substep * k2)
        k4 = fieldline_rhs(points + substep * k3)
        return normalize(points + (substep / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4))

    def plane_stepper(points, _index):
        advanced = jax.lax.fori_loop(
            0,
            int(substeps_per_plane),
            lambda _i, value: rk4_substep(value),
            points,
        )
        valid = jnp.all(jnp.isfinite(advanced), axis=-1)
        valid &= (advanced[:, 0] >= u_lower) & (advanced[:, 0] <= u_upper)
        advanced = jnp.where(valid[:, None], advanced, jnp.nan)
        return advanced, advanced

    step_count = int(turns) * eta_centers.size
    _final, samples = jax.jit(
        lambda state: jax.lax.scan(plane_stepper, state, jnp.arange(step_count))
    )(initial)
    samples = np.asarray(jax.block_until_ready(samples), dtype=np.float64)
    traces = np.full(
        (eta_centers.size, seed_u.size, int(turns), 2),
        np.nan,
        dtype=np.float64,
    )
    for step_index in range(step_count):
        plane = (step_index + 1) % eta_centers.size
        turn = (step_index + 1) // eta_centers.size
        if plane == 0:
            turn -= 1
        if 0 <= turn < turns:
            traces[plane, :, turn, 0] = samples[step_index, :, 0]
            traces[plane, :, turn, 1] = samples[step_index, :, 1]
    return eta_centers, traces


def _fourier_poincare_radius(
    points: np.ndarray,
    target_theta: np.ndarray,
    *,
    samples: int = 512,
    retained_modes: int = 14,
) -> np.ndarray | None:
    points = np.asarray(points, dtype=np.float64)
    points = points[np.all(np.isfinite(points), axis=1)]
    if points.shape[0] < 32:
        return None
    radius = points[:, 0]
    angle = np.mod(points[:, 1], 2.0 * np.pi)
    order = np.argsort(angle)
    angle, radius = angle[order], radius[order]
    extended_angle = np.concatenate(
        (angle[-1:] - 2.0 * np.pi, angle, angle[:1] + 2.0 * np.pi)
    )
    extended_radius = np.concatenate((radius[-1:], radius, radius[:1]))
    sample_theta = np.linspace(0.0, 2.0 * np.pi, samples, endpoint=False)
    sample_radius = np.interp(sample_theta, extended_angle, extended_radius)
    spectrum = np.fft.rfft(sample_radius)
    spectrum[retained_modes + 1 :] = 0.0
    smooth_radius = np.fft.irfft(spectrum, n=samples)
    return np.interp(
        np.mod(target_theta, 2.0 * np.pi),
        sample_theta,
        smooth_radius,
        period=2.0 * np.pi,
    )


def traced_flux_label_from_poincare(
    geometry: production.FciGeometry3D,
    seed_u: np.ndarray,
    traces_theta_u: np.ndarray,
) -> np.ndarray:
    """Construct a monotone numerical flux label from nested Poincare sets."""

    seed_u = np.asarray(seed_u, dtype=np.float64)
    traces = np.asarray(traces_theta_u, dtype=np.float64)
    u_centers = np.asarray(geometry.grid.x.centers, dtype=np.float64)
    theta_centers = np.asarray(geometry.grid.y.centers, dtype=np.float64)
    eta_count = np.asarray(geometry.grid.z.centers).size
    if traces.shape[:2] != (eta_count, seed_u.size):
        raise ValueError("Poincare traces do not match the geometry and seed arrays")
    surface_radius = np.full(
        (eta_count, seed_u.size, theta_centers.size), np.nan, dtype=np.float64
    )
    for plane in range(eta_count):
        for seed in range(seed_u.size):
            fitted = _fourier_poincare_radius(traces[plane, seed], theta_centers)
            if fitted is not None:
                surface_radius[plane, seed] = fitted

    label = np.empty(
        (u_centers.size, theta_centers.size, eta_count), dtype=np.float64
    )
    for plane in range(eta_count):
        for angular in range(theta_centers.size):
            radii = surface_radius[plane, :, angular]
            valid = np.isfinite(radii)
            if np.count_nonzero(valid) < 3:
                raise RuntimeError(
                    f"fewer than three nested Poincare surfaces survive at plane={plane}, theta={angular}"
                )
            radii = np.maximum.accumulate(np.clip(radii[valid], 0.0, 1.0))
            labels = seed_u[valid]
            keep = np.concatenate(([True], np.diff(radii) > 1.0e-8))
            radii, labels = radii[keep], labels[keep]
            knots_u = np.concatenate(([0.0], radii, [1.0]))
            knots_label = np.concatenate(([0.0], labels, [1.0]))
            knots_u = np.maximum.accumulate(knots_u)
            label[:, angular, plane] = np.interp(u_centers, knots_u, knots_label)
    return np.clip(label, 0.0, 1.0)


def make_flux_function_state(
    geometry: production.FciGeometry3D,
    flux_label: np.ndarray,
    *,
    amplitude: float,
    center: float,
    width: float,
) -> FciDrbEBState:
    """Initialise the literature numerical-diffusion Gaussian f(psi)."""

    flux_label = np.asarray(flux_label, dtype=np.float64)
    if flux_label.shape != geometry.shape:
        raise ValueError("flux_label must match the geometry cell shape")
    if amplitude <= 0.0 or width <= 0.0:
        raise ValueError("flux-function amplitude and width must be positive")
    perturbation = amplitude * np.exp(-0.5 * ((flux_label - center) / width) ** 2)
    Te = jnp.asarray(1.0 + perturbation, dtype=jnp.float64)
    zeros = jnp.zeros(geometry.shape, dtype=jnp.float64)
    ones = jnp.ones(geometry.shape, dtype=jnp.float64)
    return FciDrbEBState(
        density=ones,
        phi=zeros,
        Te=Te,
        Ti=ones,
        Vi=zeros,
        Ve=zeros,
        vorticity=zeros,
    )


def build_te_only_rhs(
    geometry: production.FciGeometry3D,
    *,
    metric_evaluator: object,
    metric_cache_path: Path | None,
    chi_parallel: float,
    halo_width: int,
    angular_agglomeration: bool = True,
) -> tuple[object, object, object, object, object]:
    """Return production local inputs for a compiled Te-only mapped RHS."""

    sharded = build_local_fci_geometries(
        geometry,
        (1, 1, 1),
        halo_width=halo_width,
        periodic_axes=(False, True, True),
        axis_regular_axes=(True, False, False),
    )
    if not sharded.maps_valid or sharded.map_fields is None:
        raise RuntimeError("production HSX FCI maps are absent or non-finite")
    # Build the production radius-dependent polar RLP payload even though the
    # isolated parallel operator itself has no perpendicular/curvature term.
    # This keeps the axis ownership and state layout identical to full HSX
    # runs, and lets the saved history be compared cell-for-cell with them.
    if angular_agglomeration:
        owner_host_geometry, _safety = (
            production.build_metric_aware_polar_angular_agglomeration_geometry(
                geometry,
                metric_evaluator,
                metric_cache_path=metric_cache_path,
            )
        )
        control_volume_descriptor, control_volume_fields = (
            production.build_sharded_polar_angular_agglomeration_payload(
                owner_host_geometry, sharded.domain
            )
        )
        control_volume_boundary_bc = production.empty_angular_agglomeration_boundary_bc(
            max_rows=int(getattr(control_volume_descriptor, "compact_face_count", 0))
        )
    else:
        owner_host_geometry = control_volume_descriptor = control_volume_boundary_bc = None
        # Keep the shard-map array signature; this dummy channel is never read.
        control_volume_fields = np.zeros_like(np.asarray(sharded.cell_fields)[..., :1])
    parameters = FciDrbEBRhsParameters(
        density_D_perp=0.0,
        density_D_parallel=0.0,
        electron_temperature_chi_parallel=float(chi_parallel),
        electron_temperature_D_perp=0.0,
        ion_temperature_chi_parallel=0.0,
        ion_temperature_D_perp=0.0,
        Ve_nu=0.0,
        Ve_D_perp=0.0,
        Ve_parallel_viscosity=0.0,
        Vi_D_perp=0.0,
        Vi_parallel_viscosity=0.0,
        vorticity_D_perp=0.0,
        vorticity_D_parallel=0.0,
    )
    return (
        sharded,
        parameters,
        control_volume_descriptor,
        control_volume_fields,
        (control_volume_boundary_bc, owner_host_geometry),
    )


def build_conduction_reconstruction(
    geometry: production.FciGeometry3D,
    owner_host_geometry: object,
    *,
    mode: str,
) -> tuple[object | None, dict[str, object]]:
    """Prepare the opt-in aggregate reconstruction for the Te conduction run.

    The reconstruction is deliberately prepared on the host, before the
    shard-map/JIT compilation.  The experiment uses a fixed quadratic basis
    and starts with 32 donors, allowing the native builder to expand a row to
    at most 96 donors when its conditioning checks require it.  ``None`` is
    returned for the default legacy lane so importing this driver preserves
    the historical code path and its compilation contract.
    """

    if mode == "legacy":
        return None, {
            "mode": "legacy",
            "enabled": False,
        }
    if mode != "aggregate-quadratic":
        raise ValueError(f"unsupported conduction reconstruction mode: {mode!r}")
    if owner_host_geometry is None:
        raise ValueError(
            "aggregate-quadratic conduction reconstruction requires RLP owner geometry"
        )
    # Keep the runtime module lazy: the default legacy experiment must not
    # import or compile the experimental lane.
    from drbx.native.fci_aggregate_reconstruction import (
        build_conduction_reconstruction as build_native_conduction_reconstruction,
    )

    plan = build_native_conduction_reconstruction(
        geometry,
        owner_host_geometry,
        degree=2,
        donor_count=32,
        max_donor_count=96,
    )
    metadata = {
        "mode": "aggregate-quadratic",
        "enabled": True,
        "degree": 2,
        "initial_donor_count": 32,
        "max_donor_count": 96,
        "builder": "drbx.native.fci_aggregate_reconstruction.build_conduction_reconstruction",
    }
    plan_metadata = getattr(plan, "metadata", None)
    if callable(plan_metadata):
        plan_metadata = plan_metadata()
    if plan_metadata is None:
        plan_metadata = getattr(plan, "diagnostics", None)
    if isinstance(plan_metadata, dict):
        metadata["plan"] = plan_metadata
    metadata["runtime"] = (
        "drbx.native.local_parallel_diffusion_fci_aggregate_op"
    )
    return plan, metadata


def validate_conduction_reconstruction_args(args: argparse.Namespace) -> None:
    """Reject the experimental lane outside its supported conduction setup."""

    mode = getattr(args, "conduction_reconstruction", "legacy")
    if mode == "legacy":
        return
    if mode != "aggregate-quadratic":
        raise SystemExit(f"unsupported --conduction-reconstruction value: {mode}")
    if getattr(args, "experiment", "heat-spot") != "heat-spot":
        raise SystemExit(
            "--conduction-reconstruction is supported only for --experiment heat-spot"
        )
    if bool(getattr(args, "no_rlp", False)):
        raise SystemExit(
            "--conduction-reconstruction aggregate-quadratic requires RLP owner geometry; remove --no-rlp"
        )


def compile_te_only_rk4(
    sharded: object,
    parameters: FciDrbEBRhsParameters,
    control_volume_descriptor: object,
    control_volume_fields: object,
    control_volume_boundary_bc: object,
    *,
    timestep: float,
    conduction_reconstruction: object | None = None,
) -> tuple[object, object, object, object]:
    """Compile a no-SOLVAX RK4 advance and literature diffusion diagnostic.

    ``conduction_reconstruction`` is an optional host-prepared native plan
    used only by the aggregate-quadratic conduction experiment.  ``None``
    retains the historical mapped-FCI lane byte-for-byte.

    Local geometry must be assembled inside ``shard_map``: the production
    local geometry builder uses x/y/z collectives, even for a single shard.
    """

    mesh = production.make_shard_mesh((1, 1, 1))
    spatial = production.P("x", "y", "z")
    geometry = production.P("x", "y", "z", None)
    replicated = production.P()
    state_spec = FciDrbEBState(
        density=spatial, phi=spatial, Te=spatial, Ti=spatial,
        Vi=spatial, Ve=spatial, vorticity=spatial,
    )

    def make_model(cell_fields, map_fields, cv_fields):
        local_geometry = assemble_local_fci_geometry(sharded, cell_fields, map_fields)
        local_cv = (
            production.assemble_local_polar_angular_agglomeration_geometry(
                control_volume_descriptor, cv_fields, local_geometry
            )
            if control_volume_descriptor is not None else None
        )
        model = production.build_local_eb_model(
            local_geometry,
            sharded.domain,
            parameters,
            gmres_target_tolerance=1.0e-8,
            gmres_acceptance_tolerance=1.0e-7,
            gmres_max_iterations=8,
            poisson_bracket_scheme="compatible-flux",
            parallel_operator_scheme="fci",
            control_volume_geometry=local_cv,
            control_volume_boundary_bc=control_volume_boundary_bc,
        )
        return model

    def parallel_te_diffusion(model, state):
        # This is the production FCI diffusion lane from
        # LocalFciDrbEBRhs._fci_parallel_terms, evaluated without compiling
        # the unrelated material, curvature, bracket, and polarization lanes.
        face_bc = model._face_bcs(state)
        state_halo = model._prepare_state_halo(state, face_bc)
        context = model._stencil_builder_context()
        inverse_b_halo, inverse_b_forward, inverse_b_backward = (
            model._fci_prepare_inverse_b(face_bc, context)
        )
        field_forward, field_backward = model._fci_remote_values(
            state_halo.Te, context
        )
        diffusivity_halo = jnp.ones_like(state_halo.Te, dtype=jnp.float64)
        diffusivity_forward, diffusivity_backward = model._fci_remote_values(
            diffusivity_halo, context
        )
        diffusion_kwargs = {
            "field_halo_full": state_halo.Te,
            "geometry": model.geometry,
            "context": context,
            "diffusivity_halo_full": diffusivity_halo,
            "inverse_b_halo_full": inverse_b_halo,
            "forward_remote_values": field_forward,
            "backward_remote_values": field_backward,
            "forward_remote_diffusivity_values": diffusivity_forward,
            "backward_remote_diffusivity_values": diffusivity_backward,
            "forward_remote_inverse_b_values": inverse_b_forward,
            "backward_remote_inverse_b_values": inverse_b_backward,
        }
        diffusion_operator = local_parallel_diffusion_fci_op
        if conduction_reconstruction is not None:
            # The native experimental runtime owns the JAX gathers and the
            # ordinary-interior mask.  The owner field is the compact Te
            # state; its halo is retained for the legacy wall/topology lane.
            from drbx.native import local_parallel_diffusion_fci_aggregate_op

            diffusion_operator = local_parallel_diffusion_fci_aggregate_op
            diffusion_kwargs["owner_values"] = state.Te
            diffusion_kwargs["reconstruction"] = conduction_reconstruction
        fine_rhs = jnp.asarray(
            model.parameters.electron_temperature_chi_parallel,
            dtype=jnp.float64,
        ) * diffusion_operator(**diffusion_kwargs)
        Te_rhs = model._owner_field(model._restrict_fine_field(fine_rhs))
        zeros = jnp.zeros_like(Te_rhs, dtype=jnp.float64)
        return FciDrbEBState(
            density=zeros,
            phi=zeros,
            Te=Te_rhs,
            Ti=zeros,
            Vi=zeros,
            Ve=zeros,
            vorticity=zeros,
        )

    def perpendicular_te_laplacian(model, state):
        face_bc = model._face_bcs(state)
        state_halo = model._prepare_state_halo(state, face_bc)
        fine_rhs = model._field_perp_diffusion(
            state_halo.Te,
            face_bc.Te,
            1.0,
        )
        return model._owner_field(model._restrict_fine_field(fine_rhs))

    def advance(state, cell_fields, map_fields, cv_fields):
        model = make_model(cell_fields, map_fields, cv_fields)

        def rhs(value):
            # Extract the named production Te parallel-diffusion ledger lane.
            # All other equations and Te terms remain exactly frozen.
            return parallel_te_diffusion(model, value)

        k1 = rhs(state)
        k2 = rhs(state.axpy(k1, scale=0.5 * timestep))
        k3 = rhs(state.axpy(k2, scale=0.5 * timestep))
        k4 = rhs(state.axpy(k3, scale=timestep))
        weighted = k1.axpy(k2, scale=2.0).axpy(k3, scale=2.0).axpy(
            k4, scale=1.0
        )
        next_state = model.project_galerkin_state(state.axpy(weighted, scale=timestep / 6.0))
        non_te = jnp.stack(
            tuple(jnp.max(jnp.abs(value)) for name, value in k1.field_items() if name != "Te")
        )
        for axis in ("x", "y", "z"):
            non_te = jax.lax.pmax(non_te, axis)
        return next_state, non_te

    compiled = jax.jit(jax.shard_map(
        advance,
        mesh=mesh,
        in_specs=(state_spec, geometry, geometry, geometry),
        out_specs=(state_spec, replicated),
        check_vma=False,
    ))

    # Hill, Shanahan & Dudson (CPC 213, 2017) estimate numerical
    # perpendicular diffusion from ||df/dt||_2 / ||laplacian_perp(f)||_2 for
    # an initial numerical flux function.  Evaluate both production operators
    # at saved states without evolving the unit-perpendicular-diffusion model.
    def diffusion_fields(state, cell_fields, map_fields, cv_fields):
        parallel_model = make_model(cell_fields, map_fields, cv_fields)
        parallel_rhs = parallel_te_diffusion(parallel_model, state)
        perpendicular_rhs = perpendicular_te_laplacian(parallel_model, state)
        return parallel_rhs.Te, perpendicular_rhs

    compiled_diffusion_fields = jax.jit(jax.shard_map(
        diffusion_fields,
        mesh=mesh,
        in_specs=(state_spec, geometry, geometry, geometry),
        out_specs=(spatial, spatial),
        check_vma=False,
    ))
    return compiled, compiled_diffusion_fields, mesh, spatial


def _weights(geometry: production.FciGeometry3D) -> np.ndarray:
    dx = np.asarray(geometry.grid.x.widths, dtype=np.float64)[:, None, None]
    dy = np.asarray(geometry.grid.y.widths, dtype=np.float64)[None, :, None]
    dz = np.asarray(geometry.grid.z.widths, dtype=np.float64)[None, None, :]
    return np.abs(np.asarray(geometry.cell_metric.J, dtype=np.float64)) * dx * dy * dz


def _materialize_owner_field(array: np.ndarray, owner_host_geometry: object) -> np.ndarray:
    if owner_host_geometry is None:
        return np.asarray(array, dtype=np.float64)
    owner_index = np.asarray(owner_host_geometry.topology.owner_index, dtype=np.int32)
    return np.asarray(array, dtype=np.float64)[tuple(np.moveaxis(owner_index, -1, 0))]


def heat_spot_diagnostics(
    Te: np.ndarray,
    geometry: production.FciGeometry3D,
    weights: np.ndarray,
) -> dict[str, float]:
    """Volume-weighted, background-subtracted diagnostics saved every frame."""

    perturbation = np.asarray(Te, dtype=np.float64) - 1.0
    volume = float(np.sum(weights))
    mass = float(np.sum(weights * perturbation))
    l2 = float(np.sqrt(np.sum(weights * perturbation**2) / volume))
    variance = float(np.sum(weights * (perturbation - mass / volume) ** 2) / volume)
    u = np.asarray(geometry.grid.x.centers, dtype=np.float64)[:, None, None]
    eta = np.asarray(geometry.grid.z.centers, dtype=np.float64)[None, None, :]
    positive_weight = weights * np.maximum(perturbation, 0.0)
    positive_mass = float(np.sum(positive_weight))
    if positive_mass <= np.finfo(np.float64).tiny:
        centroid = width = eta_spread = float("nan")
    else:
        centroid = float(np.sum(positive_weight * u) / positive_mass)
        width = float(np.sqrt(np.sum(positive_weight * (u - centroid) ** 2) / positive_mass))
        phase = float(np.angle(np.sum(positive_weight * np.exp(1j * eta))))
        eta_offset = _periodic_offset(eta, phase, 2.0 * np.pi)
        eta_spread = float(np.sqrt(np.sum(positive_weight * eta_offset**2) / positive_mass))
    return {
        "Te_min": float(np.min(Te)),
        "Te_max": float(np.max(Te)),
        "Te_finite_fraction": float(np.mean(np.isfinite(Te))),
        "perturbation_mass": mass,
        "perturbation_l2": l2,
        "perturbation_variance": variance,
        "radial_centroid_u": centroid,
        "radial_width_u": width,
        "eta_spread": eta_spread,
    }


def _freeze_diagnostic(rhs: FciDrbEBState) -> dict[str, float]:
    return {
        name: float(np.max(np.abs(np.asarray(value))))
        for name, value in rhs.field_items()
        if name != "Te"
    }


def run_heat_spot(args: argparse.Namespace) -> Path:
    validate_conduction_reconstruction_args(args)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    geometry_start = time.perf_counter()
    geometry_kwargs = effective_geometry_kwargs(args)
    geometry_result = production.build_hsx_fci_geometry(**geometry_kwargs)
    geometry, cell_positions, nfp, metric_cache_path, metric_evaluator = geometry_result
    geometry_seconds = time.perf_counter() - geometry_start
    flux_label = None
    poincare_seed_u = None
    poincare_traces = None
    if args.initial_condition == "flux-function":
        poincare_seed_u = np.linspace(
            args.trace_seed_min,
            args.trace_seed_max,
            args.trace_seed_count,
            dtype=np.float64,
        )
        traced_eta, poincare_traces = trace_poincare_theta_u(
            geometry,
            seed_u=poincare_seed_u,
            turns=args.trace_turns,
            substeps_per_plane=args.fci_trace_substeps,
        )
        if not np.allclose(traced_eta, np.asarray(geometry.grid.z.centers)):
            raise RuntimeError("traced eta planes do not match the production grid")
        flux_label = traced_flux_label_from_poincare(
            geometry, poincare_seed_u, poincare_traces
        )
        state = make_flux_function_state(
            geometry,
            flux_label,
            amplitude=args.amplitude,
            center=args.flux_center,
            width=args.flux_width,
        )
    else:
        state = make_heat_spot_state(
            geometry,
            amplitude=args.amplitude,
            center_u=args.center_u,
            center_v=args.center_v,
            center_eta=args.center_eta,
            width_u=args.width_u,
            width_v=args.width_v,
            width_eta=args.width_eta,
        )
    (
        sharded,
        parameters,
        control_volume_descriptor,
        control_volume_fields,
        (control_volume_boundary_bc, owner_host_geometry),
    ) = build_te_only_rhs(
        geometry,
        metric_evaluator=metric_evaluator,
        metric_cache_path=metric_cache_path,
        chi_parallel=args.chi_parallel,
        halo_width=args.halo_width,
        angular_agglomeration=not args.no_rlp,
    )
    conduction_reconstruction, reconstruction_metadata = build_conduction_reconstruction(
        geometry,
        owner_host_geometry,
        mode=getattr(args, "conduction_reconstruction", "legacy"),
    )
    weights = _weights(geometry)
    # RLP runs evolve owner values.  Diagnostics/history are materialized back
    # to the fine logical grid, exactly as the production driver does.
    if owner_host_geometry is not None:
        state = production._aggregate_initial_owner_state(state, owner_host_geometry)
    angular_group_sizes = (
        np.ones(geometry.shape[0], dtype=np.int32)
        if owner_host_geometry is None else np.asarray(owner_host_geometry.angular_group_size, dtype=np.int32)
    )
    fixed_initial = {
        name: np.asarray(value)
        for name, value in state.field_items()
        if name != "Te"
    }

    dt = float(args.final_time) / int(args.num_steps)
    compiled_advance, compiled_diffusion_fields, mesh, spatial = compile_te_only_rk4(
        sharded,
        parameters,
        control_volume_descriptor,
        control_volume_fields,
        control_volume_boundary_bc,
        timestep=dt,
        conduction_reconstruction=conduction_reconstruction,
    )
    state_sharding = production.NamedSharding(mesh, spatial)
    geometry_sharding = production.NamedSharding(mesh, production.P("x", "y", "z", None))
    state = state.map_fields(
        lambda value: jax.device_put(jnp.asarray(value, dtype=jnp.float64), state_sharding)
    )
    cell_fields = jax.device_put(jnp.asarray(sharded.cell_fields, dtype=jnp.float64), geometry_sharding)
    map_fields = jax.device_put(jnp.asarray(sharded.map_fields, dtype=jnp.float64), geometry_sharding)
    cv_fields = jax.device_put(jnp.asarray(control_volume_fields, dtype=jnp.float64), geometry_sharding)
    frame_stride = max(1, int(args.save_every))
    frames: list[np.ndarray] = []
    times: list[float] = []
    diagnostics: list[dict[str, float]] = []

    def save_frame(time_value: float, current: FciDrbEBState) -> None:
        output_state = (
            current if owner_host_geometry is None
            else production._materialize_owner_state(current, owner_host_geometry)
        )
        Te_host = np.asarray(output_state.Te)
        parallel_owner, perpendicular_owner = compiled_diffusion_fields(
            current, cell_fields, map_fields, cv_fields
        )
        parallel_field = _materialize_owner_field(parallel_owner, owner_host_geometry)
        perpendicular_field = _materialize_owner_field(
            perpendicular_owner, owner_host_geometry
        )
        volume = max(float(np.sum(weights)), np.finfo(float).tiny)
        parallel_norm = float(np.sqrt(np.sum(weights * parallel_field**2) / volume))
        perpendicular_norm = float(
            np.sqrt(np.sum(weights * perpendicular_field**2) / volume)
        )
        effective_perp = parallel_norm / max(
            perpendicular_norm, np.finfo(float).tiny
        )
        frames.append(Te_host.copy())
        times.append(float(time_value))
        diagnostics.append(
            heat_spot_diagnostics(Te_host, geometry, weights)
            | {
                "parallel_rhs_l2": parallel_norm,
                "perpendicular_laplacian_l2": perpendicular_norm,
                "effective_perp_diffusivity": effective_perp,
                "effective_perp_to_parallel_ratio": effective_perp
                / max(float(args.chi_parallel), np.finfo(float).tiny),
            }
        )

    save_frame(0.0, state)
    integration_start = time.perf_counter()
    for step in range(1, int(args.num_steps) + 1):
        state, frozen_rhs_values = compiled_advance(state, cell_fields, map_fields, cv_fields)
        frozen_rhs = {
            name: float(value)
            for name, value in zip(fixed_initial, np.asarray(frozen_rhs_values), strict=True)
        }
        if any(value != 0.0 for value in frozen_rhs.values()):
            raise RuntimeError(f"Te-only isolation failed: non-Te RHS={frozen_rhs}")
        if step % frame_stride == 0 or step == int(args.num_steps):
            save_frame(step * dt, state)
            latest = diagnostics[-1]
            print(
                f"[heat-spot] step={step:4d}/{args.num_steps} t={step * dt:.4e} "
                f"Te=[{latest['Te_min']:.6e}, {latest['Te_max']:.6e}] "
                f"eta_rms={latest['eta_spread']:.4e}",
                flush=True,
            )
    integration_seconds = time.perf_counter() - integration_start

    frozen_error = {
        name: float(np.max(np.abs(np.asarray(getattr(state, name)) - initial)))
        for name, initial in fixed_initial.items()
    }
    final = diagnostics[-1]
    if final["Te_finite_fraction"] != 1.0 or final["Te_min"] <= 0.0:
        raise RuntimeError("heat-spot integration produced a non-finite or non-positive Te")
    if any(value != 0.0 for value in frozen_error.values()):
        raise RuntimeError(f"non-Te state changed in Te-only test: {frozen_error}")

    diagnostics_array = {
        name: np.asarray([entry[name] for entry in diagnostics], dtype=np.float64)
        for name in diagnostics[0]
    }
    history_path = output_dir / "history.npz"
    np.savez_compressed(
        history_path,
        times=np.asarray(times, dtype=np.float64),
        Te=np.asarray(frames, dtype=np.float64),
        volume_weights=weights,
        u=np.asarray(geometry.grid.x.centers, dtype=np.float64),
        theta=np.asarray(geometry.grid.y.centers, dtype=np.float64),
        eta=np.asarray(geometry.grid.z.centers, dtype=np.float64),
        metric_J=np.asarray(geometry.cell_metric.J, dtype=np.float64),
        magnetic_field=np.asarray(geometry.cell_bfield.Bmag, dtype=np.float64),
        Cartesian_position=np.asarray(cell_positions, dtype=np.float64),
        fci_map_fields=np.asarray(sharded.map_fields, dtype=np.float64),
        fci_map_field_names=np.asarray(production.FCI_MAP_FIELDS),
        angular_group_sizes=angular_group_sizes,
        **({"traced_flux_label": flux_label} if flux_label is not None else {}),
        **diagnostics_array,
    )
    if poincare_traces is not None:
        valid_counts = np.sum(
            np.all(np.isfinite(poincare_traces), axis=-1), axis=-1
        )
        np.savez_compressed(
            output_dir / "poincare_theta_u.npz",
            eta=np.asarray(geometry.grid.z.centers, dtype=np.float64),
            seed_u=poincare_seed_u,
            seed_theta=np.full(poincare_seed_u.shape, np.pi, dtype=np.float64),
            traces_theta_u=poincare_traces,
            valid_counts=valid_counts,
            turns=np.asarray(args.trace_turns),
            substeps_per_plane=np.asarray(args.fci_trace_substeps),
            tracing_method=np.asarray("production B_contravariant RK4"),
            makegrid_currents=np.asarray(args.makegrid_currents, dtype=np.float64),
            flux_label=flux_label,
        )
    latter_half = np.asarray(
        diagnostics_array["effective_perp_diffusivity"], dtype=np.float64
    )[np.asarray(times) >= 0.5 * float(args.final_time)]
    effective_perp_time_average = float(np.mean(latter_half))
    effective_ratio_time_average = effective_perp_time_average / max(
        float(args.chi_parallel), np.finfo(float).tiny
    )
    metadata = {
        "experiment": "HSX Te-only mapped-FCI parallel heat spot",
        "equation": "dTe/dt = chi_parallel * L_parallel_FCI(Te)",
        "physical_perpendicular_diffusion": 0.0,
        "initial_condition": args.initial_condition,
        "numerical_perpendicular_diffusion": {
            "definition": "time_average(||dTe/dt||_2 / ||laplacian_perp Te||_2)",
            "averaging_window": [0.5 * float(args.final_time), float(args.final_time)],
            "effective_perp_diffusivity": effective_perp_time_average,
            "effective_perp_to_parallel_ratio": effective_ratio_time_average,
            "literature_method": "Hill, Shanahan & Dudson, CPC 213 (2017), equations 24-26",
        },
        "other_rhs_terms": "disabled; only the production Te parallel-diffusion lane is evaluated",
        "geometry_source": "simulate_hsx_blob.build_hsx_fci_geometry",
        "toroidal_axis_treatment": (
            "fine polar grid; RLP angular agglomeration disabled"
            if args.no_rlp else "production metric-aware polar RLP owner grid"
        ),
        "rlp_angular_agglomeration": not args.no_rlp,
        "conduction_reconstruction": reconstruction_metadata,
        "geometry_contract": {
            **{key: list(value) if isinstance(value, tuple) else value for key, value in geometry_kwargs.items() if key not in {"makegrid_path", "vessel_path", "metric_cache_dir"}},
            "makegrid_path": str(args.makegrid),
            "vessel_path": str(args.vessel),
            "metric_cache_dir": str(args.metric_cache_dir),
            "metric_cache_path": None if metric_cache_path is None else str(metric_cache_path),
            "nfp": int(nfp),
        },
        "time_integration": {"method": "RK4", "dt": dt, "num_steps": int(args.num_steps), "final_time": float(args.final_time)},
        "execution": {"shard_counts": [1, 1, 1]},
        "heat_spot": {key: getattr(args, key) for key in ("amplitude", "center_u", "center_v", "center_eta", "width_u", "width_v", "width_eta", "chi_parallel")},
        "flux_function": {
            "center": args.flux_center,
            "width": args.flux_width,
            "trace_seed_min": args.trace_seed_min,
            "trace_seed_max": args.trace_seed_max,
            "trace_seed_count": args.trace_seed_count,
            "trace_turns": args.trace_turns,
        },
        "angular_group_sizes": angular_group_sizes.tolist(),
        "isolation": {"non_Te_rhs_max_abs": frozen_rhs, "final_non_Te_state_max_abs_change": frozen_error},
        "timing_seconds": {"geometry": geometry_seconds, "integration": integration_seconds},
        "history": str(history_path),
        "analysis_notebook": str(SCRIPT_DIR / "hsx_sanity_plots.ipynb"),
        "fci_map_field_names": list(production.FCI_MAP_FIELDS),
        "final_diagnostics": final,
    }
    with (output_dir / "metadata.json").open("w", encoding="utf-8") as stream:
        json.dump(metadata, stream, indent=2, sort_keys=True)
        stream.write("\n")
    summary = [
        "HSX mapped-FCI Te-only parallel heat-spot sanity run",
        f"history: {history_path}",
        f"analysis notebook: {SCRIPT_DIR / 'hsx_sanity_plots.ipynb'} (Python (drb) kernel)",
        f"resolution: {tuple(args.resolution)}, maps: production build_hsx_fci_geometry, nfp: {nfp}",
        f"RK4: steps={args.num_steps}, dt={dt:.6e}, chi_parallel={args.chi_parallel:.6e}",
        "physical perpendicular diffusivity: exactly 0; all non-Te RHS lanes: exactly 0",
        f"Te range final: [{final['Te_min']:.8e}, {final['Te_max']:.8e}]",
        f"mass initial/final: {diagnostics[0]['perturbation_mass']:.8e} / {final['perturbation_mass']:.8e}",
        f"effective perpendicular diffusivity (latter-half mean): {effective_perp_time_average:.8e}",
        f"effective D_perp / chi_parallel: {effective_ratio_time_average:.8e}",
        f"eta spread initial/final: {diagnostics[0]['eta_spread']:.8e} / {final['eta_spread']:.8e}",
        f"maximum non-Te state change: {max(frozen_error.values(), default=0.0):.3e}",
    ]
    (output_dir / "summary.txt").write_text("\n".join(summary) + "\n", encoding="utf-8")
    print(f"[heat-spot] wrote {history_path}", flush=True)
    return history_path


def _simple_toroidal_geometry(args: argparse.Namespace, *, use_fci: bool = True):
    """Build the analytic circular/pure-toroidal geometry used by Stage 6.

    This deliberately goes through the package's published shifted-torus
    constructor.  ``iota=0`` makes the contravariant field purely toroidal;
    ``alpha=0`` and ``sigma=0`` leave a circular, axisymmetric metric while
    retaining the full local EB/FCI geometry representation.
    """

    from drbx.geometry import build_shifted_torus_geometry as build

    return build(
        tuple(int(value) for value in args.resolution),
        x_min=float(args.simple_x_min),
        x_max=float(args.simple_x_max),
        r0=float(args.simple_major_radius),
        alpha_value=0.0,
        iota=0.0,
        c_phi=float(args.simple_bfield),
        sigma=0.0,
        construct_fci_maps=bool(use_fci),
    )


def _simple_stage6_slab_geometry(args: argparse.Namespace):
    """Return a flat slab with straight ``B`` and true identity FCI maps.

    The radial coordinate is centered on zero and is the only nonperiodic
    direction.  The binormal and parallel axes are periodic.  Each mapped FCI
    leg connects ``(i, j, k)`` to the same ``(i, j)`` point on plane ``k +/- 1``;
    no open-slab placeholder map is reused.
    """

    shape = tuple(int(value) for value in args.resolution)
    nx, ny, nz = shape
    lx = float(args.slab_radial_extent)
    ly = float(args.slab_binormal_extent)
    lz = float(args.slab_parallel_length)
    bmag = float(args.slab_bfield)
    geometry = build_open_slab_geometry(
        shape,
        radial_extent=lx,
        binormal_extent=ly,
        parallel_length=lz,
    )
    # Center x so n0=1+G*x has n0=1 at the reference surface.
    x_grid = replace(
        geometry.grid.x,
        centers=geometry.grid.x.centers - 0.5 * lx,
        faces=geometry.grid.x.faces - 0.5 * lx,
    )
    grid = replace(geometry.grid, x=x_grid)
    i = jnp.arange(nx, dtype=jnp.float64)[:, None, None]
    j = jnp.arange(ny, dtype=jnp.float64)[None, :, None]
    forward_x = jnp.broadcast_to(i, shape)
    forward_y = jnp.broadcast_to(j, shape)
    x = jnp.broadcast_to(grid.x.centers[:, None, None], shape)
    y = jnp.broadcast_to(grid.y.centers[None, :, None], shape)
    z = jnp.broadcast_to(grid.z.centers[None, None, :], shape)
    dz = lz / float(nz)
    zeros_bool = jnp.zeros(shape, dtype=bool)
    maps = FciMaps3D(
        forward_x=forward_x,
        forward_y=forward_y,
        backward_x=forward_x,
        backward_y=forward_y,
        forward_endpoint_x=x,
        forward_endpoint_y=y,
        forward_endpoint_z=z + dz,
        backward_endpoint_x=x,
        backward_endpoint_y=y,
        backward_endpoint_z=z - dz,
        forward_length=jnp.full(shape, dz, dtype=jnp.float64),
        backward_length=jnp.full(shape, dz, dtype=jnp.float64),
        forward_boundary=zeros_bool,
        backward_boundary=zeros_bool,
    )
    bvector = jnp.asarray((0.0, 0.0, bmag), dtype=jnp.float64)
    cell_bfield = replace(
        geometry.cell_bfield,
        B_contra=jnp.broadcast_to(bvector, shape + (3,)),
        Bmag=jnp.full(shape, bmag, dtype=jnp.float64),
    )
    face_bfield = replace(
        geometry.face_bfield,
        x=replace(
            geometry.face_bfield.x,
            B_contra=jnp.broadcast_to(bvector, (nx + 1, ny, nz, 3)),
            Bmag=jnp.full((nx + 1, ny, nz), bmag, dtype=jnp.float64),
        ),
        y=replace(
            geometry.face_bfield.y,
            B_contra=jnp.broadcast_to(bvector, (nx, ny + 1, nz, 3)),
            Bmag=jnp.full((nx, ny + 1, nz), bmag, dtype=jnp.float64),
        ),
        z=replace(
            geometry.face_bfield.z,
            B_contra=jnp.broadcast_to(bvector, (nx, ny, nz + 1, 3)),
            Bmag=jnp.full((nx, ny, nz + 1), bmag, dtype=jnp.float64),
        ),
    )
    return replace(
        geometry,
        grid=grid,
        maps=maps,
        cell_bfield=cell_bfield,
        face_bfield=face_bfield,
    )


def _stage6_wavenumbers(args: argparse.Namespace) -> tuple[float, float, float, float]:
    """Return ``(kx, ky, k_parallel, k_perp^2)`` for the slab mode."""

    kx = float(args.linear_radial_mode) * np.pi / float(args.slab_radial_extent)
    ky = 2.0 * np.pi * float(args.linear_mode_m_theta) / float(args.slab_binormal_extent)
    k_parallel = 2.0 * np.pi * float(args.linear_mode_n_eta) / float(args.slab_parallel_length)
    return kx, ky, k_parallel, kx * kx + ky * ky


def _simple_stage6_state(geometry, args, experiment: str) -> FciDrbEBState:
    """Exact slab equilibrium with a density-only Fourier seed."""

    x = np.asarray(geometry.grid.x.centers, dtype=np.float64)[:, None, None]
    y = np.asarray(geometry.grid.y.centers, dtype=np.float64)[None, :, None]
    z = np.asarray(geometry.grid.z.centers, dtype=np.float64)[None, None, :]
    kx, ky, k_parallel, _ = _stage6_wavenumbers(args)
    phase = ky * y + k_parallel * z
    envelope = np.ones_like(x) if int(args.linear_radial_mode) == 0 else np.sin(
        kx * (x + 0.5 * float(args.slab_radial_extent))
    )
    perturbation = float(args.linear_amplitude) * envelope * np.cos(phase)
    if experiment == "interchange":
        gradient = float(args.interchange_gradient)
        density = 1.0 + gradient * x + perturbation
        Te = np.ones(geometry.shape, dtype=np.float64)
        Ti = np.ones(geometry.shape, dtype=np.float64)
    elif experiment == "drift-wave":
        gradient = float(args.drift_wave_gradient)
        density = 1.0 + gradient * x + perturbation
        Te = np.ones(geometry.shape, dtype=np.float64)
        Ti = np.ones(geometry.shape, dtype=np.float64)
    else:
        raise ValueError(f"unsupported Stage 6 evolution experiment {experiment!r}")
    zeros = np.zeros(geometry.shape, dtype=np.float64)
    ones = np.ones(geometry.shape, dtype=np.float64)
    return FciDrbEBState(
        density=jnp.asarray(np.broadcast_to(density, geometry.shape)),
        phi=jnp.asarray(zeros),
        Te=jnp.asarray(np.broadcast_to(Te, geometry.shape)),
        Ti=jnp.asarray(np.broadcast_to(Ti, geometry.shape)),
        Vi=jnp.asarray(zeros),
        Ve=jnp.asarray(zeros),
        vorticity=jnp.asarray(zeros),
    )


def _stage6_parameters(args, experiment: str) -> FciDrbEBRhsParameters:
    """Return normalized parameters with only the requested Stage 6 physics."""

    alpha = float(args.drift_wave_adiabaticity) if experiment == "drift-wave" else 0.0
    return FciDrbEBRhsParameters(
        n0=1.0,
        Te0=1.0,
        Ti0=1.0,
        cs_0=1.0,
        rhos_s0=1.0,
        tau=1.0,
        # A normalized unit mass ratio keeps this analytic benchmark
        # time-scale manageable while retaining the production collision,
        # pressure, electrostatic, and current terms.
        mi_over_me=1.0,
        rho_star=1.0,
        phi_inversion_regularization=1.0e-9,
        Ve_nu=alpha,
        density_D_perp=0.0,
        density_D_parallel=0.0,
        electron_temperature_chi_parallel=0.0,
        electron_temperature_D_perp=0.0,
        ion_temperature_chi_parallel=0.0,
        ion_temperature_D_perp=0.0,
        Ve_D_perp=0.0,
        Ve_parallel_viscosity=0.0,
        Vi_D_perp=0.0,
        Vi_parallel_viscosity=0.0,
        vorticity_D_perp=0.0,
        vorticity_D_parallel=0.0,
    )


def _compile_stage6_step(
    geometry, args, parameters, *, curvature_equations, parallel_scheme="coordinate",
    equilibrium=None, curvature_scale=1.0, curvature_coefficient_y=None,
):
    """Compile the unmodified production RHS and RK4 step on one slab shard.

    ``equilibrium`` is transported only for the optional diagnostic caller; it
    is never subtracted from the RHS.  Likewise, no evolved field is masked.
    """

    sharded = build_local_fci_geometries(
        geometry,
        (1, 1, 1),
        halo_width=int(args.halo_width),
        periodic_axes=SIMPLE_SLAB_PERIODIC_AXES,
        axis_regular_axes=SIMPLE_SLAB_AXIS_REGULAR_AXES,
    )
    mesh = production.make_shard_mesh((1, 1, 1))
    spatial = production.P("x", "y", "z")
    geometry_spec = production.P("x", "y", "z", None)
    state_spec = FciDrbEBState(
        density=spatial, phi=spatial, Te=spatial, Ti=spatial,
        Vi=spatial, Ve=spatial, vorticity=spatial,
    )
    dt = float(args.final_time) / max(int(args.num_steps), 1)

    if parallel_scheme == "fci" and sharded.map_fields is None:
        raise RuntimeError("Stage 6 FCI evolution requested but analytic maps are absent")
    equilibrium = equilibrium if equilibrium is not None else FciDrbEBState(
        density=jnp.ones(geometry.shape), phi=jnp.zeros(geometry.shape),
        Te=jnp.ones(geometry.shape), Ti=jnp.ones(geometry.shape),
        Vi=jnp.zeros(geometry.shape), Ve=jnp.zeros(geometry.shape),
        vorticity=jnp.zeros(geometry.shape),
    )

    def kernel(current, equilibrium_current, cell_fields, map_fields):
        local_geometry = assemble_local_fci_geometry(sharded, cell_fields, map_fields)
        curvature_scheme = "direct" if curvature_equations else "disabled"
        model = production.build_local_eb_model(
            local_geometry,
            sharded.domain,
            parameters,
            gmres_target_tolerance=1.0e-8,
            gmres_acceptance_tolerance=1.0e-7,
            gmres_max_iterations=int(args.gmres_max_iterations),
            gmres_restart=int(args.gmres_max_iterations),
            gmres_preconditioner="none",
            curvature_scheme=curvature_scheme,
            curvature_scale=float(curvature_scale),
            curvature_equations=tuple(curvature_equations),
            parallel_operator_scheme=str(parallel_scheme),
            fci_parallel_leg_scheme="centered",
            parallel_inflow_closure="central",
            curvature_inflow_closure="central",
            poisson_bracket_scheme="direct",
        )
        if curvature_coefficient_y is not None:
            coefficients = jnp.zeros(
                local_geometry.owned_shape + (3,), dtype=jnp.float64
            ).at[..., 1].set(float(curvature_coefficient_y))
            model = replace(model, curvature_coefficients_owned=coefficients)

        def evaluate(value):
            phi, info = model.reconstruct_phi(value, return_diagnostics=True)
            stage = value.replace(phi=phi)
            derivative = model.project_galerkin_state(
                model.evaluate_stage(stage, phi_owned=phi)
            )
            return derivative, phi, info

        def derivative(value):
            raw, _, info = evaluate(value)
            return raw, info

        k1, info1 = derivative(current)
        k2, info2 = derivative(current.axpy(k1, scale=0.5 * dt))
        k3, info3 = derivative(current.axpy(k2, scale=0.5 * dt))
        k4, info4 = derivative(current.axpy(k3, scale=dt))
        weighted = k1.axpy(k2, scale=2.0).axpy(k3, scale=2.0).axpy(k4, scale=1.0)
        # Phi is a diagnostic inversion, not an independently evolved field.
        final_phi, final_info = model.reconstruct_phi(
            current.axpy(weighted, scale=dt / 6.0), return_diagnostics=True
        )
        next_state = current.axpy(weighted, scale=dt / 6.0).replace(phi=final_phi)
        converged = (
            jnp.all(info1.converged) & jnp.all(info2.converged)
            & jnp.all(info3.converged) & jnp.all(info4.converged)
            & jnp.all(final_info.converged) & jnp.all(info1.phi_is_finite)
            & jnp.all(final_info.phi_is_finite)
        )
        return next_state, converged

    mapped = jax.jit(jax.shard_map(
        kernel,
        mesh=mesh,
        in_specs=(state_spec, state_spec, geometry_spec, geometry_spec),
        out_specs=(state_spec, production.P()),
        check_vma=False,
    ))
    def seed_kernel(current, cell_fields_owned, map_fields_owned):
        local_geometry = assemble_local_fci_geometry(
            sharded, cell_fields_owned, map_fields_owned
        )
        model = production.build_local_eb_model(
            local_geometry, sharded.domain, parameters,
            gmres_target_tolerance=1.0e-8,
            gmres_acceptance_tolerance=1.0e-7,
            gmres_max_iterations=int(args.gmres_max_iterations),
            gmres_restart=int(args.gmres_max_iterations),
            curvature_scheme=("direct" if curvature_equations else "disabled"),
            curvature_scale=float(curvature_scale), curvature_equations=tuple(curvature_equations),
            parallel_operator_scheme=str(parallel_scheme),
        )
        if curvature_coefficient_y is not None:
            coefficients = jnp.zeros(
                local_geometry.owned_shape + (3,), dtype=jnp.float64
            ).at[..., 1].set(float(curvature_coefficient_y))
            model = replace(model, curvature_coefficients_owned=coefficients)
        # Phi is diagnostic; all six material/polarization fields remain the
        # independently supplied physical initial condition.
        phi, info = model.reconstruct_phi(current, return_diagnostics=True)
        return current.replace(phi=phi), info.converged & info.phi_is_finite

    seed = jax.jit(jax.shard_map(
        seed_kernel,
        mesh=mesh,
        in_specs=(state_spec, geometry_spec, geometry_spec),
        out_specs=(state_spec, production.P()),
        check_vma=False,
    ))
    sharding = production.NamedSharding(mesh, spatial)
    geometry_sharding = production.NamedSharding(mesh, geometry_spec)
    cell_fields = jax.device_put(jnp.asarray(sharded.cell_fields, dtype=jnp.float64), geometry_sharding)
    map_host = sharded.map_fields
    if map_host is None:
        map_host = jnp.zeros(geometry.shape + (len(production.FCI_MAP_FIELDS),), dtype=jnp.float64)
    map_fields = jax.device_put(jnp.asarray(map_host, dtype=jnp.float64), geometry_sharding)
    equilibrium_device = equilibrium.map_fields(lambda value: jax.device_put(jnp.asarray(value, dtype=jnp.float64), sharding))
    return mapped, seed, cell_fields, map_fields, equilibrium_device, sharding, sharded


def _build_stage6_modal_reference(
    geometry, args, parameters, *, curvature_equations, parallel_scheme,
    equilibrium, active_fields, curvature_scale=1.0,
    curvature_coefficient_y=None,
):
    """Build an optional semidiscrete tangent diagnostic from production RHS.

    This intentionally circular matrix is useful when diagnosing a disagreement
    with the independent continuous reference, but it is never used to choose
    the initial condition or to determine pass/fail.
    """

    sharded = build_local_fci_geometries(
        geometry, (1, 1, 1), halo_width=int(args.halo_width),
        periodic_axes=SIMPLE_SLAB_PERIODIC_AXES,
        axis_regular_axes=SIMPLE_SLAB_AXIS_REGULAR_AXES,
    )
    mesh = production.make_shard_mesh((1, 1, 1))
    spatial = production.P("x", "y", "z")
    gspec = production.P("x", "y", "z", None)
    sharding = production.NamedSharding(mesh, spatial)
    gsharding = production.NamedSharding(mesh, gspec)
    cell = jax.device_put(jnp.asarray(sharded.cell_fields, dtype=jnp.float64), gsharding)
    map_host = sharded.map_fields
    if map_host is None:
        map_host = jnp.zeros(geometry.shape + (len(production.FCI_MAP_FIELDS),), dtype=jnp.float64)
    maps = jax.device_put(jnp.asarray(map_host, dtype=jnp.float64), gsharding)
    equilibrium_device = equilibrium.map_fields(
        lambda value: jax.device_put(jnp.asarray(value, dtype=jnp.float64), sharding)
    )
    x = np.asarray(geometry.grid.x.centers, dtype=np.float64)[:, None, None]
    y = np.asarray(geometry.grid.y.centers, dtype=np.float64)[None, :, None]
    z = np.asarray(geometry.grid.z.centers, dtype=np.float64)[None, None, :]
    kx, ky, k_parallel, _ = _stage6_wavenumbers(args)
    radial = np.ones_like(x) if int(args.linear_radial_mode) == 0 else np.sin(
        kx * (x + 0.5 * float(args.slab_radial_extent))
    )
    phase = ky * y + k_parallel * z
    quadratures = (jnp.asarray(np.broadcast_to(radial * np.cos(phase), geometry.shape)),
                   jnp.asarray(np.broadcast_to(radial * np.sin(phase), geometry.shape)))
    mode_names = tuple(
        name for name in ("density", "Te", "Ti", "Vi", "Ve", "vorticity")
        if name in active_fields
    )
    basis = tuple((name, quadrature) for name in mode_names for quadrature in quadratures)
    basis_values = jnp.stack(tuple(value for _name, value in basis), axis=0)
    norms = jnp.maximum(jnp.sum(basis_values * basis_values, axis=(1, 2, 3)), 1.0e-30)
    field_names = tuple(FciDrbEBState.__dataclass_fields__.keys())
    active = tuple(name in set(active_fields) for name in field_names)
    mode_offsets = {name: 2 * index for index, name in enumerate(mode_names)}

    def modal_kernel(amplitudes, equilibrium_current, cell_fields, map_fields):
        local_geometry = assemble_local_fci_geometry(sharded, cell_fields, map_fields)
        model = production.build_local_eb_model(
            local_geometry, sharded.domain, parameters,
            gmres_target_tolerance=1.0e-8,
            gmres_acceptance_tolerance=1.0e-7,
            gmres_max_iterations=int(args.gmres_max_iterations),
            gmres_restart=int(args.gmres_max_iterations),
            curvature_scheme=("direct" if curvature_equations else "disabled"),
            curvature_scale=float(curvature_scale),
            curvature_equations=tuple(curvature_equations),
            parallel_operator_scheme=str(parallel_scheme),
            fci_parallel_leg_scheme="centered", parallel_inflow_closure="central",
            curvature_inflow_closure="central", poisson_bracket_scheme="direct",
        )
        if curvature_coefficient_y is not None:
            coefficients = jnp.zeros(
                local_geometry.owned_shape + (3,), dtype=jnp.float64
            ).at[..., 1].set(float(curvature_coefficient_y))
            model = replace(model, curvature_coefficients_owned=coefficients)
        fields = {}
        cursor = 0
        for name, is_active in zip(field_names, active, strict=True):
            reference = getattr(equilibrium_current, name)
            if is_active:
                offset = mode_offsets[name]
                fields[name] = reference + jnp.einsum("m,mxyz->xyz", amplitudes[offset:offset + 2], basis_values[offset:offset + 2])
            else:
                fields[name] = reference
        current = FciDrbEBState(**fields)

        def evaluate(value):
            phi, info = model.reconstruct_phi(value, return_diagnostics=True)
            stage = value.replace(phi=phi)
            return model.project_galerkin_state(model.evaluate_stage(stage, phi_owned=phi)), info

        reference_rhs, reference_info = evaluate(equilibrium_current)
        raw_rhs, info = evaluate(current)
        rhs = raw_rhs.replace(**{
            name: jnp.where(active[index], getattr(raw_rhs, name) - getattr(reference_rhs, name), jnp.zeros_like(getattr(raw_rhs, name)))
            for index, name in enumerate(field_names)
        })
        projected = []
        cursor = 0
        for name in mode_names:
            value = getattr(rhs, name)
            projected.extend((jnp.sum(value * basis_values[cursor]) / norms[cursor],
                              jnp.sum(value * basis_values[cursor + 1]) / norms[cursor + 1]))
            cursor += 2
        return jnp.stack(tuple(projected)), jnp.all(reference_info.converged) & jnp.all(info.converged)

    modal_map = jax.jit(jax.shard_map(
        modal_kernel, mesh=mesh,
        in_specs=(production.P(),
                  FciDrbEBState(density=spatial, phi=spatial, Te=spatial, Ti=spatial, Vi=spatial, Ve=spatial, vorticity=spatial),
                  gspec, gspec),
        out_specs=(production.P(), production.P()), check_vma=False,
    ))
    zero = jnp.zeros((2 * len(mode_names),), dtype=jnp.float64)
    # Differentiate the already-compiled production modal RHS with a small
    # central difference.  This avoids tracing the distributed GMRES through
    # ``jax.jacfwd`` (which can be prohibitively expensive on a workstation),
    # while retaining the production RHS as the source of every matrix column.
    difference_step = 1.0e-6
    columns = []
    reference_solves_converged = True
    for index in range(int(zero.size)):
        direction = np.zeros((int(zero.size),), dtype=np.float64)
        direction[index] = difference_step
        plus_result, plus_ok = modal_map(jnp.asarray(direction), equilibrium_device, cell, maps)
        minus_result, minus_ok = modal_map(jnp.asarray(-direction), equilibrium_device, cell, maps)
        plus = np.asarray(jax.block_until_ready(plus_result))
        minus = np.asarray(jax.block_until_ready(minus_result))
        reference_solves_converged &= bool(np.asarray(jax.block_until_ready(plus_ok))) and bool(np.asarray(jax.block_until_ready(minus_ok)))
        columns.append((plus - minus) / (2.0 * difference_step))
    matrix = jnp.asarray(np.stack(columns, axis=1), dtype=jnp.float64)
    modes = eigenmodes(matrix)
    return matrix, modes, basis_values, mode_names, modal_map, equilibrium_device, cell, maps, sharding, reference_solves_converged, difference_step


def _write_stage6_result(output_dir: Path, metadata: dict[str, object], arrays: dict[str, np.ndarray]) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    history = output_dir / "history.npz"
    np.savez_compressed(history, **arrays)
    metadata = dict(metadata)
    metadata["history"] = str(history)
    with (output_dir / "metadata.json").open("w", encoding="utf-8") as stream:
        json.dump(metadata, stream, indent=2, sort_keys=True)
        stream.write("\n")
    return history


def _modal_history(frames, equilibrium, geometry, args) -> np.ndarray:
    """Project production density perturbations onto the seeded Fourier mode."""

    theta = np.asarray(geometry.grid.y.centers, dtype=np.float64)[None, :, None]
    eta = np.asarray(geometry.grid.z.centers, dtype=np.float64)[None, None, :]
    phase = float(args.linear_mode_m_theta) * theta + float(args.linear_mode_n_eta) * eta
    radial = np.sin(np.pi * (np.asarray(geometry.grid.x.centers)[:, None, None] - args.simple_x_min) / (args.simple_x_max - args.simple_x_min)) ** 2
    basis = radial * np.exp(-1j * phase)
    denominator = max(float(np.sum(radial * radial)), np.finfo(float).tiny)
    eq = np.asarray(equilibrium.density, dtype=np.float64)
    return np.asarray([
        np.sum((np.asarray(frame.density, dtype=np.float64) - eq) * basis) / denominator
        for frame in frames
    ], dtype=np.complex128)


def _fit_modal_rate(times: np.ndarray, mode: np.ndarray) -> tuple[float, float]:
    """Fit growth and angular frequency from a complex modal history."""

    times = np.asarray(times, dtype=np.float64)
    mode = np.asarray(mode, dtype=np.complex128)
    keep = np.isfinite(mode.real) & np.isfinite(mode.imag) & (np.abs(mode) > 1.0e-14)
    if np.count_nonzero(keep) < 3:
        return float("nan"), float("nan")
    t = times[keep]
    z = mode[keep]
    growth = float(np.polyfit(t, np.log(np.abs(z)), 1)[0])
    frequency = float(np.polyfit(t, np.unwrap(np.angle(z)), 1)[0])
    return growth, frequency


def _stage6_quadrature_basis(geometry, args) -> tuple[np.ndarray, np.ndarray]:
    """Real quadratures for ``Re[A exp(i(kx x + ky y + kpar z))]``."""

    x = np.asarray(geometry.grid.x.centers, dtype=np.float64)[:, None, None]
    y = np.asarray(geometry.grid.y.centers, dtype=np.float64)[None, :, None]
    z = np.asarray(geometry.grid.z.centers, dtype=np.float64)[None, None, :]
    kx, ky, k_parallel, _ = _stage6_wavenumbers(args)
    envelope = np.ones_like(x) if int(args.linear_radial_mode) == 0 else np.sin(
        kx * (x + 0.5 * float(args.slab_radial_extent))
    )
    phase = ky * y + k_parallel * z
    return (
        np.broadcast_to(envelope * np.cos(phase), geometry.shape),
        np.broadcast_to(envelope * np.sin(phase), geometry.shape),
    )


def _stage6_basis_values(geometry, args, mode_names) -> np.ndarray:
    cosine, sine = _stage6_quadrature_basis(geometry, args)
    return np.stack(
        tuple(value for _name in mode_names for value in (cosine, sine)), axis=0
    )


def _state_from_analytic_eigenmode(
    equilibrium,
    geometry,
    args,
    mode_names,
    eigenvector,
):
    """Initialize the real part of an independently derived complex mode."""

    fields = {
        name: np.asarray(value, dtype=np.float64).copy()
        for name, value in equilibrium.field_items()
    }
    vector = np.asarray(eigenvector, dtype=np.complex128)
    scale = float(args.linear_amplitude) / max(
        float(np.max(np.abs(vector))), np.finfo(float).tiny
    )
    vector = scale * vector
    cosine, sine = _stage6_quadrature_basis(geometry, args)
    for name, amplitude in zip(mode_names, vector, strict=True):
        fields[name] += amplitude.real * cosine - amplitude.imag * sine
    fields["phi"] = np.zeros_like(fields["phi"])
    return FciDrbEBState(**fields), vector


def _complex_ratio_diagnostics(
    modal_history: np.ndarray,
    mode_names,
    reference_vector: np.ndarray,
    fit_count: int,
) -> tuple[dict[str, dict[str, float]], float]:
    """Compare measured field ratios with the independent eigenvector."""

    complex_fields = {
        name: modal_history[:, 2 * index] - 1j * modal_history[:, 2 * index + 1]
        for index, name in enumerate(mode_names)
    }
    reference = np.asarray(reference_vector, dtype=np.complex128)
    pivot = int(np.argmax(np.abs(reference)))
    pivot_name = mode_names[pivot]
    sample_index = max(0, int(fit_count) - 1)
    measured_pivot = complex_fields[pivot_name][sample_index]
    reference_pivot = reference[pivot]
    diagnostics: dict[str, dict[str, float]] = {}
    errors = []
    for index, name in enumerate(mode_names):
        measured_ratio = complex_fields[name][sample_index] / measured_pivot
        reference_ratio = reference[index] / reference_pivot
        error = abs(measured_ratio - reference_ratio) / max(
            abs(reference_ratio), 1.0e-12
        )
        diagnostics[name] = {
            "measured_real": float(measured_ratio.real),
            "measured_imag": float(measured_ratio.imag),
            "reference_real": float(reference_ratio.real),
            "reference_imag": float(reference_ratio.imag),
            "relative_error": float(error),
        }
        if index != pivot:
            errors.append(float(error))
    return diagnostics, max(errors, default=0.0)


def _state_from_modal_amplitudes(equilibrium, basis_values, amplitudes, mode_names):
    """Materialize a real physical perturbation from a modal eigenvector."""

    fields = {name: np.asarray(value, dtype=np.float64).copy() for name, value in equilibrium.field_items()}
    basis = np.asarray(basis_values, dtype=np.float64)
    amplitudes = np.asarray(amplitudes, dtype=np.float64)
    for index, name in enumerate(mode_names):
        offset = 2 * index
        fields[name] += amplitudes[offset] * basis[offset] + amplitudes[offset + 1] * basis[offset + 1]
    fields["phi"] = np.zeros_like(fields["phi"])
    return FciDrbEBState(**fields)


def _project_stage6_modal_history(frames, equilibrium, basis_values, mode_names):
    basis = np.asarray(basis_values, dtype=np.float64)
    norms = np.maximum(np.sum(basis * basis, axis=(1, 2, 3)), 1.0e-30)
    values = []
    for frame in frames:
        coefficients = []
        for index, name in enumerate(mode_names):
            perturbation = np.asarray(getattr(frame, name), dtype=np.float64) - np.asarray(getattr(equilibrium, name), dtype=np.float64)
            offset = 2 * index
            coefficients.extend((np.sum(perturbation * basis[offset]) / norms[offset], np.sum(perturbation * basis[offset + 1]) / norms[offset + 1]))
        values.append(coefficients)
    return np.asarray(values, dtype=np.float64)


def run_polarization(args: argparse.Namespace) -> Path:
    """Run a production polarization inversion round trip on simple geometry."""

    geometry = _simple_toroidal_geometry(args, use_fci=False)
    sharded = build_local_fci_geometries(
        geometry, (1, 1, 1), halo_width=int(args.halo_width),
        periodic_axes=SIMPLE_TORUS_PERIODIC_AXES,
        axis_regular_axes=SIMPLE_TORUS_AXIS_REGULAR_AXES,
    )
    mesh = production.make_shard_mesh((1, 1, 1))
    spatial, gspec = production.P("x", "y", "z"), production.P("x", "y", "z", None)
    sharding, gsharding = production.NamedSharding(mesh, spatial), production.NamedSharding(mesh, gspec)
    cell_fields = jax.device_put(jnp.asarray(sharded.cell_fields), gsharding)
    params = _stage6_parameters(args, "polarization")

    def kernel(phi, ti, omega, cell):
        local = assemble_local_fci_geometry(sharded, cell)
        model = production.build_local_eb_model(
            local, sharded.domain, params, gmres_target_tolerance=1.0e-8,
            gmres_acceptance_tolerance=1.0e-7, gmres_max_iterations=int(args.gmres_max_iterations),
            gmres_restart=int(args.gmres_max_iterations), curvature_scheme="direct",
            curvature_equations=(), parallel_operator_scheme="coordinate",
        )
        zeros = jnp.zeros_like(phi)
        probe = FciDrbEBState(zeros, phi, jnp.ones_like(phi), ti, zeros, zeros, zeros)
        state = probe.replace(vorticity=omega)
        solved, info = model.reconstruct_phi(state, return_diagnostics=True)
        residual = model.polarization_residual(state, phi_owned=solved)
        return solved, residual, info.converged & info.phi_is_finite

    mapped = jax.jit(jax.shard_map(kernel, mesh=mesh, in_specs=(spatial, spatial, spatial, gspec), out_specs=(spatial, spatial, production.P()), check_vma=False))
    x = np.asarray(geometry.grid.x.centers)[:, None, None]
    y = np.asarray(geometry.grid.y.centers)[None, :, None]
    z = np.asarray(geometry.grid.z.centers)[None, None, :]
    phi = jnp.asarray(np.broadcast_to(float(args.linear_amplitude) * np.sin(np.pi * (x - args.simple_x_min) / (args.simple_x_max - args.simple_x_min)) ** 2 * np.cos(args.linear_mode_m_theta * y + args.linear_mode_n_eta * z), geometry.shape))
    c = np.pi * (x - args.simple_x_min) / (args.simple_x_max - args.simple_x_min)
    radial = np.sin(c) ** 2
    radial_x = (2.0 * np.pi / (args.simple_x_max - args.simple_x_min)) * np.sin(c) * np.cos(c)
    radial_xx = (2.0 * np.pi**2 / (args.simple_x_max - args.simple_x_min) ** 2) * np.cos(2.0 * c)
    phase = args.linear_mode_m_theta * y + args.linear_mode_n_eta * z
    R = args.simple_major_radius + x * np.cos(y)
    A = R * x
    Ax = R + x * np.cos(y)
    m = float(args.linear_mode_m_theta)
    continuous_lperp_phi = float(args.linear_amplitude) * (((Ax * radial_x + A * radial_xx) * np.cos(phase)) + ((-np.sin(y)) * (-m * radial * np.sin(phase)) + (R / x) * (-m * m * radial * np.cos(phase)))) / A
    omega = jnp.asarray(np.broadcast_to(continuous_lperp_phi, geometry.shape))
    ti = jnp.ones(geometry.shape, dtype=jnp.float64)
    solved, residual, converged = mapped(jax.device_put(phi, sharding), jax.device_put(ti, sharding), jax.device_put(omega, sharding), cell_fields)
    solved, residual = (np.asarray(jax.block_until_ready(value)) for value in (solved, residual))
    phi_scale = max(float(np.max(np.abs(np.asarray(phi)))), np.finfo(float).tiny)
    phi_reconstruction_error = float(np.max(np.abs(solved - np.asarray(phi))) / phi_scale)
    residual_abs_error = float(np.max(np.abs(residual)))
    omega_scale = max(float(np.max(np.abs(np.asarray(omega)))), np.finfo(float).tiny)
    residual_error = residual_abs_error / omega_scale
    passed = bool(np.asarray(jax.block_until_ready(converged))) and (
        phi_reconstruction_error <= float(args.polarization_tolerance)
        and residual_error <= float(args.polarization_residual_tolerance)
    )
    output = args.output_dir.resolve() / "stage6_polarization"
    history = _write_stage6_result(output, {"experiment": "stage6-polarization", "passed": passed, "max_abs_residual": residual_abs_error, "residual_error": residual_error, "residual_error_definition": "max(abs(polarization_residual))/max(abs(analytic_omega))", "phi_reconstruction_error": phi_reconstruction_error, "phi_error_definition": "max(abs(phi_reconstructed-phi_input))/max(abs(phi_input))", "phi_tolerance": float(args.polarization_tolerance), "residual_tolerance": float(args.polarization_residual_tolerance), "geometry": "analytic circular pure-toroidal shifted torus", "continuous_operator": "[d_x(R x f_x)+d_theta((R/x) f_theta)]/(R x)", "solver": "LocalFciDrbEBRhs.reconstruct_phi"}, {"phi_input": np.asarray(phi), "phi_reconstructed": solved, "analytic_omega": np.asarray(omega), "polarization_residual": residual})
    print(f"[stage6-polarization] passed={passed} phi_reconstruction_error={phi_reconstruction_error:.3e} residual_error={residual_error:.3e} wrote {history}", flush=True)
    return history


def run_stage6_evolution(args: argparse.Namespace, experiment: str) -> Path:
    """Run a literature-style independent linear-physics benchmark."""

    geometry = _simple_stage6_slab_geometry(args)
    params = _stage6_parameters(args, experiment)
    kx, ky, k_parallel, kperp2 = _stage6_wavenumbers(args)
    gradient = float(
        args.interchange_gradient
        if experiment == "interchange"
        else args.drift_wave_gradient
    )
    x = np.asarray(geometry.grid.x.centers, dtype=np.float64)[:, None, None]
    zeros = jnp.zeros(geometry.shape, dtype=jnp.float64)
    ones = jnp.ones(geometry.shape, dtype=jnp.float64)
    equilibrium = FciDrbEBState(
        density=jnp.asarray(np.broadcast_to(1.0 + gradient * x, geometry.shape)),
        phi=zeros,
        Te=ones,
        Ti=ones,
        Vi=zeros,
        Ve=zeros,
        vorticity=zeros,
    )
    if float(np.min(np.asarray(equilibrium.density))) <= 0.0:
        raise ValueError("Stage 6 slab equilibrium n0=1+G*x must stay positive")

    bmag = float(args.slab_bfield)
    rho_star = float(params.rho_star)
    tau = float(params.tau)
    curvature_scale = 1.0
    if experiment == "interchange":
        if abs(k_parallel) > 1.0e-14:
            raise ValueError("the interchange benchmark requires k_parallel=0")
        curvature_equations = ("vorticity",)
        parallel_scheme = "coordinate"
        analytic_gravity = float(args.interchange_gravity)
        kappa = -gradient / (rho_star * bmag)
        curvature_coefficient_y = -analytic_gravity / (
            2.0 * bmag * (1.0 + tau)
        )
        analytic_matrix_phi_n = np.asarray(
            interchange_operator(ky, kperp2, analytic_gravity, kappa),
            dtype=np.complex128,
        )
        analytic_modes = eigenmodes(jnp.asarray(analytic_matrix_phi_n))
        phi_n_vector = np.asarray(analytic_modes.eigenvectors[:, 0])
        # Convert independent (phi,n) eigenvector to production evolved
        # variables (n,omega).  Production solves -L_perp(phi) on its inverse
        # path, so a constant-Ti Fourier mode obeys omega=-kperp2*phi.
        reference_vector = np.asarray(
            (phi_n_vector[1], -kperp2 * phi_n_vector[0]),
            dtype=np.complex128,
        )
        mode_names = ("density", "vorticity")
        analytic_matrix = analytic_matrix_phi_n
        analytic_parameters = {
            "G": gradient,
            "kappa": kappa,
            "g": analytic_gravity,
            "curvature_coefficient_y": curvature_coefficient_y,
            "identity": "g=-2*B*(1+tau)*c_y; kappa=-G/(rho_star*B)",
        }
    else:
        from drbx.linear import full_drb_resistive_drift_wave_operator

        curvature_equations = ()
        parallel_scheme = "fci"
        curvature_coefficient_y = None
        analytic_matrix = np.asarray(
            full_drb_resistive_drift_wave_operator(
                ky,
                kperp2,
                k_parallel,
                rho_star,
                bmag,
                gradient,
                tau,
                float(params.mi_over_me),
                float(params.Ve_nu),
            ),
            dtype=np.complex128,
        )
        analytic_modes = eigenmodes(jnp.asarray(analytic_matrix))
        reference_vector = np.asarray(analytic_modes.eigenvectors[:, 0])
        mode_names = ("density", "Te", "Ti", "Vi", "Ve", "vorticity")
        analytic_parameters = {
            "G": gradient,
            "rho_star": rho_star,
            "B0": bmag,
            "tau": tau,
            "mi_over_me": float(params.mi_over_me),
            "Ve_nu": float(params.Ve_nu),
        }

    target_growth = float(np.asarray(analytic_modes.dominant_growth_rate))
    target_frequency = float(np.asarray(analytic_modes.dominant_frequency))
    initial, scaled_reference_vector = _state_from_analytic_eigenmode(
        equilibrium, geometry, args, mode_names, reference_vector
    )
    modal_basis = _stage6_basis_values(geometry, args, mode_names)

    semidiscrete_matrix = None
    semidiscrete_modes = None
    semidiscrete_solves_converged = None
    modal_difference_step = None
    if bool(args.stage6_semidiscrete_diagnostic):
        (
            semidiscrete_matrix,
            semidiscrete_modes,
            _diagnostic_basis,
            _diagnostic_names,
            _modal_map,
            _modal_eq,
            _modal_cell,
            _modal_maps,
            _modal_sharding,
            semidiscrete_solves_converged,
            modal_difference_step,
        ) = _build_stage6_modal_reference(
            geometry,
            args,
            params,
            curvature_equations=curvature_equations,
            parallel_scheme=parallel_scheme,
            equilibrium=equilibrium,
            active_fields=mode_names,
            curvature_scale=curvature_scale,
            curvature_coefficient_y=curvature_coefficient_y,
        )

    advance, seed, cell_fields, map_fields, equilibrium_device, state_sharding, sharded = _compile_stage6_step(
        geometry, args, params, curvature_equations=curvature_equations,
        parallel_scheme=parallel_scheme, equilibrium=equilibrium,
        curvature_scale=curvature_scale,
        curvature_coefficient_y=curvature_coefficient_y,
    )
    # Verify the claimed analytic background is stationary under the actual
    # unmodified RHS.  This is a diagnostic evolution, never a subtraction.
    equilibrium_state = equilibrium.map_fields(
        lambda value: jax.device_put(value, state_sharding)
    )
    equilibrium_state, equilibrium_seed_ok = seed(
        equilibrium_state, cell_fields, map_fields
    )
    equilibrium_next, equilibrium_step_ok = advance(
        equilibrium_state, equilibrium_device, cell_fields, map_fields
    )
    dt = float(args.final_time) / int(args.num_steps)
    equilibrium_rhs_linf = max(
        float(
            np.max(
                np.abs(
                    np.asarray(jax.block_until_ready(getattr(equilibrium_next, name)))
                    - np.asarray(jax.block_until_ready(getattr(equilibrium_state, name)))
                )
            )
            / dt
        )
        for name in ("density", "Te", "Ti", "Vi", "Ve", "vorticity")
    )
    equilibrium_stationary = bool(
        np.asarray(jax.block_until_ready(equilibrium_seed_ok))
    ) and bool(np.asarray(jax.block_until_ready(equilibrium_step_ok))) and (
        equilibrium_rhs_linf <= float(args.equilibrium_rhs_tolerance)
    )

    state = initial.map_fields(lambda value: jax.device_put(value, state_sharding))
    state, seed_converged = seed(state, cell_fields, map_fields)
    converged_all = bool(np.asarray(jax.block_until_ready(seed_converged)))
    initial = FciDrbEBState(**{
        name: np.asarray(jax.block_until_ready(value))
        for name, value in state.field_items()
    })
    frames = [initial]
    times = [0.0]
    save_every = max(1, int(args.save_every))
    for step in range(1, int(args.num_steps) + 1):
        state, converged = advance(state, equilibrium_device, cell_fields, map_fields)
        converged_all &= bool(np.asarray(jax.block_until_ready(converged)))
        if step % save_every == 0 or step == int(args.num_steps):
            host = FciDrbEBState(**{
                name: np.asarray(jax.block_until_ready(value))
                for name, value in state.field_items()
            })
            frames.append(host)
            times.append(step * float(args.final_time) / int(args.num_steps))
    values = np.asarray([np.max(np.abs(np.asarray(frame.density) - np.asarray(initial.density))) for frame in frames])
    evolved_fields = ("density", "Te", "Ti", "Vi", "Ve", "vorticity")
    active_fields_finite = all(
        np.all(np.isfinite(np.asarray(getattr(frame, name))))
        for frame in frames
        for name in evolved_fields
    )
    times_array = np.asarray(times, dtype=np.float64)
    equilibrium_host = FciDrbEBState(**{name: np.asarray(getattr(equilibrium, name)) for name in FciDrbEBState.__dataclass_fields__})
    mode_history = _project_stage6_modal_history(frames, equilibrium_host, modal_basis, mode_names)
    inactive_names = (
        ("Te", "Ti", "Vi", "Ve") if experiment == "interchange" else ()
    )
    frozen_field_max_change = {
        name: max(float(np.max(np.abs(np.asarray(frame.__getattribute__(name)) - np.asarray(getattr(equilibrium_host, name))))) for frame in frames)
        for name in inactive_names
    }
    frozen_fields_ok = max(frozen_field_max_change.values(), default=0.0) <= float(args.frozen_field_tolerance)
    complex_mode = mode_history[:, 0] - 1j * mode_history[:, 1]
    # Fit a declared early linear window; the initial condition comes from the
    # independent analytic operator, not from this measured trajectory.
    fit_count = min(
        times_array.size,
        max(3, int(np.ceil(float(args.linear_fit_fraction) * times_array.size))),
    )
    measured_growth, measured_frequency = _fit_modal_rate(
        times_array[:fit_count], complex_mode[:fit_count]
    )
    growth_error = abs(measured_growth - target_growth) if np.isfinite(measured_growth) else float("inf")
    # Signed frequency is required: it catches a reversed parallel derivative
    # or diamagnetic propagation direction.
    frequency_error = abs(measured_frequency - target_frequency) if np.isfinite(measured_frequency) else float("inf")
    growth_scale = max(
        abs(target_growth), float(args.growth_absolute_scale),
    )
    frequency_scale = max(abs(target_frequency), float(args.frequency_absolute_scale))
    rate_match = growth_error <= float(args.growth_tolerance) * growth_scale
    frequency_match = frequency_error <= float(args.frequency_tolerance) * frequency_scale
    ratio_diagnostics, eigenfunction_ratio_error = _complex_ratio_diagnostics(
        mode_history, mode_names, scaled_reference_vector, fit_count
    )
    eigenfunction_match = eigenfunction_ratio_error <= float(
        args.eigenfunction_tolerance
    )
    fit_duration = float(times_array[fit_count - 1] - times_array[0])
    fit_growth = abs(target_growth) * fit_duration
    fit_phase = abs(target_frequency) * fit_duration
    fit_window_resolved = (
        fit_growth >= float(args.minimum_fit_growth)
        and (
            abs(target_frequency) <= float(args.frequency_absolute_scale)
            or fit_phase >= float(args.minimum_fit_phase)
        )
    )
    passed = bool(
        converged_all
        and equilibrium_stationary
        and active_fields_finite
        and np.all(np.isfinite(values))
        and frozen_fields_ok
        and rate_match
        and frequency_match
        and eigenfunction_match
        and fit_window_resolved
    )
    complex_matrix = np.asarray(analytic_matrix)
    output = args.output_dir.resolve() / f"stage6_{experiment.replace('-', '_')}"
    arrays = {
        "times": np.asarray(times, dtype=np.float64),
        "density": np.asarray([np.asarray(frame.density) for frame in frames]),
        "phi": np.asarray([np.asarray(frame.phi) for frame in frames]),
        "Te": np.asarray([np.asarray(frame.Te) for frame in frames]),
        "Ti": np.asarray([np.asarray(frame.Ti) for frame in frames]),
        "Vi": np.asarray([np.asarray(frame.Vi) for frame in frames]),
        "Ve": np.asarray([np.asarray(frame.Ve) for frame in frames]),
        "vorticity": np.asarray([np.asarray(frame.vorticity) for frame in frames]),
        "density_change_linf": values,
        "modal_amplitude": mode_history,
        "analytic_eigenvector_real": scaled_reference_vector.real,
        "analytic_eigenvector_imag": scaled_reference_vector.imag,
    }
    metadata = {
        "experiment": f"stage6-{experiment}",
        "passed": passed,
        "solver": "LocalFciDrbEBRhs + production build_local_eb_model + RK4",
        "geometry": "flat Cartesian slab; x bounded, y/z periodic; straight B",
        "identity_fci_maps": True,
        "curvature_equations": list(curvature_equations),
        "curvature_scale": curvature_scale,
        "parallel_operator_scheme": parallel_scheme,
        "electron_collision_coefficient_Ve_nu": float(args.drift_wave_adiabaticity if experiment == "drift-wave" else 0.0),
        "active_physics": "curvature E×B interchange" if experiment == "interchange" else "parallel electron pressure/electrostatic/collision/current response",
        "reference_kind": (
            "independent continuous analytic interchange dispersion relation"
            if experiment == "interchange"
            else "independent continuous full six-field DRB resistive-drift-wave operator"
        ),
        "reference_uses_production_rhs": False,
        "initialization_kind": "independent analytic eigenvector",
        "equilibrium_rhs_subtracted": False,
        "post_rhs_active_field_mask": False,
        "all_six_evolved_fields_advanced": True,
        "analytic_parameters": analytic_parameters,
        "wavenumbers": {"kx": kx, "ky": ky, "k_parallel": k_parallel, "kperp2": kperp2},
        "theory_operator": {"real": complex_matrix.real.tolist(), "imag": complex_matrix.imag.tolist()},
        "theory_dominant_growth": target_growth,
        "theory_dominant_frequency": target_frequency,
        "measured_modal_growth": measured_growth,
        "measured_modal_frequency": measured_frequency,
        "linear_fit_frame_count": int(fit_count),
        "linear_fit_final_time": float(times_array[fit_count - 1]),
        "linear_fit_window_kind": (
            "declared early linear window initialized from the independent "
            "continuous eigenmode"
        ),
        "growth_abs_error": growth_error,
        "frequency_abs_error": frequency_error,
        "growth_match": bool(rate_match),
        "frequency_match": bool(frequency_match),
        "signed_frequency_comparison": True,
        "eigenfunction_ratio_diagnostics": ratio_diagnostics,
        "eigenfunction_ratio_max_error": eigenfunction_ratio_error,
        "eigenfunction_match": bool(eigenfunction_match),
        "eigenfunction_tolerance_relative": float(args.eigenfunction_tolerance),
        "fit_growth_exponent": fit_growth,
        "fit_phase_advance": fit_phase,
        "fit_window_resolved": bool(fit_window_resolved),
        "minimum_fit_growth": float(args.minimum_fit_growth),
        "minimum_fit_phase": float(args.minimum_fit_phase),
        "equilibrium_rhs_linf": equilibrium_rhs_linf,
        "equilibrium_rhs_tolerance": float(args.equilibrium_rhs_tolerance),
        "equilibrium_stationary": bool(equilibrium_stationary),
        "frozen_field_max_change": frozen_field_max_change,
        "frozen_fields_ok": bool(frozen_fields_ok),
        "frozen_field_tolerance": float(args.frozen_field_tolerance),
        "growth_tolerance_relative": float(args.growth_tolerance),
        "frequency_tolerance_relative": float(args.frequency_tolerance),
        "all_phi_solves_converged": bool(converged_all),
        "active_fields_finite": bool(active_fields_finite),
        "semidiscrete_diagnostic_enabled": bool(args.stage6_semidiscrete_diagnostic),
        "semidiscrete_diagnostic_phi_solves_converged": semidiscrete_solves_converged,
        "semidiscrete_diagnostic_difference_step": modal_difference_step,
        "semidiscrete_diagnostic_operator": (
            None if semidiscrete_matrix is None else {
                "real": np.asarray(semidiscrete_matrix).real.tolist(),
                "imag": np.asarray(semidiscrete_matrix).imag.tolist(),
            }
        ),
        "semidiscrete_diagnostic_dominant_growth": (
            None if semidiscrete_modes is None else float(np.asarray(semidiscrete_modes.dominant_growth_rate))
        ),
        "semidiscrete_diagnostic_dominant_frequency": (
            None if semidiscrete_modes is None else float(np.asarray(semidiscrete_modes.dominant_frequency))
        ),
        "resolution": list(map(int, args.resolution)),
        "time_integration": {"dt": float(args.final_time) / int(args.num_steps), "num_steps": int(args.num_steps), "final_time": float(args.final_time)},
    }
    history = _write_stage6_result(output, metadata, arrays)
    print(
        f"[stage6-{experiment}] passed={passed} converged={converged_all} "
        f"measured=(gamma={measured_growth:.3e},omega={measured_frequency:.3e}) "
        f"analytic=(gamma={target_growth:.3e},omega={target_frequency:.3e}) "
        f"wrote {history}",
        flush=True,
    )
    return history


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--experiment",
        choices=("heat-spot", "polarization", "interchange", "drift-wave", "resistive-drift-wave"),
        default="heat-spot",
        help=(
            "sanity experiment: heat-spot preserves the existing HSX run; "
            "polarization uses an analytic torus; interchange/drift-wave use "
            "independent analytic references on a flat slab"
        ),
    )
    parser.add_argument(
        "--initial-condition",
        choices=("heat-spot", "flux-function"),
        default="heat-spot",
        help=(
            "heat-spot performs the qualitative mapping test; flux-function "
            "performs the literature numerical-perpendicular-diffusion test"
        ),
    )
    parser.add_argument("--resolution", type=_three_ints, default=PRODUCTION_GEOMETRY_DEFAULTS["resolution"])
    parser.add_argument("--fit-sample-shape", type=_three_ints, default=PRODUCTION_GEOMETRY_DEFAULTS["fit_sample_shape"])
    parser.add_argument("--metric-mesh-shape", type=_three_ints, default=PRODUCTION_GEOMETRY_DEFAULTS["metric_mesh_shape"])
    parser.add_argument("--makegrid", type=Path, default=production.DEFAULT_MAKEGRID)
    parser.add_argument(
        "--makegrid-currents",
        type=lambda value: tuple(float(part) for part in value.split(",")),
        default=QHS_MAKEGRID_CURRENTS,
        help=(
            "comma-separated MAKEGRID group multipliers; defaults to the "
            "1 T HSX QHS setting (10722 for MainCoil1-6, zero for AuxCoil1-6)"
        ),
    )
    parser.add_argument("--vessel", type=Path, default=production.DEFAULT_VESSEL)
    parser.add_argument("--metric-cache-dir", type=Path, default=production.DEFAULT_METRIC_CACHE_DIR)
    parser.add_argument("--rebuild-metric-cache", action="store_true")
    parser.add_argument("--radial-degree", type=int, default=PRODUCTION_GEOMETRY_DEFAULTS["radial_degree"])
    parser.add_argument("--vertical-degree", type=int, default=PRODUCTION_GEOMETRY_DEFAULTS["vertical_degree"])
    parser.add_argument("--toroidal-modes", type=int, default=PRODUCTION_GEOMETRY_DEFAULTS["toroidal_modes"])
    parser.add_argument("--metric-spline-degree", type=int, default=1)
    parser.add_argument("--mmpde-iterations", type=int, default=0)
    parser.add_argument("--metric-radial-degree", type=int, default=PRODUCTION_GEOMETRY_DEFAULTS["metric_radial_degree"])
    parser.add_argument("--metric-poloidal-modes", type=int, default=PRODUCTION_GEOMETRY_DEFAULTS["metric_poloidal_modes"])
    parser.add_argument("--metric-toroidal-modes", type=int, default=PRODUCTION_GEOMETRY_DEFAULTS["metric_toroidal_modes"])
    parser.add_argument("--eta-projection-iterations", type=int, default=PRODUCTION_GEOMETRY_DEFAULTS["eta_projection_iterations"])
    parser.add_argument("--axis-core-radius", type=float, default=PRODUCTION_GEOMETRY_DEFAULTS["axis_core_radius"])
    parser.add_argument("--fci-trace-substeps", type=int, default=PRODUCTION_GEOMETRY_DEFAULTS["fci_trace_substeps"])
    parser.add_argument("--halo-width", type=int, default=2)
    parser.add_argument("--no-rlp", action="store_true", help="Disable angular owner agglomeration for the Te-only heat control; retain polar axis topology.")
    parser.add_argument(
        "--conduction-reconstruction",
        choices=("legacy", "aggregate-quadratic"),
        default="legacy",
        help=(
            "Te-only heat-spot conduction lane; legacy preserves the mapped "
            "FCI sampler, while aggregate-quadratic opts into the experimental "
            "RLP owner-cell quadratic evaluator (degree 2, 32 donors with "
            "adaptive expansion to 96)"
        ),
    )
    # This resolves a parallel length sqrt(2 chi t) ~= 0.17 in the default
    # run, while dt stays deliberately conservative for the shortest FCI leg.
    parser.add_argument("--chi-parallel", type=float, default=1.0e-1)
    parser.add_argument("--final-time", type=float, default=1.5e-1)
    parser.add_argument("--num-steps", type=int, default=225)
    parser.add_argument("--save-every", type=int, default=15)
    parser.add_argument("--amplitude", type=float, default=0.1)
    parser.add_argument("--center-u", type=float, default=0.35)
    parser.add_argument("--center-v", type=float, default=3.141592653589793)
    parser.add_argument("--center-eta", type=float, default=3.141592653589793)
    parser.add_argument("--width-u", type=float, default=0.08)
    parser.add_argument("--width-v", type=float, default=0.23)
    # Broad compact parallel envelope, analogous to the original FCI test's
    # sin^6 parallel profile.  A narrow 3-D pulse remains a CLI option.
    parser.add_argument("--width-eta", type=float, default=3.141592653589793)
    parser.add_argument("--flux-center", type=float, default=0.0)
    parser.add_argument("--flux-width", type=float, default=0.1)
    parser.add_argument("--trace-seed-min", type=float, default=0.04)
    parser.add_argument("--trace-seed-max", type=float, default=0.76)
    parser.add_argument("--trace-seed-count", type=int, default=25)
    parser.add_argument("--trace-turns", type=int, default=160)
    parser.add_argument("--simple-x-min", type=float, default=0.15)
    parser.add_argument("--simple-x-max", type=float, default=1.0)
    parser.add_argument("--simple-major-radius", type=float, default=3.0)
    parser.add_argument("--simple-bfield", type=float, default=3.0)
    parser.add_argument("--slab-radial-extent", type=float, default=1.0)
    parser.add_argument("--slab-binormal-extent", type=float, default=2.0 * np.pi)
    parser.add_argument("--slab-parallel-length", type=float, default=2.0 * np.pi)
    parser.add_argument("--slab-bfield", type=float, default=1.0)
    parser.add_argument("--linear-amplitude", type=float, default=1.0e-4)
    parser.add_argument(
        "--linear-radial-mode",
        type=int,
        default=1,
        help=(
            "radial sine mode number; one satisfies the production phi "
            "Dirichlet wall condition (zero requests a local kx=0 diagnostic)"
        ),
    )
    parser.add_argument("--linear-mode-m-theta", type=int, default=1)
    parser.add_argument("--linear-mode-n-eta", type=int, default=1)
    parser.add_argument("--interchange-gradient", type=float, default=0.1)
    parser.add_argument(
        "--interchange-gravity",
        type=float,
        default=-100.0,
        help="signed analytic g; default pairs with G>0 to give bad curvature",
    )
    parser.add_argument("--drift-wave-gradient", type=float, default=0.1)
    parser.add_argument(
        "--drift-wave-collisionality",
        "--drift-wave-adiabaticity",
        dest="drift_wave_adiabaticity",
        type=float,
        default=1.0,
        help=(
            "production electron collision coefficient Ve_nu; the legacy "
            "adiabaticity spelling is accepted, but this is not the "
            "algebraic Hasegawa-Wakatani alpha"
        ),
    )
    parser.add_argument("--gmres-max-iterations", type=int, default=100)
    parser.add_argument("--polarization-tolerance", type=float, default=2.0e-2)
    parser.add_argument("--polarization-residual-tolerance", type=float, default=1.0e-6)
    parser.add_argument("--linear-fit-fraction", type=float, default=1.0)
    parser.add_argument("--growth-tolerance", type=float, default=0.05)
    parser.add_argument("--frequency-tolerance", type=float, default=0.05)
    parser.add_argument("--growth-absolute-scale", type=float, default=1.0e-3)
    parser.add_argument("--frequency-absolute-scale", type=float, default=1.0e-3)
    parser.add_argument("--eigenfunction-tolerance", type=float, default=0.15)
    parser.add_argument("--minimum-fit-growth", type=float, default=0.25)
    parser.add_argument("--minimum-fit-phase", type=float, default=0.25)
    parser.add_argument("--equilibrium-rhs-tolerance", type=float, default=1.0e-9)
    parser.add_argument(
        "--stage6-semidiscrete-diagnostic",
        action="store_true",
        help=(
            "also finite-difference the production modal RHS; diagnostic only, "
            "never used for initialization or pass/fail"
        ),
    )
    parser.add_argument("--frozen-field-tolerance", type=float, default=1.0e-12)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    args = build_parser().parse_args(raw_argv)
    if args.experiment == "resistive-drift-wave":
        args.experiment = "drift-wave"
    if args.experiment == "interchange":
        # The interchange/flute reference is k_parallel=0 by construction.
        args.linear_mode_n_eta = 0
    if args.experiment in ("interchange", "drift-wave"):
        # Stage 6 needs a genuinely resolved growth/phase window.  Preserve
        # every explicit CLI override and preserve the historical heat-spot
        # defaults, while giving a bare Stage 6 command a useful duration.
        if not any(item == "--final-time" or item.startswith("--final-time=") for item in raw_argv):
            args.final_time = 3.0
        if not any(item == "--num-steps" or item.startswith("--num-steps=") for item in raw_argv):
            args.num_steps = 600
        if not any(item == "--save-every" or item.startswith("--save-every=") for item in raw_argv):
            args.save_every = 10
        if (
            args.experiment == "drift-wave"
            and not any(
                item == "--linear-fit-fraction"
                or item.startswith("--linear-fit-fraction=")
                for item in raw_argv
            )
        ):
            # The independent continuous eigenvector is only approximately an
            # eigenvector of the finite-resolution production operator.  Fit
            # the declared early linear interval before the resulting benign
            # modal beating, while retaining enough phase and amplitude change
            # for a meaningful signed-rate measurement.
            args.linear_fit_fraction = 1.0 / 3.0
        if (
            args.experiment == "drift-wave"
            and not any(
                item == "--minimum-fit-growth"
                or item.startswith("--minimum-fit-growth=")
                for item in raw_argv
            )
        ):
            args.minimum_fit_growth = 0.1
    if args.num_steps < 1 or args.save_every < 1 or args.final_time <= 0.0:
        raise SystemExit("--num-steps and --save-every must be positive and --final-time must be positive")
    if not (0.0 < args.linear_fit_fraction <= 1.0):
        raise SystemExit("--linear-fit-fraction must be in (0, 1]")
    if args.halo_width < 1:
        raise SystemExit("--halo-width must be positive")
    if args.gmres_max_iterations < 1:
        raise SystemExit("--gmres-max-iterations must be positive")
    if min(
        args.slab_radial_extent,
        args.slab_binormal_extent,
        args.slab_parallel_length,
        args.slab_bfield,
    ) <= 0.0:
        raise SystemExit("slab extents and --slab-bfield must be positive")
    if args.linear_radial_mode < 0:
        raise SystemExit("--linear-radial-mode must be nonnegative")
    if args.experiment in ("interchange", "drift-wave") and args.linear_mode_m_theta == 0:
        raise SystemExit("Stage 6 interchange/drift-wave requires nonzero k_y")
    if args.experiment == "drift-wave" and args.linear_mode_n_eta == 0:
        raise SystemExit("Stage 6 drift-wave requires nonzero k_parallel")
    validate_conduction_reconstruction_args(args)
    if not (0.0 <= args.flux_center <= 1.0) or args.flux_width <= 0.0:
        raise SystemExit("--flux-center must be in [0,1] and --flux-width must be positive")
    if not (0.0 < args.trace_seed_min < args.trace_seed_max < 1.0):
        raise SystemExit("trace seed bounds must satisfy 0 < min < max < 1")
    if args.trace_seed_count < 3 or args.trace_turns < 8:
        raise SystemExit("--trace-seed-count must be >=3 and --trace-turns must be >=8")
    if len(args.makegrid_currents) != 12 or not np.all(
        np.isfinite(args.makegrid_currents)
    ):
        raise SystemExit("--makegrid-currents must contain exactly 12 finite values")
    if args.experiment == "heat-spot":
        run_heat_spot(args)
    elif args.experiment == "polarization":
        run_polarization(args)
    else:
        run_stage6_evolution(args, args.experiment)


if __name__ == "__main__":
    main()
