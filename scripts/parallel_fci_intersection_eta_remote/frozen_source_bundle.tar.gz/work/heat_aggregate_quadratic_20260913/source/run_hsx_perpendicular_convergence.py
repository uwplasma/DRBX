#!/usr/bin/env python3
"""Run the literature FCI numerical-perpendicular-diffusion resolution series.

The toroidal/parallel plane count and all physical inputs remain fixed while
the two perpendicular logical dimensions are refined together.  Every case is
written to an independent directory and may be resumed safely.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys
from typing import Sequence

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_SERIES_DIR = (
    SCRIPT_DIR
    / "prototype_runs"
    / "hsx_parallel_heat_perpendicular_convergence_qhs_1T"
)
DEFAULT_PERPENDICULAR_RESOLUTIONS = (32, 40, 48, 64)
DEFAULT_PARALLEL_PLANES = 32


def _comma_ints(value: str) -> tuple[int, ...]:
    values = tuple(int(part) for part in value.split(","))
    if len(values) < 3 or any(item < 8 for item in values):
        raise argparse.ArgumentTypeError(
            "provide at least three comma-separated resolutions >= 8"
        )
    if tuple(sorted(set(values))) != values:
        raise argparse.ArgumentTypeError(
            "perpendicular resolutions must be unique and strictly increasing"
        )
    return values


def case_directory(series_dir: Path, perpendicular: int, parallel: int) -> Path:
    return series_dir / f"nperp_{perpendicular:03d}_neta_{parallel:03d}"


def completed_case(case_dir: Path, perpendicular: int, parallel: int) -> bool:
    history_path = case_dir / "history.npz"
    metadata_path = case_dir / "metadata.json"
    poincare_path = case_dir / "poincare_theta_u.npz"
    if not (history_path.is_file() and metadata_path.is_file() and poincare_path.is_file()):
        return False
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        resolution = metadata["geometry_contract"]["resolution"]
        with np.load(history_path, allow_pickle=False) as history:
            required = {
                "effective_perp_diffusivity",
                "effective_perp_to_parallel_ratio",
                "parallel_rhs_l2",
                "perpendicular_laplacian_l2",
                "traced_flux_label",
            }
            return bool(
                resolution == [perpendicular, perpendicular, parallel]
                and metadata.get("initial_condition") == "flux-function"
                and not required.difference(history.files)
                and np.all(np.isfinite(history["effective_perp_diffusivity"]))
            )
    except (KeyError, OSError, ValueError, json.JSONDecodeError):
        return False


def command_for_case(args: argparse.Namespace, perpendicular: int) -> list[str]:
    shape = f"{perpendicular},{perpendicular},{args.parallel_planes}"
    case_dir = case_directory(args.series_dir, perpendicular, args.parallel_planes)
    return [
        sys.executable,
        str(SCRIPT_DIR / "run_hsx_sanity.py"),
        "--initial-condition",
        "flux-function",
        "--resolution",
        shape,
        "--fit-sample-shape",
        shape,
        "--metric-mesh-shape",
        shape,
        "--chi-parallel",
        str(args.chi_parallel),
        "--final-time",
        str(args.final_time),
        "--num-steps",
        str(args.num_steps),
        "--save-every",
        str(args.save_every),
        "--amplitude",
        str(args.amplitude),
        "--flux-center",
        str(args.flux_center),
        "--flux-width",
        str(args.flux_width),
        "--trace-seed-min",
        str(args.trace_seed_min),
        "--trace-seed-max",
        str(args.trace_seed_max),
        "--trace-seed-count",
        str(args.trace_seed_count),
        "--trace-turns",
        str(args.trace_turns),
        "--output-dir",
        str(case_dir),
    ]


def write_series_manifest(args: argparse.Namespace) -> None:
    cases = []
    for perpendicular in args.perpendicular_resolutions:
        directory = case_directory(
            args.series_dir, perpendicular, args.parallel_planes
        )
        entry = {
            "perpendicular_resolution": [perpendicular, perpendicular],
            "parallel_planes": args.parallel_planes,
            "logical_perpendicular_spacing": 1.0 / perpendicular,
            "directory": str(directory),
            "complete": completed_case(
                directory, perpendicular, args.parallel_planes
            ),
        }
        metadata_path = directory / "metadata.json"
        if entry["complete"] and metadata_path.is_file():
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            entry.update(metadata["numerical_perpendicular_diffusion"])
        cases.append(entry)
    manifest = {
        "experiment": "HSX FCI effective numerical perpendicular diffusion convergence",
        "literature_method": {
            "reference": "Hill, Shanahan & Dudson, Computer Physics Communications 213 (2017), equations 24-26",
            "initial_condition": "Gaussian of a numerically reconstructed flux label",
            "effective_diffusivity": "time_average(||dTe/dt||_2 / ||laplacian_perp Te||_2)",
            "average": "latter half of each run",
            "fixed_parallel_resolution": True,
        },
        "fixed_parameters": {
            "parallel_planes": args.parallel_planes,
            "chi_parallel": args.chi_parallel,
            "final_time": args.final_time,
            "num_steps": args.num_steps,
            "save_every": args.save_every,
            "flux_center": args.flux_center,
            "flux_width": args.flux_width,
            "amplitude": args.amplitude,
            "qhs_main_current_amperes": 10722.0,
            "qhs_aux_current_amperes": 0.0,
        },
        "cases": cases,
    }
    args.series_dir.mkdir(parents=True, exist_ok=True)
    (args.series_dir / "series.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--perpendicular-resolutions",
        type=_comma_ints,
        default=DEFAULT_PERPENDICULAR_RESOLUTIONS,
    )
    parser.add_argument("--parallel-planes", type=int, default=DEFAULT_PARALLEL_PLANES)
    parser.add_argument("--series-dir", type=Path, default=DEFAULT_SERIES_DIR)
    parser.add_argument("--chi-parallel", type=float, default=0.1)
    parser.add_argument("--final-time", type=float, default=10.0)
    parser.add_argument("--num-steps", type=int, default=15000)
    parser.add_argument("--save-every", type=int, default=150)
    parser.add_argument("--amplitude", type=float, default=0.1)
    parser.add_argument("--flux-center", type=float, default=0.0)
    parser.add_argument("--flux-width", type=float, default=0.1)
    parser.add_argument("--trace-seed-min", type=float, default=0.04)
    parser.add_argument("--trace-seed-max", type=float, default=0.76)
    parser.add_argument("--trace-seed-count", type=int, default=25)
    parser.add_argument("--trace-turns", type=int, default=160)
    parser.add_argument(
        "--rerun-complete",
        action="store_true",
        help="rerun cases even when their validated histories already exist",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    args.series_dir = args.series_dir.resolve()
    if args.parallel_planes < 8:
        raise SystemExit("--parallel-planes must be >= 8")
    if args.num_steps < 1 or args.save_every < 1 or args.final_time <= 0.0:
        raise SystemExit("time-step and save controls must be positive")
    write_series_manifest(args)
    for perpendicular in args.perpendicular_resolutions:
        directory = case_directory(
            args.series_dir, perpendicular, args.parallel_planes
        )
        if not args.rerun_complete and completed_case(
            directory, perpendicular, args.parallel_planes
        ):
            print(f"[convergence] reuse complete case: {directory}", flush=True)
            continue
        print(
            f"[convergence] running Nperp={perpendicular}, "
            f"Neta={args.parallel_planes}: {directory}",
            flush=True,
        )
        subprocess.run(command_for_case(args, perpendicular), check=True)
        if not completed_case(directory, perpendicular, args.parallel_planes):
            raise RuntimeError(f"case did not produce a valid completed history: {directory}")
        write_series_manifest(args)
    write_series_manifest(args)
    print(f"[convergence] complete: {args.series_dir / 'series.json'}", flush=True)


if __name__ == "__main__":
    main()
