"""Prepare immutable aggregate-quadratic cases after native integration review.

This command intentionally refuses to snapshot an unintegrated driver.  It
does not launch work; ``launch.py`` performs the smoke gates first.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
RUN = Path(__file__).resolve().parent
SOURCE = RUN / "source"
AGGREGATE_FLAG = "--conduction-reconstruction"
AGGREGATE_VALUE = "aggregate-quadratic"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def parser() -> argparse.ArgumentParser:
    return argparse.ArgumentParser(description=__doc__)


def main() -> None:
    parser().parse_args()
    if SOURCE.exists():
        raise SystemExit(f"source snapshot already exists: {SOURCE}; refusing to overwrite")
    driver = ROOT / "run_hsx_sanity.py"
    text = driver.read_text()
    if AGGREGATE_FLAG not in text or AGGREGATE_VALUE not in text:
        raise SystemExit(
            "native integration marker is absent from run_hsx_sanity.py; "
            "review and integrate --conduction-reconstruction aggregate-quadratic before prepare"
        )

    (SOURCE / "DRBX").mkdir(parents=True)
    for relative in ("run_hsx_sanity.py", "run_hsx_perpendicular_convergence.py", "simulate_hsx_blob.py"):
        source_path = ROOT / ("DRBX" if relative == "simulate_hsx_blob.py" else "") / relative
        shutil.copy2(source_path, SOURCE / ("DRBX" if relative == "simulate_hsx_blob.py" else "") / relative)
    shutil.copytree(ROOT / "DRBX" / "src", SOURCE / "DRBX" / "src", ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))

    files = {
        str(path.relative_to(SOURCE)): sha256(path)
        for path in SOURCE.rglob("*") if path.is_file()
    }
    git = lambda *args: subprocess.check_output(["git", "-C", str(ROOT / "DRBX"), *args], text=True).strip()
    manifest = {
        "git_head": git("rev-parse", "HEAD"),
        "git_status": git("status", "--short"),
        "integration_driver": str(driver),
        "integration_driver_sha256": sha256(driver),
        "aggregate_flag": [AGGREGATE_FLAG, AGGREGATE_VALUE],
        "files_sha256": files,
    }
    (RUN / "source_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")

    cases = []
    for resolution in (32, 64):
        baseline_tag = "32" if resolution == 32 else "64x64x32"
        baseline = ROOT / "prototype_runs" / f"hsx_parallel_heat_spot_qhs_1T_main_only_{baseline_tag}_t25"
        if not baseline.is_dir():
            raise SystemExit(f"missing baseline directory: {baseline}")
        metadata_path = baseline / "metadata.json"
        history_path = baseline / "history.npz"
        contour_path = baseline / "makegrid_poincare_theta_u.npz"
        for required in (metadata_path, history_path, contour_path):
            if not required.exists():
                raise SystemExit(f"missing baseline artifact: {required}")
        metadata = json.loads(metadata_path.read_text())
        metric_source = Path(metadata["geometry_contract"]["metric_cache_path"]).resolve()
        if not metric_source.exists():
            raise SystemExit(f"missing baseline metric cache: {metric_source}")
        metric_dir = RUN / f"metric_cache_{resolution}"
        metric_dir.mkdir(exist_ok=False)
        metric_file = metric_dir / metric_source.name
        shutil.copy2(metric_source, metric_file)
        output = ROOT / "prototype_runs" / f"hsx_parallel_heat_spot_qhs_1T_main_only_{resolution}x{resolution}x32_aggregate_quadratic_t25_20260913"
        legacy_output = ROOT / "prototype_runs" / f"hsx_parallel_heat_spot_qhs_1T_main_only_{resolution}x{resolution}x32_aggregate_quadratic_t25_20260913_legacy"
        if output.exists():
            raise SystemExit(f"output already exists: {output}; refusing to overwrite")
        if legacy_output.exists():
            raise SystemExit(f"output already exists: {legacy_output}; refusing to overwrite")
        output.mkdir(parents=True)
        legacy_output.mkdir(parents=True)
        # The contour payload is independent of the evolving Te history and is
        # made available immediately for partial-history visualization.
        shutil.copy2(contour_path, output / contour_path.name)
        shutil.copy2(contour_path, legacy_output / contour_path.name)
        case = {
            "resolution": resolution,
            "baseline": str(baseline),
            "output": str(output),
            "legacy_output": str(legacy_output),
            "metric_cache": str(metric_dir),
            "metric_file": str(metric_file),
            "source": str(SOURCE),
            "final_time": 25.0,
            "num_steps": 37500,
            "dt": 25.0 / 37500.0,
            "save_every": 750,
            "aggregate_flag": [AGGREGATE_FLAG, AGGREGATE_VALUE],
            "legacy_control": "native default RLP; pass --legacy-control",
        }
        cases.append(case)
        (output / "control_plan.json").write_text(json.dumps(case, indent=2, sort_keys=True) + "\n")
        (legacy_output / "control_plan.json").write_text(json.dumps({**case, "output": str(legacy_output), "legacy_control": True}, indent=2, sort_keys=True) + "\n")
    (RUN / "cases.json").write_text(json.dumps(cases, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"source": str(SOURCE), "cases": cases}, indent=2))


if __name__ == "__main__":
    main()
