"""Analyze completed aggregate, historical-RLP, and no-RLP heat histories.

This is a read-only research analysis.  It uses the full raw host volumes for
heat budgets, and the saved midpoint weights only as a continuity comparison.
Surface budgets use the prepared MAKEGRID Poincare contours with fractional
radial-cell overlap.  They are redistribution diagnostics, not a flux-surface
transport coefficient or a conservation proof.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / "mpl_cache"))
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[1]
ANALYSIS = RUN / "analysis"
ANALYSIS.mkdir(parents=True, exist_ok=True)
SEEDS = (0.13, 0.19, 0.37, 0.46)
TARGET_TIMES = (3.5, 25.0)
HOST_RAW = {
    32: RUN / "metric_cache_32/angular_rlp_host_85832e63967cf29a96d27b10.npz",
    64: RUN / "metric_cache_64/angular_rlp_host_390bee6323f1de99aafa7806.npz",
}


def _load(path: Path) -> dict[str, np.ndarray]:
    with np.load(path) as archive:
        return {key: np.asarray(archive[key]).copy() for key in archive.files}


def _faces(centers: np.ndarray) -> np.ndarray:
    centers = np.asarray(centers, dtype=float)
    if centers.size < 2:
        raise ValueError("at least two radial centers are required")
    result = np.empty(centers.size + 1, dtype=float)
    result[1:-1] = 0.5 * (centers[:-1] + centers[1:])
    result[0] = centers[0] - 0.5 * (centers[1] - centers[0])
    result[-1] = centers[-1] + 0.5 * (centers[-1] - centers[-2])
    return result


def _surface_fraction(history: dict[str, np.ndarray], contours: dict[str, np.ndarray], seed: float) -> tuple[np.ndarray, float]:
    seed_index = int(np.argmin(np.abs(np.asarray(contours["seed_u"]) - seed)))
    selected_seed = float(contours["seed_u"][seed_index])
    if not bool(np.all(contours["valid_surfaces"][:, seed_index])):
        raise RuntimeError(f"surface seed {selected_seed} has invalid contour planes")
    normalized_theta = np.mod(np.asarray(history["theta"], dtype=float) / (2.0 * np.pi), 1.0)
    contour_theta = np.asarray(contours["contour_theta"], dtype=float)
    contour_u = np.asarray(contours["contour_u"][:, seed_index, :], dtype=float)
    # Interpolate each eta-plane contour at the actual cell-centered theta
    # coordinates.  contour_u is (eta, theta), so transpose to (theta, eta).
    surface = np.stack([np.interp(normalized_theta, contour_theta, row) for row in contour_u], axis=1)
    edges = _faces(history["u"])
    lower = edges[:-1, None, None]
    widths = np.diff(edges)[:, None, None]
    fraction = np.clip((surface[None, :, :] - lower) / widths, 0.0, 1.0)
    return fraction, selected_seed


def _series(history: dict[str, np.ndarray], raw_volume: np.ndarray, fraction: np.ndarray | None = None) -> dict[str, np.ndarray]:
    delta = np.asarray(history["Te"], dtype=float) - 1.0
    weights = np.asarray(raw_volume, dtype=float)
    midpoint_weights = np.asarray(history["volume_weights"], dtype=float)
    signed = np.sum(delta * weights[None, ...], axis=(1, 2, 3))
    signed_mid = np.sum(delta * midpoint_weights[None, ...], axis=(1, 2, 3))
    positive = np.sum(np.maximum(delta, 0.0) * weights[None, ...], axis=(1, 2, 3))
    negative = np.sum(np.maximum(-delta, 0.0) * weights[None, ...], axis=(1, 2, 3))
    answer = {"signed": signed, "signed_midpoint": signed_mid, "positive": positive, "negative": negative}
    if fraction is not None:
        inner_signed = np.sum(delta * weights[None, ...] * fraction[None, ...], axis=(1, 2, 3))
        inner_positive = np.sum(np.maximum(delta, 0.0) * weights[None, ...] * fraction[None, ...], axis=(1, 2, 3))
        answer["inner_signed"] = inner_signed
        answer["inner_positive"] = inner_positive
    return answer


def _time_index(times: np.ndarray, target: float) -> int:
    return int(np.argmin(np.abs(np.asarray(times) - target)))


def _centroids(history: dict[str, np.ndarray], target: float, eta_index: int = 25) -> dict[str, object]:
    times = np.asarray(history["times"])
    frame = _time_index(times, target)
    theta = np.mod(np.asarray(history["theta"]) / (2.0 * np.pi), 1.0)
    theta_mask = (theta > 0.25) & (theta < 0.75)
    values = np.asarray(history["Te"])[frame, :, :, eta_index][:, theta_mask] - 1.0
    u = np.asarray(history["u"], dtype=float)
    def one(field: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        denominator = np.sum(field, axis=1)
        numerator = np.sum(field * theta[theta_mask][None, :], axis=1)
        guard = max(1.0e-14, 1.0e-8 * float(np.max(np.abs(denominator))))
        valid = np.abs(denominator) > guard
        result = np.full(denominator.shape, np.nan)
        result[valid] = numerator[valid] / denominator[valid]
        return result, valid
    positive, positive_valid = one(np.maximum(values, 0.0))
    signed, signed_valid = one(values)
    return {
        "requested_time": float(target), "actual_time": float(times[frame]), "eta_index": eta_index,
        "theta_window": [0.25, 0.75], "row_guard": "abs(denominator)>max(1e-14,1e-8*max_row_abs)",
        "u": u.tolist(), "positive_centroid": positive.tolist(), "positive_valid": positive_valid.tolist(),
        "signed_centroid": signed.tolist(), "signed_valid": signed_valid.tolist(),
    }


def _json_series(series: dict[str, np.ndarray], times: np.ndarray) -> dict[str, list[float]]:
    return {key: np.asarray(value, dtype=float).tolist() for key, value in {"times": times, **series}.items()}


def main() -> None:
    aggregate_cases = json.loads((RUN / "cases.json").read_text())
    no_rlp_cases = {int(item["resolution"]): item for item in json.loads((ROOT / "work/heat_no_rlp_20260913/cases.json").read_text())}
    all_runs: dict[int, dict[str, dict[str, object]]] = {}
    summary: dict[str, object] = {
        "method": {"heat_volume": "host_raw_volume", "continuity_volume": "history.volume_weights", "surface_seeds": list(SEEDS), "surface_overlap": "fractional radial-cell overlap at actual normalized theta centers", "centroid_weighting": "positive perturbation and signed perturbation, separately guarded", "eta_index": 25},
        "runs": {}, "surface_budgets": {}, "centroid_profiles": {},
        "caveats": ["32 and 64 fitted metrics and initial physical profiles differ; this is not a strict convergence-order comparison.", "Surface budgets are relative to prepared MAKEGRID contours and do not establish exact flux-surface conservation.", "The current native-owner LEGACY standalone reference has a smooth t=3.5 centroid across the 64 transition, unlike the historical RLP baseline; reconstruction cannot be credited with all historical shear improvement."],
    }
    for case in aggregate_cases:
        n = int(case["resolution"])
        host = _load(HOST_RAW[n])
        raw_volume = np.asarray(host["host_raw_volume"], dtype=float)
        new_output = Path(case["output"])
        no_output = Path(no_rlp_cases[n]["output"])
        specs = [("historical_rlp", Path(case["baseline"])), ("no_rlp", no_output), ("aggregate_quadratic", new_output)]
        all_runs[n] = {}
        summary["runs"][str(n)] = {}
        summary["surface_budgets"][str(n)] = {}
        summary["centroid_profiles"][str(n)] = {}
        for label, directory in specs:
            history = _load(directory / "history.npz")
            contours = _load(directory / "makegrid_poincare_theta_u.npz")
            times = np.asarray(history["times"], dtype=float)
            fractions = {str(seed): _surface_fraction(history, contours, seed)[0] for seed in SEEDS}
            series = _series(history, raw_volume)
            surface_rows = {}
            for seed, fraction in zip(SEEDS, fractions.values(), strict=True):
                inner = _series(history, raw_volume, fraction)
                signed_ratio = inner["inner_signed"] / max(abs(series["signed"][0]), 1.0e-300)
                positive_ratio = inner["inner_positive"] / max(series["positive"][0], 1.0e-300)
                surface_rows[str(seed)] = {
                    "selected_seed_u": float(_surface_fraction(history, contours, seed)[1]),
                    "signed_inner_over_signed_Q0": signed_ratio.tolist(),
                    "positive_inner_over_positive_Q0": positive_ratio.tolist(),
                    "signed_change_percentage_points": float(100.0 * (signed_ratio[-1] - signed_ratio[0])),
                    "positive_change_percentage_points": float(100.0 * (positive_ratio[-1] - positive_ratio[0])),
                }
            centroid = {str(target): _centroids(history, target) for target in TARGET_TIMES}
            q0 = float(series["signed"][0])
            record = {
                "directory": str(directory), "times": times.tolist(),
                "q0_signed_raw_volume": q0, "q0_positive_raw_volume": float(series["positive"][0]),
                "final_signed_heat_drift_percent_raw_volume": float(100.0 * (series["signed"][-1] / q0 - 1.0)),
                "final_signed_heat_drift_percent_midpoint_weights": float(100.0 * (series["signed_midpoint"][-1] / series["signed_midpoint"][0] - 1.0)),
                "final_negative_mass_over_signed_Q0_percent": float(100.0 * series["negative"][-1] / q0),
                "final_positive_mass_over_initial_positive_percent": float(100.0 * series["positive"][-1] / max(series["positive"][0], 1.0e-300)),
                "min_Te": float(np.min(history["Te"])), "min_Te_location": np.unravel_index(np.argmin(history["Te"]), history["Te"].shape),
                "series": _json_series(series, times), "surface_budgets": surface_rows, "centroids": centroid,
            }
            # Convert the location tuple to JSON-friendly integers.
            record["min_Te_location"] = [int(x) for x in record["min_Te_location"]]
            summary["runs"][str(n)][label] = record
            summary["surface_budgets"][str(n)][label] = surface_rows
            summary["centroid_profiles"][str(n)][label] = centroid
            all_runs[n][label] = {"history": history, "contours": contours, "series": series, "fractions": fractions}

        # Signed delta-Te contour comparisons with each run's own Poincare overlay.
        for target in TARGET_TIMES:
            frame_data = [_load(Path(case["baseline"]) / "history.npz"), _load(no_output / "history.npz"), _load(new_output / "history.npz")]
            vmax = max(float(np.max(np.abs(h["Te"][_time_index(h["times"], target), :, :, 25] - 1.0))) for h in frame_data)
            vmax = max(vmax, 1.0e-15)
            fig, axes = plt.subplots(1, 3, figsize=(15, 4.7), sharex=True, sharey=True, layout="constrained")
            norm = TwoSlopeNorm(vmin=-vmax, vcenter=0.0, vmax=vmax)
            for ax, (label, directory) in zip(axes, specs, strict=True):
                item = all_runs[n][label]
                h = item["history"]; c = item["contours"]
                index = _time_index(h["times"], target)
                image = ax.pcolormesh(np.mod(h["theta"] / (2.0 * np.pi), 1.0), h["u"], h["Te"][index, :, :, 25] - 1.0, shading="nearest", cmap="RdBu_r", norm=norm)
                for seed_index in range(len(c["seed_u"])):
                    if bool(c["valid_surfaces"][25, seed_index]):
                        ax.plot(c["contour_theta"], c["contour_u"][25, seed_index], color="black", lw=0.35, alpha=0.45)
                if n == 64:
                    ax.axhline(0.34375, color="black", ls="--", lw=0.8, alpha=0.7)
                ax.set(xlim=(0.25, 0.75), ylim=(0.15, 0.6), xlabel="theta / (2 pi)", title=label.replace("_", " "))
                ax.grid(alpha=0.15)
            axes[0].set_ylabel("u")
            fig.colorbar(image, ax=axes, label="signed delta Te", shrink=0.9)
            fig.suptitle(f"{n}x{n}x32 eta index 25, t={target:g}; each panel's Poincare overlay")
            fig.savefig(ANALYSIS / f"contours_{n}_t{target:g}.png", dpi=150)
            plt.close(fig)

        # Full-poloidal t=25 view retains the outer radial region where ringing
        # can be missed by the focused u<0.6 comparison.
        target = 25.0
        frame_data = [all_runs[n][label]["history"] for label in ("historical_rlp", "no_rlp", "aggregate_quadratic")]
        vmax = max(float(np.max(np.abs(h["Te"][_time_index(h["times"], target), :, :, 25] - 1.0))) for h in frame_data)
        vmax = max(vmax, 1.0e-15)
        fig, axes = plt.subplots(1, 3, figsize=(15, 5.2), sharex=True, sharey=True, layout="constrained")
        norm = TwoSlopeNorm(vmin=-vmax, vcenter=0.0, vmax=vmax)
        for ax, (label, directory) in zip(axes, specs, strict=True):
            item = all_runs[n][label]; h = item["history"]; c = item["contours"]
            index = _time_index(h["times"], target)
            image = ax.pcolormesh(np.mod(h["theta"] / (2.0 * np.pi), 1.0), h["u"], h["Te"][index, :, :, 25] - 1.0, shading="nearest", cmap="RdBu_r", norm=norm)
            for seed_index in range(len(c["seed_u"])):
                if bool(c["valid_surfaces"][25, seed_index]):
                    ax.plot(c["contour_theta"], c["contour_u"][25, seed_index], color="black", lw=0.35, alpha=0.45)
            ax.set(xlim=(0.0, 1.0), ylim=(float(h["u"][0]), float(h["u"][-1])), xlabel="theta / (2 pi)", title=label.replace("_", " "))
            ax.grid(alpha=0.15)
        axes[0].set_ylabel("u")
        fig.colorbar(image, ax=axes, label="signed delta Te", shrink=0.9)
        fig.suptitle(f"{n}x{n}x32 eta index 25, t=25; full-poloidal Poincare overlays")
        fig.savefig(ANALYSIS / f"contours_{n}_t25_full.png", dpi=150)
        plt.close(fig)

        # Budget and inner-surface time series. Signed curves retain undershoots.
        fig, axes = plt.subplots(2, 2, figsize=(12, 8), layout="constrained")
        for label in ("historical_rlp", "no_rlp", "aggregate_quadratic"):
            item = all_runs[n][label]
            h = item["history"]; t = h["times"]; s = item["series"]
            style = {"historical_rlp": "--", "no_rlp": ":", "aggregate_quadratic": "-"}[label]
            axes[0, 0].plot(t, 100.0 * (s["signed"] / s["signed"][0] - 1.0), style, label=label)
            axes[0, 1].plot(t, s["negative"] / s["signed"][0], style, label=label)
            inner = _series(h, raw_volume, item["fractions"]["0.19"])
            axes[1, 0].plot(t, 100.0 * inner["inner_signed"] / s["signed"][0], style, label=label)
            axes[1, 1].plot(t, inner["inner_positive"] / s["positive"][0], style, label=label)
        axes[0, 0].set_ylabel("signed heat drift (%)")
        axes[0, 1].set_ylabel("negative mass / signed Q0")
        axes[1, 0].set_ylabel("signed inner heat / signed Q0 (%)")
        axes[1, 1].set_ylabel("positive inner mass / positive Q0")
        for ax in axes.ravel():
            ax.set_xlabel("time"); ax.grid(alpha=0.2); ax.legend()
        fig.suptitle(f"{n}x{n}x32 heat and seed-u~0.19 budgets")
        fig.savefig(ANALYSIS / f"budget_inner_heat_{n}.png", dpi=150)
        plt.close(fig)

        # Positive and signed centroid profiles, with a row guard.
        fig, axes = plt.subplots(2, 2, figsize=(12, 8), sharex=True, sharey=True, layout="constrained")
        for row, target in enumerate(TARGET_TIMES):
            for label in ("historical_rlp", "no_rlp", "aggregate_quadratic"):
                c = summary["centroid_profiles"][str(n)][label][str(target)]
                style = {"historical_rlp": "--", "no_rlp": ":", "aggregate_quadratic": "-"}[label]
                axes[row, 0].plot(c["u"], c["positive_centroid"], style, label=label)
                axes[row, 1].plot(c["u"], c["signed_centroid"], style, label=label)
            axes[row, 0].set_title(f"positive weighting, t={target:g}")
            axes[row, 1].set_title(f"signed weighting, t={target:g}")
            if n == 64:
                axes[row, 0].axvline(0.34375, color="black", ls="--", lw=0.8)
                axes[row, 1].axvline(0.34375, color="black", ls="--", lw=0.8)
        for ax in axes.ravel():
            ax.set(xlabel="u", ylabel="theta centroid / (2 pi)"); ax.grid(alpha=0.2); ax.legend()
        for ax in axes.ravel():
            ax.set_xlim(0.26, 0.44)
            ax.set_ylim(0.42, 0.57)
        fig.suptitle(f"{n}x{n}x32 eta index 25 centroid profiles; theta window .25-.75")
        fig.savefig(ANALYSIS / f"centroid_profiles_{n}.png", dpi=150)
        plt.close(fig)

        # Explicit transition-row diagnostics at the 64-grid transition.
        if n == 64:
            for target in TARGET_TIMES:
                transition = {}
                for label in ("historical_rlp", "no_rlp", "aggregate_quadratic"):
                    c = summary["centroid_profiles"][str(n)][label][str(target)]
                    u = np.asarray(c["u"])
                    i0 = int(np.searchsorted(u, 0.34375, side="right") - 1)
                    i0 = min(max(i0, 0), u.size - 2)
                    i1 = i0 + 1
                    transition[label] = {"rows": [float(u[i0]), float(u[i1])], "positive_jump": float(np.asarray(c["positive_centroid"])[i1] - np.asarray(c["positive_centroid"])[i0]), "signed_jump": float(np.asarray(c["signed_centroid"])[i1] - np.asarray(c["signed_centroid"])[i0])}
                summary[f"transition_64_t{target:g}"] = transition

    # Q0 equality is a useful check before comparing normalized budgets.
    summary["q0_signed_relative_to_aggregate"] = {
        str(n): {label: float(item["q0_signed_raw_volume"] / summary["runs"][str(n)]["aggregate_quadratic"]["q0_signed_raw_volume"] - 1.0) for label, item in summary["runs"][str(n)].items()}
        for n in summary["runs"]
    }
    (ANALYSIS / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")

    lines = [
        "# Completed aggregate-quadratic analysis", "",
        "This read-only analysis compares the new aggregate quadratic reconstruction with the historical RLP run and the matched no-RLP control. Full host raw volumes are used for every heat budget; saved midpoint weights are reported separately for continuity.", "",
        "The historical backward bend is absent in the new run at 64 and t=3.5, but the current native-owner LEGACY standalone reference is already smooth there; therefore this result cannot attribute all historical shear improvement to the reconstruction. Inner filling is reduced especially at 64 resolution, but the surface response is nonuniform (for example, the 32 seed-u=0.46 signed budget increases by 21.29 percentage points). The 32-grid negative mass and heat drift are large enough that this is not a validated general replacement or evidence that leakage is within a reasonable FCI error.", "",
        "## Heat and signed undershoot", "", "| Grid | Run | Raw-volume heat drift at t=25 | Midpoint-weight drift | Final negative mass / signed Q0 | Minimum Te |", "|---|---|---:|---:|---:|---:|",
    ]
    for n in (32, 64):
        for label, item in summary["runs"][str(n)].items():
            lines.append(f"| {n} | {label} | {item['final_signed_heat_drift_percent_raw_volume']:.5f}% | {item['final_signed_heat_drift_percent_midpoint_weights']:.5f}% | {item['final_negative_mass_over_signed_Q0_percent']:.5f}% | {item['min_Te']:.8g} |")
    lines += ["", "The signed quantities preserve negative perturbations; positive-only quantities are included in `summary.json` and the budget figures so undershoots cannot be hidden by a positive-only total.", "", "## Flux-surface inner budgets", "", "Seed u values are selected by nearest prepared contour seed. Fractions use the actual normalized theta centers and fractional radial-cell overlap. Each table entry is `100*(Q_inside(t=25)-Q_inside(t=0))/Q_total(t=0)` in percentage points. Signed and positive-only definitions use separate, consistent numerators and denominators.", "", "| Grid | Run | Seed .13 signed / positive pp | Seed .19 signed / positive pp | Seed .37 signed / positive pp | Seed .46 signed / positive pp |", "|---|---|---:|---:|---:|---:|"]
    for n in (32, 64):
        for label, rows in summary["surface_budgets"][str(n)].items():
            cells = [f"{rows[str(seed)]['signed_change_percentage_points']:.4f} / {rows[str(seed)]['positive_change_percentage_points']:.4f}" for seed in SEEDS]
            lines.append(f"| {n} | {label} | " + " | ".join(cells) + " |")
    lines += ["", "## Shape and transition", "", "Centroids use eta index 25 and the actual theta-center window 0.25–0.75. Positive and signed weighting are calculated separately with a meaningful row denominator guard. The 64 transition near u=0.34375 is reported in `summary.json`; signed centroids can be sensitive to ringing, so the positive profile is the primary shape view.", "", "| Run | t=3.5 positive / signed jump | t=25 positive / signed jump |", "|---|---:|---:|"]
    for label in ("historical_rlp", "no_rlp", "aggregate_quadratic"):
        a = summary["transition_64_t3.5"][label]; b = summary["transition_64_t25"][label]
        lines.append(f"| {label} | {a['positive_jump']:+.6f} / {a['signed_jump']:+.6f} | {b['positive_jump']:+.6f} / {b['signed_jump']:+.6f} |")
    lines += ["", "The current native-owner LEGACY standalone reference already has a smooth 64-grid t=3.5 centroid across the transition (approximately 0.511192 and 0.514523 at u=0.3359375 and 0.3515625), while the historical RLP values are approximately 0.538643 and 0.527938. Therefore the aggregate reconstruction cannot be credited with all historical shear improvement. The short native/reconstructed matrix agreement is recorded in [`validation.json`](</Users/yxie/Desktop/HSX drbx/work/heat_aggregate_quadratic_20260913/validation.json>). The 64 t=25 contour retains visible cell-scale scalloping around the transition, and the full-poloidal figures expose outer ringing beyond the focused crop.", "", "## Figures", ""]
    for n in (32, 64):
        lines += [f"- [Signed contour comparison at t=3.5](<{ANALYSIS / f'contours_{n}_t3.5.png'}>) and [t=25](<{ANALYSIS / f'contours_{n}_t25.png'}>); [full-poloidal t=25](<{ANALYSIS / f'contours_{n}_t25_full.png'}>)", f"- [Heat and inner-budget time series](<{ANALYSIS / f'budget_inner_heat_{n}.png'}>)", f"- [Positive and signed centroid profiles](<{ANALYSIS / f'centroid_profiles_{n}.png'}>)"]
    lines += ["", "The fitted metrics and initial physical profiles differ between 32 and 64, so these plots are not a strict convergence-order study. Surface budgets measure redistribution relative to prepared MAKEGRID contours and do not establish exact conservation or wall closure."]
    (ANALYSIS / "report.md").write_text("\n".join(lines) + "\n")
    print(json.dumps({"summary": str(ANALYSIS / "summary.json"), "report": str(ANALYSIS / "report.md"), "figures": sorted(path.name for path in ANALYSIS.glob("*.png"))}, indent=2))


if __name__ == "__main__":
    main()
