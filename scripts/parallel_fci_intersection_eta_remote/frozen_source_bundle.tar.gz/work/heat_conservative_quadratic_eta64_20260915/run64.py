"""Run the frozen conservative-quadratic H heat test on a 32x32x64 grid."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

import numpy as np


RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[1]
SOURCE_RUN = ROOT / "work" / "heat_conservative_quadratic_20260913"
SOURCE = SOURCE_RUN / "source"
SOURCE_MANIFEST = SOURCE_RUN / "source_manifest.json"
METRIC_CACHE = RUN / "metric_cache_32x32x64"
SMOKE_OUTPUT = RUN / "smoke32x32x64_dt1over1500"
FULL_OUTPUT = ROOT / (
    "prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_"
    "32x32x64_conservative_quadratic_dt1over1500_t25_20260915"
)


def _atomic_json(path: Path, payload: object) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def _status(path: Path, **fields: object) -> None:
    _atomic_json(path, {"pid": os.getpid(), "updated": time.time(), **fields})


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _verify_frozen_source() -> int:
    manifest = json.loads(SOURCE_MANIFEST.read_text())
    expected = manifest["source_files_sha256"]
    mismatches = []
    for relative, digest in expected.items():
        path = SOURCE / relative
        if not path.is_file() or _sha256(path) != digest:
            mismatches.append(relative)
    if mismatches:
        raise RuntimeError(f"frozen source hash mismatch: {mismatches}")
    return len(expected)


def _arguments(output: Path, *, smoke: bool) -> list[str]:
    steps = 3 if smoke else 37_500
    final_time = 0.002 if smoke else 25.0
    save_every = 1 if smoke else 750
    currents = ",".join(["10722"] * 6 + ["0"] * 6)
    return [
        "--experiment", "heat-spot",
        "--initial-condition", "heat-spot",
        "--output-dir", str(output),
        "--resolution", "32,32,64",
        "--fit-sample-shape", "32,32,64",
        "--metric-mesh-shape", "32,32,64",
        "--makegrid", str(ROOT / "mgrid_res2p5cm_180pln.nc"),
        "--makegrid-currents", currents,
        "--vessel", str(ROOT / "vessel_hsx_flare.txt"),
        "--metric-cache-dir", str(METRIC_CACHE),
        "--radial-degree", "3",
        "--vertical-degree", "3",
        "--toroidal-modes", "10",
        "--metric-spline-degree", "1",
        "--mmpde-iterations", "0",
        "--axis-core-radius", "0.03",
        "--metric-radial-degree", "17",
        "--metric-poloidal-modes", "15",
        "--metric-toroidal-modes", "3",
        "--eta-projection-iterations", "0",
        "--fci-trace-substeps", "4",
        "--halo-width", "2",
        "--conduction-reconstruction", "conservative-quadratic",
        "--chi-parallel", "0.1",
        "--amplitude", "0.1",
        "--center-u", "0.35",
        "--center-v", str(np.pi),
        "--center-eta", str(np.pi),
        "--width-u", "0.05",
        "--width-v", "0.12",
        "--width-eta", str(np.pi),
        "--num-steps", str(steps),
        "--final-time", str(final_time),
        "--save-every", str(save_every),
    ]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke", action="store_true")
    opts = parser.parse_args()
    output = SMOKE_OUTPUT if opts.smoke else FULL_OUTPUT
    output.mkdir(parents=True, exist_ok=True)
    status = output / "process_status.json"
    started = time.time()
    steps = 3 if opts.smoke else 37_500
    final_time = 0.002 if opts.smoke else 25.0
    argv = _arguments(output, smoke=opts.smoke)
    _status(
        status,
        state="initializing",
        smoke=opts.smoke,
        resolution=[32, 32, 64],
        reconstruction="conservative-quadratic",
        steps=steps,
        final_time=final_time,
        dt=final_time / steps,
    )
    try:
        source_file_count = _verify_frozen_source()
        os.environ.pop("DRBX_SOURCE_ROOT", None)
        os.environ["DRBX_CACHE_DIR"] = str(RUN / "jax_cache")
        sys.path.insert(0, str(SOURCE))
        import run_hsx_sanity as sanity  # type: ignore
        import drbx  # type: ignore

        if not Path(sanity.__file__).resolve().is_relative_to(SOURCE):
            raise RuntimeError(f"run_hsx_sanity escaped frozen source: {sanity.__file__}")
        expected_drbx = SOURCE / "DRBX" / "src"
        if not Path(drbx.__file__).resolve().is_relative_to(expected_drbx):
            raise RuntimeError(f"drbx escaped frozen source: {drbx.__file__}")
        args = sanity.build_parser().parse_args(argv)
        _atomic_json(
            output / "preflight_metadata.json",
            {
                "argv": argv,
                "frozen_source": str(SOURCE),
                "frozen_source_file_count": source_file_count,
                "frozen_source_manifest": str(SOURCE_MANIFEST),
                "frozen_source_manifest_sha256": _sha256(SOURCE_MANIFEST),
                "metric_cache": str(METRIC_CACHE),
                "purpose": "isolate the effect of doubling eta planes from 32 to 64",
            },
        )
        _status(
            status,
            state="running",
            smoke=opts.smoke,
            resolution=[32, 32, 64],
            reconstruction="conservative-quadratic",
            steps=steps,
            final_time=final_time,
            dt=final_time / steps,
        )
        history = sanity.run_heat_spot(args)
        with np.load(history) as result:
            if tuple(result["Te"].shape[1:]) != (32, 32, 64):
                raise RuntimeError(f"unexpected history shape: {result['Te'].shape}")
            if not np.isclose(float(result["times"][-1]), final_time, rtol=0.0, atol=1e-13):
                raise RuntimeError(f"history ended at {result['times'][-1]}, expected {final_time}")
            if not np.all(np.isfinite(result["Te"])) or float(np.min(result["Te"])) <= 0.0:
                raise RuntimeError("history contains non-finite or non-positive absolute Te")
            frames = int(result["times"].size)
            minimum_te = float(np.min(result["Te"]))
        metadata = json.loads((output / "metadata.json").read_text())
        if metadata.get("conduction_reconstruction", {}).get("mode") != "conservative-quadratic":
            raise RuntimeError("metadata does not report conservative-quadratic reconstruction")
        if metadata.get("geometry_contract", {}).get("resolution") != [32, 32, 64]:
            raise RuntimeError("metadata resolution does not match 32x32x64")
        _status(
            status,
            state="completed",
            smoke=opts.smoke,
            resolution=[32, 32, 64],
            reconstruction="conservative-quadratic",
            steps=steps,
            final_time=final_time,
            dt=final_time / steps,
            frames=frames,
            minimum_Te=minimum_te,
            elapsed_seconds=time.time() - started,
            history=str(history),
        )
    except BaseException as exc:
        _status(
            status,
            state="failed",
            smoke=opts.smoke,
            resolution=[32, 32, 64],
            reconstruction="conservative-quadratic",
            error=repr(exc),
            elapsed_seconds=time.time() - started,
        )
        traceback.print_exc()
        raise


if __name__ == "__main__":
    main()
