"""Safely launch the 32x32x64 conservative-H smoke or full run."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time


RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[1]
SMOKE_OUTPUT = RUN / "smoke32x32x64_dt1over1500"
FULL_OUTPUT = ROOT / (
    "prototype_runs/hsx_parallel_heat_spot_qhs_1T_main_only_"
    "32x32x64_conservative_quadratic_dt1over1500_t25_20260915"
)
FORBIDDEN = {
    "process_status.json", "history.npz", "metadata.json", "launch.json",
    "run.log", "preflight_metadata.json", "summary.txt",
}


def _atomic_json(path: Path, payload: object) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def _guard_output(output: Path) -> None:
    if not output.exists():
        return
    present = sorted(name for name in FORBIDDEN if (output / name).exists())
    if present:
        raise SystemExit(f"refusing duplicate or overwrite of {output}: {present}")


def _require_smoke() -> None:
    path = SMOKE_OUTPUT / "process_status.json"
    try:
        status = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise SystemExit(f"smoke gate is unavailable: {path}: {exc}") from exc
    expected = {
        "state": "completed",
        "smoke": True,
        "steps": 3,
        "final_time": 0.002,
        "resolution": [32, 32, 64],
        "reconstruction": "conservative-quadratic",
    }
    mismatches = {key: (status.get(key), value) for key, value in expected.items() if status.get(key) != value}
    if mismatches:
        raise SystemExit(f"smoke gate did not pass the expected contract: {mismatches}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke", action="store_true")
    opts = parser.parse_args()
    output = SMOKE_OUTPUT if opts.smoke else FULL_OUTPUT
    if not opts.smoke:
        _require_smoke()
    _guard_output(output)
    output.mkdir(parents=True, exist_ok=True)
    command = [sys.executable, "-u", str(RUN / "run64.py")]
    if opts.smoke:
        command.append("--smoke")
    env = os.environ.copy()
    env.update(
        {
            "DRBX_CACHE_DIR": str(RUN / "jax_cache"),
            "DRBX_HOST_DEVICE_COUNT": "1",
            "OMP_NUM_THREADS": "4",
            "OPENBLAS_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1",
            "NUMEXPR_NUM_THREADS": "1",
            "PYTHONUNBUFFERED": "1",
        }
    )
    env.pop("DRBX_SOURCE_ROOT", None)
    log = output / "run.log"
    with log.open("ab", buffering=0) as stream:
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=stream,
            stderr=subprocess.STDOUT,
            cwd=ROOT,
            env=env,
            start_new_session=True,
        )
    record = {
        "pid": process.pid,
        "smoke": opts.smoke,
        "command": command,
        "cwd": str(ROOT),
        "output": str(output),
        "log": str(log),
        "launched_at": time.time(),
    }
    _atomic_json(output / "launch.json", record)
    print(json.dumps(record, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
