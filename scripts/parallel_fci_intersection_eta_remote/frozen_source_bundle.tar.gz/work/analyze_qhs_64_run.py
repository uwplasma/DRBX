from __future__ import annotations

import gc
import json
from pathlib import Path

import numpy as np


ROOT = Path("/Users/yxie/Desktop/HSX drbx")
RUN = ROOT / "prototype_runs/fci_qhs_64_material_scalar_pb3_characteristic_sat_imex_allwalls_trace4_rhsterms_t015_800steps_26d9e506_20260901"
PREFIX = "hsx_qhs_64_materialscalar_pb3_affinelift_pair_imex_rhsterms_eta4_t015_800steps"
FULL = RUN / f"{PREFIX}.npz"
FINAL = RUN / f"{PREFIX}.checkpoint_step000800.npz"
RUN48 = ROOT / "prototype_runs/fci_qhs_48_material_scalar_pb3_characteristic_sat_imex_allwalls_trace4_t015_640steps_26d9e506_20260901"
FINAL48 = RUN48 / "hsx_qhs_bc_characteristic_materialscalar_pb3_affinelift_pair_imex_allwalls_eta4_48_t015_640steps.checkpoint_step000640.npz"
FULL48 = RUN48 / "hsx_qhs_bc_characteristic_materialscalar_pb3_affinelift_pair_imex_allwalls_eta4_48_t015_640steps.npz"
OUTPUT = ROOT / "work/qhs_64_run_analysis.json"

FIELDS = ("density", "Te", "Ti", "Vi", "Ve", "vorticity", "phi")
EQUILIBRIUM = {"density": 1.0, "Te": 1.0, "Ti": 1.0, "Vi": 0.0, "Ve": 0.0, "vorticity": 0.0, "phi": 0.0}


def index_of(array: np.ndarray, flat: int) -> list[int]:
    return [int(value) for value in np.unravel_index(flat, array.shape)]


def finite_ratio(top: float, bottom: float) -> float | None:
    if bottom == 0.0:
        return None
    return float(top / bottom)


def weighted_rms(values: np.ndarray, weight: np.ndarray) -> float:
    return float(np.sqrt(np.sum(weight * values * values) / np.sum(weight)))


def periodic_spectrum(values: np.ndarray, axis: int) -> np.ndarray:
    coefficients = np.fft.rfft(values, axis=axis, norm="ortho")
    return np.sum(np.abs(coefficients) ** 2, axis=tuple(i for i in range(coefficients.ndim) if i != axis))


def spectrum_summary(power: np.ndarray, size: int) -> dict[str, object]:
    nonzero = np.asarray(power, dtype=np.float64).copy()
    nonzero[0] = 0.0
    total = float(np.sum(nonzero))
    high_start = int(np.ceil(0.55 * (size // 2)))
    near_start = int(np.ceil(0.90 * (size // 2)))
    dominant = int(np.argmax(nonzero)) if total else 0
    return {
        "dominant_nonzero_mode": dominant,
        "dominant_fraction": finite_ratio(float(nonzero[dominant]), total),
        "high_start_mode": high_start,
        "high_fraction": finite_ratio(float(np.sum(nonzero[high_start:])), total),
        "near_nyquist_start_mode": near_start,
        "near_nyquist_fraction": finite_ratio(float(np.sum(nonzero[near_start:])), total),
        "nyquist_fraction": finite_ratio(float(nonzero[-1]), total),
    }


def final_frame_summary(path: Path) -> dict[str, object]:
    with np.load(path, allow_pickle=False) as data:
        weight = np.asarray(data["jacobian"], dtype=np.float64)
        result: dict[str, object] = {
            "time": float(data["time"]),
            "step": int(data["step"]),
            "fields": {},
        }
        for name in FIELDS:
            field = np.asarray(data[name], dtype=np.float64)
            perturbation = field - EQUILIBRIUM[name]
            result["fields"][name] = {
                "minimum": float(np.min(field)),
                "maximum": float(np.max(field)),
                "maximum_absolute": float(np.max(np.abs(field))),
                "perturbation_weighted_rms": weighted_rms(perturbation, weight),
                "weighted_mean": float(np.sum(weight * field) / np.sum(weight)),
            }
        return result


def history_final_frame_summary(path: Path) -> dict[str, object]:
    with np.load(path, allow_pickle=False) as data:
        weight = np.asarray(data["jacobian"], dtype=np.float64)
        times = np.asarray(data["times"], dtype=np.float64)
        result: dict[str, object] = {
            "time": float(times[-1]),
            "step": int(times.size - 1),
            "fields": {},
        }
        for name in FIELDS:
            field = np.asarray(data[name][-1], dtype=np.float64)
            perturbation = field - EQUILIBRIUM[name]
            result["fields"][name] = {
                "minimum": float(np.min(field)),
                "maximum": float(np.max(field)),
                "maximum_absolute": float(np.max(np.abs(field))),
                "perturbation_weighted_rms": weighted_rms(perturbation, weight),
                "weighted_mean": float(np.sum(weight * field) / np.sum(weight)),
            }
        return result


def checkpoint_audit() -> tuple[dict[str, object], dict[str, np.ndarray]]:
    metric_path = next((RUN / "metric_cache").glob("hsx_metric_*.npz"))
    with np.load(metric_path, allow_pickle=False) as metric:
        forward_wall = np.asarray(metric["fci_maps_forward_boundary"], dtype=bool)
        backward_wall = np.asarray(metric["fci_maps_backward_boundary"], dtype=bool)
        forward_length = np.asarray(metric["fci_maps_forward_length"], dtype=np.float64)
        backward_length = np.asarray(metric["fci_maps_backward_length"], dtype=np.float64)
    wall_mask = forward_wall | backward_wall

    with np.load(FINAL, allow_pickle=False) as data:
        weight = np.asarray(data["jacobian"], dtype=np.float64)
        group_sizes = np.asarray(data["angular_group_sizes"], dtype=np.int64)
        result: dict[str, object] = {
            "time": float(data["time"]),
            "step": int(data["step"]),
            "all_fields_finite": True,
            "angular_group_size_outer_shell": int(group_sizes[-1]),
            "wall_cells": int(np.count_nonzero(wall_mask)),
            "double_hit_wall_cells": int(np.count_nonzero(forward_wall & backward_wall)),
            "fields": {},
            "ghost_state": {},
            "saved_grid_scale_diagnostic": {},
        }
        diagnostic = np.asarray(data["grid_scale_diagnostics"], dtype=np.float64)
        high_pass = diagnostic[2:].reshape(7, 2)
        for name, values in zip(FIELDS, high_pass):
            result["saved_grid_scale_diagnostic"][name] = {
                "wall_sum_squared_second_difference": float(values[0]),
                "bulk_sum_squared_second_difference": float(values[1]),
                "wall_over_bulk": finite_ratio(float(values[0]), float(values[1])),
            }
        result["saved_grid_scale_diagnostic"]["max_abs_Ve"] = float(diagnostic[0])
        result["saved_grid_scale_diagnostic"]["max_abs_Ve_linear_index"] = int(diagnostic[1])

        ghosts = np.asarray(data["wall_ghost_states"], dtype=np.float64)
        result["ghost_state"] = {
            "all_finite": bool(np.all(np.isfinite(ghosts))),
            "density_minimum": float(np.min(ghosts[0])),
            "Te_minimum": float(np.min(ghosts[2])),
            "Ti_minimum": float(np.min(ghosts[3])),
        }

        saved_fields: dict[str, np.ndarray] = {}
        for name in FIELDS:
            field = np.asarray(data[name], dtype=np.float64)
            saved_fields[name] = field
            result["all_fields_finite"] = bool(result["all_fields_finite"] and np.all(np.isfinite(field)))
            perturbation = field - EQUILIBRIUM[name]
            outer = perturbation[-1]
            interior = perturbation[:-4]
            wall_values = perturbation[wall_mask]
            bulk_values = perturbation[~wall_mask]
            theta_power = np.sum(np.abs(np.fft.rfft(outer, axis=0, norm="ortho")) ** 2, axis=1)
            eta_power = np.sum(np.abs(np.fft.rfft(outer, axis=1, norm="ortho")) ** 2, axis=0)
            theta_jump = np.roll(field[-1], -1, axis=0) - field[-1]
            max_jump_flat = int(np.argmax(np.abs(theta_jump)))
            jump_theta, jump_eta = np.unravel_index(max_jump_flat, theta_jump.shape)
            shell_energy = np.asarray([
                np.sum(weight[u] * perturbation[u] * perturbation[u]) for u in range(field.shape[0])
            ])
            shell_max = int(np.argmax(shell_energy))
            result["fields"][name] = {
                "minimum": float(np.min(field)),
                "minimum_location": index_of(field, int(np.argmin(field))),
                "maximum": float(np.max(field)),
                "maximum_location": index_of(field, int(np.argmax(field))),
                "maximum_absolute": float(np.max(np.abs(field))),
                "maximum_absolute_location": index_of(field, int(np.argmax(np.abs(field)))),
                "perturbation_weighted_rms": weighted_rms(perturbation, weight),
                "outer_shell_rms": float(np.sqrt(np.mean(outer * outer))),
                "interior_rms": float(np.sqrt(np.mean(interior * interior))),
                "outer_over_interior_rms": finite_ratio(float(np.sqrt(np.mean(outer * outer))), float(np.sqrt(np.mean(interior * interior)))),
                "fci_wall_hit_rms": float(np.sqrt(np.mean(wall_values * wall_values))),
                "nonwall_rms": float(np.sqrt(np.mean(bulk_values * bulk_values))),
                "wall_hit_over_nonwall_rms": finite_ratio(float(np.sqrt(np.mean(wall_values * wall_values))), float(np.sqrt(np.mean(bulk_values * bulk_values)))),
                "largest_energy_shell": shell_max,
                "outer_shell_fraction_of_radial_energy": finite_ratio(float(shell_energy[-1]), float(np.sum(shell_energy))),
                "outer_theta_spectrum": spectrum_summary(theta_power, field.shape[1]),
                "outer_eta_spectrum": spectrum_summary(eta_power, field.shape[2]),
                "maximum_outer_poloidal_jump": float(theta_jump[jump_theta, jump_eta]),
                "maximum_outer_poloidal_jump_absolute": float(abs(theta_jump[jump_theta, jump_eta])),
                "maximum_outer_poloidal_jump_pair": [[field.shape[0] - 1, int(jump_theta), int(jump_eta)], [field.shape[0] - 1, int((jump_theta + 1) % field.shape[1]), int(jump_eta)]],
                "maximum_jump_forward_wall_flags": [bool(forward_wall[-1, jump_theta, jump_eta]), bool(forward_wall[-1, (jump_theta + 1) % field.shape[1], jump_eta])],
                "maximum_jump_backward_wall_flags": [bool(backward_wall[-1, jump_theta, jump_eta]), bool(backward_wall[-1, (jump_theta + 1) % field.shape[1], jump_eta])],
                "maximum_jump_forward_lengths": [float(forward_length[-1, jump_theta, jump_eta]), float(forward_length[-1, (jump_theta + 1) % field.shape[1], jump_eta])],
                "maximum_jump_backward_lengths": [float(backward_length[-1, jump_theta, jump_eta]), float(backward_length[-1, (jump_theta + 1) % field.shape[1], jump_eta])],
            }
        return result, saved_fields


def full_history_audit() -> dict[str, object]:
    with np.load(FULL, allow_pickle=False) as data:
        times = np.asarray(data["times"], dtype=np.float64)
        weight = np.asarray(data["jacobian"], dtype=np.float64)
        result: dict[str, object] = {
            "frame_count": int(times.size),
            "initial_time": float(times[0]),
            "final_time": float(times[-1]),
            "fields": {},
            "inventories": {},
        }
        for name in FIELDS:
            values = np.asarray(data[name])
            equilibrium = EQUILIBRIUM[name]
            frame_min = np.min(values, axis=(1, 2, 3))
            frame_max = np.max(values, axis=(1, 2, 3))
            frame_abs = np.max(np.abs(values), axis=(1, 2, 3))
            min_step = int(np.argmin(frame_min))
            max_step = int(np.argmax(frame_max))
            abs_step = int(np.argmax(frame_abs))
            outer = np.asarray(values[:, -1], dtype=np.float64) - equilibrium
            jumps = np.roll(outer, -1, axis=1) - outer
            jump_max_per_step = np.max(np.abs(jumps), axis=(1, 2))
            jump_peak_step = int(np.argmax(jump_max_per_step))
            final_jump_flat = int(np.argmax(np.abs(jumps[-1])))
            final_jump_theta, final_jump_eta = np.unravel_index(final_jump_flat, jumps[-1].shape)
            theta_coefficients = np.fft.rfft(outer, axis=1, norm="ortho")
            theta_power = np.sum(np.abs(theta_coefficients) ** 2, axis=2)
            theta_power[:, 0] = 0.0
            theta_total = np.sum(theta_power, axis=1)
            high_start = int(np.ceil(0.55 * (values.shape[2] // 2)))
            near_start = int(np.ceil(0.90 * (values.shape[2] // 2)))
            high_fraction = np.divide(np.sum(theta_power[:, high_start:], axis=1), theta_total, out=np.zeros_like(theta_total), where=theta_total > 0.0)
            near_fraction = np.divide(np.sum(theta_power[:, near_start:], axis=1), theta_total, out=np.zeros_like(theta_total), where=theta_total > 0.0)
            high_energy = np.sum(theta_power[:, high_start:], axis=1)
            near_energy = np.sum(theta_power[:, near_start:], axis=1)
            high_peak_step = int(np.argmax(high_fraction))
            high_energy_peak_step = int(np.argmax(high_energy))
            sample_steps = [step for step in (0, 200, 400, 600, 700, 775, 800) if step < times.size]
            result["fields"][name] = {
                "worst_minimum": float(frame_min[min_step]),
                "worst_minimum_step": min_step,
                "worst_minimum_time": float(times[min_step]),
                "largest_maximum": float(frame_max[max_step]),
                "largest_maximum_step": max_step,
                "largest_maximum_time": float(times[max_step]),
                "largest_absolute": float(frame_abs[abs_step]),
                "largest_absolute_step": abs_step,
                "largest_absolute_time": float(times[abs_step]),
                "initial_range": [float(frame_min[0]), float(frame_max[0])],
                "final_range": [float(frame_min[-1]), float(frame_max[-1])],
                "outer_poloidal_jump_initial_max_abs": float(jump_max_per_step[0]),
                "outer_poloidal_jump_final_max_abs": float(jump_max_per_step[-1]),
                "outer_poloidal_jump_peak_max_abs": float(jump_max_per_step[jump_peak_step]),
                "outer_poloidal_jump_peak_step": jump_peak_step,
                "outer_poloidal_jump_peak_time": float(times[jump_peak_step]),
                "outer_poloidal_jump_final_pair": [[values.shape[1] - 1, int(final_jump_theta), int(final_jump_eta)], [values.shape[1] - 1, int((final_jump_theta + 1) % values.shape[2]), int(final_jump_eta)]],
                "outer_theta_high_fraction_initial": float(high_fraction[0]),
                "outer_theta_high_fraction_final": float(high_fraction[-1]),
                "outer_theta_high_fraction_peak": float(high_fraction[high_peak_step]),
                "outer_theta_high_fraction_peak_step": high_peak_step,
                "outer_theta_high_fraction_peak_time": float(times[high_peak_step]),
                "outer_theta_near_nyquist_fraction_final": float(near_fraction[-1]),
                "outer_theta_high_energy_initial": float(high_energy[0]),
                "outer_theta_high_energy_final": float(high_energy[-1]),
                "outer_theta_high_energy_peak": float(high_energy[high_energy_peak_step]),
                "outer_theta_high_energy_peak_step": high_energy_peak_step,
                "outer_theta_high_energy_peak_time": float(times[high_energy_peak_step]),
                "outer_theta_near_nyquist_energy_final": float(near_energy[-1]),
                "late_samples": {
                    str(step): {
                        "minimum": float(frame_min[step]),
                        "maximum": float(frame_max[step]),
                        "maximum_absolute": float(frame_abs[step]),
                        "outer_poloidal_jump_max_abs": float(jump_max_per_step[step]),
                        "outer_theta_high_fraction": float(high_fraction[step]),
                        "outer_theta_high_energy": float(high_energy[step]),
                        "outer_theta_near_nyquist_energy": float(near_energy[step]),
                    }
                    for step in sample_steps
                },
            }
            if name in ("density", "Te", "Ti"):
                initial_inventory = float(np.sum(weight * np.asarray(values[0], dtype=np.float64)))
                final_inventory = float(np.sum(weight * np.asarray(values[-1], dtype=np.float64)))
                initial_excess = float(np.sum(weight * (np.asarray(values[0], dtype=np.float64) - 1.0)))
                final_excess = float(np.sum(weight * (np.asarray(values[-1], dtype=np.float64) - 1.0)))
                result["inventories"][name] = {
                    "relative_total_change": finite_ratio(final_inventory - initial_inventory, initial_inventory),
                    "initial_excess": initial_excess,
                    "final_excess": final_excess,
                    "retained_excess_fraction": finite_ratio(final_excess, initial_excess),
                }
            del values, outer, jumps, theta_coefficients, theta_power
            gc.collect()
        return result


def saved_grid_history_audit() -> dict[str, object]:
    records: list[dict[str, object]] = []
    for path in sorted(RUN.glob(f"{PREFIX}.checkpoint_step*.npz")):
        with np.load(path, allow_pickle=False) as data:
            step = int(data["step"])
            time = float(data["time"])
            diagnostic = np.asarray(data["grid_scale_diagnostics"], dtype=np.float64)
        high_pass = diagnostic[2:].reshape(7, 2)
        records.append({
            "step": step,
            "time": time,
            "max_abs_Ve": float(diagnostic[0]),
            "fields": {
                name: {"wall": float(values[0]), "bulk": float(values[1])}
                for name, values in zip(FIELDS, high_pass)
            },
        })
    result: dict[str, object] = {"checkpoint_count": len(records), "fields": {}}
    for name in FIELDS:
        wall = np.asarray([record["fields"][name]["wall"] for record in records])
        bulk = np.asarray([record["fields"][name]["bulk"] for record in records])
        peak = int(np.argmax(wall))
        result["fields"][name] = {
            "first_step": int(records[0]["step"]),
            "first_wall": float(wall[0]),
            "final_wall": float(wall[-1]),
            "peak_wall": float(wall[peak]),
            "peak_wall_step": int(records[peak]["step"]),
            "final_over_peak_wall": finite_ratio(float(wall[-1]), float(wall[peak])),
            "final_bulk": float(bulk[-1]),
            "late_samples": {
                str(record["step"]): {"wall": float(wall[index]), "bulk": float(bulk[index])}
                for index, record in enumerate(records)
                if int(record["step"]) in (600, 700, 750, 775, 800)
            },
        }
    return result


def rhs_audit() -> dict[str, object]:
    with np.load(FULL, allow_pickle=False) as data:
        times = np.asarray(data["rhs_term_times"], dtype=np.float64)
        statistics = np.asarray(data["rhs_term_statistics"], dtype=np.float64)
        fields = json.loads(str(data["rhs_term_field_names_json"].item()))
        terms = json.loads(str(data["rhs_term_names_json"].item()))
        statistic_names = json.loads(str(data["rhs_term_statistic_names_json"].item()))
    rms_index = statistic_names.index("volume_weighted_rms")
    max_index = statistic_names.index("maximum_absolute")
    result: dict[str, object] = {"fields": {}}
    for field_index, field in enumerate(fields):
        field_result: dict[str, object] = {}
        for term_index, term in enumerate(terms[field]):
            rms = statistics[:, rms_index, field_index, term_index]
            maximum = statistics[:, max_index, field_index, term_index]
            peak_step = int(np.nanargmax(rms))
            field_result[term] = {
                "initial_rms": float(rms[0]),
                "final_rms": float(rms[-1]),
                "peak_rms": float(rms[peak_step]),
                "peak_rms_step": peak_step,
                "peak_rms_time": float(times[peak_step]),
                "final_maximum_absolute": float(maximum[-1]),
                "final_over_peak_rms": finite_ratio(float(rms[-1]), float(rms[peak_step])),
            }
        result["fields"][field] = field_result
    return result


def old_signature_audit(fields: dict[str, np.ndarray]) -> dict[str, object]:
    pairs = {
        "scaled_eta21": ((63, 62, 28), (63, 63, 28)),
        "scaled_eta22": ((63, 62, 29), (63, 63, 29)),
    }
    result: dict[str, object] = {}
    for label, (left, right) in pairs.items():
        result[label] = {
            name: {
                "left": float(field[left]),
                "right": float(field[right]),
                "contrast": float(field[left] - field[right]),
            }
            for name, field in fields.items()
        }
    return result


checkpoint, final_fields = checkpoint_audit()
result = {
    "run": str(RUN),
    "checkpoint": checkpoint,
    "full_history": full_history_audit(),
    "saved_grid_history": saved_grid_history_audit(),
    "rhs_terms": rhs_audit(),
    "old_failure_signature_scaled_cells": old_signature_audit(final_fields),
    "comparison_48_final": history_final_frame_summary(FULL48),
}
OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
print(OUTPUT)
