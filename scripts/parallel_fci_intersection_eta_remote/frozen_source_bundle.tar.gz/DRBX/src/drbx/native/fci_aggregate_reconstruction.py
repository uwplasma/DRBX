"""Opt-in aggregate reconstruction for the isolated FCI conduction study.

The production FCI operators retain their ordinary mapped stencil by default.
This module provides the small bridge needed by the conduction experiment:
host-built quadratic aggregate rows are evaluated in JAX and can replace the
field values at a source cell and its two mapped endpoints.  Coefficient
fields, connection lengths, and physical-wall rows remain on the native path.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import jax
import jax.numpy as jnp
import numpy as np

from ..geometry.fci_aggregate_reconstruction import (
    AggregateGeometry,
    AggregateEvaluation,
    build_aggregate_evaluation,
)


def _as_1d_array(value: Any, dtype: Any, name: str) -> np.ndarray:
    result = np.asarray(value, dtype=dtype).reshape(-1)
    if result.ndim != 1:
        raise ValueError(f"{name} must be one-dimensional")
    return result


def _pack_evaluation(
    evaluation: AggregateEvaluation,
    row_ids: np.ndarray,
    n_rows: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Convert a variable-width CSR evaluation into JAX scatter rows."""

    matrix = evaluation.matrix.tocsr()
    row_ids = _as_1d_array(row_ids, np.int32, "row_ids")
    if matrix.shape[0] != row_ids.size:
        raise ValueError(
            "evaluation row count must equal row_ids size; "
            f"got {matrix.shape[0]} and {row_ids.size}"
        )
    if np.any(row_ids < 0) or np.any(row_ids >= n_rows):
        raise ValueError("evaluation row_ids contain an out-of-range row")
    # CSR rows may have different donor counts because the host builder
    # expands unstable rows.  Explicit row IDs preserve that adaptive shape.
    counts = np.diff(matrix.indptr).astype(np.int32, copy=False)
    expanded_rows = np.repeat(row_ids, counts)
    return (
        expanded_rows,
        np.asarray(matrix.indices, dtype=np.int32),
        np.asarray(matrix.data, dtype=np.float64),
    )


def _evaluation_diagnostics(evaluation: AggregateEvaluation) -> dict[str, Any]:
    """Return compact JSON-friendly diagnostics for driver metadata."""

    diag = evaluation.diagnostics
    counts = np.asarray(diag.donor_counts, dtype=np.int64)
    return {
        "rows": int(counts.size),
        "degree": int(diag.degree),
        "basis_size": int(diag.basis_size),
        "donor_count_initial": int(diag.initial_donor_count),
        "donor_count_max": int(np.max(counts)) if counts.size else 0,
        "donor_histogram": {
            str(int(k)): int(v)
            for k, v in zip(*np.unique(counts, return_counts=True))
        },
        "max_condition": float(diag.max_condition),
        "max_reproduction_residual": float(diag.max_reproduction_residual),
        "max_l1_norm": float(diag.max_l1_norm),
        "rank_deficient_count": int(diag.rank_deficient_count),
        "ill_conditioned_count": int(diag.ill_conditioned_count),
        "reproduction_failure_count": int(diag.reproduction_failure_count),
        "l1_exceeded_count": int(diag.l1_exceeded_count),
    }


@jax.tree_util.register_pytree_node_class
@dataclass(frozen=True)
class AggregateConductionReconstruction:
    """Prebuilt aggregate rows and their eligible two-sided interior mask.

    The sparse columns index ``owner_flat_ids`` rather than the full fine
    storage array.  ``*_row_ids`` and the corresponding indices/weights are
    flattened CSR rows; duplicate entries are allowed and are accumulated by
    the JAX scatter.  Endpoint rows can be a selected subset of the full
    field shape.  This is useful for retaining native wall closure on every
    row where a two-sided mapped endpoint is unavailable.
    """

    shape: tuple[int, int, int]
    owner_flat_ids: np.ndarray
    source_row_ids: np.ndarray
    source_indices: np.ndarray
    source_weights: np.ndarray
    forward_row_ids: np.ndarray
    forward_indices: np.ndarray
    forward_weights: np.ndarray
    backward_row_ids: np.ndarray
    backward_indices: np.ndarray
    backward_weights: np.ndarray
    two_sided_interior: np.ndarray
    degree: int = 2
    donor_count: int = 32
    max_donor_count: int = 96
    diagnostics: dict[str, Any] | None = None

    def __post_init__(self) -> None:
        shape = tuple(int(v) for v in self.shape)
        if len(shape) != 3 or any(v < 1 for v in shape):
            raise ValueError("shape must contain three positive dimensions")
        n_rows = int(np.prod(shape))
        owners = _as_1d_array(self.owner_flat_ids, np.int32, "owner_flat_ids")
        if owners.size == 0 or np.any(owners < 0) or np.any(np.diff(owners) <= 0):
            raise ValueError("owner_flat_ids must be nonempty and strictly sorted")
        object.__setattr__(self, "shape", shape)
        object.__setattr__(self, "owner_flat_ids", owners)

        for prefix in ("source", "forward", "backward"):
            rows = _as_1d_array(getattr(self, f"{prefix}_row_ids"), np.int32, f"{prefix}_row_ids")
            indices = _as_1d_array(getattr(self, f"{prefix}_indices"), np.int32, f"{prefix}_indices")
            weights = _as_1d_array(getattr(self, f"{prefix}_weights"), np.float64, f"{prefix}_weights")
            if rows.size != indices.size or rows.size != weights.size:
                raise ValueError(f"{prefix} sparse arrays must have equal lengths")
            if np.any(rows < 0) or np.any(rows >= n_rows):
                raise ValueError(f"{prefix}_row_ids contain an out-of-range row")
            if np.any(indices < 0) or np.any(indices >= owners.size):
                raise ValueError(f"{prefix}_indices contain an out-of-range owner")
            if not np.all(np.isfinite(weights)):
                raise ValueError(f"{prefix}_weights must be finite")
            object.__setattr__(self, f"{prefix}_row_ids", rows)
            object.__setattr__(self, f"{prefix}_indices", indices)
            object.__setattr__(self, f"{prefix}_weights", weights)

        interior = np.asarray(self.two_sided_interior, dtype=bool)
        if interior.shape != shape:
            raise ValueError(
                "two_sided_interior must match reconstruction shape; "
                f"got {interior.shape}, expected {shape}"
            )
        object.__setattr__(self, "two_sided_interior", interior.reshape(-1))
        for name in ("degree", "donor_count", "max_donor_count"):
            value = int(getattr(self, name))
            if value < 1:
                raise ValueError(f"{name} must be positive")
            object.__setattr__(self, name, value)
        if self.diagnostics is not None:
            object.__setattr__(self, "diagnostics", dict(self.diagnostics))

    def tree_flatten(self):
        # Keep geometry rows as dynamic leaves so shard_map/jit can place them
        # on the same device as the owner values.  Shape and build settings are
        # static metadata and do not affect runtime arithmetic.
        names = (
            "owner_flat_ids", "source_row_ids", "source_indices", "source_weights",
            "forward_row_ids", "forward_indices", "forward_weights",
            "backward_row_ids", "backward_indices", "backward_weights",
            "two_sided_interior",
        )
        return tuple(jnp.asarray(getattr(self, name)) for name in names), (
            self.shape, self.degree, self.donor_count, self.max_donor_count,
            self.diagnostics,
        )

    @classmethod
    def tree_unflatten(cls, aux_data, children):
        shape, degree, donor_count, max_donor_count, diagnostics = aux_data
        # JAX may hand us tracers here.  Re-running the host-side NumPy
        # validation in ``__post_init__`` would attempt to materialize those
        # tracers, so unflatten installs the already-validated tree leaves
        # directly.
        obj = object.__new__(cls)
        object.__setattr__(obj, "shape", shape)
        names = (
            "owner_flat_ids", "source_row_ids", "source_indices", "source_weights",
            "forward_row_ids", "forward_indices", "forward_weights",
            "backward_row_ids", "backward_indices", "backward_weights",
            "two_sided_interior",
        )
        for name, value in zip(names, children):
            object.__setattr__(obj, name, value)
        object.__setattr__(obj, "degree", degree)
        object.__setattr__(obj, "donor_count", donor_count)
        object.__setattr__(obj, "max_donor_count", max_donor_count)
        object.__setattr__(obj, "diagnostics", diagnostics)
        return obj

    @property
    def n_rows(self) -> int:
        return int(np.prod(self.shape))

    @property
    def n_owner(self) -> int:
        return int(self.owner_flat_ids.size)

    def metadata(self) -> dict[str, Any]:
        """Return host diagnostics suitable for run metadata JSON."""

        return {
            "shape": [int(v) for v in self.shape],
            "owner_count": self.n_owner,
            "two_sided_interior_rows": int(np.sum(np.asarray(self.two_sided_interior))),
            "degree": self.degree,
            "initial_donor_count": self.donor_count,
            "max_donor_count": self.max_donor_count,
            "diagnostics": self.diagnostics or {},
        }

    def _evaluate_rows(
        self,
        values_owned: jnp.ndarray,
        row_ids: np.ndarray,
        indices: np.ndarray,
        weights: np.ndarray,
    ) -> jnp.ndarray:
        values = jnp.asarray(values_owned, dtype=jnp.float64)
        if values.shape != self.shape:
            raise ValueError(
                "owner values must match reconstruction shape; "
                f"got {values.shape}, expected {self.shape}"
            )
        compact = values.reshape(-1)[jnp.asarray(self.owner_flat_ids)]
        contributions = jnp.asarray(weights) * compact[jnp.asarray(indices)]
        result = jnp.zeros((self.n_rows,), dtype=values.dtype)
        result = result.at[jnp.asarray(row_ids)].add(contributions)
        return result.reshape(self.shape)

    def source(self, values_owned: jnp.ndarray) -> jnp.ndarray:
        return self._evaluate_rows(
            values_owned, self.source_row_ids, self.source_indices, self.source_weights
        )

    def endpoint(self, values_owned: jnp.ndarray, direction: str) -> jnp.ndarray:
        if direction == "forward":
            arrays = (self.forward_row_ids, self.forward_indices, self.forward_weights)
        elif direction == "backward":
            arrays = (self.backward_row_ids, self.backward_indices, self.backward_weights)
        else:
            raise ValueError("direction must be 'forward' or 'backward'")
        return self._evaluate_rows(values_owned, *arrays)

    def replace_field_stencil(
        self,
        values_owned: jnp.ndarray,
        native_stencil: Any,
        eligible_mask: jnp.ndarray | None = None,
    ) -> Any:
        """Replace source/endpoints on eligible rows of a native FCI stencil."""

        source = self.source(values_owned)
        forward = self.endpoint(values_owned, "forward")
        backward = self.endpoint(values_owned, "backward")
        mask = jnp.asarray(self.two_sided_interior).reshape(self.shape)
        if eligible_mask is not None:
            eligible_mask = jnp.asarray(eligible_mask, dtype=bool)
            if eligible_mask.shape != self.shape:
                raise ValueError(
                    "eligible_mask must match reconstruction shape; "
                    f"got {eligible_mask.shape}, expected {self.shape}"
                )
            mask = mask & eligible_mask
        return native_stencil.replace(
            center=jnp.where(mask, source, native_stencil.center),
            minus=jnp.where(mask, backward, native_stencil.minus),
            plus=jnp.where(mask, forward, native_stencil.plus),
        )


def build_conduction_reconstruction(
    geometry: Any,
    owner_host_geometry: Any,
    *,
    degree: int = 2,
    donor_count: int = 32,
    max_donor_count: int = 96,
    condition_limit: float = 1.0e8,
    weight_power: float = 4.0,
    chunk_size: int = 1024,
    row_l1_limit: float = 8.0,
) -> AggregateConductionReconstruction:
    """Build all source/endpoint rows for the two-sided conduction lane.

    This is host preprocessing.  It is intentionally restricted to one
    complete owned shape: the conduction experiment currently runs one
    eta-shard, and global owner IDs cannot be interpreted as local IDs on a
    partial shard without a separate exchange contract.
    """

    if int(degree) != degree or int(degree) != 2:
        raise ValueError("conduction reconstruction currently requires degree=2")
    shape = tuple(int(v) for v in geometry.shape)
    topology = owner_host_geometry.topology
    if tuple(int(v) for v in topology.shape) != shape:
        raise ValueError("owner geometry and FCI geometry must have the same shape")
    if getattr(geometry, "maps", None) is None:
        raise ValueError("FCI geometry must provide mapped endpoints")

    active = np.asarray(topology.is_active_owner, dtype=bool)
    owner_flat_ids = np.flatnonzero(active.reshape(-1)).astype(np.int32)
    if owner_flat_ids.size >= int(np.prod(shape)):
        raise ValueError(
            "aggregate conduction reconstruction requires at least one merged owner"
        )
    owner_plane = np.unravel_index(owner_flat_ids, shape)[-1].astype(np.int64)
    aggregate_geometry = AggregateGeometry(
        owner_flat_ids=owner_flat_ids,
        owner_plane=owner_plane,
        volumes=np.asarray(owner_host_geometry.aggregate_chart_volume).reshape(-1)[owner_flat_ids],
        centroid_xy=np.asarray(owner_host_geometry.aggregate_chart_centroid).reshape((-1, 3))[owner_flat_ids, :2],
        central_second_xy=np.asarray(owner_host_geometry.aggregate_chart_second_moment).reshape((-1, 3, 3))[owner_flat_ids, :2, :2],
        central_third_xy=np.asarray(owner_host_geometry.aggregate_chart_third_moment).reshape((-1, 3, 3, 3))[owner_flat_ids, :2, :2, :2],
    )

    u = np.asarray(geometry.grid.x.centers, dtype=np.float64)[:, None, None]
    theta = np.asarray(geometry.grid.y.centers, dtype=np.float64)[None, :, None]
    eta = np.broadcast_to(np.arange(shape[2], dtype=np.int64)[None, None, :], shape)
    source_points = np.stack(
        (np.broadcast_to(u * np.cos(theta), shape), np.broadcast_to(u * np.sin(theta), shape)),
        axis=-1,
    ).reshape((-1, 2))
    source_rows = np.arange(int(np.prod(shape)), dtype=np.int32)
    source_eval = build_aggregate_evaluation(
        aggregate_geometry, source_points, eta.reshape(-1), degree=degree,
        donor_count=donor_count, max_donor_count=max_donor_count,
        condition_limit=condition_limit, weight_power=weight_power,
        chunk_size=chunk_size, row_l1_limit=row_l1_limit,
    )

    maps = geometry.maps
    nx, ny, nz = shape
    radial_valid = {}
    for direction in ("forward", "backward"):
        mapped_x = np.asarray(
            getattr(maps, f"{direction}_x"), dtype=np.float64
        )
        radial_valid[direction] = (
            np.floor(mapped_x).astype(np.int64) >= 0
        ) & (np.floor(mapped_x).astype(np.int64) < nx - 1)
    endpoint_valid = {
        direction: (~np.asarray(getattr(maps, f"{direction}_boundary"), dtype=bool))
        & radial_valid[direction]
        for direction in ("forward", "backward")
    }
    two_sided = endpoint_valid["forward"] & endpoint_valid["backward"]
    endpoint_rows = np.flatnonzero(two_sided.reshape(-1)).astype(np.int32)
    z_centers = np.asarray(geometry.grid.z.centers, dtype=np.float64)
    z_faces = np.asarray(geometry.grid.z.faces, dtype=np.float64)
    z_period = float(z_faces[-1] - z_faces[0])
    if z_centers.shape != (nz,) or not np.isfinite(z_period) or z_period <= 0.0:
        raise ValueError("geometry eta grid must provide a positive finite period")

    def destination_plane(direction: str, rows: np.ndarray) -> np.ndarray:
        z = np.asarray(
            getattr(maps, f"{direction}_endpoint_z"), dtype=np.float64
        ).reshape(-1)[rows]
        distance = np.abs(
            (z[:, None] - z_centers[None, :] + 0.5 * z_period) % z_period
            - 0.5 * z_period
        )
        plane = np.argmin(distance, axis=1).astype(np.int64)
        tolerance = max(1.0e-10, 1.0e-8 * float(np.min(np.diff(z_centers))))
        if np.any(np.min(distance, axis=1) > tolerance):
            raise ValueError(
                f"{direction} endpoint z coordinates are not on destination eta planes"
            )
        return plane

    endpoints: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
    endpoint_diagnostics: dict[str, dict[str, Any]] = {}
    for direction in ("forward", "backward"):
        u_endpoint = np.asarray(getattr(maps, f"{direction}_endpoint_x"), dtype=np.float64).reshape(-1)[endpoint_rows]
        theta_endpoint = np.asarray(getattr(maps, f"{direction}_endpoint_y"), dtype=np.float64).reshape(-1)[endpoint_rows]
        points = np.column_stack((u_endpoint * np.cos(theta_endpoint), u_endpoint * np.sin(theta_endpoint)))
        evaluation = build_aggregate_evaluation(
            aggregate_geometry, points, destination_plane(direction, endpoint_rows), degree=degree,
            donor_count=donor_count, max_donor_count=max_donor_count,
            condition_limit=condition_limit, weight_power=weight_power,
            chunk_size=chunk_size, row_l1_limit=row_l1_limit,
        )
        endpoint_diagnostics[direction] = _evaluation_diagnostics(evaluation)
        endpoints[direction] = _pack_evaluation(evaluation, endpoint_rows, source_rows.size)

    source_packed = _pack_evaluation(source_eval, source_rows, source_rows.size)
    return AggregateConductionReconstruction(
        shape=shape, owner_flat_ids=owner_flat_ids,
        source_row_ids=source_packed[0], source_indices=source_packed[1], source_weights=source_packed[2],
        forward_row_ids=endpoints["forward"][0], forward_indices=endpoints["forward"][1], forward_weights=endpoints["forward"][2],
        backward_row_ids=endpoints["backward"][0], backward_indices=endpoints["backward"][1], backward_weights=endpoints["backward"][2],
        two_sided_interior=two_sided, degree=degree, donor_count=donor_count,
        max_donor_count=max_donor_count,
        diagnostics={
            "source": _evaluation_diagnostics(source_eval),
            "forward": endpoint_diagnostics["forward"],
            "backward": endpoint_diagnostics["backward"],
        },
    )


def local_parallel_diffusion_fci_aggregate_op(
    field_halo_full: jnp.ndarray,
    owner_values: jnp.ndarray,
    geometry: Any,
    reconstruction: AggregateConductionReconstruction,
    *,
    context: Any,
    diffusivity_halo_full: jnp.ndarray | None = None,
    inverse_b_halo_full: jnp.ndarray | None = None,
    b_floor: float = 1.0e-30,
    fci_stencil_builder: Any = None,
    forward_remote_values: jnp.ndarray | None = None,
    backward_remote_values: jnp.ndarray | None = None,
    forward_remote_diffusivity_values: jnp.ndarray | None = None,
    backward_remote_diffusivity_values: jnp.ndarray | None = None,
    forward_remote_inverse_b_values: jnp.ndarray | None = None,
    backward_remote_inverse_b_values: jnp.ndarray | None = None,
) -> jnp.ndarray:
    """Evaluate native FCI diffusion with opt-in aggregate field sampling.

    The native mapped field stencil is prepared first, including its wall
    values.  Only rows valid in both the host endpoint audit and the local FCI
    target-valid masks receive aggregate source/endpoint values.  The native
    diffusion helper then computes all connection lengths and coefficient
    averages unchanged.
    """

    if tuple(int(v) for v in geometry.owned_shape) != reconstruction.shape:
        raise ValueError("reconstruction shape must match local geometry owned_shape")
    from .fci_operators import (
        _build_mapped_stencil,
        build_local_fci_stencil_from_field,
        local_parallel_diffusion_fci_op,
    )
    stencil_builder = (
        build_local_fci_stencil_from_field
        if fci_stencil_builder is None else fci_stencil_builder
    )

    native_stencil = _build_mapped_stencil(
        jnp.asarray(field_halo_full, dtype=jnp.float64), geometry, context,
        fci_stencil_builder=stencil_builder,
        forward_remote_values=forward_remote_values,
        backward_remote_values=backward_remote_values,
        cut_wall_values=None,
        forward_cut_wall_values=None,
        backward_cut_wall_values=None,
    )
    native_valid = (
        jnp.asarray(geometry.maps.forward.target_valid, dtype=bool)
        & jnp.asarray(geometry.maps.backward.target_valid, dtype=bool)
    )
    prepared = reconstruction.replace_field_stencil(
        owner_values, native_stencil, eligible_mask=native_valid
    )
    return local_parallel_diffusion_fci_op(
        field_halo_full,
        geometry,
        context=context,
        diffusivity_halo_full=diffusivity_halo_full,
        inverse_b_halo_full=inverse_b_halo_full,
        b_floor=b_floor,
        fci_stencil_builder=stencil_builder,
        forward_remote_values=forward_remote_values,
        backward_remote_values=backward_remote_values,
        forward_remote_diffusivity_values=forward_remote_diffusivity_values,
        backward_remote_diffusivity_values=backward_remote_diffusivity_values,
        forward_remote_inverse_b_values=forward_remote_inverse_b_values,
        backward_remote_inverse_b_values=backward_remote_inverse_b_values,
        prepared_field_stencil=prepared,
    )


__all__ = [
    "AggregateConductionReconstruction",
    "build_conduction_reconstruction",
    "local_parallel_diffusion_fci_aggregate_op",
]
