"""Experimental conservative owner-to-raw cell-average reconstruction.

The builder in this module is deliberately separate from the production RLP
builder.  It constructs a host-side sparse map ``H`` whose rows are raw-cell
averages and whose columns are compact aggregate-owner averages.  Quadratic
polynomial moments are fitted in the planar ``(X, Y)`` chart, with donors
restricted to the target eta plane.  A volume-weighted correction enforces
``R H = I`` coefficientwise after fitting.

This is a conduction-reconstruction primitive.  It does not claim a wall
closure, a sharding implementation, or global FCI conservation by itself.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

import jax
import jax.numpy as jnp
import numpy as np
from scipy.sparse import csr_matrix, eye
from scipy.spatial import cKDTree


_BASIS_SIZE = 6
_SVD_CUTOFF = 1.0e-12
_REPRODUCTION_TOL = 1.0e-9


def _get(value: Any, *names: str) -> Any:
    for name in names:
        if isinstance(value, Mapping) and name in value:
            return value[name]
        if hasattr(value, name):
            return getattr(value, name)
    raise KeyError(f"none of {names!r} found in geometry payload")


def _array(value: Any, name: str, dtype: Any = np.float64) -> np.ndarray:
    result = np.asarray(value, dtype=dtype)
    if not np.all(np.isfinite(result)):
        raise ValueError(f"{name} must be finite")
    return result


def _quadratic_basis(centroid: np.ndarray, second: np.ndarray, *, origin: np.ndarray, scale: np.ndarray) -> np.ndarray:
    """Return averages of [1,x,y,x²,xy,y²] in scaled local coordinates."""

    centroid = np.asarray(centroid, dtype=np.float64)
    second = np.asarray(second, dtype=np.float64)
    displacement = centroid - np.asarray(origin, dtype=np.float64)
    xi = displacement / np.asarray(scale, dtype=np.float64)
    raw_second = second + displacement[..., :, None] * displacement[..., None, :]
    return np.stack(
        (
            np.ones(xi.shape[:-1]),
            xi[..., 0],
            xi[..., 1],
            raw_second[..., 0, 0] / scale[0] ** 2,
            raw_second[..., 0, 1] / (scale[0] * scale[1]),
            raw_second[..., 1, 1] / scale[1] ** 2,
        ),
        axis=-1,
    )


def _fit_weights(observation: np.ndarray, target: np.ndarray, donor_xy: np.ndarray, target_xy: np.ndarray, condition_limit: float) -> tuple[np.ndarray, float, float]:
    """Minimum-distance weighted quadratic fit using an SVD pseudoinverse."""

    displacement = donor_xy - target_xy[None, :]
    distance2 = np.einsum("ni,ni->n", displacement, displacement)
    positive = distance2[distance2 > 1.0e-28]
    floor = 0.25 * float(np.min(positive)) if positive.size else 1.0
    weights = 1.0 / np.maximum(distance2, floor)
    sqrt_weights = np.sqrt(weights)
    weighted = sqrt_weights[:, None] * observation
    singular = np.linalg.svd(weighted, compute_uv=False)
    tolerance = _SVD_CUTOFF * singular[0] if singular.size else np.inf
    rank = int(np.count_nonzero(singular > tolerance))
    if rank < _BASIS_SIZE:
        raise ValueError(f"quadratic donor fit is rank deficient: rank={rank}")
    condition = float(singular[0] / singular[_BASIS_SIZE - 1])
    if not np.isfinite(condition) or condition > condition_limit:
        raise ValueError(f"quadratic donor fit is ill conditioned: condition={condition:.6g}")
    inverse = np.linalg.pinv(weighted, rcond=_SVD_CUTOFF)
    fitted = (target @ inverse) * sqrt_weights[None, :]
    residual = float(np.max(np.abs(fitted @ observation - target)))
    if not np.isfinite(residual) or residual > _REPRODUCTION_TOL:
        raise ValueError(f"quadratic donor fit residual is too large: {residual:.6g}")
    return fitted, condition, residual


def _compact_owner_payload(geometry: Any, owner_host_geometry: Any | None) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Extract compact owners and planar moments from either host payload form."""

    host = geometry if owner_host_geometry is None else owner_host_geometry
    topology = None
    try:
        topology = _get(host, "topology")
    except KeyError:
        pass

    try:
        owner_flat_ids = _array(_get(geometry, "owner_flat_ids"), "owner_flat_ids", np.int64).reshape(-1)
        owner_plane = _array(_get(geometry, "owner_plane"), "owner_plane", np.int64).reshape(-1)
        owner_centroid = _array(_get(geometry, "centroid_xy", "owner_centroid_xy"), "owner centroid").reshape((-1, 2))
        owner_second = _array(_get(geometry, "central_second_xy", "owner_second_moment_xy"), "owner second moment").reshape((-1, 2, 2))
    except KeyError:
        if topology is None:
            try:
                _get(host, "topology_is_active_owner")
            except KeyError as error:
                raise ValueError("geometry must provide compact owners or a host topology") from error
        try:
            active_source = _get(topology, "is_active_owner") if topology is not None else _get(host, "topology_is_active_owner")
        except KeyError:
            active_source = _get(host, "topology_is_active_owner")
        active = _array(active_source, "is_active_owner", bool)
        owner_flat_ids = np.flatnonzero(active.reshape(-1))
        shape = active.shape
        owner_plane = np.unravel_index(owner_flat_ids, shape)[-1].astype(np.int64)
        owner_centroid = _array(_get(host, "aggregate_chart_centroid", "aggregate_centroid", "host_aggregate_chart_centroid"), "aggregate centroid").reshape(shape + (3,)).reshape((-1, 3))[owner_flat_ids, :2]
        owner_second = _array(_get(host, "aggregate_chart_second_moment", "aggregate_second_moment", "host_aggregate_chart_second_moment"), "aggregate second moment").reshape(shape + (3, 3)).reshape((-1, 3, 3))[owner_flat_ids, :2, :2]
    count = owner_flat_ids.size
    if owner_plane.shape != (count,) or owner_centroid.shape != (count, 2) or owner_second.shape != (count, 2, 2):
        raise ValueError("compact owner arrays have incompatible shapes")
    if count == 0 or np.any(owner_flat_ids < 0) or np.any(np.diff(owner_flat_ids) <= 0):
        raise ValueError("owner_flat_ids must be nonempty and strictly sorted")
    if np.any(owner_plane < 0) or np.any(~np.isfinite(owner_centroid)) or np.any(~np.isfinite(owner_second)):
        raise ValueError("owner plane and moments must be finite and valid")
    return owner_flat_ids, owner_plane, owner_centroid, owner_second, np.asarray(owner_flat_ids)


def _raw_payload(host: Any, shape: tuple[int, int, int]) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    raw_volume = _array(_get(host, "raw_volume", "host_raw_volume"), "raw_volume").reshape(shape)
    try:
        raw_centroid = _array(_get(host, "raw_chart_centroid", "raw_centroid", "host_raw_chart_centroid"), "raw centroid").reshape(shape + (3,))[..., :2]
    except KeyError:
        raw_centroid = _array(_get(host, "raw_centroid_xy"), "raw centroid").reshape(shape + (2,))
    try:
        raw_second = _array(_get(host, "raw_chart_second_moment", "raw_second_moment", "host_raw_chart_second_moment"), "raw second moment").reshape(shape + (3, 3))[..., :2, :2]
    except KeyError:
        raw_second = _array(_get(host, "raw_second_moment_xy"), "raw second moment").reshape(shape + (2, 2))
    aggregate_id = None
    try:
        aggregate_id = _array(_get(_get(host, "topology"), "aggregate_id"), "aggregate_id", np.int64)
    except KeyError:
        try:
            aggregate_id = _array(_get(host, "topology_aggregate_id"), "aggregate_id", np.int64)
        except KeyError:
            pass
    if aggregate_id is None:
        raise ValueError("owner_host_geometry must provide topology aggregate_id")
    if aggregate_id.shape != shape:
        aggregate_id = aggregate_id.reshape(shape)
    if np.any(raw_volume <= 0.0):
        raise ValueError("raw_volume must be strictly positive")
    return raw_volume, raw_centroid, raw_second, aggregate_id


@jax.tree_util.register_pytree_node_class
@dataclass(frozen=True)
class ConservativeConductionReconstruction:
    """JAX sparse payload for conservative owner-to-raw average prolongation."""

    raw_row_flat: jax.Array
    row_ptr: jax.Array
    owner_cols: jax.Array
    weights: jax.Array
    raw_owner_slot: jax.Array
    owner_flat_ids: jax.Array
    raw_volume: jax.Array
    owner_volume: jax.Array
    raw_shape: tuple[int, int, int]
    _metadata: dict[str, Any]

    @property
    def raw_rows(self) -> jax.Array:
        return self.raw_row_flat

    @property
    def nnz(self) -> int:
        return int(self.owner_cols.shape[0])

    @property
    def n_owner(self) -> int:
        return int(self.owner_flat_ids.shape[0])

    @property
    def shape(self) -> tuple[int, int, int]:
        return self.raw_shape

    @property
    def matrix_shape(self) -> tuple[int, int]:
        return (int(np.prod(self.raw_shape)), self.n_owner)

    @property
    def owner_count(self) -> int:
        return self.n_owner

    @property
    def H(self) -> csr_matrix:
        """Host CSR view of the sparse map."""

        return csr_matrix((np.asarray(self.weights), np.asarray(self.owner_cols), np.asarray(self.row_ptr)), shape=(int(np.prod(self.raw_shape)), self.n_owner))

    def tree_flatten(self):
        return (self.raw_row_flat, self.row_ptr, self.owner_cols, self.weights, self.raw_owner_slot, self.owner_flat_ids, self.raw_volume, self.owner_volume), (self.raw_shape, self._metadata)

    @classmethod
    def tree_unflatten(cls, aux, children):
        raw_shape, metadata = aux
        return cls(*children, raw_shape, metadata)

    def metadata(self) -> dict[str, Any]:
        return dict(self._metadata)

    def _compact_values(self, owner_values: jax.Array) -> jax.Array:
        values = jnp.asarray(owner_values)
        if tuple(values.shape[:3]) == self.raw_shape:
            return values.reshape((int(np.prod(self.raw_shape)),) + values.shape[3:])[self.owner_flat_ids]
        if values.shape[0] == self.n_owner:
            return values
        raise ValueError(f"owner_values must have leading shape {self.raw_shape} or ({self.n_owner},)")

    def prolong(self, owner_values: jax.Array) -> jax.Array:
        """Apply H to compact or cell-shaped owner values."""

        compact = self._compact_values(owner_values)
        gathered = compact[self.owner_cols]
        trailing = (1,) * (compact.ndim - 1)
        contribution = gathered * self.weights.reshape(self.weights.shape + trailing)
        result = jnp.zeros((int(np.prod(self.raw_shape)),) + compact.shape[1:], dtype=jnp.result_type(compact, self.weights))
        result = result.at[self.raw_row_flat].add(contribution)
        return result.reshape(self.raw_shape + compact.shape[1:])

    def return_residual(self, fine_rhs: jax.Array, mode: str = "adjoint") -> jax.Array:
        """Restrict a fine RHS with the mass adjoint or volume restriction."""

        rhs = jnp.asarray(fine_rhs)
        if tuple(rhs.shape[:3]) != self.raw_shape:
            raise ValueError(f"fine_rhs must have leading shape {self.raw_shape}")
        flat = rhs.reshape((int(np.prod(self.raw_shape)),) + rhs.shape[3:])
        if mode == "adjoint":
            contribution = flat[self.raw_row_flat] * self.raw_volume[self.raw_row_flat].reshape((-1,) + (1,) * (flat.ndim - 1))
            contribution = contribution * self.weights.reshape(self.weights.shape + (1,) * (flat.ndim - 1))
            compact = jnp.zeros((self.n_owner,) + flat.shape[1:], dtype=jnp.result_type(rhs, self.weights))
            compact = compact.at[self.owner_cols].add(contribution)
            compact = compact / self.owner_volume.reshape((self.n_owner,) + (1,) * (flat.ndim - 1))
        elif mode == "volume":
            contribution = flat * self.raw_volume.reshape((-1,) + (1,) * (flat.ndim - 1))
            compact = jnp.zeros((self.n_owner,) + flat.shape[1:], dtype=jnp.result_type(rhs, self.raw_volume))
            compact = compact.at[self.raw_owner_slot].add(contribution)
            compact = compact / self.owner_volume.reshape((self.n_owner,) + (1,) * (flat.ndim - 1))
        else:
            raise ValueError("mode must be 'adjoint' or 'volume'")
        result = jnp.zeros((int(np.prod(self.raw_shape)),) + compact.shape[1:], dtype=compact.dtype)
        result = result.at[self.owner_flat_ids].set(compact)
        return result.reshape(self.raw_shape + compact.shape[1:])


def build_conservative_conduction_reconstruction(
    geometry: Any,
    owner_host_geometry: Any | None = None,
    *,
    degree: int = 2,
    donor_count: int = 32,
    max_donor_count: int = 96,
    condition_limit: float = 1.0e8,
    row_l1_limit: float = 8.0,
) -> ConservativeConductionReconstruction:
    """Build a conservative quadratic owner-to-raw-cell-average map.

    ``geometry`` may be the compact :class:`AggregateGeometry` payload or a
    full host agglomeration geometry.  ``owner_host_geometry`` supplies raw
    cell volumes/moments when the first argument is compact.  Donors are
    selected and fitted independently in each eta plane, with adaptive
    planar counts 32, 48, 64, and 96 (capped by the available owners).
    """

    if int(degree) != 2:
        raise ValueError("only quadratic degree=2 is supported")
    donor_count, max_donor_count = int(donor_count), int(max_donor_count)
    if donor_count < _BASIS_SIZE or max_donor_count < donor_count:
        raise ValueError("donor counts must span the quadratic basis")
    condition_limit, row_l1_limit = float(condition_limit), float(row_l1_limit)
    if not np.isfinite(condition_limit) or condition_limit <= 1.0:
        raise ValueError("condition_limit must be finite and greater than one")
    if not np.isfinite(row_l1_limit) or row_l1_limit < 1.0:
        raise ValueError("row_l1_limit must be finite and at least one")

    host = geometry if owner_host_geometry is None else owner_host_geometry
    try:
        topology = _get(host, "topology")
        shape = tuple(int(v) for v in _get(topology, "shape"))
    except KeyError:
        shape = tuple(int(v) for v in np.asarray(_get(host, "shape")).reshape(-1))
    if len(shape) != 3 or any(v <= 0 for v in shape):
        raise ValueError("host topology shape must be three positive dimensions")
    owner_flat_ids, owner_plane, owner_centroid, owner_second, _ = _compact_owner_payload(geometry, owner_host_geometry)
    raw_volume, raw_centroid, raw_second, aggregate_id = _raw_payload(host, shape)
    n_raw = int(np.prod(shape)); n_owner = owner_flat_ids.size
    if owner_flat_ids[-1] >= n_raw or np.any(owner_plane >= shape[2]):
        raise ValueError("compact owner geometry does not match host shape")
    owner_slot = np.full(n_raw, -1, dtype=np.int64); owner_slot[owner_flat_ids] = np.arange(n_owner)
    if np.any(aggregate_id < 0) or np.any(aggregate_id >= n_raw):
        raise ValueError("aggregate_id contains an invalid fine-cell index")
    compact_ids = owner_slot[aggregate_id.ravel()]
    if np.any(compact_ids < 0):
        raise ValueError("every raw cell must map to an active compact owner")
    owner_volume = np.bincount(compact_ids, weights=raw_volume.ravel(), minlength=n_owner)
    if np.any(owner_volume <= 0.0) or not np.all(np.isfinite(owner_volume)):
        raise ValueError("owner volumes must be positive and finite")
    if np.any(~np.isfinite(raw_centroid)) or np.any(~np.isfinite(raw_second)):
        raise ValueError("raw moments must be finite")

    # Group rows by compact owner.  The host topology is the authority for
    # aliases; q=1 rows are represented by exact one-column identities.
    sorted_rows = np.argsort(compact_ids, kind="stable")
    sorted_owners = compact_ids[sorted_rows]
    boundaries = np.flatnonzero(np.diff(sorted_owners)) + 1
    members_by_owner = np.split(sorted_rows, boundaries)
    if len(members_by_owner) != n_owner or any(group.size == 0 for group in members_by_owner):
        raise ValueError("compact owners must each have raw members")
    for owner, rows in enumerate(members_by_owner):
        if np.any(rows % shape[2] != owner_plane[owner]):
            raise ValueError("aggregate members must remain in one eta plane")

    row_cols: list[np.ndarray] = []
    row_weights: list[np.ndarray] = []
    conditions: list[float] = []
    residuals: list[float] = []
    l1_values: list[float] = []
    donor_counts_used: list[int] = []
    q1_count = 0
    expanded_count = 0
    trees: dict[int, tuple[cKDTree, np.ndarray]] = {}
    for plane in np.unique(owner_plane):
        indices = np.flatnonzero(owner_plane == plane)
        trees[int(plane)] = (cKDTree(owner_centroid[indices]), indices)

    for owner, rows in enumerate(members_by_owner):
        if rows.size == 1:
            q1_count += 1
            row_cols.append(np.asarray([owner], dtype=np.int64)); row_weights.append(np.asarray([1.0]))
            donor_counts_used.append(1); conditions.append(1.0); residuals.append(0.0); l1_values.append(1.0)
            continue
        plane = int(owner_plane[owner])
        tree, plane_indices = trees[plane]
        available = int(plane_indices.size)
        if available < _BASIS_SIZE:
            raise ValueError(f"eta plane {plane} has only {available} owners; quadratic fit needs {_BASIS_SIZE}")
        target_xy = owner_centroid[owner]
        max_count = min(max_donor_count, available)
        initial = min(donor_count, max_count)
        candidates = [initial]
        for count in (48, 64, 96, max_count):
            if initial <= count <= max_count and count not in candidates:
                candidates.append(count)
        accepted = None
        last_error: Exception | None = None
        for candidate_index, count in enumerate(candidates):
            distances, nearest = tree.query(target_xy, k=count)
            nearest = np.atleast_1d(nearest).astype(np.int64)
            donors = plane_indices[nearest]
            if owner not in donors:
                donors[-1] = owner
            donors = np.unique(donors)
            if donors.size < _BASIS_SIZE:
                last_error = ValueError("quadratic donor set lost distinct owners")
                continue
            donor_xy = owner_centroid[donors]
            displacement = donor_xy - target_xy[None, :]
            scale = np.maximum(np.sqrt(np.mean(displacement * displacement, axis=0)), 1.0e-12)
            observation = _quadratic_basis(donor_xy, owner_second[donors], origin=target_xy, scale=scale)
            target = _quadratic_basis(raw_centroid.reshape(n_raw, 2)[rows], raw_second.reshape(n_raw, 2, 2)[rows], origin=target_xy, scale=scale)
            try:
                fitted, condition, residual = _fit_weights(observation, target, donor_xy, target_xy, condition_limit)
                fitted[:, :] += (1.0 - np.sum(fitted, axis=1))[:, None] / donors.size
                member_alpha = raw_volume.ravel()[rows] / np.sum(raw_volume.ravel()[rows])
                desired = np.zeros(donors.size); desired[np.flatnonzero(donors == owner)[0]] = 1.0
                defect = desired - member_alpha @ fitted
                fitted += defect[None, :]
                # The defect has zero sum, so the first correction remains a
                # constant-reproducing row after RH=I is imposed.
                final_l1 = float(np.max(np.sum(np.abs(fitted), axis=1)))
                final_residual = float(np.max(np.abs(fitted @ observation - target)))
                conservation = float(np.max(np.abs(member_alpha @ fitted - desired)))
                if not np.isfinite(final_l1) or final_l1 > row_l1_limit or final_residual > _REPRODUCTION_TOL or conservation > 1.0e-10:
                    raise ValueError(f"corrected quadratic rows fail bounds: L1={final_l1:.6g}, reproduction={final_residual:.6g}, RH={conservation:.6g}")
                accepted = (donors, fitted, condition, max(residual, final_residual), final_l1)
                if candidate_index > 0:
                    expanded_count += 1
                break
            except ValueError as error:
                last_error = error
        if accepted is None:
            raise ValueError(f"no stable conservative quadratic stencil for owner {owner}: {last_error}")
        donors, fitted, condition, residual, final_l1 = accepted
        for row, row_fit in zip(rows, fitted, strict=True):
            row_cols.append(donors.copy()); row_weights.append(row_fit.copy()); conditions.append(float(condition)); residuals.append(float(residual)); l1_values.append(float(final_l1)); donor_counts_used.append(int(donors.size))

    # Append order above is grouped by owner, while CSR requires rows in flat
    # order.  Reorder through a dense temporary row table once at host build
    # time; the runtime payload itself remains sparse.
    cols_by_row: list[np.ndarray | None] = [None] * n_raw; weights_by_row: list[np.ndarray | None] = [None] * n_raw
    cursor = 0
    row_owner = compact_ids.copy()
    for owner, rows in enumerate(members_by_owner):
        for row in rows:
            cols_by_row[int(row)] = row_cols[cursor]; weights_by_row[int(row)] = row_weights[cursor]; cursor += 1
    if any(cols is None for cols in cols_by_row):
        raise AssertionError("failed to populate every raw row")
    row_ptr = np.zeros(n_raw + 1, dtype=np.int64)
    row_ptr[1:] = np.cumsum([int(cols.size) for cols in cols_by_row if cols is not None])
    owner_cols = np.concatenate([cols for cols in cols_by_row if cols is not None]).astype(np.int32)
    coefficients = np.concatenate([weights for weights in weights_by_row if weights is not None]).astype(np.float64)
    raw_row_flat = np.repeat(np.arange(n_raw, dtype=np.int32), np.diff(row_ptr))
    H = csr_matrix((coefficients, owner_cols, row_ptr), shape=(n_raw, n_owner))
    # Check the actual sparse map, including q=1 identity rows, before JAX
    # lowering.  This is the coefficientwise conservative contract.
    restriction = csr_matrix(
        (raw_volume.ravel() / owner_volume[row_owner], (row_owner, np.arange(n_raw))),
        shape=(n_owner, n_raw),
    ).tocsr() @ H
    defect = restriction - eye(n_owner, format="csr")
    max_conservation_residual = float(np.max(np.abs(defect.data))) if defect.nnz else 0.0
    if max_conservation_residual > 2.0e-12:
        raise ValueError("constructed H fails coefficientwise R H = I")
    metadata = {
        "degree": 2, "donor_count": donor_count, "max_donor_count": max_donor_count,
        "condition_limit": condition_limit, "row_l1_limit": row_l1_limit,
        "shape": shape, "owner_count": int(n_owner), "raw_count": int(n_raw),
        "nnz": int(H.nnz), "q1_identity_count": int(q1_count), "expanded_owner_count": int(expanded_count),
        "max_condition": float(max(conditions)), "max_reproduction_residual": float(max(residuals)),
        "max_l1_norm": float(max(l1_values)), "max_conservation_residual": max_conservation_residual,
        "same_eta_plane": True,
    }
    return ConservativeConductionReconstruction(
        raw_row_flat=jnp.asarray(raw_row_flat, dtype=jnp.int32), row_ptr=jnp.asarray(row_ptr, dtype=jnp.int32),
        owner_cols=jnp.asarray(owner_cols, dtype=jnp.int32), weights=jnp.asarray(coefficients, dtype=jnp.float64), raw_owner_slot=jnp.asarray(row_owner, dtype=jnp.int32),
        owner_flat_ids=jnp.asarray(owner_flat_ids, dtype=jnp.int32), raw_volume=jnp.asarray(raw_volume.ravel(), dtype=jnp.float64),
        owner_volume=jnp.asarray(owner_volume, dtype=jnp.float64), raw_shape=shape, _metadata=metadata,
    )


__all__ = ["ConservativeConductionReconstruction", "build_conservative_conduction_reconstruction"]
