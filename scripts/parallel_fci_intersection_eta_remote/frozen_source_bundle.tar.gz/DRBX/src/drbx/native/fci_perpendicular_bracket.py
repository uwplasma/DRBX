"""Pure JAX application of prepared cubic perpendicular-bracket blocks."""
from __future__ import annotations

from typing import NamedTuple

import jax
import jax.numpy as jnp

__all__ = ["FaceDiagnostics", "apply_face_block", "apply_cell_block", "aggregate_owner_actions"]


class FaceDiagnostics(NamedTuple):
    generator_flux: jnp.ndarray
    product_a: jnp.ndarray
    product_b: jnp.ndarray
    jump_flux: jnp.ndarray
    common_generator: jnp.ndarray
    common_transported: jnp.ndarray
    jump: jnp.ndarray


def _as_fields(values):
    value=jnp.asarray(values,dtype=jnp.float64)
    return value[None,:] if value.ndim==1 else value


def _reconstruct(block, owner_values, coefficient_map):
    values=_as_fields(owner_values)
    donor=jnp.asarray(block.donors)
    gathered=values[:,donor]
    coefficients=jnp.einsum("fkd,bfd->bfk",jnp.asarray(coefficient_map),gathered)
    q=jnp.einsum("fqk,bfk->bfq",jnp.asarray(block.basis),coefficients)
    grad=jnp.einsum("fqkc,bfk->bfqc",jnp.asarray(block.derivative_basis),coefficients)
    return q,grad


def apply_face_block(
    block,
    generator_owner,
    transported_owner,
    raw_generator_anchor,
    raw_transported_anchor,
    *,
    generator_wall_trace,
    transported_wall_trace,
    raw_cell_count: int,
):
    """Return raw-cell A/B/material contributions for one fixed face block."""
    g,ggrad=_reconstruct(block,generator_owner,block.central_map)
    q,qgrad=_reconstruct(block,transported_owner,block.central_map)
    left,_=_reconstruct(block,transported_owner,block.left_map)
    right,_=_reconstruct(block,transported_owner,block.right_map)
    wall=jnp.asarray(block.wall)[None,:,None];collapsed=jnp.asarray(block.collapsed)[None,:,None]
    donor=jnp.asarray(block.donors)
    g_wall_grad=jnp.einsum("fcd,bfd->bfc",jnp.asarray(block.boundary_gradient_map),_as_fields(generator_owner)[:,donor])
    q_wall_grad=jnp.einsum("fcd,bfd->bfc",jnp.asarray(block.boundary_gradient_map),_as_fields(transported_owner)[:,donor])
    ggrad=jnp.where(wall[:,:,:,None],g_wall_grad[:,:,None,:],ggrad)
    qgrad=jnp.where(wall[:,:,:,None],q_wall_grad[:,:,None,:],qgrad)
    g=jnp.where(wall,jnp.asarray(generator_wall_trace)[:,:,None],g)
    q=jnp.where(wall,jnp.asarray(transported_wall_trace)[:,:,None],q)
    # Frozen wall jump is trace minus the adjacent raw anchor; no exterior fit.
    qanchor=_as_fields(raw_transported_anchor)
    wall_jump=jnp.asarray(transported_wall_trace)-jnp.take(qanchor,jnp.asarray(block.lower_raw),axis=1)
    jump=jnp.where(wall,wall_jump[:,:,None],right-left)
    h=jnp.asarray(block.h);axis=jnp.asarray(block.keys[:,0])
    cross_g=jnp.cross(h[None,...],ggrad)
    cross_q=jnp.cross(h[None,...],qgrad)
    take_axis=axis[None,:,None,None]
    u=jnp.take_along_axis(cross_g,take_axis,axis=-1)[...,0]
    uq=jnp.take_along_axis(cross_q,take_axis,axis=-1)[...,0]
    active=jnp.asarray(block.valid&~block.collapsed)[None,:,None]
    u=jnp.where(active,u,0.0);uq=jnp.where(active,uq,0.0)
    w=jnp.asarray(block.weights)[None,:,:]
    flux_g=jnp.sum(w*u,axis=2);flux_q=jnp.sum(w*uq,axis=2)
    product_a=jnp.sum(w*u*q,axis=2)
    product_b=jnp.sum(w*uq*g,axis=2)
    jump_flux=jnp.sum(-0.5*w*jnp.abs(u)*jump,axis=2)
    ga=_as_fields(raw_generator_anchor);qa=_as_fields(raw_transported_anchor)
    lower=jnp.asarray(block.lower_raw);upper=jnp.asarray(block.upper_raw)
    def scatter(face,anchor):
        out=jnp.zeros((face.shape[0],raw_cell_count),dtype=face.dtype)
        lo=face-anchor[:,lower]*flux_g
        out=out.at[:,lower].add(jnp.where(jnp.asarray(block.lower_valid)[None,:],lo,0.0))
        hi=-(face-anchor[:,upper]*flux_g)
        out=out.at[:,upper].add(jnp.where(jnp.asarray(block.upper_valid)[None,:],hi,0.0))
        return out
    raw_a=scatter(product_a,qa)
    # Swapped raw term uses transported generator flux and generator anchor.
    def scatter_b(face):
        out=jnp.zeros((face.shape[0],raw_cell_count),dtype=face.dtype)
        lo=face-ga[:,lower]*flux_q
        out=out.at[:,lower].add(jnp.where(jnp.asarray(block.lower_valid)[None,:],lo,0.0))
        hi=-(face-ga[:,upper]*flux_q)
        return out.at[:,upper].add(jnp.where(jnp.asarray(block.upper_valid)[None,:],hi,0.0))
    raw_b=scatter_b(product_b)
    raw_jump=jnp.zeros_like(raw_a)
    raw_jump=raw_jump.at[:,lower].add(jnp.where(jnp.asarray(block.lower_valid)[None,:],jump_flux,0.0))
    raw_jump=raw_jump.at[:,upper].add(jnp.where(jnp.asarray(block.upper_valid)[None,:],-jump_flux,0.0))
    return raw_a,raw_b,raw_jump,FaceDiagnostics(flux_g,product_a,product_b,jump_flux,g,q,jump)


def apply_cell_block(block,generator_owner,transported_owner,raw_generator_anchor,raw_transported_anchor,*,raw_cell_count:int):
    g,ggrad=_reconstruct(block,generator_owner,block.central_map)
    q,qgrad=_reconstruct(block,transported_owner,block.central_map)
    curl=jnp.asarray(block.curl_h)[None,...];w=jnp.asarray(block.weights)[None,...]
    div_g=jnp.sum(ggrad*curl,axis=-1);div_q=jnp.sum(qgrad*curl,axis=-1)
    index=jnp.asarray(block.indices);ga=_as_fields(raw_generator_anchor)[:,index,None];qa=_as_fields(raw_transported_anchor)[:,index,None]
    volume_a=jnp.sum(w*(q-qa)*div_g,axis=2);volume_b=jnp.sum(w*(g-ga)*div_q,axis=2)
    active=jnp.asarray(block.valid)[None,:]
    out_a=jnp.zeros((q.shape[0],raw_cell_count)).at[:,index].add(jnp.where(active,-volume_a,0.0))
    out_b=jnp.zeros((q.shape[0],raw_cell_count)).at[:,index].add(jnp.where(active,-volume_b,0.0))
    return out_a,out_b,(volume_a,volume_b)


def aggregate_owner_actions(raw_a,raw_b,raw_jump,raw_owner,owner_volume,rho_star):
    """Aggregate complete raw actions; material correction is added only to A."""
    raw_owner=jnp.asarray(raw_owner);volume=jnp.asarray(owner_volume)
    nowner=volume.shape[0]
    def aggregate(value):
        out=jnp.zeros((value.shape[0],nowner),dtype=value.dtype)
        return out.at[:,raw_owner].add(value)
    a=-aggregate(raw_a)/(rho_star*volume[None,:])
    b= aggregate(raw_b)/(rho_star*volume[None,:])
    jump=-aggregate(raw_jump)/(rho_star*volume[None,:])
    return {"A":a,"B":b,"C":0.5*(a+b),"material_A":a+jump,"material_correction":jump}
