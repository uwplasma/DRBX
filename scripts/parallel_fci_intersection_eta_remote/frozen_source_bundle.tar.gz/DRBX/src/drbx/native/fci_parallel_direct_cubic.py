"""Pure JAX application of prepared direct-cubic parallel G/D maps."""

from __future__ import annotations

from typing import Any

from .fci_direct_cubic_diffusion import (
    assemble_direct_cubic_owner_residual,
    direct_cubic_linear_functional,
)


def parallel_direct_cubic_gradient(
    owner_values: Any,
    donors: Any,
    coefficients: Any,
) -> Any:
    """Apply prepared owner-volume ``b dot grad`` rows."""

    return direct_cubic_linear_functional(owner_values, donors, coefficients)


def parallel_direct_cubic_divergence(
    owner_values: Any,
    donors: Any,
    coefficients: Any,
    face_minus: Any,
    face_plus: Any,
    face_boundary: Any,
    output_owner_measures: Any,
    boundary_face_flux: Any | None = None,
) -> Any:
    """Apply prepared conservative ``div(b g)`` with dynamic boundary data."""

    import jax.numpy as jnp

    reconstructed = direct_cubic_linear_functional(owner_values, donors, coefficients)
    if boundary_face_flux is None:
        boundary_face_flux = jnp.zeros_like(reconstructed)
    return assemble_direct_cubic_owner_residual(
        reconstructed,
        boundary_face_flux,
        face_minus,
        face_plus,
        face_boundary,
        output_owner_measures,
    )


def parallel_direct_cubic_product(
    owner_values: Any,
    donors: Any,
    coefficients: Any,
) -> Any:
    """Apply optional prepared owner-average ``g div(b)`` diagnostic rows."""

    return direct_cubic_linear_functional(owner_values, donors, coefficients)
