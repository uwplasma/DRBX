"""Runtime application of a prepared direct-cubic FCI diffusion action.

Geometry-only coefficient fitting lives in :mod:`drbx.geometry`; campaign and
MMS logic remain outside the package. This module applies the resulting face
functional or sparse unit-diffusivity owner action to the *current* compact
owner state.
"""

from __future__ import annotations

from typing import Any


def direct_cubic_linear_functional(owner_values: Any, donors: Any, coefficients: Any) -> Any:
    """Evaluate one or more prepared direct-cubic linear functional rows."""

    import jax.numpy as jnp

    values = jnp.asarray(owner_values)
    donor_ids = jnp.asarray(donors)
    coefficient = jnp.asarray(coefficients, dtype=values.dtype)
    safe_donors = jnp.maximum(donor_ids, 0)
    gathered = jnp.take(values, safe_donors, axis=-1)
    return jnp.sum(gathered * coefficient, axis=-1)


def direct_cubic_face_flux(owner_values: Any, donors: Any, coefficients: Any) -> Any:
    """Evaluate shared integrated interior-face fluxes for one or more fields.

    ``owner_values`` has shape ``(..., n_owner)``. The result has shape
    ``(..., n_face)``. Boundary rows may use donor ``-1`` only when their
    coefficients are zero; their physical flux is supplied during assembly.
    """

    return direct_cubic_linear_functional(owner_values, donors, coefficients)


def assemble_direct_cubic_owner_residual(
    reconstructed_face_flux: Any,
    boundary_face_flux: Any,
    face_minus: Any,
    face_plus: Any,
    face_boundary: Any,
    owner_volumes: Any,
) -> Any:
    """Assemble one shared face flux with opposite incidence into owners.

    Both flux arrays have shape ``(..., n_face)``. Interior entries are taken
    only from ``reconstructed_face_flux`` and physical-boundary entries only
    from ``boundary_face_flux``, so boundary data enter exactly once.
    """

    import jax.numpy as jnp

    reconstructed = jnp.asarray(reconstructed_face_flux)
    boundary_flux = jnp.asarray(boundary_face_flux, dtype=reconstructed.dtype)
    if reconstructed.shape != boundary_flux.shape:
        raise ValueError("reconstructed and boundary face flux shapes must match")
    minus = jnp.asarray(face_minus)
    plus = jnp.asarray(face_plus)
    boundary = jnp.asarray(face_boundary, dtype=bool)
    volume = jnp.asarray(owner_volumes, dtype=reconstructed.dtype)
    if reconstructed.shape[-1] != minus.shape[0]:
        raise ValueError("face flux and incidence counts differ")
    flux = jnp.where(boundary, boundary_flux, reconstructed)
    residual = jnp.zeros(reconstructed.shape[:-1] + (volume.shape[0],), dtype=reconstructed.dtype)
    residual = residual.at[..., minus].add(flux)
    shared = plus >= 0
    safe_plus = jnp.maximum(plus, 0)
    residual = residual.at[..., safe_plus].add(-flux * shared)
    return residual / volume


def direct_cubic_unit_diffusion_action(
    owner_values: Any,
    donors: Any,
    coefficients: Any,
    face_minus: Any,
    face_plus: Any,
    face_boundary: Any,
    owner_volumes: Any,
    boundary_face_flux: Any | None = None,
) -> Any:
    """Apply the unit-diffusivity direct face functional and assembly."""

    import jax.numpy as jnp

    face_flux = direct_cubic_face_flux(owner_values, donors, coefficients)
    if boundary_face_flux is None:
        boundary_face_flux = jnp.zeros_like(face_flux)
    return assemble_direct_cubic_owner_residual(
        face_flux,
        boundary_face_flux,
        face_minus,
        face_plus,
        face_boundary,
        owner_volumes,
    )


def local_parallel_diffusion_direct_cubic_op(
    owner_values: Any,
    unit_diffusivity_action: Any,
    chi_parallel: float,
) -> Any:
    """Apply ``chi_parallel * L`` without materializing a dense matrix.

    ``unit_diffusivity_action`` may be a JAX ``BCSR`` or any JAX-compatible
    sparse linear operator implementing matrix multiplication.
    """

    import jax
    import jax.numpy as jnp

    values = jnp.asarray(owner_values)
    if values.ndim == 1:
        result = unit_diffusivity_action @ values
    else:
        flat = values.reshape((-1, values.shape[-1]))
        result = jax.vmap(lambda value: unit_diffusivity_action @ value)(flat)
        result = result.reshape(values.shape[:-1] + (result.shape[-1],))
    return chi_parallel * result
