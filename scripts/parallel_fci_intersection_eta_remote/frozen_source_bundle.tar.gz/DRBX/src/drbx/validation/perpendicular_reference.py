"""Independent owner-average references for perpendicular-operator studies.

This module is deliberately host-only.  It integrates analytic fields and
independently supplied continuum sources over physical control volumes; it
does not call a DRBX discrete operator.  Midpoint samples are returned only as
labelled controls and are never used as qualified owner averages.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Callable, Mapping, Sequence

import numpy as np


ArrayFunction = Callable[[np.ndarray], np.ndarray]


@dataclass(frozen=True)
class ManufacturedField:
    """Smooth regular-chart scalar with independent differential data."""

    name: str
    family: str
    value: ArrayFunction
    gradient: ArrayFunction
    hessian: ArrayFunction
    powers: tuple[int, int, int] | None = None

    def laplacian_xy(self, points: np.ndarray) -> np.ndarray:
        hessian = np.asarray(self.hessian(points), dtype=np.float64)
        return hessian[..., 0, 0] + hessian[..., 1, 1]


@dataclass(frozen=True)
class OwnerReference:
    """Physical owner averages and separately labelled midpoint controls."""

    field: np.ndarray
    source: np.ndarray
    volume: np.ndarray
    midpoint_field_control: np.ndarray
    midpoint_source_control: np.ndarray
    quadrature_order: int
    geometry_reference_id: str


def regular_chart(points: np.ndarray) -> np.ndarray:
    """Map logical ``(u, theta, eta)`` points to regular ``(x, y, eta)``."""

    q = np.asarray(points, dtype=np.float64)
    if q.ndim < 2 or q.shape[-1] != 3:
        raise ValueError("points must have shape (..., 3)")
    u, theta, eta = np.moveaxis(q, -1, 0)
    return np.stack((u * np.cos(theta), u * np.sin(theta), eta), axis=-1)


def _polynomial_field(name: str, family: str, powers: tuple[int, int, int]):
    powers_array = np.asarray(powers, dtype=np.int64)

    def value(points):
        xyz = regular_chart(points)
        return np.prod(np.power(xyz, powers_array), axis=-1)

    def gradient(points):
        xyz = regular_chart(points)
        result = np.zeros_like(xyz)
        for axis, power in enumerate(powers):
            if power:
                reduced = powers_array.copy()
                reduced[axis] -= 1
                result[..., axis] = power * np.prod(
                    np.power(xyz, reduced), axis=-1
                )
        return result

    def hessian(points):
        xyz = regular_chart(points)
        result = np.zeros(xyz.shape[:-1] + (3, 3), dtype=np.float64)
        for first, p_first in enumerate(powers):
            for second, p_second in enumerate(powers):
                coefficient = p_first * (p_second - (first == second))
                if coefficient:
                    reduced = powers_array.copy()
                    reduced[first] -= 1
                    reduced[second] -= 1
                    result[..., first, second] = coefficient * np.prod(
                        np.power(xyz, reduced), axis=-1
                    )
        return result

    return ManufacturedField(name, family, value, gradient, hessian, powers)


def manufactured_field_catalogue() -> Mapping[str, ManufacturedField]:
    """Catalogue spanning linear, quadratic, cubic, mixed, and smooth modes."""

    fields = {
        "one": _polynomial_field("one", "constant", (0, 0, 0)),
        "x": _polynomial_field("x", "linear", (1, 0, 0)),
        "y": _polynomial_field("y", "linear", (0, 1, 0)),
        "x2": _polynomial_field("x2", "quadratic", (2, 0, 0)),
        "xy": _polynomial_field("xy", "quadratic-mixed", (1, 1, 0)),
        "y2": _polynomial_field("y2", "quadratic", (0, 2, 0)),
        "x3": _polynomial_field("x3", "cubic", (3, 0, 0)),
        "x2y": _polynomial_field("x2y", "cubic-mixed", (2, 1, 0)),
        "xy2": _polynomial_field("xy2", "cubic-mixed", (1, 2, 0)),
        "y3": _polynomial_field("y3", "cubic", (0, 3, 0)),
    }

    def smooth_value(points):
        x, y, eta = np.moveaxis(regular_chart(points), -1, 0)
        return np.exp(0.2 * x - 0.15 * y) * np.cos(eta)

    def smooth_gradient(points):
        x, y, eta = np.moveaxis(regular_chart(points), -1, 0)
        exponential = np.exp(0.2 * x - 0.15 * y)
        cosine = np.cos(eta)
        return np.stack(
            (0.2 * exponential * cosine,
             -0.15 * exponential * cosine,
             -exponential * np.sin(eta)),
            axis=-1,
        )

    def smooth_hessian(points):
        x, y, eta = np.moveaxis(regular_chart(points), -1, 0)
        exponential = np.exp(0.2 * x - 0.15 * y)
        cosine = np.cos(eta)
        sine = np.sin(eta)
        result = np.empty(np.shape(x) + (3, 3), dtype=np.float64)
        result[..., 0, 0] = 0.04 * exponential * cosine
        result[..., 1, 1] = 0.0225 * exponential * cosine
        result[..., 2, 2] = -exponential * cosine
        result[..., 0, 1] = result[..., 1, 0] = -0.03 * exponential * cosine
        result[..., 0, 2] = result[..., 2, 0] = -0.2 * exponential * sine
        result[..., 1, 2] = result[..., 2, 1] = 0.15 * exponential * sine
        return result

    fields["smooth_nonpolynomial"] = ManufacturedField(
        "smooth_nonpolynomial", "non-polynomial",
        smooth_value, smooth_gradient, smooth_hessian,
    )
    return fields


def _monomial_average_from_moments(
    powers: tuple[int, int, int],
    centroid: np.ndarray,
    second_moment: np.ndarray,
    third_moment: np.ndarray,
) -> np.ndarray:
    """Exact degree-three monomial average from central owner moments."""

    from drbx.geometry.fci_control_volumes import (
        control_volume_average_basis_numpy,
    )

    return control_volume_average_basis_numpy(
        centroid,
        second_moment,
        third_moment,
        origin=np.zeros(3, dtype=np.float64),
        scale=np.ones(3, dtype=np.float64),
        exponents=(powers,),
    )[..., 0]


def physical_owner_moment_reference(
    field: ManufacturedField,
    *,
    centroid: np.ndarray,
    second_moment: np.ndarray,
    third_moment: np.ndarray,
    active_owner: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Return exact polynomial field and Cartesian-Laplacian source averages.

    The source is derived analytically from the manufactured polynomial, not
    by applying a discrete DRBX operator.  Non-polynomial fields deliberately
    use the separate opt-in selected-cell quadrature helper.
    """

    if field.powers is None:
        raise ValueError("moment references require a polynomial catalogue field")
    active = np.asarray(active_owner, dtype=bool)
    average = _monomial_average_from_moments(
        field.powers, centroid, second_moment, third_moment
    )
    source = np.zeros_like(average)
    for axis in (0, 1):
        power = field.powers[axis]
        if power >= 2:
            reduced = list(field.powers)
            reduced[axis] -= 2
            source += power * (power - 1) * _monomial_average_from_moments(
                tuple(reduced), centroid, second_moment, third_moment
            )
    return np.where(active, average, 0.0), np.where(active, source, 0.0)


def geometry_reference_id(metadata: Mapping[str, object]) -> str:
    """Stable identifier for the continuum geometry used by every mesh."""

    encoded = json.dumps(metadata, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _tensor_quadrature(faces: Sequence[np.ndarray], order: int):
    if len(faces) != 3 or order < 1:
        raise ValueError("three face arrays and a positive order are required")
    nodes, weights = np.polynomial.legendre.leggauss(int(order))
    lows = np.stack(
        np.meshgrid(*(np.asarray(face)[:-1] for face in faces), indexing="ij"),
        axis=-1,
    )
    highs = np.stack(
        np.meshgrid(*(np.asarray(face)[1:] for face in faces), indexing="ij"),
        axis=-1,
    )
    offsets = np.stack(np.meshgrid(nodes, nodes, nodes, indexing="ij"), axis=-1)
    offsets = offsets.reshape((-1, 3))
    tensor_weights = np.einsum("i,j,k->ijk", weights, weights, weights).reshape(-1)
    centers = 0.5 * (lows + highs)
    half_widths = 0.5 * (highs - lows)
    points = centers[..., None, :] + half_widths[..., None, :] * offsets
    coordinate_weights = np.prod(half_widths, axis=-1)[..., None] * tensor_weights
    return points, coordinate_weights, centers


def _aggregate(raw_integral, aggregate_id, active_owner):
    ids = np.asarray(aggregate_id, dtype=np.int64).ravel()
    owner_mask = np.asarray(active_owner, dtype=bool)
    if ids.size != owner_mask.size:
        raise ValueError("aggregate_id and active_owner shapes must match")
    sums = np.zeros(ids.size, dtype=np.float64)
    np.add.at(sums, ids, np.asarray(raw_integral, dtype=np.float64).ravel())
    return np.where(owner_mask, sums.reshape(owner_mask.shape), 0.0)


def physical_owner_reference(
    *,
    faces: Sequence[np.ndarray],
    aggregate_id: np.ndarray,
    active_owner: np.ndarray,
    jacobian: ArrayFunction,
    field: ArrayFunction,
    source: ArrayFunction,
    quadrature_order: int,
    geometry_id: str,
) -> OwnerReference:
    """Opt-in quadrature control for tiny fixtures or selected cells.

    This helper is intentionally not part of the routine full-domain MMS.
    Prefer :func:`physical_owner_moment_reference` for polynomial controls.
    """

    points, coordinate_weights, centers = _tensor_quadrature(
        faces, quadrature_order
    )
    shape = points.shape[:-2]
    flat = points.reshape((-1, 3))
    J = np.asarray(jacobian(flat), dtype=np.float64).reshape(points.shape[:-1])
    if np.any(~np.isfinite(J)) or np.any(J <= 0.0):
        raise ValueError("physical quadrature requires finite positive Jacobians")
    weights = coordinate_weights * J

    def integrate(function):
        values = np.asarray(function(flat), dtype=np.float64).reshape(points.shape[:-1])
        return np.sum(weights * values, axis=-1)

    raw_volume = np.sum(weights, axis=-1)
    owner_volume = _aggregate(raw_volume, aggregate_id, active_owner)
    owner_field_integral = _aggregate(integrate(field), aggregate_id, active_owner)
    owner_source_integral = _aggregate(integrate(source), aggregate_id, active_owner)
    tiny = np.finfo(np.float64).tiny
    owner_field = np.where(
        active_owner, owner_field_integral / np.maximum(owner_volume, tiny), 0.0
    )
    owner_source = np.where(
        active_owner, owner_source_integral / np.maximum(owner_volume, tiny), 0.0
    )

    midpoint_J = np.asarray(jacobian(centers.reshape((-1, 3))), dtype=np.float64).reshape(shape)
    midpoint_volume = midpoint_J * (
        np.diff(np.asarray(faces[0]))[:, None, None]
        * np.diff(np.asarray(faces[1]))[None, :, None]
        * np.diff(np.asarray(faces[2]))[None, None, :]
    )

    def midpoint_control(function):
        values = np.asarray(function(centers.reshape((-1, 3))), dtype=np.float64).reshape(shape)
        integral = _aggregate(values * midpoint_volume, aggregate_id, active_owner)
        volume = _aggregate(midpoint_volume, aggregate_id, active_owner)
        return np.where(active_owner, integral / np.maximum(volume, tiny), 0.0)

    return OwnerReference(
        field=owner_field,
        source=owner_source,
        volume=owner_volume,
        midpoint_field_control=midpoint_control(field),
        midpoint_source_control=midpoint_control(source),
        quadrature_order=int(quadrature_order),
        geometry_reference_id=str(geometry_id),
    )


def matching_boundary_data(
    field: ManufacturedField,
    points: np.ndarray,
    outward_normals_xyz: np.ndarray,
) -> Mapping[str, np.ndarray]:
    """Return mutually compatible Dirichlet and physical-normal data."""

    normals = np.asarray(outward_normals_xyz, dtype=np.float64)
    gradient = np.asarray(field.gradient(points), dtype=np.float64)
    if normals.shape != gradient.shape:
        raise ValueError("boundary normals must match the field gradient shape")
    return {
        "dirichlet": np.asarray(field.value(points), dtype=np.float64),
        "physical_normal_derivative": np.einsum("...i,...i->...", gradient, normals),
    }


def validate_region_masks(
    *,
    active: np.ndarray,
    diagnostic_masks: Mapping[str, np.ndarray],
    partition_masks: Mapping[str, np.ndarray],
) -> Mapping[str, object]:
    """Validate overlapping diagnostics separately from a disjoint partition."""

    active = np.asarray(active, dtype=bool)
    diagnostics = {
        name: np.asarray(mask, dtype=bool) & active
        for name, mask in diagnostic_masks.items()
    }
    partition = {
        name: np.asarray(mask, dtype=bool) & active
        for name, mask in partition_masks.items()
    }
    if any(mask.shape != active.shape for mask in (*diagnostics.values(), *partition.values())):
        raise ValueError("all region masks must match the active-owner shape")
    counts = np.zeros(active.shape, dtype=np.int64)
    for mask in partition.values():
        counts += mask
    complete = bool(np.array_equal(counts[active], np.ones(np.count_nonzero(active))))
    return {
        "partition_is_disjoint_and_complete": complete,
        "unassigned_active_count": int(np.count_nonzero(active & (counts == 0))),
        "multiply_assigned_active_count": int(np.count_nonzero(active & (counts > 1))),
        "diagnostic_overlap_count": int(sum(
            np.count_nonzero(left & right)
            for index, left in enumerate(diagnostics.values())
            for right in list(diagnostics.values())[index + 1:]
        )),
    }


def error_statistics(
    actual: np.ndarray,
    exact: np.ndarray,
    volume: np.ndarray,
    masks: Mapping[str, np.ndarray],
) -> Mapping[str, Mapping[str, float | int | None]]:
    """RMS/Linf/volume/SSE diagnostics for any named regions."""

    actual = np.asarray(actual, dtype=np.float64)
    exact = np.asarray(exact, dtype=np.float64)
    volume = np.asarray(volume, dtype=np.float64)
    difference = actual - exact
    selected_union = np.zeros(actual.shape, dtype=bool)
    for mask in masks.values():
        selected_union |= np.asarray(mask, dtype=bool)
    global_sse = float(np.sum(volume[selected_union] * difference[selected_union] ** 2))
    result = {}
    for name, raw_mask in masks.items():
        mask = np.asarray(raw_mask, dtype=bool)
        region_volume = float(np.sum(volume[mask]))
        sse = float(np.sum(volume[mask] * difference[mask] ** 2))
        exact_square = float(np.sum(volume[mask] * exact[mask] ** 2))
        absolute = np.sqrt(sse / region_volume) if region_volume > 0.0 else None
        relative = (
            np.sqrt(sse / exact_square) if exact_square > np.finfo(float).tiny else None
        )
        result[name] = {
            "cell_count": int(np.count_nonzero(mask)),
            "physical_volume": region_volume,
            "absolute_rms": None if absolute is None else float(absolute),
            "relative_rms": None if relative is None else float(relative),
            "linf": None if not np.any(mask) else float(np.max(np.abs(difference[mask]))),
            "squared_error": sse,
            "global_squared_error_share": (
                sse / global_sse if global_sse > 0.0 else None
            ),
        }
    return result


def reference_error_budget(
    coarse: np.ndarray,
    fine: np.ndarray,
    volume: np.ndarray,
    active: np.ndarray,
    *,
    finest_spatial_error: float,
    fraction_limit: float = 0.1,
) -> Mapping[str, float | bool]:
    """Measure quadrature/reference change against the finest spatial error."""

    mask = np.asarray(active, dtype=bool)
    weights = np.asarray(volume, dtype=np.float64)
    delta = np.asarray(fine, dtype=np.float64) - np.asarray(coarse, dtype=np.float64)
    error = float(np.sqrt(np.sum(weights[mask] * delta[mask] ** 2) / np.sum(weights[mask])))
    ratio = error / float(finest_spatial_error)
    return {
        "reference_error": error,
        "finest_spatial_error": float(finest_spatial_error),
        "ratio": ratio,
        "fraction_limit": float(fraction_limit),
        "passes": bool(ratio < fraction_limit),
    }


def first_interior_polar_average_gradient_factor() -> Mapping[str, float]:
    """Exact ``f=x`` radial-average difference at the first interior face.

    For a polar cell with physical measure ``r dr dtheta``, the radial
    averages of ``r`` on ``[0, h]`` and ``[h, 2h]`` are ``2h/3`` and
    ``14h/9``.  Their centre-to-centre difference divided by ``h`` is
    therefore ``8/9``.  Midpoint samples instead give one.  The common
    angular average of ``cos(theta)`` is deliberately factored out, making
    this helper independent of angular resolution.
    """

    inner_average_over_h = 2.0 / 3.0
    outer_average_over_h = 14.0 / 9.0
    return {
        "inner_owner_average_over_h": inner_average_over_h,
        "outer_owner_average_over_h": outer_average_over_h,
        "exact_average_gradient_factor": (
            outer_average_over_h - inner_average_over_h
        ),
        "midpoint_gradient_factor": 1.0,
    }


def refinement_orders(
    errors: Sequence[float], resolutions: Sequence[float], *, floor: float = 1.0e-13
) -> list[float | None]:
    """Return adjacent observed orders, suppressing roundoff-floor slopes."""

    values = np.asarray(errors, dtype=np.float64)
    mesh = np.asarray(resolutions, dtype=np.float64)
    if values.ndim != 1 or mesh.ndim != 1 or values.size != mesh.size:
        raise ValueError("errors and resolutions must be equal-length vectors")
    if values.size < 2 or np.any(mesh <= 0.0) or np.any(np.diff(mesh) <= 0.0):
        raise ValueError("at least two strictly increasing resolutions are required")
    result: list[float | None] = []
    for coarse, fine, n_coarse, n_fine in zip(
        values[:-1], values[1:], mesh[:-1], mesh[1:]
    ):
        if coarse <= floor or fine <= floor:
            result.append(None)
        else:
            result.append(
                float(np.log(coarse / fine) / np.log(n_fine / n_coarse))
            )
    return result
