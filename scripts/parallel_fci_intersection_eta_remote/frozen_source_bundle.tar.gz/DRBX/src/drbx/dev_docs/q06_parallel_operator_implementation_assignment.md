# Q06 parallel-operator implementation and global-study preparation

Authorized 22 September 2026. This assignment follows the bounded Q06
gradient/divergence, reference/transfer, and integration/derived audits. It
authorizes a reusable package implementation, bounded actual-HSX verification,
and a runnable N32/N48/N64 global-campaign bundle. It does not authorize the
global campaign itself, a remote launch, Q07, an evolved solve, production
selection, direct-diffusion changes, or a donor/degree/support search.

Evidence belongs under
`work/parallel_q06_parallel_implementation_20260922/`. Historical arrays remain
unchanged.

## Corrected integration interpretation

The cached HSX metric uses topology code 1 with a Fourier--Zernike
representation and eta Fourier modes -3 through 3. `MetricEvaluator.eta` is a
sampling coordinate array, not a set of piecewise interpolation knots. The
previous audit's `axis_knots()` subdivided on those sample planes. Its measured
eta under-resolution and composite-integration improvement remain valid, but
the audit did not identify metric breakpoints. MAKEGRID interpolation is a
separate cylindrical-coordinate operation and its stencil boundaries were not
isolated.

Before selecting a production candidate, compare on the frozen complete-owner
pairs N32 `[24528,5728]`, N48 `[84168,15840]`, and N64 `[32,36480]`:

- the old sample-plane composite rule, named as such;
- an equal-cost uniform eta composite rule; and
- on the worst N32/N48 faces only, an equal-cost shifted interior partition.

Inspect the full `J*b^axis` eta integrand and do not infer loss of smoothness at
sample planes without direct evidence. Use a small fixed rule family and select
the simplest field-independent geometry rule supported by the comparison.

## Frozen reconstruction and operator contracts

Retain the Q05a total-degree cubic, 120 donors on five eta planes, deterministic
distance selection, weights, raw-midpoint physical-volume owner observations,
continuous geometry queries, oriented canonical faces, dynamic boundary trace,
periodic incidence, and zero collapsed-axis lower flux.

Prepare geometry-only, compact, versioned maps for:

- `D g = div(b g)`: integrated face targets
  `integral_face J b^alpha p`, composed with the frozen observation-to-cubic
  reconstruction and assembled by signed incidence over the declared output
  owner measure;
- `G f = b dot grad(f)`: owner-volume targets
  `V^-1 integral_owner J b dot grad(p)` on the same observation convention;
- optional `f div(b)` diagnostics: separately identified owner-volume targets
  using the direct divergence of the evaluated geometry. Never silently use
  `-b dot grad(log|B|)`.

Observation normalization and output normalization are independent identity
fields. Boundary values are runtime field data, enter once, and are never
manufactured values embedded in preparation. Preparation performs donor
selection, quadrature, factorization and coefficient composition in streaming
blocks; application is a pure JAX gather/reduce/scatter with no geometry query,
quadrature loop or factorization. Do not retain a global donor-by-quadrature
tensor. The qualified direct-diffusion action and identity are unchanged.

## Bounded verification and reference qualification

Replay the six frozen complete owners and a predeclared deterministic
geometry-selected actual-HSX coverage fixture spanning RLP bulk/transition,
ordinary interior, axis, wall and theta/eta seams. Reproduce the archived q9
policy when explicitly selected. Do not describe the prior 8/12, 8/12 and
68/198 hybrid refinement as a uniform policy.

Qualify D face and volume references separately at the corrected error scale,
and qualify G's volume target directly. Independent-rule differences are
empirical uncertainty estimates, not rigorous bounds. Report or propagate
material local uncertainty without inventing pointwise gates. Include focused
actual-HSX tests for target construction, constants and polynomial behavior,
shared-face conservation, boundary/axis/seam treatment, identity rejection,
changed-field reuse, block-size invariance, replay, eager/JIT/JVP, and bounded
serial/parallel equivalence. Record preparation and application timings and
peak memory separately; keep local total memory below 10 GiB.

## Prepared global campaign

Provide a portable runner and frozen configurations for all owners at N32,
N48 and N64 using the original Q06 nonconstant field catalogue plus constants.
The future campaign certifies G and D separately with global
physical-volume-weighted operator L2 order at least 1.8 on both refinement
intervals. Regional/max errors and product/composition diagnostics remain
diagnostic. Save per-field actions, references, provenance, regional
contributions and uncertainty qualifications.

The runner must support configurable input/output roots and workers,
checkpoint/resume, bounded streaming/concurrency, strict identity checks,
completion validation, and bounded serial/parallel equivalence tests. Runtime
projections come from measured preparation, application and reference stages,
not cell-count guesses alone. Deliver exact commands, but do not execute the
global configurations or perform remote setup, commits or pushes.

## Completion

Completion requires the source-level correction, selected integration policy,
reusable package components, bounded evidence and test receipts, separate setup
and application timing/memory measurements, runnable campaign bundle and
updated roadmap. If a numerical choice remains unresolved, preserve the
working bounded implementation and report that specific obstacle rather than
claiming campaign readiness.
