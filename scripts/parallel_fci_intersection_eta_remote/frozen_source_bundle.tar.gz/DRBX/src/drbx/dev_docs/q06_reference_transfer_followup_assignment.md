# Q06 reference/transfer follow-up assignment

Authorized 22 September 2026. This is a bounded real-HSX diagnostic following
the completed 11-owner Q06 gradient/divergence study. It does not authorize a
global campaign, a production selector, an evolved solve, Q07 work, a new
worker, or a remote launch. Detailed numerical evidence belongs in
`work/parallel_q06_reference_transfer_followup_20260922/`.

## Interpretation correction

The old quantity labelled composed `D(G)` is actually
`D_h O_mid(G_cont f)`. The archived `midpoint_g_states` path evaluates the
analytic field gradient contracted with continuously evaluated `b` at raw-cell
midpoints, applies the frozen physical-volume owner observation, and supplies
those observations to the fitted `D` face rows. Neither the fitted `G` action
nor its coefficients enter that action. Preserve the old numerical arrays and
receipts, but do not use them as evidence that `D_h(G_h f)` failed.

Global `G`/`D` certification is pending. It was not attempted and did not fail
a global-order gate. The independently fitted `G` and `D` operators are not
required to factor the certified direct diffusion matrix.

## Frozen numerical contract

- Reuse the Q05a raw memberships, frozen owner moments, five eta planes, 24
  owners per plane (120 donors total), distance weights, deterministic support
  selection, cubic degree, and current continuous metric/MAKEGRID evaluator.
- Preserve raw-midpoint physical-volume owner averages as observations.
- Use complete owner incidence, one canonical oriented face flux, signed
  scatter, analytic dynamic physical-boundary replacement exactly once,
  zero-measure axis-face treatment, and periodic owner semantics.
- Record input, implementation, evaluator and field identities; field
  amplitudes; observation and target normalizers; derivative steps; quadrature
  rules; and every boundary replacement.
- Initial comparisons use q9 and q11. Disputed terms may use targeted
  subdivision or another bounded qualification rule. Do not blindly raise the
  tensor rule on every face.

The fixed hotspot/control selection is frozen in
`work/parallel_q06_reference_transfer_followup_20260922/selection.json` before
new integrations are compared. It intentionally over-represents known
residuals and is not a representative convergence sample.

## Stage 1: exact-face / volume divergence consistency

For every frozen owner and each constant/nontrivial field, save separately:

1. analytic field flux integrated over every oriented incident face;
2. independent owner-volume integration of
   `G g + g div(b)`, where
   `div(b) = J^-1 partial_alpha(J b^alpha)`;
3. fitted face flux and assembled action with the unchanged observations and
   support.

Start with `g=1`; retain the archived constant state `g=1.2` explicitly. Save
unnormalized integrals and volumes, every signed face contribution, boundary
replacement, periodic ownership, axis treatment, and completed owner errors.
Measure incidence cancellation from the saved signed contributions rather than
recording a hard-coded zero.

At a fixed reference and normalizer, vary face integration, volume
integration, and derivative evaluation one at a time where feasible. Interpret
changes against the completed spatial-error scale. Near-zero polynomial target
norms do not create a failure by themselves.

At identical quadrature probes compare direct `div(b)`,
`-b dot grad(log|B|)`, and `div(B)/|B|`. Repeat derivative steps at the actual
offending nodes and record proximity to axis, seam, and evaluator knots. The
identity only reduces to zero defect for a consistent solenoidal `B`
representation; a nonzero `div(B)/|B|` is a geometry diagnostic, not
automatically a reconstruction failure or a new acceptance gate.

## Stage 2: continuum-gradient observations passed through D

On the frozen N64 angular hotspots and controls, audit
`D_h O_mid(G_cont f)` without calling it discrete composition:

- reconstruct raw midpoint observations independently from analytic field
  derivatives and continuous `b`;
- audit amplitude, owner membership, raw weights, stored-volume
  normalization, periodic coordinates, and missing/zero donor behavior;
- compare each fitted face integral with the exact integral of
  `(b dot n)(b dot grad f)` and then assemble all incident faces;
- save per-face signed errors/cancellation, coefficient L1, support extent,
  and the worst-face contribution to each owner residual;
- compare exact and reconstructed derived-scalar values at selected face nodes
  and held-out points, including regular-chart and eta behavior across the
  support;
- repeat the face analysis for the original smooth scalar on the identical
  support as the control.

Observation moments remain midpoint owner moments. A changed sampling
convention must update the moments consistently. Degree/support changes are
not the first experiment. A true `D_h(G_h f)` comparison is optional and may
only be added with a complete donor closure and an explicit mapping from
`G_h` volume averages to D's midpoint-observation input.

## Decisions, evidence and stopping rule

Routine implementation/bookkeeping defects may be corrected with focused
tests and identical-sample before/after evidence. Geometry changes, degree or
support changes, and global qualification require separate decisions. If no
simple defect is found, stop with the best-supported mechanism and one bounded
next experiment.

Completion requires a reproducible driver, frozen selections, reanalysis-ready
intermediate integrals/observations/fluxes, timings split by geometry,
integration, fitting and application, peak memory below 10 GiB, and a report
that separates computation completion, structural checks, reference
qualification, and global qualification still pending. Retain the successful
direct-diffusion accuracy evidence and deferred monotonicity/production scope.

