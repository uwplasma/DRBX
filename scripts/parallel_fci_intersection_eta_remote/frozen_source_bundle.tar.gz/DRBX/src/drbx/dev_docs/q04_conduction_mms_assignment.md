# Q1: fixed-time direct-cubic conduction MMS

Research implementation and execution assignment, 22 September 2026. The
[parallel roadmap](parallel_second_order_roadmap.md) remains the authority.
Monotonicity repair is deferred. This assignment tests evolved accuracy, not
production readiness, limiter design or a complete Q04 structural pass.

## Frozen design and separation of work

Use the returned direct-cubic campaign at
`work/q03_direct_66aea41b_KyVdek` (source `66aea41b`) and the existing N32 heat
implementation at `work/parallel_q03_direct_heat_spot_20260922`. Keep total-degree
cubic scalar-owner reconstruction, 120 donors on five eta planes, raw-midpoint
volume-weighted owner observations, q9 face targets, shared incidence and
actual HSX geometry unchanged. The parent owns independent reference closure
in `work/parallel_q03_reference_closure_20260922`; Q owns the unforced N48 heat
spot. Q1 owns a separate `work/parallel_q04_conduction_mms_20260922` directory.
Do not modify either worker's run or overwrite archived references/actions.

## Primary manufactured problem: stationary fields, evolved numerical solution

Use each of the three frozen campaign scalar fields separately: radial_eta,
angular_x, mixed_y_eta. Retain their existing amplitudes and analytic formulas;
confirm whether saved owner states already include the background and amplitude
before constructing inputs. Let the physical solution be
`T_exact(x,t) = 1 + F(x)` and solve
`dT/dt = chi L_parallel T + S`, with `chi=0.1` and independent continuum source
`S(x) = -chi L_parallel F(x)`. Use periodic eta and the campaign's manufactured
physical boundary flux. These smooth envelopes have vanishing radial-wall
gradient analytically; verify the frozen faces/conventions rather than assuming
all stored boundary faces are walls. Preserve the collapsed-axis convention.

Evolve the actual current state, not a manufactured residual supplied as the
right-hand side. Initialize and compare against the frozen raw-midpoint
physical-volume-weighted owner sampling `P_h(1+F)`. The source is independently
integrated over each owner using continuum face fluxes and divided by the same
frozen owner volume. It must never be `-chi * L_h(P_h F)`.

The stationary exact solution is deliberate: its exact time derivative is
zero under both midpoint and volume sampling. This avoids introducing a
midpoint-versus-cell-average mass-term mismatch while still testing error
propagation under diffusion over a finite time. Do not describe this as testing
general time-dependent spatial forcing. Add a cheap uniform-in-space decaying
manufactured solution with its analytic time-dependent source to check source
evaluation at RK stage times; its spatial error is not a convergence gate.

Write down the implemented equation explicitly as `chi*(L0 @ T + b) + s`,
where `L0` is the homogeneous action, `b` is prescribed boundary flux assembled
once with signed incidence/volume, and `s=-chi*R`, with `R` the independently
integrated complete continuum diffusion action for F. Prevent double-counting
boundary flux or diffusivity. Confirm at t=0 that the residual reproduces the
archived static error times chi, to ordinary floating-point replay tolerance.
This verifies wiring; it is not the evolved solution result.

## Implementation and staged execution

1. Freeze a manifest with formulas, source/state functional, geometry/evaluator,
   boundary and implementation identities, final time, timestep and checks.
   Read the parent reference-closure report/manifest if available. Existing
   q11 arrays may support implementation preflight and provisional runs; clearly
   label final reference qualification pending until new evidence is available.
2. Reuse a validated homogeneous CSR action when present. N32 is available in
   the existing heat directory. Discover N48 outputs read-only; never race Q's
   coefficient preparation or consume incomplete receipts. Prepare missing
   matrices in Q1's own directory using bounded-memory chunk assembly. Do not
   concatenate full-domain COO intermediates blindly at N64. Reuse unchanged
   geometry/reconstruction data; do not regenerate continuum references.
3. Use the existing float64 JAX current-state sparse-action path and classical
   RK4, evaluating source and boundary data at the actual stage time. Batched
   independent fields are useful when they reduce runtime. Preserve the source
   path for zero-source checks too. Compare a bounded real-HSX action with the
   audited CPU matrix and JIT output, then a short N32 evolution.
4. Primary final physical time is `t=1`, fixed across N32/N48/N64. This differs
   intentionally from the unforced heat spot's t=25 and from old one-step MMS.
   Start with `dt=1/1500` and exact endpoint step count 1500, then `dt/2`.
   Measure runtime/memory before full execution. Run sequential resolutions;
   no remote handoff or new long global reconstruction campaign is authorized.
5. Require the weighted final-state difference between dt and dt/2 to be below
   10% of the finer-step spatial error for each field/resolution. If it is not,
   refine time locally and diagnose stability; record all choices, do not retune
   spatial reconstruction. No extrapolation factor is needed to claim the
   conservative difference-based check. Use the finer result for reported
   spatial orders. An additional dt/4 check is warranted only by ambiguity.
6. Qualify the reference's *evolved effect*, not just its static norm ratio.
   With the same action, propagate the difference between accepted independent
   source arrays (and boundary differences if applicable); linearity permits an
   auxiliary difference solve instead of duplicating full histories. Require
   this final-state difference below 10% of spatial error. Reuse the parent's
   reference artifacts; do not assume a static budget automatically controls
   evolved error. If parent closure is pending, finish provisional integration
   and report that dependency explicitly rather than inventing qualification.

## Acceptance and reporting

Global physical-volume-weighted solution L2 order must be at least 1.8 on
32→48 and 48→64 for every nontrivial field. Norms count each unique owner once.
Keep axis, transition, agglomerated, ordinary and boundary region contributions
and maximum errors diagnostic. Report static orders separately; neither static
nor evolved results replace the other. An unresolved/nonmonotone result is
inconclusive or a failure to diagnose, not permission to add resolutions.

Record source/boundary heat balance, extrema, variance, finite state, temporal
and reference error budgets, setup/application runtime and memory. Forced MMS
need not preserve unforced extrema; do not impose a positivity gate on this
assignment. Keep the already demonstrated homogeneous minimum-principle defect
visible without attempting repair. No production integration, eta-sharding
campaign, new transport physics or blanket Q04 completion claim.

Use small actual-HSX fixtures for new reusable-code tests; for research scripts,
retain reproducible algebra/replay and timestep checks without creating a large
package test project. Preserve unrelated changes and state/restart layouts.

## Supervision and deliverables

Use `supervise-long-runs` for work outlasting the active turn: one persistent
checkpointed supervisor, one quiet heartbeat, 10 minutes by default adapting
to 20–30 minutes. Bound this worker's memory below 4 GiB initially and use one
setup worker while Q and the parent are active; measure rather than speculatively
optimizing. Do not message Q, P/P1, O or the parent with unsolicited updates.
Keep progress in Q1 and its report. No extra agent or task creation.

Deliver executable implementation, immutable configuration/identity receipts,
all-resolution dt comparisons and solution orders (or the concrete dependency
preventing final qualification), source/state/boundary audit, compact saved
final states and report. Link evidence from this assignment; avoid editing the
main roadmap concurrently with the parent's reference closure. Recommend the
next bounded action without starting a new scientific campaign.
