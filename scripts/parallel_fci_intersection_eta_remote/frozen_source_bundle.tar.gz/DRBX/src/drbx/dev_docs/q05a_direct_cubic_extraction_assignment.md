# Q05a assignment: direct-cubic reconstruction extraction and replay

Authorized 22 September 2026. This is a bounded implementation and replay
assignment under the parallel second-order roadmap. It is not full Q04
certification, Q05 promotion, a production selector change, or Q09 integration.

**Status: passed 22 September 2026.** The reusable package extraction, frozen
real-HSX bounded N32/N48/N64 preparation replay, complete saved-coefficient
action replay, strict sidecar checks and focused tests are complete. See the
[Q05a report](../../../../work/parallel_q05a_direct_cubic_extraction_20260922/report.md)
and [reproducibility audit](../../../../work/parallel_q05a_direct_cubic_extraction_20260922/audit.json).
The local/returned-remote numerical cause remains unresolved because returned
remote coefficients are unavailable. Minimum-principle repair, general
dissipation and eta-sharding remain open, so this does not promote Q05 or
complete Q04.

## Objective

Extract the qualified field-independent direct-cubic face reconstruction and
signed conservative owner assembly into reusable package components, then
replay the identified passing local N32/N48/N64 coefficient-export actions.
Keep the returned remote action identity separate and audit its unexplained
local difference on deterministic faces where saved data permit.

## Frozen numerical contract

- total-degree cubic regular-chart basis including the constant;
- raw-midpoint physical-volume owner observations with the existing
  collapsed-axis convention;
- 120 donors: 24 owners on each of five eta planes;
- existing exact anisotropic-distance selection, incident-owner retention,
  deterministic ordering/ties, weights, face scales and periodic eta handling;
- rank-revealing weighted SVD, float64, and the continuous-geometry q9
  integrated parallel face target;
- one shared integrated face flux with opposite signed incidence and
  owner-volume normalization;
- explicit dynamic physical-boundary flux entering exactly once; homogeneous
  boundary flux for the unforced heat case; and
- unit-diffusivity reconstruction/action with diffusivity applied by the caller.

No normal equations, weak-mode removal, support/degree change, field-dependent
selection, cell-centered metric interpolation, giant donor-by-quadrature
tensor, matrix symmetrization, limiter, clipping, or retuning is authorized.

## Required extraction

1. Host preparation for compact owners, memberships, volumes, observation
   moments, oriented faces/incidence, boundary/periodic classifications,
   supports/scales, and geometry-only target/coefficient construction.
2. A separately reusable observation-moment and linear face-functional layer
   retaining directional geometry for later Q06/Q07 consumers.
3. Pure JAX face evaluation and conservative owner assembly, including a
   leading field-batch dimension where straightforward, plus the existing
   sparse action path. Runtime performs no search, quadrature, SVD, or factorization.
4. A versioned reconstruction sidecar whose identity covers geometry/topology,
   observations, support/weights, target/evaluator, precision, implementation,
   and boundary convention, with incompatible reuse rejected.

Package modules must not import campaign scripts, MMS catalogues, workspace
helpers, or saved answers. Geometry producers remain separate from consumers.

## Evidence and completion

Freeze geometry-based real-HSX representative selections before inspecting
extraction discrepancies. Cover axis-adjacent, agglomerated, transition,
ordinary, boundary and theta/eta seams with completed selected-owner actions.
Replay complete N32 and saved-coefficient N48/N64 actions; rebuild N48/N64
preparation only on bounded samples. Compare explicit face assembly with the
local sparse action and retain remote limitations honestly. Add focused actual-
HSX, float64 JIT/JVP, batch, sidecar and mismatch tests. Keep preparation/replay
below 10 GiB and record timing and peak memory.

Deliver reusable package modules, tests, replay evidence and a concise report.
Update the roadmap with Q05a completion separately from structural certification
and production integration. Do not launch Q06, new campaigns, limiter work,
remote work, commits, pushes or production integration.
