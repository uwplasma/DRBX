# Q06 integration and derived-gradient audit assignment

Authorized 22 September 2026. This is a bounded follow-up to the completed
[Q06 reference/transfer audit](q06_reference_transfer_followup_assignment.md)
and its independent parent review. New evidence belongs under
`work/parallel_q06_integration_derived_audit_20260922/`; historical arrays and
reports remain unchanged.

This assignment does not authorize a representative global campaign, evolved
solve, Q07 work, production selector/default, degree or support sweep, new
worker, remote launch, or reopening the qualified direct-diffusion result.

## Corrected starting interpretation

Matched face/volume quadrature is a consistency check, not an independently
converged reference. On the previous frozen sample, q9-to-q11 exact-face action
changes exceed the matched q9 face/volume residual at N32 and N48. The fitted
unit-field action and exact-field q9 face action agree after conversion to a
common normalizer, so operator integration can share the same error. Do not
classify the discrepancy as reference-only or infer convergence from
co-refinement.

The archived derived diagnostic remains `D_h O_mid(G_cont f)`, not
`D_h(G_h f)`. The direct diffusion action does not require this intermediate
reconstructed scalar and its existing qualification remains intact.

## Frozen Stage A sample and integration contract

Use exactly the refined complete-owner pairs, in this order:

- N32: `24528, 5728`
- N48: `84168, 15840`
- N64: `32, 36480`

Reuse all raw member cells and every incident face required for each completed
owner action. Freeze the continuous evaluator and MAKEGRID identities, midpoint
owner observations, total-degree cubic reconstruction, donor order/support,
distance weights, boundary replacement, periodic incidence, collapsed-axis
rule, and one common owner normalizer before comparing variants.

Start from the saved q9, q11 and q8-subdivision integrals. Rank signed
per-face and per-raw-cell changes deterministically, inspect logical ranges,
periodic wrapping, Jacobian/weights, wall evaluation and crossings of actual
evaluator pieces, then apply evaluator-knot-aware or adaptive integration only
to the bounded offending set. Piecewise geometry is a hypothesis until the
new arrays support it. Include an independent quadrature family or equivalent
independent refinement check. Qualify the volume source separately on the same
complete owners and report normalization uncertainty explicitly. Constants
precede the original radial, angular and mixed fields; reuse geometry
evaluations across fields.

Use a measured pilot to cap refinement and runtime. Do not apply a blanket
high-order tensor rule to the domain. Compare integration uncertainty with the
completed operator spatial-error scale and applicable reference-error budget;
do not impose a relative target on a nearly zero local difference.

## Stage B completed-owner decomposition

At common integration and boundary conventions, save and compare:

- `A`: current q9 fitted action;
- `B`: the same frozen cubic reconstruction integrated with qualified geometry;
- `C`: exact manufactured values integrated with that geometry rule;
- `R`: an independently qualified continuum volume source.

Retain unnormalized face fluxes, signed incidence, physical-boundary
replacements, owner numerators and each volume estimate. Report vector
differences `A-B`, `B-C`, `C-R`, `A-R` and `B-R`; do not treat their norms as
additive shares. Paired comparisons use identical boundary data and
integration, while the boundary-integration change from the archived q9 action
is recorded separately. A supported integration correction may be prepared as
a bounded candidate only; no other numerical policy changes are allowed.

## Stage C derived-gradient diagnostic

Freeze a few existing worst N64 near-axis faces and one or two ordinary
controls before evaluating new variants. At common nodes and integration,
compare:

1. a cubic fit of the midpoint-observed scalar `g = b dot grad(f)`;
2. a cubic fit of the original scalar `f`, differentiated analytically and
   contracted with continuously evaluated `b` at target nodes;
3. exact continuously evaluated `b dot grad(f)`.

Save absolute and relative node errors, variation scales, signed face fluxes,
logical coordinates, regular `x=u cos(theta), y=u sin(theta), eta`
coordinates, and transformed regular-chart components of `b`. Use the existing
direct diffusion functional as a control only where support, functional and
boundary treatment match, and disclose differences. A face-only result remains
face-only unless every incident face for an owner is included.

This diagnostic asks whether carrying geometry-dependent variation inside the
fitted scalar explains amplification. It does not require `G` and `D` to factor
the diffusion action and is not a new qualification blocker.

## Evidence and stopping point

Deliver a reproducible driver, frozen selection, reanalysis-ready intermediate
arrays and complete identities, measured timing and peak memory below 10 GiB,
and an addendum that classifies the result as bookkeeping defect, shared
operator/reference integration error, residual reconstruction issue, or an
unresolved combination with quantified uncertainty. Recommend either one next
bounded step or preparation of the global N32/N48/N64 G/D qualification once
the action/reference identity is defensible. Do not launch that campaign.

