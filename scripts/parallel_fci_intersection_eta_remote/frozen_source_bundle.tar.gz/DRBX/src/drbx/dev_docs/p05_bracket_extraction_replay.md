# P05 bracket extraction and replay

## Assignment and frozen contract

This implementation follow-through extracts the globally qualified centered
and material bracket prototypes into reusable package interfaces. Its numerical
authorities are the centered campaign at revision `c54b0552` and the material
campaign at revision `257bd55f`; their static accuracy milestones remain
passed. Scope ends at operator implementation and saved-action replay.

Freeze total-degree cubic reconstruction (20 regular-chart coefficients), the
raw-midpoint physical-volume owner observation, installed selection-v3 donor
ties/sectors/coverage/expansion, q3 face and cell integration, continuous
geometry evaluation, raw anchors, matched volume correction, and owner-volume
normalization. Centered actions are `A`, `B`, and `C=(A+B)/2`. Material is
centered `A` plus the recentered nodewise jump with fixed bias `0.75`. Preserve
collapsed-axis, wall, and stored periodic-endpoint conventions. The volume
curl uses the campaign finite-difference setting.

Selection acceptance is also frozen: use the campaign Gram eigenspectrum with
relative cutoff `1e-12`, maximum polynomial-reproduction residual `1e-9`, and
at least three angular columns on every participating plane. This arithmetic
detail matters for nearly deficient N64 rows; substituting an otherwise
equivalent rectangular-SVD rank decision can select a different fallback.

Host preparation belongs in `drbx.geometry.fci_perpendicular_bracket` and is
field independent. It emits versioned, fixed-shape face/cell blocks containing
compact topology, q3 geometry, selected donors, polynomial coefficient maps,
and boundary classifications. Dynamic owner values, raw anchors, and wall
traces are runtime inputs. Side fits use rank-revealing least squares; runtime
does no search or factorization. Sidecars are separate from restart and the
existing geometry schema and reject geometry/policy identity mismatches.

Pure JAX application belongs in `drbx.native.fci_perpendicular_bracket`.
Application retains raw-cell incidence before owner aggregation, including
same-owner internal anchor terms and one-sided stored periodic endpoints.
Material correction is added only to `A`.

## Replay and completion

Replay proceeds from bounded actual-HSX rows through complete N32, then frozen
complete-owner N48/N64 samples selected before mismatch inspection. Component
order is donors/scales, coefficient maps, q-node values/gradients, face fluxes,
anchors/volume terms, and complete actions. The completed-action discrepancy
budget is 0.1% of the corresponding archived spatial error; scale-aware float64
tolerances apply to zero targets. Mismatches are implementation defects, not
permission to retune the method.

Focused tests cover field-independent preparation and reuse, polynomial and
constant reproduction, raw incidence/endpoints/walls, centered/material
components, eager/JIT/JVP, sidecar identity/round-trip, and block-size
independence. Evidence is recorded in the
[P05 extraction/replay report](../../../../work/p05_bracket_extraction_replay_20260922/report.md).

The completed replay passes. Complete-domain N32 has a worst
owner-volume-weighted replay discrepancy of `4.8688e-4` of the corresponding
archived action's spatial error; preselected complete-owner N48 and N64 have
worst ratios `2.8006e-4` and `3.1556e-10`. `A`, `B`, `C`, and material `A`
use their own archived error against the continuum reference; the standalone
correction diagnostic uses material `A`'s error. The bounded component
preflight agrees to `1.79e-17` or better and confirms padded/split block
invariance. These are
implementation-replay results, not new accuracy or production certification.

A self-contained [actual-HSX fixture](../../../tests/data/p05_actual_hsx/README.md)
now freezes five N32 complete owners with all 44 raw members, all 225 incident
faces, and the full 1,162-owner donor closure. Its focused tests replay archived
components/actions and exercise resident eager/JIT/JVP evaluation, changed-field
reuse, wall/periodic/anchor/volume paths, and real-block padding without reading
the original campaign artifacts. This is bounded regression evidence, not a
replacement for the completed global replay or a production integration claim.

This work does not integrate the MMS driver, change production defaults,
evolve solutions, implement curvature, synchronize the blob driver, or certify
structural/production behavior. After completion, the next bounded task is a
P06 complete-curvature comparison using the extracted machinery.
