"""Prepared direct-cubic parallel gradient and divergence functionals.

Geometry queries, quadrature, donor selection and factorization are host-side
preparation. Runtime application consumes only compact donor/coefficient maps,
incidence and declared output measures. Manufactured fields never enter this
module.
"""

from __future__ import annotations

from dataclasses import dataclass, fields
import json
import os
from pathlib import Path
from typing import Callable, Mapping

import numpy as np

from .fci_direct_cubic_reconstruction import (
    DirectCubicHostGeometry,
    DirectCubicPolicy,
    prepare_direct_cubic_functional_rows,
    prepare_direct_cubic_reconstruction,
)


PARALLEL_DIRECT_CUBIC_VERSION = "drbx.fci-parallel-direct-cubic-v1"
PARALLEL_DIRECT_CUBIC_IMPLEMENTATION = "parallel-direct-cubic-host-v1"


@dataclass(frozen=True)
class UniformCompositeIntegrationPolicy:
    """Field-independent uniform logical-cell composite quadrature policy.

    The subdivision counts are ordinary uniform partitions. They do not name
    or imply evaluator interpolation knots.
    """

    face_family: str = "gauss-legendre"
    face_order: int = 8
    volume_family: str = "gauss-legendre"
    volume_order: int = 8
    subdivisions_u: int = 2
    subdivisions_theta: int = 2
    subdivisions_eta: int = 4

    def __post_init__(self) -> None:
        if self.face_family != "gauss-legendre" or self.volume_family != "gauss-legendre":
            raise ValueError("only the frozen Gauss-Legendre policy is supported")
        if min(
            self.face_order,
            self.volume_order,
            self.subdivisions_u,
            self.subdivisions_theta,
            self.subdivisions_eta,
        ) < 1:
            raise ValueError("orders and subdivision counts must be positive")

    @property
    def subdivisions(self) -> tuple[int, int, int]:
        return (self.subdivisions_u, self.subdivisions_theta, self.subdivisions_eta)

    def payload(self) -> dict[str, object]:
        return {
            "face_family": self.face_family,
            "face_order": self.face_order,
            "volume_family": self.volume_family,
            "volume_order": self.volume_order,
            "uniform_subdivisions_per_logical_axis": list(self.subdivisions),
            "sample_planes_are_knots": False,
        }


def q06_uniform_composite_policy(resolution: int) -> UniformCompositeIntegrationPolicy:
    """Return the frozen equal-cost Q06 candidate for one resolution."""

    eta = {32: 8, 48: 6, 64: 4}
    try:
        eta_count = eta[int(resolution)]
    except KeyError as error:
        raise ValueError("Q06 policy is frozen only for resolutions 32, 48 and 64") from error
    return UniformCompositeIntegrationPolicy(subdivisions_eta=eta_count)


def uniform_composite_legendre_nodes(
    lower: float,
    upper: float,
    *,
    order: int,
    subdivisions: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Return nodes and weights for a uniform composite Legendre interval."""

    if not np.isfinite(lower) or not np.isfinite(upper) or upper <= lower:
        raise ValueError("integration interval must be finite and increasing")
    if order < 1 or subdivisions < 1:
        raise ValueError("order and subdivisions must be positive")
    nodes, weights = np.polynomial.legendre.leggauss(order)
    edges = np.linspace(lower, upper, subdivisions + 1)
    values = []
    factors = []
    for lo, hi in zip(edges[:-1], edges[1:], strict=True):
        values.append(0.5 * (lo + hi) + 0.5 * (hi - lo) * nodes)
        factors.append(0.5 * (hi - lo) * weights)
    return np.concatenate(values), np.concatenate(factors)


def integrated_parallel_face_target(
    logical_weights: np.ndarray,
    jacobian: np.ndarray,
    b_contravariant: np.ndarray,
    face_axis: int,
    basis_values: np.ndarray,
) -> np.ndarray:
    """Integrate ``J b^axis p`` for one canonical oriented face."""

    weights = np.asarray(logical_weights, dtype=np.float64)
    J = np.asarray(jacobian, dtype=np.float64)
    b = np.asarray(b_contravariant, dtype=np.float64)
    basis = np.asarray(basis_values, dtype=np.float64)
    if weights.shape != J.shape or b.shape != (len(weights), 3):
        raise ValueError("face geometry sample shape mismatch")
    if basis.ndim != 2 or basis.shape[0] != len(weights):
        raise ValueError("face basis sample shape mismatch")
    if face_axis not in (0, 1, 2):
        raise ValueError("face_axis must be 0, 1 or 2")
    return np.sum((weights * J * b[:, face_axis])[:, None] * basis, axis=0)


def integrated_parallel_gradient_target(
    logical_weights: np.ndarray,
    jacobian: np.ndarray,
    b_contravariant: np.ndarray,
    basis_logical_gradient: np.ndarray,
) -> np.ndarray:
    """Integrate ``J b dot grad(p)`` over one physical owner."""

    weights = np.asarray(logical_weights, dtype=np.float64)
    J = np.asarray(jacobian, dtype=np.float64)
    b = np.asarray(b_contravariant, dtype=np.float64)
    gradient = np.asarray(basis_logical_gradient, dtype=np.float64)
    if weights.shape != J.shape or b.shape != (len(weights), 3):
        raise ValueError("owner geometry sample shape mismatch")
    if gradient.ndim != 3 or gradient.shape[0] != len(weights) or gradient.shape[2] != 3:
        raise ValueError("owner gradient-basis sample shape mismatch")
    return np.sum(
        (weights * J)[:, None] * np.einsum("ni,nji->nj", b, gradient), axis=0
    )


def integrated_parallel_product_target(
    logical_weights: np.ndarray,
    jacobian: np.ndarray,
    div_b: np.ndarray,
    basis_values: np.ndarray,
) -> np.ndarray:
    """Integrate ``J p div(b)`` using the supplied direct geometry divergence."""

    weights = np.asarray(logical_weights, dtype=np.float64)
    J = np.asarray(jacobian, dtype=np.float64)
    divergence = np.asarray(div_b, dtype=np.float64)
    basis = np.asarray(basis_values, dtype=np.float64)
    if weights.shape != J.shape or divergence.shape != weights.shape:
        raise ValueError("owner product geometry sample shape mismatch")
    if basis.ndim != 2 or basis.shape[0] != len(weights):
        raise ValueError("owner basis sample shape mismatch")
    return np.sum((weights * J * divergence)[:, None] * basis, axis=0)


@dataclass(frozen=True)
class PreparedParallelDirectCubic:
    """Runtime-ready G/D maps and their explicit normalization conventions."""

    resolution: int
    face_ids: np.ndarray
    divergence_donors: np.ndarray
    divergence_coefficients: np.ndarray
    face_minus: np.ndarray
    face_plus: np.ndarray
    face_boundary: np.ndarray
    gradient_owner_ids: np.ndarray
    gradient_donors: np.ndarray
    gradient_coefficients: np.ndarray
    product_donors: np.ndarray
    product_coefficients: np.ndarray
    observation_owner_measures: np.ndarray
    output_owner_measures: np.ndarray

    def __post_init__(self) -> None:
        n_face = len(self.face_ids)
        n_owner = len(self.output_owner_measures)
        n_gradient = len(self.gradient_owner_ids)
        if self.divergence_donors.shape != (n_face, 120) or self.divergence_coefficients.shape != (n_face, 120):
            raise ValueError("divergence maps require 120 donors per face")
        if self.face_minus.shape != (n_face,) or self.face_plus.shape != (n_face,) or self.face_boundary.shape != (n_face,):
            raise ValueError("face incidence shape mismatch")
        if self.gradient_donors.shape != (n_gradient, 120) or self.gradient_coefficients.shape != (n_gradient, 120):
            raise ValueError("gradient maps require 120 donors per owner row")
        if self.product_donors.shape not in ((0, 120), (n_gradient, 120)) or self.product_coefficients.shape != self.product_donors.shape:
            raise ValueError("product maps must be absent or align with gradient rows")
        if self.observation_owner_measures.shape != (n_owner,) or self.output_owner_measures.shape != (n_owner,):
            raise ValueError("owner measure shape mismatch")
        if np.any(self.observation_owner_measures <= 0) or np.any(self.output_owner_measures <= 0):
            raise ValueError("owner measures must be positive")
        if np.any(self.gradient_owner_ids < 0) or np.any(self.gradient_owner_ids >= n_owner):
            raise ValueError("gradient owner ids are out of range")
        boundary = np.asarray(self.face_boundary, dtype=bool)
        if np.any(self.divergence_donors[boundary] != -1) or np.any(self.divergence_coefficients[boundary] != 0):
            raise ValueError("boundary divergence rows must be empty and dynamic")


FaceTargetEvaluator = Callable[[np.ndarray, np.ndarray, np.ndarray, np.ndarray], np.ndarray]
OwnerTargetEvaluator = Callable[[np.ndarray, np.ndarray, np.ndarray, np.ndarray], np.ndarray]


def _evaluate_owner_targets(
    target: np.ndarray | OwnerTargetEvaluator,
    owner_ids: np.ndarray,
    owner_centers: np.ndarray,
    owner_scales: np.ndarray,
    owner_planes: np.ndarray,
    *,
    block_size: int,
) -> np.ndarray:
    if not callable(target):
        result = np.asarray(target, dtype=np.float64)
        if result.shape != (len(owner_ids), 20):
            raise ValueError("owner target array must have shape (n_rows, 20)")
        return result
    result = np.empty((len(owner_ids), 20), dtype=np.float64)
    for start in range(0, len(owner_ids), block_size):
        rows = np.arange(start, min(start + block_size, len(owner_ids)))
        block = np.asarray(
            target(owner_ids[rows], owner_centers[rows], owner_scales[rows], owner_planes[rows]),
            dtype=np.float64,
        )
        if block.shape != (len(rows), 20):
            raise ValueError("owner target evaluator returned an incompatible shape")
        result[rows] = block
    return result


def prepare_parallel_direct_cubic(
    geometry: DirectCubicHostGeometry,
    divergence_face_target: np.ndarray | FaceTargetEvaluator,
    gradient_integrated_target: np.ndarray | OwnerTargetEvaluator,
    *,
    owner_scales: np.ndarray,
    output_owner_measures: np.ndarray,
    gradient_owner_ids: np.ndarray | None = None,
    product_integrated_target: np.ndarray | OwnerTargetEvaluator | None = None,
    reconstruction_policy: DirectCubicPolicy = DirectCubicPolicy(),
    block_size: int = 32,
) -> tuple[PreparedParallelDirectCubic, dict[str, dict[str, np.ndarray]]]:
    """Prepare compact parallel G/D maps without retaining quadrature tensors.

    Owner target callbacks return *integrated numerators*. This routine divides
    them by ``output_owner_measures`` before fitting owner-average functionals.
    The observation moments embedded in ``geometry`` remain normalized by
    ``geometry.owner_volumes`` and are not silently redefined.
    """

    if block_size < 1:
        raise ValueError("block_size must be positive")
    n_owner = len(geometry.owner_volumes)
    output_measure = np.asarray(output_owner_measures, dtype=np.float64)
    scales = np.asarray(owner_scales, dtype=np.float64)
    if output_measure.shape != (n_owner,) or np.any(output_measure <= 0):
        raise ValueError("output_owner_measures must be positive with one entry per owner")
    if scales.shape != (n_owner, 3) or np.any(scales <= 0):
        raise ValueError("owner_scales must have shape (n_owner, 3) and be positive")
    owner_ids = (
        np.arange(n_owner, dtype=np.int64)
        if gradient_owner_ids is None
        else np.asarray(gradient_owner_ids, dtype=np.int64)
    )
    if owner_ids.ndim != 1 or len(np.unique(owner_ids)) != len(owner_ids):
        raise ValueError("gradient_owner_ids must be one-dimensional and unique")
    if np.any(owner_ids < 0) or np.any(owner_ids >= n_owner):
        raise ValueError("gradient_owner_ids are out of range")

    divergence, divergence_diagnostics = prepare_direct_cubic_reconstruction(
        geometry,
        divergence_face_target,
        policy=reconstruction_policy,
        batch_size=block_size,
    )
    target_G_numerator = _evaluate_owner_targets(
        gradient_integrated_target,
        owner_ids,
        np.asarray(geometry.owner_centers)[owner_ids],
        scales[owner_ids],
        np.asarray(geometry.owner_planes)[owner_ids],
        block_size=block_size,
    )
    target_G = target_G_numerator / output_measure[owner_ids, None]
    no_plus = np.full(len(owner_ids), -1, dtype=np.int64)
    gradient_donors, gradient_coefficients, gradient_diagnostics = prepare_direct_cubic_functional_rows(
        resolution=geometry.resolution,
        owner_centers=geometry.owner_centers,
        owner_planes=geometry.owner_planes,
        owner_moments=geometry.owner_moments,
        evaluation_centers=np.asarray(geometry.owner_centers)[owner_ids],
        evaluation_scales=scales[owner_ids],
        evaluation_planes=np.asarray(geometry.owner_planes)[owner_ids],
        retained_minus=owner_ids,
        retained_plus=no_plus,
        target=target_G,
        policy=reconstruction_policy,
        batch_size=block_size,
    )

    if product_integrated_target is None:
        product_donors = np.empty((0, 120), dtype=np.int64)
        product_coefficients = np.empty((0, 120), dtype=np.float64)
        product_diagnostics: dict[str, np.ndarray] = {}
    else:
        target_product_numerator = _evaluate_owner_targets(
            product_integrated_target,
            owner_ids,
            np.asarray(geometry.owner_centers)[owner_ids],
            scales[owner_ids],
            np.asarray(geometry.owner_planes)[owner_ids],
            block_size=block_size,
        )
        target_product = target_product_numerator / output_measure[owner_ids, None]
        product_donors, product_coefficients, product_diagnostics = prepare_direct_cubic_functional_rows(
            resolution=geometry.resolution,
            owner_centers=geometry.owner_centers,
            owner_planes=geometry.owner_planes,
            owner_moments=geometry.owner_moments,
            evaluation_centers=np.asarray(geometry.owner_centers)[owner_ids],
            evaluation_scales=scales[owner_ids],
            evaluation_planes=np.asarray(geometry.owner_planes)[owner_ids],
            retained_minus=owner_ids,
            retained_plus=no_plus,
            target=target_product,
            policy=reconstruction_policy,
            batch_size=block_size,
        )

    prepared = PreparedParallelDirectCubic(
        resolution=geometry.resolution,
        face_ids=divergence.face_ids,
        divergence_donors=divergence.donors,
        divergence_coefficients=divergence.coefficients,
        face_minus=divergence.face_minus,
        face_plus=divergence.face_plus,
        face_boundary=divergence.face_boundary,
        gradient_owner_ids=owner_ids,
        gradient_donors=gradient_donors,
        gradient_coefficients=gradient_coefficients,
        product_donors=product_donors,
        product_coefficients=product_coefficients,
        observation_owner_measures=np.asarray(geometry.owner_volumes, dtype=np.float64),
        output_owner_measures=output_measure,
    )
    return prepared, {
        "divergence": divergence_diagnostics,
        "gradient": gradient_diagnostics,
        "product": product_diagnostics,
    }


def parallel_direct_cubic_identity(
    *,
    source: str,
    geometry: str,
    topology: str,
    evaluator: str,
    observation: str,
    quadrature: Mapping[str, object],
    output_normalizer: str,
    boundary_convention: str,
    implementation: str = PARALLEL_DIRECT_CUBIC_IMPLEMENTATION,
) -> dict[str, object]:
    """Build the strict identity required for prepared-map reuse."""

    return {
        "schema": PARALLEL_DIRECT_CUBIC_VERSION,
        "source": str(source),
        "geometry": str(geometry),
        "topology": str(topology),
        "evaluator": str(evaluator),
        "observation": str(observation),
        "quadrature": json.loads(json.dumps(dict(quadrature), sort_keys=True)),
        "output_normalizer": str(output_normalizer),
        "precision": "float64",
        "boundary_convention": str(boundary_convention),
        "implementation": str(implementation),
    }


def write_parallel_direct_cubic_sidecar(
    path: str | Path,
    prepared: PreparedParallelDirectCubic,
    *,
    identity: Mapping[str, object],
) -> Path:
    """Atomically write prepared G/D maps and strict identity metadata."""

    if identity.get("schema") != PARALLEL_DIRECT_CUBIC_VERSION:
        raise ValueError("parallel sidecar identity schema mismatch")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".{os.getpid()}.tmp")
    arrays = {
        field.name: np.asarray(getattr(prepared, field.name))
        for field in fields(PreparedParallelDirectCubic)
    }
    with temporary.open("wb") as stream:
        np.savez_compressed(
            stream,
            **arrays,
            metadata_json=np.asarray(json.dumps(dict(identity), sort_keys=True)),
        )
    os.replace(temporary, path)
    return path


def load_parallel_direct_cubic_sidecar(
    path: str | Path,
    *,
    identity: Mapping[str, object],
) -> PreparedParallelDirectCubic:
    """Load a prepared map only when every identity field matches exactly."""

    expected = json.loads(json.dumps(dict(identity), sort_keys=True))
    with np.load(path, allow_pickle=False) as payload:
        actual = json.loads(str(payload["metadata_json"].item()))
        if actual != expected:
            raise ValueError("parallel direct-cubic sidecar identity mismatch")
        return PreparedParallelDirectCubic(
            **{
                field.name: int(payload[field.name]) if field.name == "resolution" else np.asarray(payload[field.name])
                for field in fields(PreparedParallelDirectCubic)
            }
        )
