"""Host preparation for the field-independent direct-cubic FCI face functional.

This module owns geometry-only preparation and reconstruction sidecar I/O.  It
does not import validation campaigns, manufactured fields, workspace helpers,
or saved answers.  Continuous geometry evaluators may provide the integrated
face target, but runtime field values never enter preparation.
"""

from __future__ import annotations

from dataclasses import dataclass, fields
import itertools
import json
import math
import os
from pathlib import Path
from typing import Callable, Mapping

import numpy as np
from scipy.spatial import cKDTree


DIRECT_CUBIC_SIDECAR_VERSION = "drbx.fci-direct-cubic-reconstruction-v1"
DIRECT_CUBIC_IMPLEMENTATION_VERSION = "direct-cubic-host-v1"
DIRECT_CUBIC_FUNCTIONAL_IDENTITY_VERSION = "drbx.fci-direct-cubic-functional-v1"
DIRECT_CUBIC_EXPONENTS = tuple(
    exponent
    for degree in range(4)
    for exponent in itertools.product(range(degree + 1), repeat=3)
    if sum(exponent) == degree
)
DIRECT_CUBIC_XY_EXPONENTS = tuple(
    (i, degree - i) for degree in range(4) for i in range(degree + 1)
)


@dataclass(frozen=True)
class DirectCubicPolicy:
    """Frozen numerical policy of the qualified direct face reconstruction."""

    degree: int = 3
    owners_per_plane: int = 24
    plane_offsets: tuple[int, ...] = (-2, -1, 0, 1, 2)
    owner_sampling: str = "raw-midpoint physical-volume-weighted means"
    selection: str = "exact local radial/tangential distance, owner-id tie; incident owners retained"
    weight: str = "(1+radial_tangential_eta_distance_squared)^(-3/2)"
    target: str = "continuous geometry integrated q9 parallel face flux"
    boundary: str = "prescribed continuum face flux, identical to high-order reference"

    def payload(self) -> dict[str, object]:
        value = {field.name: getattr(self, field.name) for field in fields(self)}
        value["plane_offsets"] = list(self.plane_offsets)
        return value


@dataclass(frozen=True)
class DirectCubicHostGeometry:
    """Field-independent compact-owner and oriented-face preparation inputs."""

    resolution: int
    owner_centers: np.ndarray
    owner_planes: np.ndarray
    owner_volumes: np.ndarray
    owner_moments: np.ndarray
    face_ids: np.ndarray
    face_centers: np.ndarray
    face_scales: np.ndarray
    face_planes: np.ndarray
    face_minus: np.ndarray
    face_plus: np.ndarray
    face_boundary: np.ndarray
    owner_raw_indptr: np.ndarray | None = None
    owner_raw_indices: np.ndarray | None = None
    owner_collapsed_axis: np.ndarray | None = None
    face_theta_seam: np.ndarray | None = None
    face_eta_seam: np.ndarray | None = None

    def __post_init__(self) -> None:
        n_owner = len(self.owner_volumes)
        n_face = len(self.face_ids)
        expected = {
            "owner_centers": (n_owner, 3),
            "owner_planes": (n_owner,),
            "owner_moments": (n_owner, 10),
            "face_centers": (n_face, 3),
            "face_scales": (n_face, 3),
            "face_planes": (n_face,),
            "face_minus": (n_face,),
            "face_plus": (n_face,),
            "face_boundary": (n_face,),
        }
        for name, shape in expected.items():
            if np.shape(getattr(self, name)) != shape:
                raise ValueError(f"{name} must have shape {shape}")
        if self.resolution < 1 or np.any(np.asarray(self.owner_volumes) <= 0):
            raise ValueError("resolution and owner volumes must be positive")
        face_ids = np.asarray(self.face_ids)
        if face_ids.ndim != 1 or np.any(face_ids < 0) or (
            n_face > 1 and np.any(np.diff(face_ids) <= 0)
        ):
            raise ValueError("face_ids must be unique canonical ids in increasing order")
        if np.any(np.asarray(self.face_minus) < 0) or np.any(np.asarray(self.face_minus) >= n_owner):
            raise ValueError("invalid minus-owner index")
        plus = np.asarray(self.face_plus)
        boundary = np.asarray(self.face_boundary, dtype=bool)
        if np.any((plus < 0) != boundary) or np.any(plus[~boundary] >= n_owner):
            raise ValueError("boundary classification and plus-owner indices disagree")
        optional_shapes = {
            "owner_collapsed_axis": (n_owner,),
            "face_theta_seam": (n_face,),
            "face_eta_seam": (n_face,),
        }
        for name, shape in optional_shapes.items():
            value = getattr(self, name)
            if value is not None and np.shape(value) != shape:
                raise ValueError(f"{name} must have shape {shape}")
        if (self.owner_raw_indptr is None) != (self.owner_raw_indices is None):
            raise ValueError("owner raw indptr and indices must be supplied together")
        if self.owner_raw_indptr is not None:
            indptr = np.asarray(self.owner_raw_indptr, dtype=np.int64)
            indices = np.asarray(self.owner_raw_indices, dtype=np.int64)
            if indptr.shape != (n_owner + 1,) or indptr[0] != 0:
                raise ValueError("owner_raw_indptr must start at zero with one entry per owner plus one")
            if np.any(np.diff(indptr) < 0) or indptr[-1] != len(indices):
                raise ValueError("owner raw membership indptr is inconsistent with indices")
            if np.any(indices < 0) or len(np.unique(indices)) != len(indices):
                raise ValueError("owner raw membership indices must be nonnegative and unique")


@dataclass(frozen=True)
class DirectCubicReconstruction:
    """Runtime-ready shared-face coefficients and conservative incidence."""

    resolution: int
    face_ids: np.ndarray
    donors: np.ndarray
    coefficients: np.ndarray
    face_minus: np.ndarray
    face_plus: np.ndarray
    face_boundary: np.ndarray
    owner_volumes: np.ndarray
    face_centers: np.ndarray
    face_scales: np.ndarray
    face_planes: np.ndarray
    face_theta_seam: np.ndarray
    face_eta_seam: np.ndarray
    owner_collapsed_axis: np.ndarray
    owner_raw_indptr: np.ndarray
    owner_raw_indices: np.ndarray

    def __post_init__(self) -> None:
        n_face = len(self.face_ids)
        n_owner = len(self.owner_volumes)
        if np.shape(self.donors) != (n_face, 120) or np.shape(self.coefficients) != (n_face, 120):
            raise ValueError("direct-cubic reconstruction requires 120 donors per canonical face")
        if np.shape(self.face_minus) != (n_face,) or np.shape(self.face_plus) != (n_face,):
            raise ValueError("face incidence shape mismatch")
        if np.shape(self.face_boundary) != (n_face,):
            raise ValueError("face boundary shape mismatch")
        if np.shape(self.owner_collapsed_axis) != (n_owner,):
            raise ValueError("collapsed-axis owner mask shape mismatch")
        indptr = np.asarray(self.owner_raw_indptr, dtype=np.int64)
        indices = np.asarray(self.owner_raw_indices, dtype=np.int64)
        if indptr.shape != (n_owner + 1,) or indptr[0] != 0:
            raise ValueError("owner raw membership indptr shape mismatch")
        if np.any(np.diff(indptr) < 0) or indptr[-1] != len(indices):
            raise ValueError("owner raw membership payload is inconsistent")
        if np.any(indices < 0) or len(np.unique(indices)) != len(indices):
            raise ValueError("owner raw membership indices must be nonnegative and unique")
        boundary = np.asarray(self.face_boundary, dtype=bool)
        if np.any(np.asarray(self.donors)[boundary] != -1) or np.any(np.asarray(self.coefficients)[boundary] != 0):
            raise ValueError("physical-boundary reconstruction rows must be empty; boundary flux is dynamic")


def periodic_delta(value: np.ndarray, origin: np.ndarray | float) -> np.ndarray:
    """Return the principal ``2*pi``-periodic displacement."""

    return (np.asarray(value) - origin + np.pi) % (2 * np.pi) - np.pi


def compact_owner_memberships(
    raw_owner_ids: np.ndarray,
    owner_ids: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Convert a raw-cell owner-id map to compact CSR-style memberships.

    ``owner_ids`` defines compact owner order. Raw cells with a negative owner
    id are inactive and omitted. Every active raw owner id must occur exactly
    once in ``owner_ids``; this makes the membership payload independent of a
    particular state or restart layout.
    """

    raw = np.asarray(raw_owner_ids, dtype=np.int64).reshape(-1)
    owners = np.asarray(owner_ids, dtype=np.int64).reshape(-1)
    if len(owners) == 0 or len(np.unique(owners)) != len(owners):
        raise ValueError("owner_ids must be nonempty and unique")
    active = np.flatnonzero(raw >= 0)
    order = np.argsort(owners)
    sorted_owners = owners[order]
    positions = np.searchsorted(sorted_owners, raw[active])
    valid = positions < len(sorted_owners)
    matched = np.zeros_like(valid)
    matched[valid] = sorted_owners[positions[valid]] == raw[active][valid]
    if not np.all(matched):
        missing = np.unique(raw[active][~matched])
        raise ValueError(f"raw owner ids are absent from compact owner_ids: {missing[:8].tolist()}")
    compact = order[positions]
    membership_order = np.lexsort((active, compact))
    compact = compact[membership_order]
    indices = active[membership_order].astype(np.int64, copy=False)
    counts = np.bincount(compact, minlength=len(owners))
    indptr = np.concatenate(([0], np.cumsum(counts, dtype=np.int64)))
    return indptr, indices


def centered_owner_observation_moments(
    raw_xyz: np.ndarray,
    raw_owner: np.ndarray,
    raw_volume: np.ndarray,
    owner_volume: np.ndarray,
    owner_centers: np.ndarray,
    resolution: int,
) -> np.ndarray:
    """Build the ten centered in-plane raw-midpoint owner observations."""

    raw_xyz = np.asarray(raw_xyz, dtype=np.float64)
    raw_owner = np.asarray(raw_owner, dtype=np.int64)
    raw_volume = np.asarray(raw_volume, dtype=np.float64)
    owner_volume = np.asarray(owner_volume, dtype=np.float64)
    owner_centers = np.asarray(owner_centers, dtype=np.float64)
    if np.max(np.abs(periodic_delta(raw_xyz[:, 2], owner_centers[raw_owner, 2]))) > 1e-12:
        raise ValueError("owner spans eta planes; planar-owner observation contract violated")
    centered = (raw_xyz[:, :2] - owner_centers[raw_owner, :2]) * resolution
    return np.column_stack(
        [
            np.bincount(
                raw_owner,
                weights=raw_volume * centered[:, 0] ** i * centered[:, 1] ** j,
                minlength=len(owner_volume),
            )
            / owner_volume
            for i, j in DIRECT_CUBIC_XY_EXPONENTS
        ]
    )


class DirectCubicOwnerIndex:
    """Indexed deterministic donor selection in the qualified local chart."""

    def __init__(self, centers: np.ndarray, planes: np.ndarray, resolution: int, policy: DirectCubicPolicy = DirectCubicPolicy()):
        self.centers = np.asarray(centers, dtype=np.float64)
        self.planes = np.asarray(planes, dtype=np.int64)
        self.resolution = int(resolution)
        self.policy = policy
        self.ids = [np.flatnonzero(self.planes == plane) for plane in range(self.resolution)]
        if any(len(ids) < policy.owners_per_plane for ids in self.ids):
            raise ValueError("fewer owners on an eta plane than the frozen policy requires")
        self.trees = [cKDTree(self.centers[ids, :2]) for ids in self.ids]

    def select(self, center: np.ndarray, plane: int, minus: int, plus: int, *, exhaustive: bool = False) -> tuple[np.ndarray, np.ndarray, tuple[int, ...]]:
        center = np.asarray(center, dtype=np.float64)
        theta = np.arctan2(center[1], center[0])
        radial_scale = 1.0 / self.resolution
        tangent_scale = max(np.hypot(*center[:2]) * 2 * np.pi / self.resolution, radial_scale)
        cosine, sine = np.cos(theta), np.sin(theta)

        def radial_tangent_distance(ids: np.ndarray) -> np.ndarray:
            xy = self.centers[ids, :2] - center[:2]
            return (
                ((xy[:, 0] * cosine + xy[:, 1] * sine) / radial_scale) ** 2
                + ((-xy[:, 0] * sine + xy[:, 1] * cosine) / tangent_scale) ** 2
            )

        donors: list[int] = []
        candidate_counts: list[int] = []
        for offset in self.policy.plane_offsets:
            source_plane = (int(plane) + offset) % self.resolution
            ids = self.ids[source_plane]
            if exhaustive:
                candidates = ids
            else:
                _, first = self.trees[source_plane].query(center[:2], k=self.policy.owners_per_plane)
                radius = math.sqrt(float(np.max(radial_tangent_distance(ids[first])))) * max(radial_scale, tangent_scale)
                radius += 64 * np.finfo(float).eps * max(1.0, np.linalg.norm(center[:2]), radius)
                candidates = ids[self.trees[source_plane].query_ball_point(center[:2], radius)]
            distance = radial_tangent_distance(candidates)
            ranked = candidates[np.lexsort((candidates, distance))]
            chosen = list(
                dict.fromkeys(
                    int(owner)
                    for owner in (minus, plus)
                    if owner >= 0 and self.planes[owner] == source_plane
                )
            )
            for owner in ranked:
                if len(chosen) == self.policy.owners_per_plane:
                    break
                if int(owner) not in chosen:
                    chosen.append(int(owner))
            if len(chosen) != self.policy.owners_per_plane:
                raise RuntimeError("candidate bound omitted required donors")
            donors.extend(chosen)
            candidate_counts.append(len(candidates))
        donor_array = np.asarray(donors, dtype=np.int64)
        distance2 = radial_tangent_distance(donor_array)
        distance2 += (
            periodic_delta(self.centers[donor_array, 2], center[2])
            / (2 * np.pi / self.resolution)
        ) ** 2
        return donor_array, distance2, tuple(candidate_counts)


def direct_cubic_observation_matrix(
    donors: np.ndarray,
    owner_centers: np.ndarray,
    owner_moments: np.ndarray,
    face_centers: np.ndarray,
    face_scales: np.ndarray,
    resolution: int,
) -> np.ndarray:
    """Translate centered owner observations into the 20-mode face chart."""

    donors = np.asarray(donors, dtype=np.int64)
    centers = np.asarray(owner_centers, dtype=np.float64)
    moments = np.asarray(owner_moments, dtype=np.float64)
    face_centers = np.asarray(face_centers, dtype=np.float64)
    face_scales = np.asarray(face_scales, dtype=np.float64)
    shift = (centers[donors] - face_centers[..., None, :]) / face_scales[..., None, :]
    shift[..., 2] = periodic_delta(centers[donors, 2], face_centers[..., None, 2]) / face_scales[..., None, 2]
    factor = 1.0 / (resolution * face_scales)
    selected_moments = moments[donors]
    result = np.empty(donors.shape + (20,), dtype=np.float64)
    for column, (a, b, c) in enumerate(DIRECT_CUBIC_EXPONENTS):
        value = np.zeros(donors.shape, dtype=np.float64)
        for i in range(a + 1):
            for j in range(b + 1):
                value += (
                    math.comb(a, i)
                    * math.comb(b, j)
                    * shift[..., 0] ** (a - i)
                    * shift[..., 1] ** (b - j)
                    * (factor[..., 0] ** i * factor[..., 1] ** j)[..., None]
                    * selected_moments[..., DIRECT_CUBIC_XY_EXPONENTS.index((i, j))]
                )
        result[..., column] = value * shift[..., 2] ** c
    return result


def fit_direct_cubic_functional(
    observation_matrix: np.ndarray,
    distance2: np.ndarray,
    target: np.ndarray,
) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    """Solve the frozen rank-revealing weighted-SVD functional fit."""

    matrix = np.asarray(observation_matrix, dtype=np.float64)
    distance2 = np.asarray(distance2, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    weight = (1.0 + distance2) ** -1.5
    weighted = matrix.swapaxes(-1, -2) * weight[..., None, :]
    left, singular, right_t = np.linalg.svd(weighted, full_matrices=False)
    rank = np.sum(
        singular > np.finfo(float).eps * max(weighted.shape[-2:]) * singular[:, :1],
        axis=1,
    )
    if np.any(rank != 20):
        raise RuntimeError(f"rank-deficient cubic fit: {rank.tolist()}")
    amplitude = np.einsum("fij,fi->fj", left, target) / singular
    coefficients = weight * np.einsum("fji,fj->fi", right_t, amplitude)
    defect = np.linalg.norm(np.einsum("fij,fi->fj", matrix, coefficients) - target, axis=1)
    defect /= np.maximum(np.linalg.norm(target, axis=1), 1e-300)
    if not np.all(np.isfinite(coefficients)) or np.any(defect > 1e-10):
        raise RuntimeError(f"incompatible cubic target: max relative defect {defect.max()}")
    return coefficients, {
        "rank": rank,
        "singular_values": singular,
        "condition": singular[:, 0] / singular[:, -1],
        "cubic_defect": defect,
        "constant_flux": np.sum(coefficients, axis=1),
    }


TargetEvaluator = Callable[[np.ndarray, np.ndarray, np.ndarray, np.ndarray], np.ndarray]


def prepare_direct_cubic_functional_rows(
    *,
    resolution: int,
    owner_centers: np.ndarray,
    owner_planes: np.ndarray,
    owner_moments: np.ndarray,
    evaluation_centers: np.ndarray,
    evaluation_scales: np.ndarray,
    evaluation_planes: np.ndarray,
    retained_minus: np.ndarray,
    retained_plus: np.ndarray,
    target: np.ndarray,
    policy: DirectCubicPolicy = DirectCubicPolicy(),
    batch_size: int = 32,
) -> tuple[np.ndarray, np.ndarray, dict[str, np.ndarray]]:
    """Fit arbitrary cubic functionals on the frozen 120-owner supports.

    The target rows may represent a face integral or an owner-volume average;
    this routine only owns the field-independent observation/SVD contract.
    ``retained_minus`` and ``retained_plus`` identify owners that must remain
    in the support on their eta plane.  Owner-centred functionals use the
    evaluated owner as ``retained_minus`` and ``-1`` as ``retained_plus``.
    """

    if batch_size < 1:
        raise ValueError("batch_size must be positive")
    if policy != DirectCubicPolicy():
        raise ValueError("only the frozen qualified direct-cubic policy is supported")
    centers = np.asarray(evaluation_centers, dtype=np.float64)
    scales = np.asarray(evaluation_scales, dtype=np.float64)
    planes = np.asarray(evaluation_planes, dtype=np.int64)
    minus = np.asarray(retained_minus, dtype=np.int64)
    plus = np.asarray(retained_plus, dtype=np.int64)
    targets = np.asarray(target, dtype=np.float64)
    n_row = len(centers)
    expected = {
        "evaluation_centers": (n_row, 3),
        "evaluation_scales": (n_row, 3),
        "evaluation_planes": (n_row,),
        "retained_minus": (n_row,),
        "retained_plus": (n_row,),
        "target": (n_row, 20),
    }
    for name, shape in expected.items():
        value = {
            "evaluation_centers": centers,
            "evaluation_scales": scales,
            "evaluation_planes": planes,
            "retained_minus": minus,
            "retained_plus": plus,
            "target": targets,
        }[name]
        if value.shape != shape:
            raise ValueError(f"{name} must have shape {shape}")
    if np.any(scales <= 0):
        raise ValueError("evaluation scales must be positive")

    donors = np.empty((n_row, 120), dtype=np.int64)
    coefficients = np.empty((n_row, 120), dtype=np.float64)
    diagnostics = {
        "rank": np.empty(n_row, dtype=np.int64),
        "condition": np.empty(n_row, dtype=np.float64),
        "cubic_defect": np.empty(n_row, dtype=np.float64),
        "constant_flux": np.empty(n_row, dtype=np.float64),
        "candidate_count": np.empty((n_row, 5), dtype=np.int64),
        "support_extent": np.empty(n_row, dtype=np.float64),
    }
    owner_index = DirectCubicOwnerIndex(owner_centers, owner_planes, resolution, policy)
    for start in range(0, n_row, batch_size):
        ids = np.arange(start, min(start + batch_size, n_row))
        selected = [
            owner_index.select(
                centers[row], int(planes[row]), int(minus[row]), int(plus[row])
            )
            for row in ids
        ]
        batch_donors = np.stack([item[0] for item in selected])
        matrix = direct_cubic_observation_matrix(
            batch_donors,
            owner_centers,
            owner_moments,
            centers[ids],
            scales[ids],
            resolution,
        )
        batch_coefficients, batch_diagnostics = fit_direct_cubic_functional(
            matrix, np.stack([item[1] for item in selected]), targets[ids]
        )
        donors[ids] = batch_donors
        coefficients[ids] = batch_coefficients
        for name in ("rank", "condition", "cubic_defect", "constant_flux"):
            diagnostics[name][ids] = batch_diagnostics[name]
        diagnostics["candidate_count"][ids] = np.asarray([item[2] for item in selected])
        diagnostics["support_extent"][ids] = np.sqrt(
            np.max(np.stack([item[1] for item in selected]), axis=1)
        )
    return donors, coefficients, diagnostics


def prepare_direct_cubic_reconstruction(
    geometry: DirectCubicHostGeometry,
    target: np.ndarray | TargetEvaluator,
    *,
    policy: DirectCubicPolicy = DirectCubicPolicy(),
    batch_size: int = 32,
) -> tuple[DirectCubicReconstruction, dict[str, np.ndarray]]:
    """Prepare runtime coefficients without using any field values.

    A callable target receives ``(face_ids, centers, scales, planes)`` and must
    evaluate the continuous geometry functional at those actual face locations.
    """

    if batch_size < 1:
        raise ValueError("batch_size must be positive")
    if policy != DirectCubicPolicy():
        raise ValueError("only the frozen qualified direct-cubic policy is supported")
    n_face = len(geometry.face_ids)
    if callable(target):
        target_array = None
    else:
        target_array = np.asarray(target, dtype=np.float64)
        if target_array.shape != (n_face, 20):
            raise ValueError("target array must have one 20-mode functional per face")
    donors = np.full((n_face, 120), -1, dtype=np.int64)
    coefficients = np.zeros((n_face, 120), dtype=np.float64)
    diagnostics = {
        "rank": np.full(n_face, np.nan),
        "condition": np.full(n_face, np.nan),
        "cubic_defect": np.full(n_face, np.nan),
        "constant_flux": np.full(n_face, np.nan),
        "candidate_count": np.full((n_face, 5), -1, dtype=np.int64),
        "support_extent": np.full(n_face, np.nan),
    }
    interior = np.flatnonzero(~np.asarray(geometry.face_boundary, dtype=bool))
    for start in range(0, len(interior), batch_size):
        ids = interior[start : start + batch_size]
        batch_target = (
            np.asarray(
                target(
                    geometry.face_ids[ids],
                    geometry.face_centers[ids],
                    geometry.face_scales[ids],
                    geometry.face_planes[ids],
                ),
                dtype=np.float64,
            )
            if target_array is None
            else target_array[ids]
        )
        if batch_target.shape != (len(ids), 20):
            raise ValueError("continuous target evaluator returned an incompatible shape")
        batch_donors, batch_coefficients, batch_diagnostics = prepare_direct_cubic_functional_rows(
            resolution=geometry.resolution,
            owner_centers=geometry.owner_centers,
            owner_planes=geometry.owner_planes,
            owner_moments=geometry.owner_moments,
            evaluation_centers=geometry.face_centers[ids],
            evaluation_scales=geometry.face_scales[ids],
            evaluation_planes=geometry.face_planes[ids],
            retained_minus=geometry.face_minus[ids],
            retained_plus=geometry.face_plus[ids],
            target=batch_target,
            policy=policy,
            batch_size=len(ids),
        )
        donors[ids] = batch_donors
        coefficients[ids] = batch_coefficients
        for name in ("rank", "condition", "cubic_defect", "constant_flux"):
            diagnostics[name][ids] = batch_diagnostics[name]
        diagnostics["candidate_count"][ids] = batch_diagnostics["candidate_count"]
        diagnostics["support_extent"][ids] = batch_diagnostics["support_extent"]
    reconstruction = DirectCubicReconstruction(
        resolution=geometry.resolution,
        face_ids=np.asarray(geometry.face_ids, dtype=np.int64),
        donors=donors,
        coefficients=coefficients,
        face_minus=np.asarray(geometry.face_minus, dtype=np.int64),
        face_plus=np.asarray(geometry.face_plus, dtype=np.int64),
        face_boundary=np.asarray(geometry.face_boundary, dtype=bool),
        owner_volumes=np.asarray(geometry.owner_volumes, dtype=np.float64),
        face_centers=np.asarray(geometry.face_centers, dtype=np.float64),
        face_scales=np.asarray(geometry.face_scales, dtype=np.float64),
        face_planes=np.asarray(geometry.face_planes, dtype=np.int64),
        face_theta_seam=np.zeros(n_face, dtype=bool) if geometry.face_theta_seam is None else np.asarray(geometry.face_theta_seam, dtype=bool),
        face_eta_seam=np.zeros(n_face, dtype=bool) if geometry.face_eta_seam is None else np.asarray(geometry.face_eta_seam, dtype=bool),
        owner_collapsed_axis=np.zeros(len(geometry.owner_volumes), dtype=bool) if geometry.owner_collapsed_axis is None else np.asarray(geometry.owner_collapsed_axis, dtype=bool),
        owner_raw_indptr=np.zeros(len(geometry.owner_volumes) + 1, dtype=np.int64) if geometry.owner_raw_indptr is None else np.asarray(geometry.owner_raw_indptr, dtype=np.int64),
        owner_raw_indices=np.empty(0, dtype=np.int64) if geometry.owner_raw_indices is None else np.asarray(geometry.owner_raw_indices, dtype=np.int64),
    )
    return reconstruction, diagnostics


def direct_cubic_functional_identity(
    *,
    geometry: str,
    topology: str,
    evaluator: str,
    target_kind: str,
    integration: str,
    evaluation_location: str,
    boundary_convention: str,
    implementation: str = DIRECT_CUBIC_IMPLEMENTATION_VERSION,
    policy: DirectCubicPolicy = DirectCubicPolicy(),
) -> dict[str, object]:
    """Version an arbitrary direct-cubic functional without changing policy."""

    return {
        "schema": DIRECT_CUBIC_FUNCTIONAL_IDENTITY_VERSION,
        "geometry": geometry,
        "topology": topology,
        "observation": policy.owner_sampling,
        "support_and_weights": {
            "owners_per_plane": policy.owners_per_plane,
            "plane_offsets": list(policy.plane_offsets),
            "selection": policy.selection,
            "weight": policy.weight,
        },
        "target": {
            "kind": str(target_kind),
            "integration": str(integration),
            "evaluation_location": str(evaluation_location),
        },
        "evaluator": evaluator,
        "precision": "float64",
        "implementation": implementation,
        "boundary_convention": boundary_convention,
    }


def direct_cubic_sidecar_identity(
    *,
    geometry: str,
    topology: str,
    evaluator: str,
    implementation: str = DIRECT_CUBIC_IMPLEMENTATION_VERSION,
    boundary_convention: str = "explicit dynamic integrated physical-boundary flux",
    policy: DirectCubicPolicy = DirectCubicPolicy(),
) -> dict[str, object]:
    """Build the complete identity required for reconstruction reuse."""

    return {
        "geometry": geometry,
        "topology": topology,
        "observation": policy.owner_sampling,
        "support_and_weights": {
            "owners_per_plane": policy.owners_per_plane,
            "plane_offsets": list(policy.plane_offsets),
            "selection": policy.selection,
            "weight": policy.weight,
        },
        "target": policy.target,
        "evaluator": evaluator,
        "precision": "float64",
        "implementation": implementation,
        "boundary_convention": boundary_convention,
    }


def _sidecar_metadata(identity: Mapping[str, object], policy: DirectCubicPolicy) -> dict[str, object]:
    required = {
        "geometry", "topology", "observation", "support_and_weights", "target",
        "evaluator", "precision", "implementation", "boundary_convention",
    }
    if set(identity) != required:
        raise ValueError(f"sidecar identity keys must be exactly {sorted(required)}")
    return {
        "schema": DIRECT_CUBIC_SIDECAR_VERSION,
        "identity": json.loads(json.dumps(identity, sort_keys=True)),
        "policy": policy.payload(),
    }


def write_direct_cubic_reconstruction_sidecar(
    path: str | Path,
    reconstruction: DirectCubicReconstruction,
    *,
    identity: Mapping[str, object],
    policy: DirectCubicPolicy = DirectCubicPolicy(),
) -> Path:
    """Atomically write the runtime reconstruction payload and strict identity."""

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    arrays = {
        field.name: np.asarray(getattr(reconstruction, field.name))
        for field in fields(DirectCubicReconstruction)
    }
    metadata = _sidecar_metadata(identity, policy)
    temporary = path.with_suffix(path.suffix + f".{os.getpid()}.tmp")
    with temporary.open("wb") as stream:
        np.savez_compressed(
            stream,
            **arrays,
            metadata_json=np.asarray(json.dumps(metadata, sort_keys=True)),
        )
    os.replace(temporary, path)
    return path


def load_direct_cubic_reconstruction_sidecar(
    path: str | Path,
    *,
    identity: Mapping[str, object],
    policy: DirectCubicPolicy = DirectCubicPolicy(),
) -> DirectCubicReconstruction:
    """Load a sidecar only when geometry and every numerical policy agree."""

    expected = _sidecar_metadata(identity, policy)
    with np.load(path, allow_pickle=False) as payload:
        metadata = json.loads(str(payload["metadata_json"].item()))
        if metadata != expected:
            raise ValueError("direct-cubic sidecar geometry/policy identity mismatch")
        reconstruction = DirectCubicReconstruction(
            **{
                field.name: int(payload[field.name]) if field.name == "resolution" else np.asarray(payload[field.name])
                for field in fields(DirectCubicReconstruction)
            }
        )
    return reconstruction
