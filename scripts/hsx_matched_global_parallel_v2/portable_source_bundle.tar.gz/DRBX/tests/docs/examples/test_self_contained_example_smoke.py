from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest


REPO_ROOT = Path(__file__).resolve().parents[3]
EXAMPLES_ROOT = REPO_ROOT / "examples"


def _example_env() -> dict[str, str]:
    environment = dict(os.environ)
    pythonpath = str(REPO_ROOT / "src")
    if environment.get("PYTHONPATH"):
        pythonpath = pythonpath + os.pathsep + environment["PYTHONPATH"]
    environment["PYTHONPATH"] = pythonpath
    environment.setdefault("MPLBACKEND", "Agg")
    return environment


def _run_example(
    command: list[str],
    *,
    cwd: Path,
    timeout: int = 90,
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        command,
        cwd=cwd,
        env=_example_env(),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        check=False,
    )
    assert completed.returncode == 0, (
        f"command failed: {' '.join(command)}\n"
        f"stdout:\n{completed.stdout}\n"
        f"stderr:\n{completed.stderr}"
    )
    return completed


@pytest.mark.parametrize(
    "relative_script",
    [
        "restartable_diffusion_tutorial.py",
        "diffusion_precision_benchmark.py",
        "autodiff_diffusion_sensitivity.py",
        "autodiff_diffusion_inverse_design.py",
        "autodiff_diffusion_uncertainty.py",
        "strong_scaling_diffusion.py",
        "model_selection_guide.py",
    ],
)
def test_docs_examples_are_flat_parameter_scripts(relative_script: str) -> None:
    # The documented examples are flat pedagogical scripts: a module docstring
    # with the run command, module-level PARAMETERS constants, and no CLI or
    # main() indirection.
    source = (EXAMPLES_ROOT / relative_script).read_text(encoding="utf-8")

    assert source.lstrip().startswith('"""'), "example must open with a module docstring"
    assert "PYTHONPATH=src" in source, "docstring must show the exact run command"
    assert "PARAMETERS" in source, "example must expose a PARAMETERS constants block"
    assert "import argparse" not in source
    assert "__main__" not in source
    assert "def main(" not in source


def test_restartable_diffusion_tutorial_default_subprocess_smoke(tmp_path: Path) -> None:
    # The tutorial's OUTPUT_ROOT is cwd-relative, so running it from tmp_path
    # keeps all artifacts inside the test sandbox.
    _run_example(
        [sys.executable, str(EXAMPLES_ROOT / "restartable_diffusion_tutorial.py")],
        cwd=tmp_path,
        timeout=90,
    )

    output_root = tmp_path / "docs" / "data" / "restartable_diffusion_demo_artifacts"
    assert (output_root / "input" / "input.toml").exists()
    assert (output_root / "run_first" / "restartable_diffusion_arrays.npz").exists()
    assert (output_root / "run_resumed" / "restartable_diffusion_resumed_arrays.npz").exists()
    assert (output_root / "run_full" / "restartable_diffusion_full_arrays.npz").exists()
    assert (output_root / "data" / "restartable_diffusion_analysis.json").exists()
    assert (output_root / "images" / "restartable_diffusion_density_snapshots.png").stat().st_size > 0
    assert (output_root / "images" / "restartable_diffusion_restart_consistency.png").stat().st_size > 0


def test_model_selection_guide_writes_parse_checked_starter_decks(tmp_path: Path) -> None:
    _run_example(
        [sys.executable, str(EXAMPLES_ROOT / "model_selection_guide.py")],
        cwd=tmp_path,
        timeout=30,
    )

    output_root = tmp_path / "output" / "model_selection_guide"
    summary_path = output_root / "model_selection_summary.json"
    payload = json.loads(summary_path.read_text(encoding="utf-8"))

    assert (output_root / "diffusion_start.toml").exists()
    assert (output_root / "open_field_concept.toml").exists()
    assert (output_root / "model_selection_guide.md").exists()
    assert "diffusion / scalar reduced transport" in {entry["name"] for entry in payload["model_families"]}
    assert payload["generated_decks"][0]["components"] == [
        "h:evolve_density",
        "h:evolve_pressure",
        "h:anomalous_diffusion",
    ]


def test_stellarator_fci_docs_analysis_commands_are_subprocess_self_contained(
    tmp_path: Path,
) -> None:
    _run_example(
        [
            sys.executable,
            str(EXAMPLES_ROOT / "geometry-3D" / "stellarator-fci" / "geometry_plotting.py"),
        ],
        cwd=tmp_path,
        timeout=60,
    )

    geometry_root = tmp_path / "docs" / "data" / "stellarator_fci_example_artifacts" / "geometry"
    assert (geometry_root / "stellarator_geometry_plotting.npz").exists()
    assert (geometry_root / "stellarator_geometry_plotting.png").stat().st_size > 0

    nonlinear_root = (
        tmp_path
        / "docs"
        / "data"
        / "stellarator_fci_example_artifacts"
        / "nonlinear_turbulence"
    )
    _write_tiny_stellarator_turbulence_release_arrays(
        nonlinear_root / "stellarator_nonlinear_turbulence.npz"
    )

    completed = _run_example(
        [
            sys.executable,
            str(EXAMPLES_ROOT / "geometry-3D" / "stellarator-fci" / "turbulent_profile_analysis.py"),
        ],
        cwd=tmp_path,
        timeout=60,
    )

    assert "wrote profile analysis:" in completed.stdout
    assert (nonlinear_root / "stellarator_nonlinear_turbulence_profiles.png").stat().st_size > 0


def test_turbulent_profile_analysis_explains_missing_artifact(tmp_path: Path) -> None:
    completed = subprocess.run(
        [
            sys.executable,
            str(EXAMPLES_ROOT / "geometry-3D" / "stellarator-fci" / "turbulent_profile_analysis.py"),
        ],
        cwd=tmp_path,
        env=_example_env(),
        text=True,
        capture_output=True,
        timeout=60,
        check=False,
    )

    assert completed.returncode == 1
    assert "Missing required artifact" in completed.stdout
    assert "stellarator_nonlinear_turbulence.npz" in completed.stdout


def _write_tiny_stellarator_turbulence_release_arrays(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    radial = np.linspace(0.0, 1.0, 28, dtype=np.float64)[:, None, None]
    poloidal = np.linspace(0.0, 2.0 * np.pi, 28, endpoint=False, dtype=np.float64)[None, :, None]
    toroidal = np.linspace(0.0, 2.0 * np.pi, 56, endpoint=False, dtype=np.float64)[None, None, :]
    mode = np.exp(-((radial - 0.62) / 0.24) ** 2) * np.cos(3.0 * poloidal - 5.0 * toroidal)
    history = np.stack(
        [
            0.05 * mode,
            0.07 * mode + 0.01 * np.sin(toroidal),
            0.09 * mode + 0.02 * radial,
        ],
        axis=0,
    )
    curvature = 0.2 * np.cos(poloidal) + 0.1 * np.sin(toroidal)
    connection_length = 1.0 + radial + 0.05 * np.cos(5.0 * toroidal)
    np.savez_compressed(
        path,
        history=history.astype(np.float16),
        time=np.asarray([0.0, 0.08, 0.16], dtype=np.float32),
        curvature=curvature.astype(np.float32),
        connection_length=connection_length.astype(np.float32),
    )
