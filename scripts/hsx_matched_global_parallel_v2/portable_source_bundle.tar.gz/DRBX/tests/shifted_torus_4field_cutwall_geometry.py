"""Closed-box embedded-control-volume geometry for shifted-torus MMS tests.

The module has no ``test_`` prefix so pytest collects only the assertions and
CLI wrappers in the public test module.
"""

from __future__ import annotations

from dataclasses import dataclass
from dataclasses import replace as dataclass_replace
import hashlib
import json
from pathlib import Path
import sys
import time as time_module

import jax
import jax.numpy as jnp
import numpy as np

from drbx.geometry import (
    LocalCellVolumeGeometry3D,
    LocalControlVolumeCellGeometry3D,
    LocalFciGeometry3D,
    LocalRegularFaceGeometry3D,
    build_local_control_volume_cell_geometry,
)
from drbx.geometry.fci_control_volumes import (
    GlobalControlVolumeTopology3D,
    LocalControlVolumeGeometry3D,
    build_global_control_volume_topology,
    compile_local_control_volume_geometry,
    remote_owner_halo_coordinate,
)
from drbx.native import precompute_local_moment_reconstruction
from drbx.native.fci_control_volume_operators import (
    cubic_control_volume_average_basis,
    cubic_parallel_gradient_face_flux_target,
    cubic_parallel_face_flux_target,
    cubic_projected_face_flux_target,
    precompute_local_face_functional,
)
from drbx.native.fci_boundaries import (
    CV_FACE_CUT_WALL,
    CV_FACE_INTERIOR,
    CV_FACE_PARTIAL,
    CV_FACE_PHYSICAL_BOUNDARY,
    LocalControlVolumeFaceRows3D,
    LocalEmbeddedControlVolumeGeometry3D,
    LocalMomentFittedFaceRows3D,
    LocalMomentReconstruction3D,
    LocalRegularBoundaryMomentClosure3D,
)
from drbx.native.fci_boundaries import (
    CV_RECONSTRUCTION_EQUATION_CELL,
    CV_RECONSTRUCTION_EQUATION_DIRICHLET,
    CV_RECONSTRUCTION_EQUATION_REMOTE_CELL,
)


_TEST_DIR = Path(__file__).resolve().parent
if str(_TEST_DIR) not in sys.path:
    sys.path.insert(0, str(_TEST_DIR))


import shifted_torus_4field_mms_helpers as shifted_mms  # noqa: E402
from mms_domain_decomp_helpers import (  # noqa: E402
    build_shifted_torus_local_geometry,
    stack_local_shard_pytree,
)


MESH_AXIS_NAMES = ("x", "y", "z")


BOX_X_FRACTION_RANGE = (0.25, 0.75)
BOX_THETA_CENTER = 1.5 * np.pi
BOX_THETA_HALF_WIDTH = 0.35
BOX_ZETA_RANGE = (0.45, 4.25)
_FACE_FUNCTIONAL_CACHE_SCHEMA = 1


def _replace_canonical_compact_rows(
    rows: list[dict[str, object]],
    canonical_rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    """Replace same-ID local discoveries with canonical compact rows."""
    canonical_ids = {
        int(row["global_face_id"]) for row in canonical_rows
    }
    result = [
        row
        for row in rows
        if int(row.get("global_face_id", -1)) not in canonical_ids
    ]
    result.extend(canonical_rows)
    return result


@dataclass(frozen=True)
class _CachedFaceFunctional:
    projected_flux_weights: np.ndarray
    parallel_flux_weights: np.ndarray
    parallel_gradient_flux_weights: np.ndarray
    polynomial_order: int
    rank: int
    condition_number: float
    reproduction_residual: float
    normalized_projected_weight_norm: float
    normalized_parallel_weight_norm: float
    normalized_parallel_gradient_weight_norm: float


def _shape_from_resolution(resolution: int) -> tuple[int, int, int]:
    n = int(resolution)
    return (n, n, n)


def _box_bounds(
    *,
    box_translation: tuple[float, float, float] = (0.0, 0.0, 0.0),
) -> tuple[tuple[float, float], tuple[float, float], tuple[float, float]]:
    try:
        translation_values = tuple(float(value) for value in box_translation)
    except (TypeError, ValueError):
        raise ValueError(
            "box_translation must contain exactly three finite floats"
        ) from None
    if len(translation_values) != 3 or not all(
        np.isfinite(value) for value in translation_values
    ):
        raise ValueError("box_translation must contain exactly three finite floats")
    x_translation, theta_translation, zeta_translation = translation_values
    radial_span = float(shifted_mms.x_max) - float(shifted_mms.x_min)
    return (
        (
            float(shifted_mms.x_min)
            + BOX_X_FRACTION_RANGE[0] * radial_span
            + x_translation,
            float(shifted_mms.x_min)
            + BOX_X_FRACTION_RANGE[1] * radial_span
            + x_translation,
        ),
        (
            BOX_THETA_CENTER - BOX_THETA_HALF_WIDTH + theta_translation,
            BOX_THETA_CENTER + BOX_THETA_HALF_WIDTH + theta_translation,
        ),
        (
            BOX_ZETA_RANGE[0] + zeta_translation,
            BOX_ZETA_RANGE[1] + zeta_translation,
        ),
    )


def _shifted_torus_cartesian_from_logical(
    x: jnp.ndarray,
    theta: jnp.ndarray,
    zeta: jnp.ndarray,
) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
    x_mid = 0.5 * (float(shifted_mms.x_min) + float(shifted_mms.x_max))
    theta_shift = theta + float(shifted_mms.sigma) * (x - x_mid)
    radius = (
        float(shifted_mms.r0)
        + float(shifted_mms.alpha_value) * x
        + x * jnp.cos(theta_shift)
    )
    return radius * jnp.cos(zeta), radius * jnp.sin(zeta), x * jnp.sin(theta_shift)


_GAUSS3_NODES = np.asarray((-np.sqrt(3.0 / 5.0), 0.0, np.sqrt(3.0 / 5.0)))
_GAUSS3_WEIGHTS = np.asarray((5.0 / 9.0, 8.0 / 9.0, 5.0 / 9.0))
_GAUSS2_NODES = np.asarray((-1.0 / np.sqrt(3.0), 1.0 / np.sqrt(3.0)))


def _shifted_torus_metric_payload_numpy(
    points: np.ndarray,
) -> tuple[
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
]:
    """Evaluate shifted-torus metric, field, and perpendicular projector."""

    points = np.asarray(points, dtype=np.float64)
    x = points[..., 0]
    theta = points[..., 1]
    x_mid = 0.5 * (float(shifted_mms.x_min) + float(shifted_mms.x_max))
    theta_shift = theta + float(shifted_mms.sigma) * (x - x_mid)
    cos_theta = np.cos(theta_shift)
    sin_theta = np.sin(theta_shift)
    alpha = float(shifted_mms.alpha_value)
    radius = float(shifted_mms.r0) + alpha * x + x * cos_theta
    q_value = 1.0 + alpha * cos_theta
    jacobian = radius * x * q_value
    zeros = np.zeros_like(jacobian)

    g_contra = np.stack(
        (
            np.stack(
                (
                    1.0 / q_value**2,
                    alpha * sin_theta / (x * q_value**2),
                    zeros,
                ),
                axis=-1,
            ),
            np.stack(
                (
                    alpha * sin_theta / (x * q_value**2),
                    (1.0 + 2.0 * alpha * cos_theta + alpha**2)
                    / (x**2 * q_value**2),
                    zeros,
                ),
                axis=-1,
            ),
            np.stack((zeros, zeros, 1.0 / radius**2), axis=-1),
        ),
        axis=-2,
    )
    g_cov = np.stack(
        (
            np.stack(
                (
                    1.0 + 2.0 * alpha * cos_theta + alpha**2,
                    -alpha * x * sin_theta,
                    zeros,
                ),
                axis=-1,
            ),
            np.stack((-alpha * x * sin_theta, x**2, zeros), axis=-1),
            np.stack((zeros, zeros, radius**2), axis=-1),
        ),
        axis=-2,
    )
    B_contra = np.stack(
        (
            zeros,
            float(shifted_mms.iota) * float(shifted_mms.c_phi) / jacobian,
            float(shifted_mms.c_phi) / jacobian,
        ),
        axis=-1,
    )
    Bmag = np.sqrt(
        np.einsum("...i,...ij,...j->...", B_contra, g_cov, B_contra)
    )
    unit_b = B_contra / np.maximum(Bmag[..., None], 1.0e-30)
    projector = g_contra - unit_b[..., :, None] * unit_b[..., None, :]
    return jacobian, g_contra, g_cov, B_contra, Bmag, projector


def _integrate_shifted_torus_rectangular_moments(
    lower: tuple[np.ndarray, np.ndarray, np.ndarray],
    upper: tuple[np.ndarray, np.ndarray, np.ndarray],
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Integrate ``J``, first moments, and origin second moments on rectangles."""

    shape = np.broadcast_shapes(
        np.shape(lower[0]),
        np.shape(lower[1]),
        np.shape(lower[2]),
    )
    lower_b = tuple(np.broadcast_to(np.asarray(value, dtype=np.float64), shape) for value in lower)
    upper_b = tuple(np.broadcast_to(np.asarray(value, dtype=np.float64), shape) for value in upper)
    half = tuple(0.5 * (hi - lo) for lo, hi in zip(lower_b, upper_b))
    midpoint = tuple(0.5 * (hi + lo) for lo, hi in zip(lower_b, upper_b))
    valid = (half[0] > 0.0) & (half[1] > 0.0) & (half[2] > 0.0)
    volume = np.zeros(shape, dtype=np.float64)
    first = np.zeros(shape + (3,), dtype=np.float64)
    second_origin = np.zeros(shape + (3, 3), dtype=np.float64)
    third_origin = np.zeros(shape + (3, 3, 3), dtype=np.float64)
    for ax, wx in zip(_GAUSS3_NODES, _GAUSS3_WEIGHTS):
        x = midpoint[0] + half[0] * ax
        for ay, wy in zip(_GAUSS3_NODES, _GAUSS3_WEIGHTS):
            theta = midpoint[1] + half[1] * ay
            x_mid = 0.5 * (
                float(shifted_mms.x_min) + float(shifted_mms.x_max)
            )
            theta_shift = theta + float(shifted_mms.sigma) * (x - x_mid)
            radius = (
                float(shifted_mms.r0)
                + float(shifted_mms.alpha_value) * x
                + x * np.cos(theta_shift)
            )
            q_value = 1.0 + float(shifted_mms.alpha_value) * np.cos(theta_shift)
            jacobian = radius * x * q_value
            for az, wz in zip(_GAUSS3_NODES, _GAUSS3_WEIGHTS):
                zeta = midpoint[2] + half[2] * az
                weight = (
                    wx
                    * wy
                    * wz
                    * half[0]
                    * half[1]
                    * half[2]
                    * jacobian
                )
                weight = np.where(valid, weight, 0.0)
                point = np.stack((x, theta, zeta), axis=-1)
                volume += weight
                first += weight[..., None] * point
                second_origin += (
                    weight[..., None, None]
                    * point[..., :, None]
                    * point[..., None, :]
                )
                third_origin += (
                    weight[..., None, None, None]
                    * point[..., :, None, None]
                    * point[..., None, :, None]
                    * point[..., None, None, :]
                )
    return volume, first, second_origin, third_origin


def _closed_box_fluid_moments_3point(
    geometry: LocalFciGeometry3D,
    *,
    box_translation: tuple[float, float, float] = (0.0, 0.0, 0.0),
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return true local fluid moments from full-cell minus solid integration."""

    x_faces = np.asarray(geometry.grid.x.faces_owned, dtype=np.float64)
    y_faces = np.asarray(geometry.grid.y.faces_owned, dtype=np.float64)
    z_faces = np.asarray(geometry.grid.z.faces_owned, dtype=np.float64)
    lower = (
        x_faces[:-1, None, None],
        y_faces[None, :-1, None],
        z_faces[None, None, :-1],
    )
    upper = (
        x_faces[1:, None, None],
        y_faces[None, 1:, None],
        z_faces[None, None, 1:],
    )
    full_volume, full_first, full_second, full_third = (
        _integrate_shifted_torus_rectangular_moments(lower, upper)
    )
    bounds = _box_bounds(box_translation=box_translation)
    solid_lower = tuple(
        np.maximum(value, float(bounds[axis][0]))
        for axis, value in enumerate(lower)
    )
    solid_upper = tuple(
        np.minimum(value, float(bounds[axis][1]))
        for axis, value in enumerate(upper)
    )
    solid_volume, solid_first, solid_second, solid_third = (
        _integrate_shifted_torus_rectangular_moments(
            solid_lower,
            solid_upper,
        )
    )
    raw_volume = np.maximum(full_volume - solid_volume, 0.0)
    raw_first = full_first - solid_first
    raw_second_origin = full_second - solid_second
    raw_third_origin = full_third - solid_third
    x_center, y_center, z_center = np.meshgrid(
        np.asarray(geometry.grid.x.centers_owned, dtype=np.float64),
        np.asarray(geometry.grid.y.centers_owned, dtype=np.float64),
        np.asarray(geometry.grid.z.centers_owned, dtype=np.float64),
        indexing="ij",
    )
    ordinary_center = np.stack((x_center, y_center, z_center), axis=-1)
    safe_volume = np.maximum(raw_volume, 1.0e-30)
    centroid = raw_first / safe_volume[..., None]
    centroid = np.where(
        (raw_volume > 1.0e-24)[..., None],
        centroid,
        ordinary_center,
    )
    second_moment = raw_second_origin / safe_volume[..., None, None]
    second_moment -= centroid[..., :, None] * centroid[..., None, :]
    second_moment = 0.5 * (
        second_moment + np.swapaxes(second_moment, -1, -2)
    )
    diagonal = np.diagonal(second_moment, axis1=-2, axis2=-1)
    clipped_diagonal = np.maximum(diagonal, 0.0)
    for axis in range(3):
        second_moment[..., axis, axis] = clipped_diagonal[..., axis]
    second_moment = np.where(
        (raw_volume > 1.0e-24)[..., None, None],
        second_moment,
        0.0,
    )
    second_origin = raw_second_origin / safe_volume[..., None, None]
    third_origin = raw_third_origin / safe_volume[..., None, None, None]
    third_moment = third_origin - (
        centroid[..., :, None, None] * second_origin[..., None, :, :]
        + centroid[..., None, :, None] * second_origin[..., :, None, :]
        + centroid[..., None, None, :] * second_origin[..., :, :, None]
    ) + 2.0 * (
        centroid[..., :, None, None]
        * centroid[..., None, :, None]
        * centroid[..., None, None, :]
    )
    third_moment = np.where(
        (raw_volume > 1.0e-24)[..., None, None, None], third_moment, 0.0
    )
    return raw_volume, centroid, second_moment, third_moment, full_volume


def _build_shifted_torus_regular_boundary_closure(
    geometry: LocalFciGeometry3D,
    cells: LocalControlVolumeCellGeometry3D,
) -> LocalRegularBoundaryMomentClosure3D:
    """Build radial Dirichlet face/owner derivatives from FV moments."""

    face_shapes = tuple(
        geometry.layout.face_control_shape(axis) for axis in range(3)
    )
    face_weights = [
        np.zeros(shape + (4,), dtype=np.float64) for shape in face_shapes
    ]
    owner_weights = [
        np.zeros(shape + (4,), dtype=np.float64) for shape in face_shapes
    ]
    valid = [np.zeros(shape, dtype=bool) for shape in face_shapes]
    if geometry.owned_shape[0] < 3:
        return LocalRegularBoundaryMomentClosure3D(
            layout=geometry.layout,
            x_face_weights=jnp.asarray(face_weights[0]),
            y_face_weights=jnp.asarray(face_weights[1]),
            z_face_weights=jnp.asarray(face_weights[2]),
            x_owner_weights=jnp.asarray(owner_weights[0]),
            y_owner_weights=jnp.asarray(owner_weights[1]),
            z_owner_weights=jnp.asarray(owner_weights[2]),
            x_valid=jnp.asarray(valid[0]),
            y_valid=jnp.asarray(valid[1]),
            z_valid=jnp.asarray(valid[2]),
        )

    x_faces = np.asarray(geometry.grid.x.faces_owned, dtype=np.float64)
    theta_faces = np.asarray(geometry.grid.y.faces_owned, dtype=np.float64)
    zeta_faces = np.asarray(geometry.grid.z.faces_owned, dtype=np.float64)
    raw_volume = np.asarray(cells.raw_volume, dtype=np.float64)
    raw_centroid = np.asarray(cells.raw_centroid, dtype=np.float64)
    raw_second_moment = np.asarray(
        cells.raw_second_moment,
        dtype=np.float64,
    )
    active_owner = np.asarray(cells.is_active_owner, dtype=bool)
    merged_source = np.asarray(cells.is_merged_source, dtype=bool)

    def side_weights(
        side: int,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        lower_side = side == 0
        wall = x_faces[0] if lower_side else x_faces[-1]
        inward_sign = 1.0 if lower_side else -1.0
        indices = (
            np.arange(3, dtype=np.int32)
            if lower_side
            else np.arange(geometry.owned_shape[0] - 1, geometry.owned_shape[0] - 4, -1)
        )
        x_lower = x_faces[indices]
        x_upper = x_faces[indices + 1]
        shape = (3, geometry.owned_shape[1], geometry.owned_shape[2])
        midpoint = (
            0.5 * (x_lower + x_upper)[:, None, None],
            0.5 * (theta_faces[:-1] + theta_faces[1:])[None, :, None],
            0.5 * (zeta_faces[:-1] + zeta_faces[1:])[None, None, :],
        )
        half_width = (
            0.5 * (x_upper - x_lower)[:, None, None],
            0.5 * (theta_faces[1:] - theta_faces[:-1])[None, :, None],
            0.5 * (zeta_faces[1:] - zeta_faces[:-1])[None, None, :],
        )
        third_integral = np.zeros(shape, dtype=np.float64)
        for node_x, weight_x in zip(_GAUSS3_NODES, _GAUSS3_WEIGHTS):
            x = midpoint[0] + half_width[0] * node_x
            for node_y, weight_y in zip(_GAUSS3_NODES, _GAUSS3_WEIGHTS):
                theta = midpoint[1] + half_width[1] * node_y
                for node_z, weight_z in zip(
                    _GAUSS3_NODES,
                    _GAUSS3_WEIGHTS,
                ):
                    zeta = midpoint[2] + half_width[2] * node_z
                    points = np.stack(
                        np.broadcast_arrays(x, theta, zeta),
                        axis=-1,
                    )
                    jacobian = _shifted_torus_metric_payload_numpy(points)[0]
                    measure = (
                        weight_x
                        * weight_y
                        * weight_z
                        * half_width[0]
                        * half_width[1]
                        * half_width[2]
                        * jacobian
                    )
                    inward_coordinate = inward_sign * (x - wall)
                    third_integral += measure * inward_coordinate**3

        volume = raw_volume[indices]
        centroid_offset = inward_sign * (
            raw_centroid[indices, ..., 0] - wall
        )
        second_origin = (
            raw_second_moment[indices, ..., 0, 0]
            + centroid_offset**2
        )
        third_origin = third_integral / np.maximum(volume, 1.0e-30)
        matrix = np.zeros(shape[1:] + (4, 4), dtype=np.float64)
        matrix[..., 0, 0] = 1.0
        matrix[..., 1:, 0] = 1.0
        matrix[..., 1:, 1] = np.moveaxis(centroid_offset, 0, -1)
        matrix[..., 1:, 2] = np.moveaxis(second_origin, 0, -1)
        matrix[..., 1:, 3] = np.moveaxis(third_origin, 0, -1)
        face_derivative = np.zeros(shape[1:] + (4,), dtype=np.float64)
        face_derivative[..., 1] = inward_sign
        face_result = np.linalg.solve(
            np.swapaxes(matrix, -1, -2),
            face_derivative[..., None],
        )[..., 0]
        owner_coordinate = centroid_offset[0]
        owner_derivative = np.stack(
            (
                np.zeros_like(owner_coordinate),
                np.full_like(owner_coordinate, inward_sign),
                2.0 * inward_sign * owner_coordinate,
                3.0 * inward_sign * owner_coordinate**2,
            ),
            axis=-1,
        )
        owner_result = np.linalg.solve(
            np.swapaxes(matrix, -1, -2),
            owner_derivative[..., None],
        )[..., 0]
        face_reproduced = np.einsum(
            "...rc,...r->...c",
            matrix,
            face_result,
        )
        owner_reproduced = np.einsum(
            "...rc,...r->...c",
            matrix,
            owner_result,
        )
        if not np.allclose(
            face_reproduced,
            face_derivative,
            rtol=1.0e-11,
            atol=1.0e-11,
        ):
            raise ValueError(
                "regular radial face derivative weights do not reproduce "
                "the cubic moment basis"
            )
        if not np.allclose(
            owner_reproduced,
            owner_derivative,
            rtol=1.0e-11,
            atol=1.0e-11,
        ):
            raise ValueError(
                "regular radial owner derivative weights do not reproduce "
                "the cubic moment basis"
            )
        side_valid = np.all(
            active_owner[indices]
            & (~merged_source[indices])
            & (volume > 1.0e-24),
            axis=0,
        )
        return face_result, owner_result, side_valid

    if np.isclose(x_faces[0], float(shifted_mms.x_min)):
        (
            face_weights[0][0],
            owner_weights[0][0],
            valid[0][0],
        ) = side_weights(0)
    if np.isclose(x_faces[-1], float(shifted_mms.x_max)):
        (
            face_weights[0][-1],
            owner_weights[0][-1],
            valid[0][-1],
        ) = side_weights(1)
    return LocalRegularBoundaryMomentClosure3D(
        layout=geometry.layout,
        x_face_weights=jnp.asarray(face_weights[0]),
        y_face_weights=jnp.asarray(face_weights[1]),
        z_face_weights=jnp.asarray(face_weights[2]),
        x_owner_weights=jnp.asarray(owner_weights[0]),
        y_owner_weights=jnp.asarray(owner_weights[1]),
        z_owner_weights=jnp.asarray(owner_weights[2]),
        x_valid=jnp.asarray(valid[0]),
        y_valid=jnp.asarray(valid[1]),
        z_valid=jnp.asarray(valid[2]),
    )


def _open_face_rectangles_numpy(
    *,
    axis: int,
    face_coordinate: float,
    tangential_bounds: tuple[tuple[float, float], tuple[float, float]],
    box_translation: tuple[float, float, float] = (0.0, 0.0, 0.0),
) -> list[tuple[tuple[float, float], tuple[float, float]]]:
    """Decompose one open box-clipped face into at most four rectangles."""

    bounds = _box_bounds(box_translation=box_translation)
    full_a, full_b = tangential_bounds
    if not (
        float(bounds[axis][0]) <= face_coordinate <= float(bounds[axis][1])
    ):
        return [(full_a, full_b)]
    tangential_axes = [candidate for candidate in range(3) if candidate != axis]
    block_a = (
        max(full_a[0], float(bounds[tangential_axes[0]][0])),
        min(full_a[1], float(bounds[tangential_axes[0]][1])),
    )
    block_b = (
        max(full_b[0], float(bounds[tangential_axes[1]][0])),
        min(full_b[1], float(bounds[tangential_axes[1]][1])),
    )
    if block_a[1] <= block_a[0] or block_b[1] <= block_b[0]:
        return [(full_a, full_b)]
    rectangles: list[tuple[tuple[float, float], tuple[float, float]]] = []

    def append(a0: float, a1: float, b0: float, b1: float) -> None:
        if a1 > a0 + 1.0e-15 and b1 > b0 + 1.0e-15:
            rectangles.append(((a0, a1), (b0, b1)))

    append(full_a[0], block_a[0], full_b[0], full_b[1])
    append(block_a[1], full_a[1], full_b[0], full_b[1])
    append(block_a[0], block_a[1], full_b[0], block_b[0])
    append(block_a[0], block_a[1], block_b[1], full_b[1])
    return rectangles


def _face_patch_quadrature_numpy(
    *,
    axis: int,
    face_coordinate: float,
    rectangle: tuple[tuple[float, float], tuple[float, float]],
    orientation: float,
) -> tuple[np.ndarray, np.ndarray]:
    tangential_axes = [candidate for candidate in range(3) if candidate != axis]
    points = np.zeros((4, 3), dtype=np.float64)
    area_weights = np.zeros((4, 3), dtype=np.float64)
    half_a = 0.5 * (rectangle[0][1] - rectangle[0][0])
    half_b = 0.5 * (rectangle[1][1] - rectangle[1][0])
    midpoint_a = 0.5 * (rectangle[0][1] + rectangle[0][0])
    midpoint_b = 0.5 * (rectangle[1][1] + rectangle[1][0])
    q = 0
    for node_a in _GAUSS2_NODES:
        for node_b in _GAUSS2_NODES:
            points[q, axis] = float(face_coordinate)
            points[q, tangential_axes[0]] = midpoint_a + half_a * node_a
            points[q, tangential_axes[1]] = midpoint_b + half_b * node_b
            area_weights[q, axis] = float(orientation) * half_a * half_b
            q += 1
    return points, area_weights


_GLOBAL_COORDINATE_FACE_MEASURE_CHUNK_SIZE = 4096


def _build_global_coordinate_face_open_measures(
    *,
    axis: int,
    axis_faces: tuple[np.ndarray, np.ndarray, np.ndarray],
    face_shape: tuple[int, int, int],
    box_translation: tuple[float, float, float] = (0.0, 0.0, 0.0),
    chunk_size: int = _GLOBAL_COORDINATE_FACE_MEASURE_CHUNK_SIZE,
) -> np.ndarray:
    """Evaluate open coordinate-face measures in fixed-size NumPy batches."""
    if axis not in (0, 1, 2):
        raise ValueError(f"axis must be 0, 1, or 2, got {axis}")
    if not isinstance(chunk_size, (int, np.integer)) or chunk_size <= 0:
        raise ValueError("chunk_size must be a positive integer")

    measure = np.zeros(face_shape, dtype=np.float64)
    tangential_axes = [candidate for candidate in range(3) if candidate != axis]
    bounds = _box_bounds(box_translation=box_translation)
    face_count = int(np.prod(face_shape, dtype=np.int64))
    q_node_a = np.repeat(_GAUSS2_NODES, 2)
    q_node_b = np.tile(_GAUSS2_NODES, 2)

    for first in range(0, face_count, int(chunk_size)):
        stop = min(first + int(chunk_size), face_count)
        flat_faces = np.arange(first, stop, dtype=np.int64)
        indices = np.stack(np.unravel_index(flat_faces, face_shape), axis=-1)
        rectangle_bounds = np.zeros(
            (len(indices), 4, 2, 2), dtype=np.float64
        )
        face_coordinate = np.asarray(
            axis_faces[axis][indices[:, axis]], dtype=np.float64
        )
        index_a = indices[:, tangential_axes[0]]
        index_b = indices[:, tangential_axes[1]]
        full_a0 = np.asarray(
            axis_faces[tangential_axes[0]][index_a], dtype=np.float64
        )
        full_a1 = np.asarray(
            axis_faces[tangential_axes[0]][index_a + 1], dtype=np.float64
        )
        full_b0 = np.asarray(
            axis_faces[tangential_axes[1]][index_b], dtype=np.float64
        )
        full_b1 = np.asarray(
            axis_faces[tangential_axes[1]][index_b + 1], dtype=np.float64
        )
        block_a0 = np.maximum(
            full_a0, float(bounds[tangential_axes[0]][0])
        )
        block_a1 = np.minimum(
            full_a1, float(bounds[tangential_axes[0]][1])
        )
        block_b0 = np.maximum(
            full_b0, float(bounds[tangential_axes[1]][0])
        )
        block_b1 = np.minimum(
            full_b1, float(bounds[tangential_axes[1]][1])
        )
        blocked = (
            (face_coordinate >= float(bounds[axis][0]))
            & (face_coordinate <= float(bounds[axis][1]))
            & (block_a1 > block_a0)
            & (block_b1 > block_b0)
        )

        rectangle_bounds[..., 0, 0] = np.stack(
            (full_a0, block_a1, block_a0, block_a0), axis=-1
        )
        rectangle_bounds[..., 0, 1] = np.stack(
            (block_a0, full_a1, block_a1, block_a1), axis=-1
        )
        rectangle_bounds[..., 1, 0] = np.stack(
            (full_b0, full_b0, full_b0, block_b1), axis=-1
        )
        rectangle_bounds[..., 1, 1] = np.stack(
            (full_b1, full_b1, block_b0, full_b1), axis=-1
        )
        rectangle_active = blocked[:, None] & (
            rectangle_bounds[..., 0, 1]
            > rectangle_bounds[..., 0, 0] + 1.0e-15
        ) & (
            rectangle_bounds[..., 1, 1]
            > rectangle_bounds[..., 1, 0] + 1.0e-15
        )

        unblocked = ~blocked
        rectangle_bounds[unblocked, 0, 0, 0] = full_a0[unblocked]
        rectangle_bounds[unblocked, 0, 0, 1] = full_a1[unblocked]
        rectangle_bounds[unblocked, 0, 1, 0] = full_b0[unblocked]
        rectangle_bounds[unblocked, 0, 1, 1] = full_b1[unblocked]
        rectangle_active[unblocked, 0] = True

        half_a = 0.5 * (
            rectangle_bounds[..., 0, 1] - rectangle_bounds[..., 0, 0]
        )
        half_b = 0.5 * (
            rectangle_bounds[..., 1, 1] - rectangle_bounds[..., 1, 0]
        )
        midpoint_a = 0.5 * (
            rectangle_bounds[..., 0, 1] + rectangle_bounds[..., 0, 0]
        )
        midpoint_b = 0.5 * (
            rectangle_bounds[..., 1, 1] + rectangle_bounds[..., 1, 0]
        )
        points = np.zeros((len(indices), 4, 4, 3), dtype=np.float64)
        points[..., axis] = face_coordinate[:, None, None]
        points[..., tangential_axes[0]] = (
            midpoint_a[..., None] + half_a[..., None] * q_node_a
        )
        points[..., tangential_axes[1]] = (
            midpoint_b[..., None] + half_b[..., None] * q_node_b
        )
        quadrature_active = np.broadcast_to(
            rectangle_active[..., None],
            points.shape[:-1],
        )
        jacobian = np.zeros(points.shape[:-1], dtype=np.float64)
        jacobian[quadrature_active] = _shifted_torus_metric_payload_numpy(
            points[quadrature_active]
        )[0]
        weighted = jacobian * (
            half_a * half_b * rectangle_active
        )[..., None]
        measure.flat[flat_faces] = np.sum(weighted, axis=(1, 2))
    return measure


def _select_closed_box_control_volume_owners(
    geometry: LocalFciGeometry3D,
    *,
    raw_volume: np.ndarray,
    raw_centroid: np.ndarray,
    full_volume: np.ndarray,
    enable_merging: bool,
    box_translation: tuple[float, float, float] = (0.0, 0.0, 0.0),
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Choose direct local merge targets by open-face measure and distance."""

    shape = geometry.owned_shape
    i_grid, j_grid, k_grid = np.meshgrid(
        np.arange(shape[0], dtype=np.int32),
        np.arange(shape[1], dtype=np.int32),
        np.arange(shape[2], dtype=np.int32),
        indexing="ij",
    )
    target_i = i_grid.copy()
    target_j = j_grid.copy()
    target_k = k_grid.copy()
    source = np.zeros(shape, dtype=bool)
    if not enable_merging:
        return source, target_i, target_j, target_k

    x, y, z = np.meshgrid(
        np.asarray(geometry.grid.x.centers_owned, dtype=np.float64),
        np.asarray(geometry.grid.y.centers_owned, dtype=np.float64),
        np.asarray(geometry.grid.z.centers_owned, dtype=np.float64),
        indexing="ij",
    )
    bounds = _box_bounds(box_translation=box_translation)
    center_in_solid = (
        (x > bounds[0][0])
        & (x < bounds[0][1])
        & (y > bounds[1][0])
        & (y < bounds[1][1])
        & (z > bounds[2][0])
        & (z < bounds[2][1])
    )
    positive = raw_volume > 1.0e-14 * max(float(np.max(full_volume)), 1.0)
    fluid_fraction = raw_volume / np.maximum(full_volume, 1.0e-30)
    candidate_source = positive & (
        center_in_solid | (fluid_fraction < 0.5)
    )
    axis_faces = (
        np.asarray(geometry.grid.x.faces_owned, dtype=np.float64),
        np.asarray(geometry.grid.y.faces_owned, dtype=np.float64),
        np.asarray(geometry.grid.z.faces_owned, dtype=np.float64),
    )
    directions = (
        (0, -1),
        (0, 1),
        (1, -1),
        (1, 1),
        (2, -1),
        (2, 1),
    )
    for source_index_array in np.argwhere(candidate_source):
        source_index = tuple(int(value) for value in source_index_array)
        candidates: list[
            tuple[float, float, int, tuple[int, int, int]]
        ] = []
        for direction, (axis, sign) in enumerate(directions):
            neighbor = list(source_index)
            neighbor[axis] += sign
            if not all(0 <= neighbor[d] < shape[d] for d in range(3)):
                continue
            neighbor_index = tuple(neighbor)
            if candidate_source[neighbor_index] or not positive[neighbor_index]:
                continue
            face_index = source_index[axis] + (1 if sign > 0 else 0)
            face_coordinate = float(axis_faces[axis][face_index])
            tangential_axes = [candidate for candidate in range(3) if candidate != axis]
            tangential = tuple(
                (
                    float(axis_faces[t][source_index[t]]),
                    float(axis_faces[t][source_index[t] + 1]),
                )
                for t in tangential_axes
            )
            rectangles = _open_face_rectangles_numpy(
                axis=axis,
                face_coordinate=face_coordinate,
                tangential_bounds=tangential,
                box_translation=box_translation,
            )
            shared_measure = 0.0
            for rectangle in rectangles:
                points, area_weight = _face_patch_quadrature_numpy(
                    axis=axis,
                    face_coordinate=face_coordinate,
                    rectangle=rectangle,
                    orientation=1.0,
                )
                J, *_rest = _shifted_torus_metric_payload_numpy(points)
                shared_measure += float(
                    np.sum(J * np.linalg.norm(area_weight, axis=-1))
                )
            distance = float(
                np.linalg.norm(
                    raw_centroid[neighbor_index] - raw_centroid[source_index]
                )
            )
            if shared_measure > 1.0e-20:
                candidates.append(
                    (-shared_measure, distance, direction, neighbor_index)
                )
        if candidates:
            _measure, _distance, _direction, target = min(candidates)
            source[source_index] = True
            target_i[source_index] = target[0]
            target_j[source_index] = target[1]
            target_k[source_index] = target[2]
    return source, target_i, target_j, target_k


def _closed_box_irregular_storage_mask(
    geometry: LocalFciGeometry3D,
    cells: LocalControlVolumeCellGeometry3D,
    *,
    box_translation: tuple[float, float, float] = (0.0, 0.0, 0.0),
) -> np.ndarray:
    """Storage cells whose dense face stencils do not represent one CV."""

    _raw_volume, _raw_centroid, _raw_m2, _raw_m3, full_volume = (
        _closed_box_fluid_moments_3point(
            geometry,
            box_translation=box_translation,
        )
    )
    raw_volume = np.asarray(cells.raw_volume, dtype=np.float64)
    cut_storage = (raw_volume > 1.0e-20) & (
        raw_volume
        < np.asarray(full_volume, dtype=np.float64) * (1.0 - 1.0e-12)
    )
    return (
        np.asarray(cells.is_merged_source, dtype=bool)
        | np.asarray(cells.is_aggregate_target, dtype=bool)
        | cut_storage
    )


def _build_closed_box_control_volume_faces(
    geometry: LocalFciGeometry3D,
    cells: LocalControlVolumeCellGeometry3D,
    *,
    remote_boundary_payloads: dict[
        tuple[int, int],
        tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    ]
    | None = None,
    reconstruction_owner_mask: np.ndarray | None = None,
    compact_owner_mask: np.ndarray | None = None,
    global_topology: GlobalControlVolumeTopology3D | None = None,
    local_topology: LocalControlVolumeGeometry3D | None = None,
    canonical_compact_face_ids: set[int] | None = None,
    canonical_rows: tuple[dict[str, object], ...] | None = None,
    box_translation: tuple[float, float, float] = (0.0, 0.0, 0.0),
) -> tuple[LocalRegularFaceGeometry3D, LocalControlVolumeFaceRows3D]:
    """Build dense ordinary faces and compact unique irregular interfaces."""

    if remote_boundary_payloads is None:
        remote_boundary_payloads = {}
    shape = geometry.owned_shape
    owner_i = np.asarray(cells.owner_i, dtype=np.int32)
    owner_j = np.asarray(cells.owner_j, dtype=np.int32)
    owner_k = np.asarray(cells.owner_k, dtype=np.int32)
    active_owner = np.asarray(cells.is_active_owner, dtype=bool)
    source = np.asarray(cells.is_merged_source, dtype=bool)
    aggregate_target = np.asarray(cells.is_aggregate_target, dtype=bool)
    aggregate_centroid = np.asarray(cells.centroid, dtype=np.float64)
    axis_faces = (
        np.asarray(geometry.grid.x.faces_owned, dtype=np.float64),
        np.asarray(geometry.grid.y.faces_owned, dtype=np.float64),
        np.asarray(geometry.grid.z.faces_owned, dtype=np.float64),
    )
    bounds = _box_bounds(box_translation=box_translation)
    axis_overlap = tuple(
        np.maximum(
            np.minimum(faces[1:], float(bounds[axis][1]))
            - np.maximum(faces[:-1], float(bounds[axis][0])),
            0.0,
        )
        / np.maximum(faces[1:] - faces[:-1], 1.0e-30)
        for axis, faces in enumerate(axis_faces)
    )
    solid_face_fraction = (
        np.where(
            (axis_faces[0][:, None, None] >= bounds[0][0])
            & (axis_faces[0][:, None, None] <= bounds[0][1]),
            axis_overlap[1][None, :, None] * axis_overlap[2][None, None, :],
            0.0,
        ),
        np.where(
            (axis_faces[1][None, :, None] >= bounds[1][0])
            & (axis_faces[1][None, :, None] <= bounds[1][1]),
            axis_overlap[0][:, None, None] * axis_overlap[2][None, None, :],
            0.0,
        ),
        np.where(
            (axis_faces[2][None, None, :] >= bounds[2][0])
            & (axis_faces[2][None, None, :] <= bounds[2][1]),
            axis_overlap[0][:, None, None] * axis_overlap[1][None, :, None],
            0.0,
        ),
    )
    open_fraction = tuple(
        np.clip(1.0 - fraction, 0.0, 1.0)
        for fraction in solid_face_fraction
    )
    open_masks = [fraction > 1.0e-12 for fraction in open_fraction]
    global_face_lookup: dict[tuple[int, int, int, int], int] = {}
    evaluator_face_ids: set[int] | None = None
    if global_topology is not None:
        if local_topology is None:
            raise ValueError("global face topology needs a local shard compilation")
        global_face_lookup = {
            (int(axis), *(int(v) for v in storage)): int(face_id)
            for face_id, axis, storage in zip(
                global_topology.face_id,
                global_topology.face_axis,
                global_topology.face_storage_index,
            )
        }
        evaluator_face_ids = set(int(value) for value in local_topology.local_face_id)
        shard_extent = tuple(
            global_topology.shape[axis] // local_topology.shard_counts[axis]
            for axis in range(3)
        )
        shard_start = tuple(
            local_topology.shard_index[axis] * shard_extent[axis]
            for axis in range(3)
        )

        def global_face_id(axis: int, face: tuple[int, int, int]) -> int:
            storage = [shard_start[d] + int(face[d]) for d in range(3)]
            # Global topology stores periodic seams at the low image.
            if axis in (1, 2) and storage[axis] == global_topology.shape[axis]:
                storage[axis] = 0
            return global_face_lookup.get((axis, *storage), -1)
    else:
        def global_face_id(axis: int, face: tuple[int, int, int]) -> int:
            return -1

    def cut_wall_face_id(
        axis: int,
        surface: int,
        storage: tuple[int, int, int],
    ) -> int:
        """Collision-free negative ID for a physical cut-wall patch.

        ``-1`` is the inactive sentinel, hence live wall IDs start at ``-2``.
        The coordinate slots are global storage indices: topology supplies the
        shard offset when available, otherwise the uniform logical lattice is
        recovered from the local physical face coordinates.
        """
        if local_topology is not None:
            global_storage = tuple(
                int(shard_start[d]) + int(storage[d]) for d in range(3)
            )
        else:
            global_storage = []
            for d in range(3):
                width = float(axis_faces[d][1] - axis_faces[d][0])
                low = float(shifted_mms.x_min) if d == 0 else 0.0
                coordinate = 0.5 * float(axis_faces[d][storage[d]] + axis_faces[d][storage[d] + 1])
                global_storage.append(int(np.rint((coordinate - low) / width - 0.5)))
            global_storage = tuple(global_storage)
        i, j, k = global_storage
        if min(i, j, k) < 0 or max(i, j, k) >= 100_000:
            raise ValueError("cut-wall global storage index is outside ID encoding")
        return -int(2 + axis * 2 * 10**15 + surface * 10**15 + i * 10**10 + j * 10**5 + k)

    face_candidates: set[tuple[int, int, int, int]] = set()
    for axis, fraction in enumerate(open_fraction):
        partial = (fraction > 1.0e-12) & (fraction < 1.0 - 1.0e-12)
        for face_index in np.argwhere(partial):
            face_candidates.add(
                (axis, *(int(value) for value in face_index))
            )
    touched_storage = _closed_box_irregular_storage_mask(
        geometry,
        cells,
        box_translation=box_translation,
    )
    for storage_array in np.argwhere(touched_storage):
        storage = tuple(int(value) for value in storage_array)
        for axis in range(3):
            for side in (0, 1):
                face = list(storage)
                face[axis] += side
                face_candidates.add((axis, face[0], face[1], face[2]))
    if reconstruction_owner_mask is not None:
        selected_owner = np.asarray(reconstruction_owner_mask, dtype=bool)
        if selected_owner.shape != shape:
            raise ValueError(
                "reconstruction_owner_mask must match the owned cell shape"
            )
        compact_owner = (
            selected_owner
            if compact_owner_mask is None
            else np.asarray(compact_owner_mask, dtype=bool)
        )
        if compact_owner.shape != shape:
            raise ValueError("compact_owner_mask must match the owned cell shape")
        selected_storage = compact_owner[owner_i, owner_j, owner_k]
        # A compact full face must own the entire dense stencil support, not
        # merely touch a reconstructed owner.  Otherwise the dense projected
        # stencil can still read one poisoned/source sample tangentially while
        # the compact row supplies the other part of the interface flux.
        identity_storage = (
            (owner_i == np.indices(shape)[0])
            & (owner_j == np.indices(shape)[1])
            & (owner_k == np.indices(shape)[2])
        )
        nonordinary_storage = (
            (~active_owner[owner_i, owner_j, owner_k])
            | source
            | (~identity_storage)
            | selected_storage
        )

        def _wrap_support_index(index: list[int]) -> tuple[int, int, int] | None:
            for candidate_axis in range(3):
                if candidate_axis in (1, 2):
                    index[candidate_axis] %= shape[candidate_axis]
                elif not 0 <= index[candidate_axis] < shape[candidate_axis]:
                    return None
            return tuple(index)

        for axis in range(3):
            face_shape = open_fraction[axis].shape
            for face_array in np.ndindex(face_shape):
                face_axis_index = face_array[axis]
                if not 0 < face_axis_index < shape[axis]:
                    continue
                minus = list(face_array)
                minus[axis] -= 1
                plus = list(face_array)
                support: set[tuple[int, int, int]] = set()
                for center in (minus, plus):
                    for derivative_axis in range(3):
                        for direction in (-1, 1):
                            sample = list(center)
                            sample[derivative_axis] += direction
                            sample_index = _wrap_support_index(sample)
                            if sample_index is not None:
                                support.add(sample_index)
                if any(nonordinary_storage[sample] for sample in support):
                    face_candidates.add((axis, *face_array))
    for (axis, side), (
        remote_touched,
        _remote_fluid,
        _remote_centroid,
        _remote_second_moment,
        _remote_third_moment,
    ) in (
        remote_boundary_payloads.items()
    ):
        local_boundary = np.take(
            touched_storage,
            0 if side == 0 else shape[axis] - 1,
            axis=axis,
        )
        for tangential_index in np.argwhere(remote_touched | local_boundary):
            face = [0, 0, 0]
            face[axis] = 0 if side == 0 else shape[axis]
            tangential_axes = [candidate for candidate in range(3) if candidate != axis]
            face[tangential_axes[0]] = int(tangential_index[0])
            face[tangential_axes[1]] = int(tangential_index[1])
            face_candidates.add((axis, face[0], face[1], face[2]))

    if (
        global_topology is not None
        and local_topology is not None
        and canonical_compact_face_ids is not None
        and evaluator_face_ids is not None
    ):
        # A shard halo can discover fewer compact candidates than the global
        # build.  Insert every globally selected face owned by this evaluator
        # shard, converting the canonical periodic low seam to the local high
        # image when its minus owner lives on the final periodic shard.
        records = {
            int(face_id): (int(axis), tuple(int(v) for v in storage))
            for face_id, axis, storage in zip(
                global_topology.face_id,
                global_topology.face_axis,
                global_topology.face_storage_index,
            )
        }
        for face_id in canonical_compact_face_ids:
            if face_id not in records:
                # Negative cut-wall IDs are canonical compact rows too, but
                # they do not correspond to dense coordinate-face masks.
                continue
            axis, storage = records[face_id]
            local_face = [storage[d] - shard_start[d] for d in range(3)]
            if axis in (1, 2) and storage[axis] == 0 and shard_start[axis] > 0:
                local_face[axis] = shape[axis]
            tangential_axes = [d for d in range(3) if d != axis]
            if not all(0 <= local_face[d] < shape[d] for d in tangential_axes):
                continue
            if 0 <= local_face[axis] <= shape[axis]:
                face_candidates.add((axis, *local_face))

    rows: list[dict[str, object]] = []


    def add_row(
        *,
        kind: int,
        minus_owner: tuple[int, int, int],
        plus_owner: tuple[int, int, int] | None,
        axis: int,
        coordinate: float,
        rectangles: list[tuple[tuple[float, float], tuple[float, float]]],
        orientation: float,
        remote_halo: tuple[int, int, int] | None = None,
        remote_centroid: np.ndarray | None = None,
        remote_second_moment: np.ndarray | None = None,
        remote_third_moment: np.ndarray | None = None,
        global_face_id: int = -1,
        remote_residual_halo: tuple[int, int, int] | None = None,
    ) -> None:
        if not rectangles:
            return
        patches = []
        for rectangle in rectangles[:4]:
            points, area_weight = _face_patch_quadrature_numpy(
                axis=axis,
                face_coordinate=coordinate,
                rectangle=rectangle,
                orientation=orientation,
            )
            metric = _shifted_torus_metric_payload_numpy(points)
            patches.append((points, area_weight, metric))
        rows.append(
            {
                "kind": int(kind),
                "minus": minus_owner,
                "plus": plus_owner,
                "remote_halo": remote_halo,
                "remote_centroid": remote_centroid,
                "remote_second_moment": remote_second_moment,
                "remote_third_moment": remote_third_moment,
                "global_face_id": global_face_id,
                "remote_residual_halo": remote_residual_halo,
                "patches": patches,
            }
        )

    for key in sorted(face_candidates):
        axis, fi, fj, fk = key
        face_index = (fi, fj, fk)
        if not all(
            0 <= face_index[d] < open_fraction[axis].shape[d]
            for d in range(3)
        ):
            continue
        axis_face_index = face_index[axis]
        row_global_face_id = global_face_id(axis, face_index)
        if global_topology is not None and row_global_face_id == -1:
            # The sentinel denotes an inactive/aggregate-internal face, not a
            # dense coordinate face.  Preserve the closed-mask behavior and
            # do not emit a compact row without a canonical face record.
            open_masks[axis][face_index] = False
            continue
        if (
            global_topology is not None
            and canonical_compact_face_ids is not None
            and row_global_face_id >= 0
            and row_global_face_id not in canonical_compact_face_ids
        ):
            # Local support discovery can see extra coordinate faces after
            # periodic wrapping.  A face omitted by the canonical whole-domain
            # compact classification remains on the dense path.
            continue
        # Only canonical compact rows are closed on non-evaluator shards.
        if (
            global_topology is not None
            and evaluator_face_ids is not None
            and row_global_face_id not in evaluator_face_ids
        ):
            open_masks[axis][face_index] = False
            continue
        if axis_face_index in (0, shape[axis]):
            side = 0 if axis_face_index == 0 else 1
            remote_payload = remote_boundary_payloads.get((axis, side))
            if remote_payload is None:
                if axis != 0:
                    continue
                # A full coordinate-aligned physical face stays on the dense
                # regular path. Compact physical rows are only needed when an
                # embedded boundary leaves a partial domain-boundary face.
                if (
                    float(open_fraction[axis][face_index])
                    >= 1.0 - 1.0e-12
                ):
                    continue
                local_storage = list(face_index)
                local_storage[axis] = (
                    0 if side == 0 else shape[axis] - 1
                )
                local_storage_index = tuple(local_storage)
                local_owner = (
                    int(owner_i[local_storage_index]),
                    int(owner_j[local_storage_index]),
                    int(owner_k[local_storage_index]),
                )
                if not active_owner[local_owner]:
                    open_masks[axis][face_index] = False
                    continue
                face_coordinate = float(
                    axis_faces[axis][axis_face_index]
                )
                tangential_axes = [
                    candidate for candidate in range(3)
                    if candidate != axis
                ]
                tangential = tuple(
                    (
                        float(axis_faces[t][face_index[t]]),
                        float(axis_faces[t][face_index[t] + 1]),
                    )
                    for t in tangential_axes
                )
                rectangles = _open_face_rectangles_numpy(
                    axis=axis,
                    face_coordinate=face_coordinate,
                    tangential_bounds=tangential,
                    box_translation=box_translation,
                )
                add_row(
                    kind=CV_FACE_PHYSICAL_BOUNDARY,
                    minus_owner=local_owner,
                    plus_owner=None,
                    axis=axis,
                    coordinate=face_coordinate,
                    rectangles=rectangles,
                    orientation=-1.0 if side == 0 else 1.0,
                    global_face_id=row_global_face_id,
                )
                open_masks[axis][face_index] = False
                continue
            (
                remote_touched,
                remote_fluid,
                remote_centroid,
                remote_second_moment,
                remote_third_moment,
            ) = remote_payload
            tangential_axes = [
                candidate for candidate in range(3) if candidate != axis
            ]
            tangential_index = tuple(face_index[d] for d in tangential_axes)
            local_storage = list(face_index)
            local_storage[axis] = 0 if side == 0 else shape[axis] - 1
            local_storage_index = tuple(local_storage)
            if not bool(remote_fluid[tangential_index]):
                open_masks[axis][face_index] = False
                continue
            local_owner = (
                int(owner_i[local_storage_index]),
                int(owner_j[local_storage_index]),
                int(owner_k[local_storage_index]),
            )
            if not active_owner[local_owner]:
                open_masks[axis][face_index] = False
                continue
            face_coordinate = float(axis_faces[axis][axis_face_index])
            tangential = tuple(
                (
                    float(axis_faces[t][face_index[t]]),
                    float(axis_faces[t][face_index[t] + 1]),
                )
                for t in tangential_axes
            )
            rectangles = _open_face_rectangles_numpy(
                axis=axis,
                face_coordinate=face_coordinate,
                tangential_bounds=tangential,
                box_translation=box_translation,
            )
            if not rectangles:
                open_masks[axis][face_index] = False
                continue
            halo_width = int(geometry.layout.halo_width)
            remote_halo = [
                halo_width + face_index[0],
                halo_width + face_index[1],
                halo_width + face_index[2],
            ]
            remote_halo[axis] = (
                halo_width - 1
                if side == 0
                else halo_width + shape[axis]
            )
            is_partial = (
                open_fraction[axis][face_index] < 1.0 - 1.0e-12
            )
            add_row(
                kind=CV_FACE_PARTIAL if is_partial else CV_FACE_INTERIOR,
                minus_owner=local_owner,
                plus_owner=None,
                remote_halo=tuple(remote_halo),
                remote_centroid=remote_centroid[tangential_index],
                remote_second_moment=remote_second_moment[tangential_index],
                remote_third_moment=remote_third_moment[tangential_index],
                axis=axis,
                coordinate=face_coordinate,
                rectangles=rectangles,
                orientation=-1.0 if side == 0 else 1.0,
                global_face_id=row_global_face_id,
                remote_residual_halo=tuple(remote_halo),
            )
            open_masks[axis][face_index] = False
            continue
        if axis_face_index < 0 or axis_face_index > shape[axis]:
            continue
        minus_storage = [fi, fj, fk]
        plus_storage = [fi, fj, fk]
        minus_storage[axis] -= 1
        minus_storage = tuple(minus_storage)
        plus_storage = tuple(plus_storage)
        minus_owner = (
            int(owner_i[minus_storage]),
            int(owner_j[minus_storage]),
            int(owner_k[minus_storage]),
        )
        plus_owner = (
            int(owner_i[plus_storage]),
            int(owner_j[plus_storage]),
            int(owner_k[plus_storage]),
        )
        if not active_owner[minus_owner] or not active_owner[plus_owner]:
            open_masks[axis][face_index] = False
            continue
        if minus_owner == plus_owner:
            open_masks[axis][face_index] = False
            continue
        face_coordinate = float(axis_faces[axis][axis_face_index])
        tangential_axes = [candidate for candidate in range(3) if candidate != axis]
        tangential = tuple(
            (
                float(axis_faces[t][face_index[t]]),
                float(axis_faces[t][face_index[t] + 1]),
            )
            for t in tangential_axes
        )
        rectangles = _open_face_rectangles_numpy(
            axis=axis,
            face_coordinate=face_coordinate,
            tangential_bounds=tangential,
            box_translation=box_translation,
        )
        if not rectangles:
            open_masks[axis][face_index] = False
            continue
        is_partial = open_fraction[axis][face_index] < 1.0 - 1.0e-12
        add_row(
            kind=CV_FACE_PARTIAL if is_partial else CV_FACE_INTERIOR,
            minus_owner=minus_owner,
            plus_owner=plus_owner,
            axis=axis,
            coordinate=face_coordinate,
            rectangles=rectangles,
            orientation=1.0,
            global_face_id=row_global_face_id,
        )
        open_masks[axis][face_index] = False

    for axis, axis_bounds in enumerate(bounds):
        tangential_axes = [candidate for candidate in range(3) if candidate != axis]
        for surface, coordinate in enumerate(axis_bounds):
            if surface == 0:
                owner_axis_index = (
                    int(np.searchsorted(axis_faces[axis], coordinate, side="left"))
                    - 1
                )
                orientation = 1.0
            else:
                owner_axis_index = (
                    int(np.searchsorted(axis_faces[axis], coordinate, side="right"))
                    - 1
                )
                orientation = -1.0
            if not 0 <= owner_axis_index < shape[axis]:
                continue
            for first in range(shape[tangential_axes[0]]):
                first_bounds = (
                    max(
                        float(axis_faces[tangential_axes[0]][first]),
                        float(bounds[tangential_axes[0]][0]),
                    ),
                    min(
                        float(axis_faces[tangential_axes[0]][first + 1]),
                        float(bounds[tangential_axes[0]][1]),
                    ),
                )
                if first_bounds[1] <= first_bounds[0] + 1.0e-15:
                    continue
                for second in range(shape[tangential_axes[1]]):
                    second_bounds = (
                        max(
                            float(axis_faces[tangential_axes[1]][second]),
                            float(bounds[tangential_axes[1]][0]),
                        ),
                        min(
                            float(axis_faces[tangential_axes[1]][second + 1]),
                            float(bounds[tangential_axes[1]][1]),
                        ),
                    )
                    if second_bounds[1] <= second_bounds[0] + 1.0e-15:
                        continue
                    storage = [0, 0, 0]
                    storage[axis] = owner_axis_index
                    storage[tangential_axes[0]] = first
                    storage[tangential_axes[1]] = second
                    storage_index = tuple(storage)
                    owner = (
                        int(owner_i[storage_index]),
                        int(owner_j[storage_index]),
                        int(owner_k[storage_index]),
                    )
                    if not active_owner[owner]:
                        continue
                    add_row(
                        kind=CV_FACE_CUT_WALL,
                        minus_owner=owner,
                        plus_owner=None,
                        axis=axis,
                        coordinate=float(coordinate),
                        rectangles=[(first_bounds, second_bounds)],
                        orientation=orientation,
                        global_face_id=cut_wall_face_id(
                            axis,
                            surface,
                            storage_index,
                        ),
                    )

    # A canonical compact row whose aggregate owner is remote is absent from
    # the local source-cell view by construction.  Repartition every such
    # whole-box row onto the shard containing its minus owner before
    # reconstruction-mask discovery.  This preserves the physical row,
    # quadrature, metric, kind, and stable ID exactly once.
    if canonical_rows:
        # Local support discovery can emit a same-ID row with coordinates
        # interpreted in the shard-local topology.  That row is not
        # authoritative for a compact face crossing a shard boundary (and in
        # particular can lower the remote owner by one periodic cell).  The
        # whole-domain row carries the canonical global minus/plus owners and
        # must replace, rather than merely deduplicate against, any such
        # local discovery.
        canonical_rows_for_lowering = [
            {
                "kind": int(canonical["kind"]),
                "minus": tuple(int(value) for value in canonical["minus"]),
                "plus": canonical.get("plus"),
                "remote_halo": canonical.get("remote_halo"),
                "remote_centroid": canonical.get("remote_centroid"),
                "remote_second_moment": canonical.get("remote_second_moment"),
                "remote_third_moment": canonical.get("remote_third_moment"),
                "global_face_id": int(canonical["global_face_id"]),
                "remote_residual_halo": canonical.get("remote_residual_halo"),
                "patches": canonical["patches"],
            }
            for canonical in canonical_rows
        ]
        rows = _replace_canonical_compact_rows(
            rows,
            canonical_rows_for_lowering,
        )

    max_rows = len(rows)
    max_patches = 4
    row_shape = (max_rows,)
    patch_shape = (max_rows, max_patches)
    quadrature_shape = (max_rows, max_patches, 4)
    kind = np.zeros(row_shape, dtype=np.int32)
    minus_i = np.zeros(row_shape, dtype=np.int32)
    minus_j = np.zeros(row_shape, dtype=np.int32)
    minus_k = np.zeros(row_shape, dtype=np.int32)
    plus_i = np.zeros(row_shape, dtype=np.int32)
    plus_j = np.zeros(row_shape, dtype=np.int32)
    plus_k = np.zeros(row_shape, dtype=np.int32)
    has_plus = np.zeros(row_shape, dtype=bool)
    has_remote = np.zeros(row_shape, dtype=bool)
    remote_halo_i = np.zeros(row_shape, dtype=np.int32)
    remote_halo_j = np.zeros(row_shape, dtype=np.int32)
    remote_halo_k = np.zeros(row_shape, dtype=np.int32)
    remote_centroid = np.zeros(row_shape + (3,), dtype=np.float64)
    remote_second_moment = np.zeros(row_shape + (3, 3), dtype=np.float64)
    remote_third_moment = np.zeros(row_shape + (3, 3, 3), dtype=np.float64)
    global_face_ids = np.full(row_shape, -1, dtype=np.int64)
    has_remote_residual = np.zeros(row_shape, dtype=bool)
    remote_residual_halo_i = np.zeros(row_shape, dtype=np.int32)
    remote_residual_halo_j = np.zeros(row_shape, dtype=np.int32)
    remote_residual_halo_k = np.zeros(row_shape, dtype=np.int32)
    points = np.zeros(quadrature_shape + (3,), dtype=np.float64)
    area = np.zeros(quadrature_shape + (3,), dtype=np.float64)
    J = np.zeros(quadrature_shape, dtype=np.float64)
    g_contra = np.zeros(quadrature_shape + (3, 3), dtype=np.float64)
    g_cov = np.zeros_like(g_contra)
    B_contra = np.zeros(quadrature_shape + (3,), dtype=np.float64)
    Bmag = np.ones(quadrature_shape, dtype=np.float64)
    projector = np.zeros_like(g_contra)
    patch_active = np.zeros(patch_shape, dtype=bool)
    for row_index, row in enumerate(rows):
        kind[row_index] = int(row["kind"])
        global_face_ids[row_index] = int(row.get("global_face_id", -1))
        minus = row["minus"]
        minus_i[row_index], minus_j[row_index], minus_k[row_index] = minus
        plus = row["plus"]
        if plus is not None:
            has_plus[row_index] = True
            plus_i[row_index], plus_j[row_index], plus_k[row_index] = plus
        remote_halo = row["remote_halo"]
        if remote_halo is not None:
            has_remote[row_index] = True
            (
                remote_halo_i[row_index],
                remote_halo_j[row_index],
                remote_halo_k[row_index],
            ) = remote_halo
            remote_centroid[row_index] = row["remote_centroid"]
            remote_second_moment[row_index] = row["remote_second_moment"]
            remote_third_moment[row_index] = row.get("remote_third_moment", 0.0)
        residual_halo = row.get("remote_residual_halo")
        if residual_halo is not None:
            has_remote_residual[row_index] = True
            remote_residual_halo_i[row_index], remote_residual_halo_j[row_index], remote_residual_halo_k[row_index] = residual_halo
        for patch_index, (q_points, q_area, metric) in enumerate(row["patches"]):
            patch_active[row_index, patch_index] = True
            points[row_index, patch_index] = q_points
            area[row_index, patch_index] = q_area
            (
                J[row_index, patch_index],
                g_contra[row_index, patch_index],
                g_cov[row_index, patch_index],
                B_contra[row_index, patch_index],
                Bmag[row_index, patch_index],
                projector[row_index, patch_index],
            ) = metric

    irregular = LocalControlVolumeFaceRows3D(
        layout=geometry.layout,
        kind=jnp.asarray(kind),
        minus_owner_i=jnp.asarray(minus_i),
        minus_owner_j=jnp.asarray(minus_j),
        minus_owner_k=jnp.asarray(minus_k),
        plus_owner_i=jnp.asarray(plus_i),
        plus_owner_j=jnp.asarray(plus_j),
        plus_owner_k=jnp.asarray(plus_k),
        has_plus_owner=jnp.asarray(has_plus),
        quadrature_points=jnp.asarray(points),
        area_covector_weight=jnp.asarray(area),
        J=jnp.asarray(J),
        g_contra=jnp.asarray(g_contra),
        g_cov=jnp.asarray(g_cov),
        B_contra=jnp.asarray(B_contra),
        Bmag=jnp.asarray(Bmag),
        projector=jnp.asarray(projector),
        patch_active=jnp.asarray(patch_active),
        active=jnp.ones((max_rows,), dtype=bool),
        max_rows=max_rows,
        max_patches=max_patches,
        has_remote_owner=jnp.asarray(has_remote),
        remote_halo_i=jnp.asarray(remote_halo_i),
        remote_halo_j=jnp.asarray(remote_halo_j),
        remote_halo_k=jnp.asarray(remote_halo_k),
        remote_centroid=jnp.asarray(remote_centroid),
        remote_second_moment=jnp.asarray(remote_second_moment),
        remote_third_moment=jnp.asarray(remote_third_moment),
        global_face_id=jnp.asarray(global_face_ids),
        has_remote_residual=jnp.asarray(has_remote_residual),
        remote_residual_halo_i=jnp.asarray(remote_residual_halo_i),
        remote_residual_halo_j=jnp.asarray(remote_residual_halo_j),
        remote_residual_halo_k=jnp.asarray(remote_residual_halo_k),
    )
    base_regular = geometry.regular_face_geometry
    regular = LocalRegularFaceGeometry3D(
        layout=geometry.layout,
        x_area=base_regular.x_area,
        y_area=base_regular.y_area,
        z_area=base_regular.z_area,
        x_area_fraction=jnp.asarray(open_fraction[0]),
        y_area_fraction=jnp.asarray(open_fraction[1]),
        z_area_fraction=jnp.asarray(open_fraction[2]),
        x_open_mask=jnp.asarray(open_masks[0]),
        y_open_mask=jnp.asarray(open_masks[1]),
        z_open_mask=jnp.asarray(open_masks[2]),
        x_centroid_offset=base_regular.x_centroid_offset,
        y_centroid_offset=base_regular.y_centroid_offset,
        z_centroid_offset=base_regular.z_centroid_offset,
    )
    for side, face_axis_index in ((0, 0), (1, shape[0])):
        if (0, side) in remote_boundary_payloads:
            continue
        boundary_fraction = np.asarray(
            open_fraction[0][face_axis_index],
            dtype=np.float64,
        )
        boundary_open = np.asarray(
            open_masks[0][face_axis_index],
            dtype=bool,
        )
        full_face = boundary_fraction >= 1.0 - 1.0e-12
        if np.any(full_face & (~boundary_open)):
            raise ValueError(
                "full coordinate-aligned radial boundary faces must remain "
                "on the dense regular path"
            )
    return regular, irregular


def _build_closed_box_control_volume_cells(
    geometry: LocalFciGeometry3D,
    *,
    enable_merging: bool,
    box_translation: tuple[float, float, float] = (0.0, 0.0, 0.0),
) -> LocalControlVolumeCellGeometry3D:
    raw_volume, raw_centroid, raw_second_moment, raw_third_moment, full_volume = (
        _closed_box_fluid_moments_3point(
            geometry,
            box_translation=box_translation,
        )
    )
    source, target_i, target_j, target_k = (
        _select_closed_box_control_volume_owners(
            geometry,
            raw_volume=raw_volume,
            raw_centroid=raw_centroid,
            full_volume=full_volume,
            enable_merging=enable_merging,
            box_translation=box_translation,
        )
    )
    cells = build_local_control_volume_cell_geometry(
        geometry.layout,
        raw_volume=jnp.asarray(raw_volume),
        raw_centroid=jnp.asarray(raw_centroid),
        raw_second_moment=jnp.asarray(raw_second_moment),
        raw_third_moment=jnp.asarray(raw_third_moment),
        source_active=jnp.asarray(source),
        target_i=jnp.asarray(target_i),
        target_j=jnp.asarray(target_j),
        target_k=jnp.asarray(target_k),
        retained_active=jnp.asarray(raw_volume > 1.0e-20),
    )
    source_volume = float(np.sum(np.asarray(cells.raw_volume, dtype=np.float64)))
    owner_volume = float(
        np.sum(np.asarray(cells.aggregate_volume, dtype=np.float64))
    )
    if not np.isclose(
        source_volume,
        owner_volume,
        rtol=5.0e-13,
        atol=5.0e-14,
    ):
        raise ValueError(
            "control-volume merging did not conserve local fluid volume: "
            f"raw={source_volume:.16e}, aggregate={owner_volume:.16e}"
        )
    owner_i_np = np.asarray(cells.owner_i, dtype=np.int32)
    owner_j_np = np.asarray(cells.owner_j, dtype=np.int32)
    owner_k_np = np.asarray(cells.owner_k, dtype=np.int32)
    mapped_owner = (
        owner_i_np[owner_i_np, owner_j_np, owner_k_np],
        owner_j_np[owner_i_np, owner_j_np, owner_k_np],
        owner_k_np[owner_i_np, owner_j_np, owner_k_np],
    )
    if not (
        np.array_equal(mapped_owner[0], owner_i_np)
        and np.array_equal(mapped_owner[1], owner_j_np)
        and np.array_equal(mapped_owner[2], owner_k_np)
    ):
        raise ValueError("control-volume owner mapping must be idempotent")
    return cells


def _build_global_closed_box_control_volume_topology(
    *,
    global_shape: tuple[int, int, int],
    halo_width: int,
    enable_merging: bool,
    box_translation: tuple[float, float, float] = (0.0, 0.0, 0.0),
) -> tuple[GlobalControlVolumeTopology3D, tuple[np.ndarray, ...]]:
    """Build the one canonical host topology for every shifted-torus shard."""
    geometry = build_shifted_torus_local_geometry(
        global_shape, halo_width, global_shape=global_shape, shard_index=(0, 0, 0),
        x_min=shifted_mms.x_min, x_max=shifted_mms.x_max, r0=shifted_mms.r0,
        alpha_value=shifted_mms.alpha_value, iota=shifted_mms.iota,
        c_phi=shifted_mms.c_phi, sigma=shifted_mms.sigma,
    )
    raw_volume, centroid, second, third, full_volume = _closed_box_fluid_moments_3point(
        geometry,
        box_translation=box_translation,
    )
    grids = (geometry.grid.x, geometry.grid.y, geometry.grid.z)
    axis_faces = tuple(np.asarray(grid.faces_owned, dtype=np.float64) for grid in grids)
    measures: list[np.ndarray] = []
    for axis in range(3):
        face_shape = list(global_shape); face_shape[axis] += 1
        measures.append(
            _build_global_coordinate_face_open_measures(
                axis=axis,
                axis_faces=axis_faces,
                face_shape=tuple(face_shape),
                box_translation=box_translation,
            )
        )
    x, y, z = np.meshgrid(*(np.asarray(grid.centers_owned, dtype=np.float64) for grid in grids), indexing="ij")
    bounds = _box_bounds(box_translation=box_translation)
    center_in_solid = ((x > bounds[0][0]) & (x < bounds[0][1]) & (y > bounds[1][0]) & (y < bounds[1][1]) & (z > bounds[2][0]) & (z < bounds[2][1]))
    floor = 1.0e-14 * max(float(np.max(full_volume)), 1.0)
    fraction = raw_volume / np.maximum(full_volume, 1.0e-30)
    # Legacy selection is ``fraction < .5 OR center_in_solid``.
    fraction = np.where(center_in_solid & (raw_volume > floor), 0.0, fraction)
    topology = build_global_control_volume_topology(
        raw_volume=raw_volume, raw_centroid=centroid, raw_second_moment=second, raw_third_moment=third,
        fluid_volume_fraction=fraction, face_open_measure=tuple(measures), periodic_axes=(False, True, True),
        coordinate_periods=(float(shifted_mms.x_max - shifted_mms.x_min), 2.0 * np.pi, 2.0 * np.pi),
        merge_fraction=0.5 if enable_merging else 0.0,
        positive_volume_floor=floor,
    )
    return topology, (raw_volume, centroid, second, third)


def _lower_global_control_volume_cells(
    geometry: LocalFciGeometry3D,
    local: LocalControlVolumeGeometry3D,
    *,
    periodic_axes: tuple[bool, bool, bool] = (False, True, True),
) -> LocalControlVolumeCellGeometry3D:
    """Lower global aggregate ownership, including directly-neighbour owners."""
    owner = np.asarray(local.owner_local_index, dtype=np.int32).copy()
    remote = np.asarray(local.owner_is_remote, dtype=bool)
    shape = geometry.owned_shape
    h = int(geometry.layout.halo_width)
    # Local indices for a remote owner are only inactive-storage placeholders.
    ii, jj, kk = np.indices(shape, dtype=np.int32)
    owner[remote] = np.stack((ii, jj, kk), axis=-1)[remote]
    remote_halo = np.zeros(shape + (3,), dtype=np.int32)
    remote_shard = np.asarray(local.owner_shard_index, dtype=np.int32)
    for index in np.argwhere(remote):
        index_t = tuple(index)
        remote_halo[index_t] = remote_owner_halo_coordinate(
            owner_local=local.owner_local_index[index_t],
            owner_shard=remote_shard[index_t],
            local_shard=np.asarray(local.shard_index, dtype=np.int32),
            owned_shape=shape,
            halo_width=h,
            shard_counts=local.shard_counts,
            periodic_axes=periodic_axes,
        )
    active = local.local_active_owner
    return LocalControlVolumeCellGeometry3D(
        layout=geometry.layout, owner_i=jnp.asarray(owner[..., 0]), owner_j=jnp.asarray(owner[..., 1]), owner_k=jnp.asarray(owner[..., 2]),
        is_merged_source=jnp.asarray(local.local_merge_source), is_active_owner=jnp.asarray(active),
        is_aggregate_target=jnp.asarray(active & (local.local_received_source_count > 0)),
        received_source_count=jnp.asarray(local.local_received_source_count), member_count=jnp.asarray(local.local_member_count),
        raw_volume=jnp.asarray(local.local_raw_volume), aggregate_volume=jnp.asarray(local.local_aggregate_volume),
        raw_centroid=jnp.asarray(local.local_raw_centroid), centroid=jnp.asarray(local.local_aggregate_centroid),
        raw_second_moment=jnp.asarray(local.local_raw_second_moment), second_moment=jnp.asarray(local.local_aggregate_second_moment),
        raw_third_moment=jnp.asarray(local.local_raw_third_moment), third_moment=jnp.asarray(local.local_aggregate_third_moment),
        aggregate_id=jnp.asarray(local.local_aggregate_id), owner_is_remote=jnp.asarray(remote),
        remote_owner_halo_i=jnp.asarray(remote_halo[..., 0]), remote_owner_halo_j=jnp.asarray(remote_halo[..., 1]), remote_owner_halo_k=jnp.asarray(remote_halo[..., 2]),
    )


def _intrinsic_reconstruction_owner_mask(
    cells: LocalControlVolumeCellGeometry3D,
    irregular_faces: LocalControlVolumeFaceRows3D,
) -> np.ndarray:
    """Select owners needing polynomial data from embedded geometry alone."""

    active_owner = np.asarray(cells.is_active_owner, dtype=bool)
    target = np.asarray(cells.is_aggregate_target, dtype=bool).copy()
    face_active = np.asarray(irregular_faces.active, dtype=bool)
    face_kind = np.asarray(irregular_faces.kind, dtype=np.int32)
    intrinsic_face = face_active & (
        (face_kind == CV_FACE_PARTIAL)
        | (face_kind == CV_FACE_CUT_WALL)
        | (face_kind == CV_FACE_PHYSICAL_BOUNDARY)
    )
    for row in np.flatnonzero(intrinsic_face):
        minus = (
            int(np.asarray(irregular_faces.minus_owner_i)[row]),
            int(np.asarray(irregular_faces.minus_owner_j)[row]),
            int(np.asarray(irregular_faces.minus_owner_k)[row]),
        )
        target[minus] = True
        if bool(np.asarray(irregular_faces.has_plus_owner)[row]):
            plus = (
                int(np.asarray(irregular_faces.plus_owner_i)[row]),
                int(np.asarray(irregular_faces.plus_owner_j)[row]),
                int(np.asarray(irregular_faces.plus_owner_k)[row]),
            )
            target[plus] = True
    return target & active_owner


def _dilate_reconstruction_owner_mask(
    cells: LocalControlVolumeCellGeometry3D,
    intrinsic_mask: np.ndarray,
    *,
    periodic_axes: tuple[bool, bool, bool],
) -> np.ndarray:
    """Add one face-neighbour guard ring around intrinsic CV owners.

    Compact-face flux reconstruction needs polynomial support on both sides
    of the irregular band. Reconstructing only the owner directly touching a
    wall leaves that support incomplete one logical cell away.
    """

    shape = cells.shape
    active = np.asarray(cells.is_active_owner, dtype=bool)
    owner_i = np.asarray(cells.owner_i, dtype=np.int32)
    owner_j = np.asarray(cells.owner_j, dtype=np.int32)
    owner_k = np.asarray(cells.owner_k, dtype=np.int32)
    result = np.asarray(intrinsic_mask, dtype=bool).copy()
    for storage_array in np.argwhere(intrinsic_mask):
        storage = [int(value) for value in storage_array]
        for axis in range(3):
            for direction in (-1, 1):
                neighbor = list(storage)
                neighbor[axis] += direction
                if periodic_axes[axis]:
                    neighbor[axis] %= shape[axis]
                elif not 0 <= neighbor[axis] < shape[axis]:
                    continue
                neighbor_index = tuple(neighbor)
                owner = (
                    int(owner_i[neighbor_index]),
                    int(owner_j[neighbor_index]),
                    int(owner_k[neighbor_index]),
                )
                if active[owner]:
                    result[owner] = True
    return result & active


def _compact_face_reconstruction_owner_mask(
    cells: LocalControlVolumeCellGeometry3D,
    irregular_faces: LocalControlVolumeFaceRows3D,
) -> np.ndarray:
    """Return active local owners attached to every compact face.

    Remote neighbors are supplied by the reconstruction halo exchange; this
    mask deliberately marks only local minus/plus owners.
    """

    result = np.zeros(cells.shape, dtype=bool)
    active = np.asarray(irregular_faces.active, dtype=bool)
    has_plus = np.asarray(irregular_faces.has_plus_owner, dtype=bool)
    for row in np.flatnonzero(active):
        minus = (
            int(np.asarray(irregular_faces.minus_owner_i)[row]),
            int(np.asarray(irregular_faces.minus_owner_j)[row]),
            int(np.asarray(irregular_faces.minus_owner_k)[row]),
        )
        result[minus] = True
        if has_plus[row]:
            plus = (
                int(np.asarray(irregular_faces.plus_owner_i)[row]),
                int(np.asarray(irregular_faces.plus_owner_j)[row]),
                int(np.asarray(irregular_faces.plus_owner_k)[row]),
            )
            result[plus] = True
    return result & np.asarray(cells.is_active_owner, dtype=bool)


_FACE_FUNCTIONAL_NORMALIZED_NORM_LIMIT = 100.0


def _validate_face_functional_boundary_weight_scale(value: float) -> float:
    scale = float(value)
    if not np.isfinite(scale) or scale <= 0.0:
        raise ValueError(
            "face_functional_boundary_weight_scale must be finite and positive"
        )
    return scale


def _validate_reconstruction_boundary_weight_scale(value: float) -> float:
    scale = float(value)
    if not np.isfinite(scale) or scale <= 0.0:
        raise ValueError(
            "reconstruction_boundary_weight_scale must be finite and positive"
        )
    return scale


def _validate_reconstruction_distance_row_weight_exponent(
    value: float,
) -> float:
    exponent = float(value)
    if not np.isfinite(exponent) or exponent < 0.0:
        raise ValueError(
            "reconstruction_distance_row_weight_exponent must be finite "
            "and nonnegative"
        )
    return exponent


def _validate_face_functional_cell_radius(value: int) -> int:
    if isinstance(value, (bool, np.bool_)) or not isinstance(
        value, (int, np.integer)
    ):
        raise ValueError("face_functional_cell_radius must be integer 1 or 2")
    radius = int(value)
    if radius not in (1, 2):
        raise ValueError("face_functional_cell_radius must be integer 1 or 2")
    return radius


def _nearest_periodic_image(
    points: np.ndarray,
    reference: np.ndarray,
) -> np.ndarray:
    """Put logical points in the evaluator owner's periodic image."""

    result = np.asarray(points, dtype=np.float64).copy()
    reference = np.asarray(reference, dtype=np.float64)
    for axis in (1, 2):
        result[..., axis] += 2.0 * np.pi * np.round(
            (reference[axis] - result[..., axis]) / (2.0 * np.pi)
        )
    return result


def _compile_global_cubic_face_functional_records(
    geometry: LocalFciGeometry3D,
    cells: LocalControlVolumeCellGeometry3D,
    faces: LocalControlVolumeFaceRows3D,
    *,
    face_functional_boundary_weight_scale: float = 1.0,
    face_functional_all_owner_boundary_observations: bool = False,
    face_functional_cell_radius: int = 2,
) -> dict[int, dict[str, object]]:
    """Compile each compact face once on the unsplit global fixture.

    Records remain test-owned until the final production embedded-face input
    representation is chosen.  Cell references are global aggregate-owner
    coordinates and boundary references use stable global face IDs, so local
    lowering cannot change the fitted weights or diagnostics.
    """
    face_functional_boundary_weight_scale = _validate_face_functional_boundary_weight_scale(
        face_functional_boundary_weight_scale
    )
    face_functional_cell_radius = _validate_face_functional_cell_radius(
        face_functional_cell_radius
    )
    count = int(faces.max_rows)
    active = np.asarray(faces.active, dtype=bool)
    centroid = np.asarray(cells.centroid, dtype=np.float64)
    second = np.asarray(cells.second_moment, dtype=np.float64)
    third = np.asarray(cells.third_moment, dtype=np.float64)
    owner_active = np.asarray(cells.is_active_owner, dtype=bool)
    owners = np.stack((np.asarray(cells.owner_i), np.asarray(cells.owner_j), np.asarray(cells.owner_k)), axis=-1)
    aggregate_id = np.asarray(cells.aggregate_id, dtype=np.int64)
    shape = tuple(int(value) for value in geometry.owned_shape)
    spacing = np.stack((np.asarray(geometry.spacing.dx_owned), np.asarray(geometry.spacing.dy_owned), np.asarray(geometry.spacing.dz_owned)), axis=-1)
    face_kind = np.asarray(faces.kind, dtype=np.int32)
    face_minus = np.stack((np.asarray(faces.minus_owner_i), np.asarray(faces.minus_owner_j), np.asarray(faces.minus_owner_k)), axis=-1)
    face_plus = np.stack((np.asarray(faces.plus_owner_i), np.asarray(faces.plus_owner_j), np.asarray(faces.plus_owner_k)), axis=-1)
    has_plus = np.asarray(faces.has_plus_owner, dtype=bool)
    qactive = np.asarray(faces.patch_active, dtype=bool)[..., None] & np.ones((1, 1, 4), dtype=bool)
    qpoints = np.asarray(faces.quadrature_points, dtype=np.float64)
    face_ids = np.asarray(faces.global_face_id, dtype=np.int64)
    if np.any(active & (face_ids == -1)):
        raise ValueError("every active global compact face needs a stable ID")
    boundary_by_owner: dict[tuple[int, int, int], list[int]] = {}
    for boundary_row in np.flatnonzero(
        active
        & (
            (face_kind == CV_FACE_CUT_WALL)
            | (face_kind == CV_FACE_PHYSICAL_BOUNDARY)
        )
    ):
        owner = tuple(int(value) for value in face_minus[boundary_row])
        boundary_by_owner.setdefault(owner, []).append(int(boundary_row))
    records: dict[int, dict[str, object]] = {}
    for row in range(count):
        if not active[row]:
            continue
        owner_list = [tuple(int(v) for v in face_minus[row])]
        if has_plus[row]:
            owner_list.append(tuple(int(v) for v in face_plus[row]))
        evaluator = owner_list[0]
        evaluator_centroid = centroid[evaluator]
        scale = np.asarray(spacing[evaluator], dtype=np.float64)
        all_qpoints = _nearest_periodic_image(qpoints[row], evaluator_centroid)
        active_qpoints = all_qpoints[qactive[row]]
        qmeasure = (
            np.asarray(faces.J, dtype=np.float64)[row]
            * np.linalg.norm(
                np.asarray(faces.area_covector_weight, dtype=np.float64)[row],
                axis=-1,
            )
        )[qactive[row]]
        if active_qpoints.size == 0 or not np.any(qmeasure > 0.0):
            raise ValueError("active compact face has no positive quadrature measure")
        origin = np.average(active_qpoints, axis=0, weights=qmeasure)
        metadata: list[tuple[int, tuple[int, ...]]] = []
        matrix: list[np.ndarray] = []
        weights: list[float] = []
        # Candidate discovery is index/topology work.  Delay all coordinate
        # transforms and cubic-moment evaluation until the unique aggregate
        # owners are known, then evaluate those arrays in one batch per face.
        # The previous scalar path repeated both operations for every storage
        # candidate in the 5^3 neighborhood, including duplicate aggregate
        # owners.
        candidates: dict[int, tuple[int, tuple[int, int, int]]] = {}
        for base in owner_list:
            for di in range(-face_functional_cell_radius, face_functional_cell_radius + 1):
                for dj in range(-face_functional_cell_radius, face_functional_cell_radius + 1):
                    for dk in range(-face_functional_cell_radius, face_functional_cell_radius + 1):
                        candidate = [base[0] + di, base[1] + dj, base[2] + dk]
                        candidate[1] %= shape[1]
                        candidate[2] %= shape[2]
                        if not 0 <= candidate[0] < shape[0]:
                            continue
                        storage = tuple(candidate)
                        owner = tuple(int(value) for value in owners[storage])
                        if not owner_active[owner]:
                            continue
                        owner_id = int(aggregate_id[owner])
                        shell = max(abs(di), abs(dj), abs(dk))
                        key = (shell, owner)
                        previous = candidates.get(owner_id)
                        if previous is None or key < previous:
                            candidates[owner_id] = key
        candidate_items = list(candidates.items())
        if candidate_items:
            candidate_owner = np.asarray(
                [item[1][1] for item in candidate_items],
                dtype=np.int32,
            )
            candidate_centroid = _nearest_periodic_image(
                centroid[
                    candidate_owner[:, 0],
                    candidate_owner[:, 1],
                    candidate_owner[:, 2],
                ],
                evaluator_centroid,
            )
            scaled_delta = (candidate_centroid - origin[None, :]) / scale[None, :]
            candidate_distance2 = np.einsum(
                "ni,ni->n",
                scaled_delta,
                scaled_delta,
            )
            candidate_order = sorted(
                range(len(candidate_items)),
                key=lambda index: (
                    candidate_items[index][1][0],
                    float(candidate_distance2[index]),
                    candidate_items[index][0],
                ),
            )
            ordered_owner = candidate_owner[candidate_order]
            ordered_centroid = candidate_centroid[candidate_order]
            ordered_distance2 = candidate_distance2[candidate_order]
            owner_basis = cubic_control_volume_average_basis(
                ordered_centroid,
                second[
                    ordered_owner[:, 0],
                    ordered_owner[:, 1],
                    ordered_owner[:, 2],
                ],
                third[
                    ordered_owner[:, 0],
                    ordered_owner[:, 1],
                    ordered_owner[:, 2],
                ],
                origin=origin,
                scale=scale,
            )
            matrix.extend(owner_basis)
            weights.extend(
                1.0 / np.maximum(ordered_distance2, 1.0e-12)
            )
            metadata.extend(
                (
                    CV_RECONSTRUCTION_EQUATION_CELL,
                    tuple(int(value) for value in owner),
                )
                for owner in ordered_owner
            )
        if face_functional_all_owner_boundary_observations:
            boundary_rows = sorted(
                {
                    boundary_row
                    for owner in owner_list
                    for boundary_row in boundary_by_owner.get(owner, ())
                },
                key=lambda boundary_row: int(face_ids[boundary_row]),
            )
        else:
            # BC quadrature values are not halo-exchanged. Restrict trace
            # observations to the evaluator owner so every referenced boundary
            # row is owned by the same shard under every decomposition.
            boundary_rows = sorted(
                set(boundary_by_owner.get(evaluator, ())),
                key=lambda boundary_row: int(face_ids[boundary_row]),
            )
        boundary_samples: list[
            tuple[int, int, int, float, float]
        ] = []
        for boundary_row in boundary_rows:
            measure = np.asarray(faces.J)[boundary_row] * np.linalg.norm(np.asarray(faces.area_covector_weight)[boundary_row], axis=-1)
            total = float(np.sum(np.where(qactive[boundary_row], measure, 0.0)))
            for patch in range(int(faces.max_patches)):
                for quad in range(4):
                    if not qactive[boundary_row, patch, quad]:
                        continue
                    boundary_samples.append(
                        (
                            int(boundary_row),
                            int(patch),
                            int(quad),
                            float(measure[patch, quad]),
                            total,
                        )
                    )
        if boundary_samples:
            boundary_point = _nearest_periodic_image(
                np.asarray(
                    [
                        qpoints[boundary_row, patch, quad]
                        for boundary_row, patch, quad, _measure, _total
                        in boundary_samples
                    ],
                    dtype=np.float64,
                ),
                evaluator_centroid,
            )
            boundary_basis = cubic_control_volume_average_basis(
                boundary_point,
                np.zeros((len(boundary_samples), 3, 3), dtype=np.float64),
                np.zeros((len(boundary_samples), 3, 3, 3), dtype=np.float64),
                origin=origin,
                scale=scale,
            )
            boundary_delta = (boundary_point - origin[None, :]) / scale[None, :]
            boundary_distance2 = np.einsum(
                "ni,ni->n",
                boundary_delta,
                boundary_delta,
            )
            matrix.extend(boundary_basis)
            for sample, distance2 in zip(
                boundary_samples,
                boundary_distance2,
            ):
                boundary_row, patch, quad, sample_measure, total = sample
                weights.append(
                    face_functional_boundary_weight_scale
                    * sample_measure
                    / max(total, 1.0e-30)
                    / max(float(distance2), 1.0e-12)
                )
                metadata.append(
                    (
                        CV_RECONSTRUCTION_EQUATION_DIRICHLET,
                        (int(face_ids[boundary_row]), patch, quad),
                    )
                )
        functional = precompute_local_face_functional(
            np.asarray(matrix), equation_kind=np.asarray([m[0] for m in metadata]),
            sample_reference=np.arange(len(metadata), dtype=np.int64),
            value_target=np.zeros((20,)), gradient_target=np.zeros((3, 20)),
            projected_flux_target=cubic_projected_face_flux_target(all_qpoints, np.asarray(faces.J)[row], np.asarray(faces.area_covector_weight)[row], np.asarray(faces.projector)[row], qactive[row], origin=origin, scale=scale),
            parallel_flux_target=cubic_parallel_face_flux_target(all_qpoints, np.asarray(faces.J)[row], np.asarray(faces.area_covector_weight)[row], np.asarray(faces.B_contra)[row], np.asarray(faces.Bmag)[row], qactive[row], origin=origin, scale=scale),
            parallel_gradient_flux_target=cubic_parallel_gradient_face_flux_target(all_qpoints, np.asarray(faces.J)[row], np.asarray(faces.area_covector_weight)[row], np.asarray(faces.B_contra)[row], np.asarray(faces.Bmag)[row], qactive[row], origin=origin, scale=scale),
            observation_weight=np.asarray(weights), face_id=int(np.asarray(faces.global_face_id)[row]),
            max_projected_flux_l1=np.inf, max_parallel_flux_l1=np.inf,
            max_parallel_gradient_flux_l1=np.inf,
            max_normalized_projected_weight_norm=_FACE_FUNCTIONAL_NORMALIZED_NORM_LIMIT,
            max_normalized_parallel_weight_norm=_FACE_FUNCTIONAL_NORMALIZED_NORM_LIMIT,
            max_normalized_parallel_gradient_weight_norm=_FACE_FUNCTIONAL_NORMALIZED_NORM_LIMIT,
        )
        records[int(face_ids[row])] = {
            "functional": functional,
            "metadata": tuple(metadata),
        }
    return records


def _global_face_functional_cache_key(
    *,
    global_shape: tuple[int, int, int],
    shard_counts: tuple[int, int, int],
    halo_width: int,
    enable_merging: bool,
    box_translation: tuple[float, float, float],
    reconstruction_boundary_weight_scale: float,
    reconstruction_distance_row_weight_exponent: float,
    face_functional_boundary_weight_scale: float,
    face_functional_all_owner_boundary_observations: bool,
    face_functional_cell_radius: int,
) -> str:
    """Return a deterministic key for reusable global functional records."""

    payload = {
        "schema": _FACE_FUNCTIONAL_CACHE_SCHEMA,
        "global_shape": tuple(int(value) for value in global_shape),
        "shard_counts": tuple(int(value) for value in shard_counts),
        "halo_width": int(halo_width),
        "enable_merging": bool(enable_merging),
        "box_translation": tuple(float(value) for value in box_translation),
        "reconstruction_boundary_weight_scale": float(
            reconstruction_boundary_weight_scale
        ),
        "reconstruction_distance_row_weight_exponent": float(
            reconstruction_distance_row_weight_exponent
        ),
        "face_functional_boundary_weight_scale": float(
            face_functional_boundary_weight_scale
        ),
        "face_functional_all_owner_boundary_observations": bool(
            face_functional_all_owner_boundary_observations
        ),
        "face_functional_cell_radius": int(face_functional_cell_radius),
        "box": {
            "x_fraction_range": BOX_X_FRACTION_RANGE,
            "theta_center": BOX_THETA_CENTER,
            "theta_half_width": BOX_THETA_HALF_WIDTH,
            "zeta_range": BOX_ZETA_RANGE,
        },
        "shifted_torus": {
            name: float(getattr(shifted_mms, name))
            for name in (
                "x_min",
                "x_max",
                "r0",
                "alpha_value",
                "iota",
                "c_phi",
                "sigma",
            )
        },
    }
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _save_global_face_functional_records(
    path: Path,
    records: dict[int, dict[str, object]],
    *,
    cache_key: str,
) -> None:
    """Write trusted numeric functional metadata without pickle."""

    face_id = np.asarray(sorted(records), dtype=np.int64)
    equation_count = np.asarray(
        [len(records[int(value)]["metadata"]) for value in face_id],
        dtype=np.int32,
    )
    max_equations = int(np.max(equation_count)) if equation_count.size else 1
    shape = (len(face_id), max_equations)
    metadata_kind = np.zeros(shape, dtype=np.int32)
    metadata_payload = np.zeros(shape + (3,), dtype=np.int64)
    projected = np.zeros(shape, dtype=np.float64)
    parallel = np.zeros(shape, dtype=np.float64)
    parallel_gradient = np.zeros(shape, dtype=np.float64)
    polynomial_order = np.zeros((len(face_id),), dtype=np.int32)
    rank = np.zeros((len(face_id),), dtype=np.int32)
    condition = np.zeros((len(face_id),), dtype=np.float64)
    residual = np.zeros((len(face_id),), dtype=np.float64)
    projected_norm = np.zeros((len(face_id),), dtype=np.float64)
    parallel_norm = np.zeros((len(face_id),), dtype=np.float64)
    parallel_gradient_norm = np.zeros((len(face_id),), dtype=np.float64)
    for row, value in enumerate(face_id):
        item = records[int(value)]
        functional = item["functional"]
        metadata = item["metadata"]
        count = len(metadata)
        metadata_kind[row, :count] = np.asarray(
            [entry[0] for entry in metadata],
            dtype=np.int32,
        )
        metadata_payload[row, :count] = np.asarray(
            [entry[1] for entry in metadata],
            dtype=np.int64,
        )
        projected[row, :count] = functional.projected_flux_weights
        parallel[row, :count] = functional.parallel_flux_weights
        parallel_gradient[row, :count] = (
            functional.parallel_gradient_flux_weights
        )
        polynomial_order[row] = functional.polynomial_order
        rank[row] = functional.rank
        condition[row] = functional.condition_number
        residual[row] = functional.reproduction_residual
        projected_norm[row] = functional.normalized_projected_weight_norm
        parallel_norm[row] = functional.normalized_parallel_weight_norm
        parallel_gradient_norm[row] = (
            functional.normalized_parallel_gradient_weight_norm
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(
        f".{path.name}.{time_module.time_ns()}.tmp"
    )
    try:
        with temporary.open("wb") as stream:
            np.savez(
                stream,
                schema=np.asarray(_FACE_FUNCTIONAL_CACHE_SCHEMA, dtype=np.int32),
                cache_key=np.asarray(cache_key),
                face_id=face_id,
                equation_count=equation_count,
                metadata_kind=metadata_kind,
                metadata_payload=metadata_payload,
                projected_flux_weights=projected,
                parallel_flux_weights=parallel,
                parallel_gradient_flux_weights=parallel_gradient,
                polynomial_order=polynomial_order,
                rank=rank,
                condition_number=condition,
                reproduction_residual=residual,
                normalized_projected_weight_norm=projected_norm,
                normalized_parallel_weight_norm=parallel_norm,
                normalized_parallel_gradient_weight_norm=parallel_gradient_norm,
            )
        temporary.replace(path)
    finally:
        if temporary.exists():
            temporary.unlink()


def _load_global_face_functional_records(
    path: Path,
    *,
    cache_key: str,
) -> dict[int, dict[str, object]]:
    """Load a versioned numeric cache and reconstruct lowering records."""

    with np.load(path, allow_pickle=False) as payload:
        schema = int(np.asarray(payload["schema"]).item())
        stored_key = str(np.asarray(payload["cache_key"]).item())
        if schema != _FACE_FUNCTIONAL_CACHE_SCHEMA or stored_key != cache_key:
            raise ValueError("face-functional cache key/schema mismatch")
        face_id = np.asarray(payload["face_id"], dtype=np.int64)
        equation_count = np.asarray(payload["equation_count"], dtype=np.int32)
        metadata_kind = np.asarray(payload["metadata_kind"], dtype=np.int32)
        metadata_payload = np.asarray(payload["metadata_payload"], dtype=np.int64)
        projected = np.asarray(payload["projected_flux_weights"], dtype=np.float64)
        parallel = np.asarray(payload["parallel_flux_weights"], dtype=np.float64)
        parallel_gradient = np.asarray(
            payload["parallel_gradient_flux_weights"],
            dtype=np.float64,
        )
        polynomial_order = np.asarray(payload["polynomial_order"], dtype=np.int32)
        rank = np.asarray(payload["rank"], dtype=np.int32)
        condition = np.asarray(payload["condition_number"], dtype=np.float64)
        residual = np.asarray(payload["reproduction_residual"], dtype=np.float64)
        projected_norm = np.asarray(
            payload["normalized_projected_weight_norm"],
            dtype=np.float64,
        )
        parallel_norm = np.asarray(
            payload["normalized_parallel_weight_norm"],
            dtype=np.float64,
        )
        parallel_gradient_norm = np.asarray(
            payload["normalized_parallel_gradient_weight_norm"],
            dtype=np.float64,
        )
    if face_id.ndim != 1 or equation_count.shape != face_id.shape:
        raise ValueError("face-functional cache has inconsistent row metadata")
    row_count = len(face_id)
    if (
        metadata_kind.ndim != 2
        or metadata_kind.shape[0] != row_count
        or metadata_payload.shape != metadata_kind.shape + (3,)
        or projected.shape != metadata_kind.shape
        or parallel.shape != metadata_kind.shape
        or parallel_gradient.shape != metadata_kind.shape
    ):
        raise ValueError("face-functional cache has inconsistent equation arrays")
    scalar_arrays = (
        polynomial_order,
        rank,
        condition,
        residual,
        projected_norm,
        parallel_norm,
        parallel_gradient_norm,
    )
    if any(value.shape != (row_count,) for value in scalar_arrays):
        raise ValueError("face-functional cache has inconsistent diagnostics")
    records: dict[int, dict[str, object]] = {}
    for row, value in enumerate(face_id):
        count = int(equation_count[row])
        if count < 1 or count > metadata_kind.shape[1]:
            raise ValueError("face-functional cache equation count is invalid")
        metadata = tuple(
            (
                int(metadata_kind[row, equation]),
                tuple(
                    int(component)
                    for component in metadata_payload[row, equation]
                ),
            )
            for equation in range(count)
        )
        records[int(value)] = {
            "functional": _CachedFaceFunctional(
                projected_flux_weights=projected[row, :count],
                parallel_flux_weights=parallel[row, :count],
                parallel_gradient_flux_weights=parallel_gradient[row, :count],
                polynomial_order=int(polynomial_order[row]),
                rank=int(rank[row]),
                condition_number=float(condition[row]),
                reproduction_residual=float(residual[row]),
                normalized_projected_weight_norm=float(projected_norm[row]),
                normalized_parallel_weight_norm=float(parallel_norm[row]),
                normalized_parallel_gradient_weight_norm=float(
                    parallel_gradient_norm[row]
                ),
            ),
            "metadata": metadata,
        }
    if len(records) != row_count:
        raise ValueError("face-functional cache contains duplicate face IDs")
    return records


def _lower_global_cubic_face_functionals(
    geometry: LocalFciGeometry3D,
    faces: LocalControlVolumeFaceRows3D,
    records: dict[int, dict[str, object]],
    *,
    global_shape: tuple[int, int, int],
    shard_index: tuple[int, int, int],
    shard_counts: tuple[int, int, int],
    boundary_source_lookup: dict[int, tuple[int, int]] | None = None,
    defer_unresolved_boundary_sources: bool = False,
) -> LocalMomentFittedFaceRows3D:
    """Lower global observation references into owned, halo, and BC gathers."""

    count = int(faces.max_rows)
    if count == 0:
        return LocalMomentFittedFaceRows3D.empty(geometry.layout)
    face_ids = np.asarray(faces.global_face_id, dtype=np.int64)
    active = np.asarray(faces.active, dtype=bool)
    local_face_rows = {
        int(face_id): int(row)
        for row, face_id in enumerate(face_ids)
        if active[row]
    }
    missing = sorted(set(local_face_rows) - set(records))
    if missing:
        raise ValueError(f"local compact faces lack global functionals: {missing[:4]}")
    owned_shape = tuple(int(value) for value in geometry.owned_shape)
    if tuple(global_shape[axis] // shard_counts[axis] for axis in range(3)) != owned_shape:
        raise ValueError("global shape and shard counts must match local owned shape")
    shard_start = tuple(shard_index[axis] * owned_shape[axis] for axis in range(3))
    halo_width = int(geometry.layout.halo_width)
    max_equations = max(
        len(records[int(face_ids[row])]["metadata"])
        for row in np.flatnonzero(active)
    )
    kwargs = {name: np.zeros((count, max_equations), dtype=dtype) for name, dtype in (("observation_kind", np.int32), ("owned_i", np.int32), ("owned_j", np.int32), ("owned_k", np.int32), ("halo_i", np.int32), ("halo_j", np.int32), ("halo_k", np.int32), ("boundary_source_shard", np.int32), ("boundary_face_row", np.int32), ("boundary_patch", np.int32), ("boundary_quadrature", np.int32), ("projected_flux_weights", np.float64), ("parallel_flux_weights", np.float64), ("parallel_gradient_flux_weights", np.float64))}
    observation_active = np.zeros((count, max_equations), dtype=bool)
    polynomial_order = np.zeros((count,), dtype=np.int32); rank = np.zeros((count,), dtype=np.int32)
    condition = np.full((count,), np.inf); residual = np.zeros((count,)); projected_norm = np.zeros((count,)); parallel_norm = np.zeros((count,)); parallel_gradient_norm = np.zeros((count,))
    for row in np.flatnonzero(active):
        item = records[int(face_ids[row])]
        functional = item["functional"]
        metadata = item["metadata"]
        n = len(metadata); observation_active[row, :n] = True
        kwargs["projected_flux_weights"][row, :n] = functional.projected_flux_weights
        kwargs["parallel_flux_weights"][row, :n] = functional.parallel_flux_weights
        kwargs["parallel_gradient_flux_weights"][row, :n] = functional.parallel_gradient_flux_weights
        polynomial_order[row] = functional.polynomial_order; rank[row] = functional.rank; condition[row] = functional.condition_number; residual[row] = functional.reproduction_residual; projected_norm[row] = functional.normalized_projected_weight_norm; parallel_norm[row] = functional.normalized_parallel_weight_norm; parallel_gradient_norm[row] = functional.normalized_parallel_gradient_weight_norm
        for equation, (kind, payload) in enumerate(metadata):
            kwargs["observation_kind"][row, equation] = kind
            if kind == CV_RECONSTRUCTION_EQUATION_CELL:
                relative = [int(payload[axis]) - shard_start[axis] for axis in range(3)]
                for axis in (1, 2):
                    candidates = (
                        relative[axis] - global_shape[axis],
                        relative[axis],
                        relative[axis] + global_shape[axis],
                    )
                    relative[axis] = min(
                        candidates,
                        key=lambda value: (
                            max(-value, value - owned_shape[axis] + 1, 0),
                            abs(value - 0.5 * (owned_shape[axis] - 1)),
                        ),
                    )
                if all(0 <= relative[axis] < owned_shape[axis] for axis in range(3)):
                    kwargs["owned_i"][row, equation], kwargs["owned_j"][row, equation], kwargs["owned_k"][row, equation] = relative
                else:
                    halo = [relative[axis] + halo_width for axis in range(3)]
                    if any(
                        not 0 <= halo[axis] < owned_shape[axis] + 2 * halo_width
                        for axis in range(3)
                    ):
                        raise ValueError(
                            "global cubic observation lies outside the populated local halo"
                        )
                    kwargs["observation_kind"][row, equation] = CV_RECONSTRUCTION_EQUATION_REMOTE_CELL
                    kwargs["halo_i"][row, equation], kwargs["halo_j"][row, equation], kwargs["halo_k"][row, equation] = halo
            else:
                boundary_face_id, patch, quadrature = payload
                boundary_face_id = int(boundary_face_id)
                if defer_unresolved_boundary_sources and (
                    boundary_source_lookup is None
                    or boundary_face_id not in boundary_source_lookup
                ):
                    source_shard, source_row = 0, 0
                elif boundary_source_lookup is None:
                    if boundary_face_id not in local_face_rows:
                        raise ValueError(
                            "global boundary observation is not owned by the evaluator shard"
                        )
                    source_shard, source_row = 0, local_face_rows[boundary_face_id]
                elif boundary_face_id in boundary_source_lookup:
                    source_shard, source_row = boundary_source_lookup[boundary_face_id]
                else:
                    raise ValueError(
                        "global boundary observation has no source-shard mapping: "
                        f"face_id={boundary_face_id}"
                    )
                kwargs["boundary_source_shard"][row, equation] = int(source_shard)
                kwargs["boundary_face_row"][row, equation] = int(source_row)
                kwargs["boundary_patch"][row, equation] = int(patch)
                kwargs["boundary_quadrature"][row, equation] = int(quadrature)
    return LocalMomentFittedFaceRows3D(layout=geometry.layout, functional_face_id=faces.global_face_id, observation_active=jnp.asarray(observation_active), polynomial_order=jnp.asarray(polynomial_order), rank=jnp.asarray(rank), condition_number=jnp.asarray(condition), reproduction_residual=jnp.asarray(residual), normalized_projected_weight_norm=jnp.asarray(projected_norm), normalized_parallel_weight_norm=jnp.asarray(parallel_norm), normalized_parallel_gradient_weight_norm=jnp.asarray(parallel_gradient_norm), active=faces.active, max_rows=count, max_equations=max_equations, **{key: jnp.asarray(value) for key, value in kwargs.items()})


def _lower_canonical_reconstruction(
    geometry: LocalFciGeometry3D,
    whole_reconstruction: LocalMomentReconstruction3D,
    whole_faces: LocalControlVolumeFaceRows3D,
    local_faces: LocalControlVolumeFaceRows3D,
    *,
    global_shape: tuple[int, int, int],
    shard_index: tuple[int, int, int],
    shard_counts: tuple[int, int, int],
    boundary_source_lookup: dict[int, tuple[int, int]] | None,
) -> LocalMomentReconstruction3D:
    """Lower whole-domain reconstruction rows without refitting per shard."""

    target_mask = np.asarray(whole_reconstruction.target_row_for_cell, dtype=np.int32) >= 0
    owned_shape = tuple(int(value) for value in geometry.owned_shape)
    starts = tuple(int(shard_index[axis]) * owned_shape[axis] for axis in range(3))
    stop = tuple(starts[axis] + owned_shape[axis] for axis in range(3))
    local_target_mask = target_mask[
        starts[0] : stop[0], starts[1] : stop[1], starts[2] : stop[2]
    ]
    targets_global = np.argwhere(target_mask)
    local_targets_global = targets_global[
        np.all(
            (targets_global >= np.asarray(starts)[None, :])
            & (targets_global < np.asarray(stop)[None, :]),
            axis=1,
        )
    ]
    whole_row_for_cell = np.asarray(whole_reconstruction.target_row_for_cell, dtype=np.int32)
    whole_face_ids = np.asarray(whole_faces.global_face_id, dtype=np.int64)
    local_face_ids = np.asarray(local_faces.global_face_id, dtype=np.int64)
    local_face_active = np.asarray(local_faces.active, dtype=bool)
    local_face_rows = {
        int(face_id): int(row)
        for row, face_id in enumerate(local_face_ids)
        if local_face_active[row]
    }
    max_rows = len(local_targets_global)
    max_equations = int(whole_reconstruction.max_equations)
    target_i = np.zeros((max_rows,), dtype=np.int32)
    target_j = np.zeros((max_rows,), dtype=np.int32)
    target_k = np.zeros((max_rows,), dtype=np.int32)
    equation_kind = np.zeros((max_rows, max_equations), dtype=np.int32)
    sample_i = np.zeros_like(equation_kind)
    sample_j = np.zeros_like(equation_kind)
    sample_k = np.zeros_like(equation_kind)
    boundary_face_row = np.zeros_like(equation_kind)
    boundary_patch = np.zeros_like(equation_kind)
    boundary_quadrature = np.zeros_like(equation_kind)
    equation_active = np.zeros((max_rows, max_equations), dtype=bool)
    rhs_transform = np.zeros((max_rows, 19, max_equations), dtype=np.float64)
    active = np.zeros((max_rows,), dtype=bool)
    polynomial_order = np.zeros((max_rows,), dtype=np.int32)
    rank = np.zeros((max_rows,), dtype=np.int32)
    condition = np.full((max_rows,), np.inf, dtype=np.float64)
    target_row_for_cell = -np.ones(owned_shape, dtype=np.int32)
    periodic_axes = (False, True, True)

    whole_kind = np.asarray(whole_reconstruction.equation_kind, dtype=np.int32)
    whole_active = np.asarray(whole_reconstruction.equation_active, dtype=bool)
    whole_sample = np.stack(
        (
            np.asarray(whole_reconstruction.sample_i, dtype=np.int32),
            np.asarray(whole_reconstruction.sample_j, dtype=np.int32),
            np.asarray(whole_reconstruction.sample_k, dtype=np.int32),
        ),
        axis=-1,
    )
    whole_boundary_row = np.asarray(whole_reconstruction.boundary_face_row, dtype=np.int32)
    whole_boundary_patch = np.asarray(whole_reconstruction.boundary_patch, dtype=np.int32)
    whole_boundary_quad = np.asarray(whole_reconstruction.boundary_quadrature, dtype=np.int32)
    for local_row, target_global in enumerate(local_targets_global):
        target = tuple(int(value) for value in target_global)
        source_row = int(whole_row_for_cell[target])
        target_local = tuple(target[axis] - starts[axis] for axis in range(3))
        target_i[local_row], target_j[local_row], target_k[local_row] = target_local
        target_row_for_cell[target_local] = local_row
        active[local_row] = True
        polynomial_order[local_row] = int(np.asarray(whole_reconstruction.polynomial_order)[source_row])
        rank[local_row] = int(np.asarray(whole_reconstruction.rank)[source_row])
        condition[local_row] = float(np.asarray(whole_reconstruction.condition_number)[source_row])
        equation_active[local_row] = whole_active[source_row]
        rhs_transform[local_row] = np.asarray(whole_reconstruction.rhs_transform)[source_row]
        for equation in np.flatnonzero(whole_active[source_row]):
            kind = int(whole_kind[source_row, equation])
            equation_kind[local_row, equation] = kind
            if kind == CV_RECONSTRUCTION_EQUATION_CELL:
                sample_global = tuple(int(value) for value in whole_sample[source_row, equation])
                relative = [sample_global[axis] - starts[axis] for axis in range(3)]
                for axis in (1, 2):
                    candidates = (
                        relative[axis] - int(global_shape[axis]),
                        relative[axis],
                        relative[axis] + int(global_shape[axis]),
                    )
                    relative[axis] = min(
                        candidates,
                        key=lambda value: (
                            max(-value, value - owned_shape[axis] + 1, 0),
                            abs(value - 0.5 * (owned_shape[axis] - 1)),
                        ),
                    )
                if all(0 <= relative[axis] < owned_shape[axis] for axis in range(3)):
                    sample_i[local_row, equation], sample_j[local_row, equation], sample_k[local_row, equation] = relative
                else:
                    halo = [relative[axis] + int(geometry.layout.halo_width) for axis in range(3)]
                    if any(
                        not 0 <= halo[axis] < owned_shape[axis] + 2 * int(geometry.layout.halo_width)
                        for axis in range(3)
                    ):
                        raise ValueError(
                            "canonical reconstruction sample lies outside the populated local halo"
                        )
                    equation_kind[local_row, equation] = CV_RECONSTRUCTION_EQUATION_REMOTE_CELL
                    sample_i[local_row, equation], sample_j[local_row, equation], sample_k[local_row, equation] = halo
            elif kind == CV_RECONSTRUCTION_EQUATION_DIRICHLET:
                whole_face_row = int(whole_boundary_row[source_row, equation])
                face_id = int(whole_face_ids[whole_face_row])
                if boundary_source_lookup is None:
                    if face_id not in local_face_rows:
                        raise ValueError(
                            "canonical reconstruction boundary face is not "
                            "owned by the evaluator shard: "
                            f"face_id={face_id}"
                        )
                    expected_shard = (
                        int(shard_index[0])
                        + int(shard_counts[0]) * (
                            int(shard_index[1])
                            + int(shard_counts[1]) * int(shard_index[2])
                        )
                    )
                    source_shard, local_face_row = expected_shard, local_face_rows[face_id]
                elif face_id not in boundary_source_lookup:
                    raise ValueError(f"canonical reconstruction boundary face is unresolved: {face_id}")
                else:
                    source_shard, local_face_row = boundary_source_lookup[face_id]
                expected_shard = (
                    int(shard_index[0])
                    + int(shard_counts[0]) * (
                        int(shard_index[1]) + int(shard_counts[1]) * int(shard_index[2])
                    )
                )
                if int(source_shard) != expected_shard:
                    raise ValueError(
                        "canonical reconstruction boundary observation is not evaluator-local"
                    )
                boundary_face_row[local_row, equation] = int(local_face_row)
                boundary_patch[local_row, equation] = whole_boundary_patch[source_row, equation]
                boundary_quadrature[local_row, equation] = whole_boundary_quad[source_row, equation]
            elif kind == CV_RECONSTRUCTION_EQUATION_REMOTE_CELL:
                raise ValueError("whole-bundle reconstruction unexpectedly contains remote-cell rows")
    return LocalMomentReconstruction3D(
        layout=geometry.layout,
        target_i=jnp.asarray(target_i), target_j=jnp.asarray(target_j), target_k=jnp.asarray(target_k),
        equation_kind=jnp.asarray(equation_kind), sample_i=jnp.asarray(sample_i), sample_j=jnp.asarray(sample_j), sample_k=jnp.asarray(sample_k),
        boundary_face_row=jnp.asarray(boundary_face_row), boundary_patch=jnp.asarray(boundary_patch), boundary_quadrature=jnp.asarray(boundary_quadrature),
        equation_active=jnp.asarray(equation_active), rhs_transform=jnp.asarray(rhs_transform), active=jnp.asarray(active),
        target_row_for_cell=jnp.asarray(target_row_for_cell), polynomial_order=jnp.asarray(polynomial_order), rank=jnp.asarray(rank), condition_number=jnp.asarray(condition),
        max_rows=max_rows, max_equations=max_equations,
    )


def _sanitize_centroid_metric_points(
    centroid: np.ndarray | jnp.ndarray,
    active_owner: np.ndarray | jnp.ndarray,
) -> np.ndarray:
    """Provide finite in-domain coordinates for metric-masked storage slots."""
    points = np.asarray(centroid, dtype=np.float64)
    valid = np.asarray(active_owner, dtype=bool) & np.all(
        np.isfinite(points), axis=-1
    )
    reference = np.asarray(
        (0.5 * (float(shifted_mms.x_min) + float(shifted_mms.x_max)), 0.0, 0.0),
        dtype=np.float64,
    )
    return np.where(valid[..., None], points, reference)


def _build_closed_box_embedded_control_volume_geometry(
    geometry: LocalFciGeometry3D,
    *,
    enable_merging: bool,
    box_translation: tuple[float, float, float] = (0.0, 0.0, 0.0),
    reconstruction_boundary_weight_scale: float = 1.0,
    reconstruction_distance_row_weight_exponent: float = 0.0,
    face_functional_boundary_weight_scale: float = 1.0,
    face_functional_all_owner_boundary_observations: bool = False,
    face_functional_cell_radius: int = 2,
    boundary_source_lookup: dict[int, tuple[int, int]] | None = None,
    defer_unresolved_boundary_sources: bool = False,
    cells: LocalControlVolumeCellGeometry3D | None = None,
    remote_boundary_payloads: dict[
        tuple[int, int],
        tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    ]
    | None = None,
    canonical_reconstruction_source: tuple[
        LocalMomentReconstruction3D,
        LocalControlVolumeFaceRows3D,
        tuple[int, int, int],
        tuple[int, int, int],
        tuple[int, int, int],
    ]
    | None = None,
    local_periodic_axes: tuple[bool, bool, bool] = (False, True, True),
    global_topology: GlobalControlVolumeTopology3D | None = None,
    local_topology: LocalControlVolumeGeometry3D | None = None,
    canonical_compact_face_ids: set[int] | None = None,
    canonical_rows: tuple[dict[str, object], ...] | None = None,
    canonical_reconstruction_target_mask: np.ndarray | None = None,
    global_radial_size: int | None = None,
    global_face_functional_records: dict[int, dict[str, object]] | None = None,
    compiled_face_functional_records_out: (
        dict[int, dict[str, object]] | None
    ) = None,
) -> LocalEmbeddedControlVolumeGeometry3D:
    reconstruction_boundary_weight_scale = _validate_reconstruction_boundary_weight_scale(
        reconstruction_boundary_weight_scale
    )
    reconstruction_distance_row_weight_exponent = (
        _validate_reconstruction_distance_row_weight_exponent(
            reconstruction_distance_row_weight_exponent
        )
    )
    face_functional_boundary_weight_scale = _validate_face_functional_boundary_weight_scale(
        face_functional_boundary_weight_scale
    )
    face_functional_cell_radius = _validate_face_functional_cell_radius(
        face_functional_cell_radius
    )
    if cells is None:
        cells = _build_closed_box_control_volume_cells(
            geometry,
            enable_merging=enable_merging,
            box_translation=box_translation,
        )
    # First discover intrinsic embedded-boundary owners, then rebuild face
    # ownership so every face touching one of those owners is compact.
    _regular_faces, seed_irregular_faces = _build_closed_box_control_volume_faces(
        geometry,
        cells,
        remote_boundary_payloads=remote_boundary_payloads,
        global_topology=global_topology,
        local_topology=local_topology,
        canonical_compact_face_ids=canonical_compact_face_ids,
        canonical_rows=canonical_rows,
        box_translation=box_translation,
    )
    intrinsic_reconstruction_owner_mask = _intrinsic_reconstruction_owner_mask(
        cells,
        seed_irregular_faces,
    )
    reconstruction_owner_mask = _dilate_reconstruction_owner_mask(
        cells,
        intrinsic_reconstruction_owner_mask,
        periodic_axes=local_periodic_axes,
    )
    regular_faces, irregular_faces = _build_closed_box_control_volume_faces(
        geometry,
        cells,
        remote_boundary_payloads=remote_boundary_payloads,
        reconstruction_owner_mask=reconstruction_owner_mask,
        compact_owner_mask=intrinsic_reconstruction_owner_mask,
        global_topology=global_topology,
        local_topology=local_topology,
        canonical_compact_face_ids=canonical_compact_face_ids,
        canonical_rows=canonical_rows,
        box_translation=box_translation,
    )
    reconstruction_owner_mask = _dilate_reconstruction_owner_mask(
        cells,
        reconstruction_owner_mask
        | _compact_face_reconstruction_owner_mask(cells, irregular_faces),
        periodic_axes=local_periodic_axes,
    )
    if canonical_reconstruction_target_mask is not None:
        canonical_reconstruction_target_mask = np.asarray(
            canonical_reconstruction_target_mask,
            dtype=bool,
        )
        if canonical_reconstruction_target_mask.shape != cells.shape:
            raise ValueError(
                "canonical reconstruction target mask must match local cell shape"
            )
        reconstruction_owner_mask = (
            canonical_reconstruction_target_mask
            & np.asarray(cells.is_active_owner, dtype=bool)
        )
    distance_weight_target_mask = np.asarray(
        reconstruction_owner_mask,
        dtype=bool,
    ).copy()
    if global_radial_size is not None:
        global_radial_size = int(global_radial_size)
        if global_radial_size < 5:
            raise ValueError("global_radial_size must be at least five")
        global_radial_index = (
            int(geometry.grid.x.owned_start_global)
            + np.arange(cells.shape[0], dtype=np.int32)
        )
        radial_interior_two_plus = (
            (global_radial_index >= 2)
            & (global_radial_index < global_radial_size - 2)
        )
        distance_weight_target_mask &= radial_interior_two_plus[:, None, None]
    if canonical_reconstruction_source is None:
        spacing = jnp.stack(
            (
                geometry.spacing.dx_owned,
                geometry.spacing.dy_owned,
                geometry.spacing.dz_owned,
            ),
            axis=-1,
        )
        reconstruction = precompute_local_moment_reconstruction(
            cells,
            irregular_faces,
            spacing_owned=spacing,
            periodic_axes=local_periodic_axes,
            coordinate_periodic_axes=(False, True, True),
            coordinate_periods=(
                float(shifted_mms.x_max) - float(shifted_mms.x_min),
                2.0 * np.pi,
                2.0 * np.pi,
            ),
            target_mask=jnp.asarray(reconstruction_owner_mask),
            distance_weight_target_mask=jnp.asarray(
                distance_weight_target_mask
            ),
            max_samples=48,
            max_equations=64,
            boundary_weight_scale=reconstruction_boundary_weight_scale,
            distance_row_weight_exponent=(
                reconstruction_distance_row_weight_exponent
            ),
        )
    else:
        (
            whole_reconstruction,
            whole_faces,
            canonical_global_shape,
            canonical_shard_index,
            canonical_shard_counts,
        ) = canonical_reconstruction_source
        canonical_global_shape = tuple(int(value) for value in canonical_global_shape)
        canonical_shard_index = tuple(int(value) for value in canonical_shard_index)
        canonical_shard_counts = tuple(int(value) for value in canonical_shard_counts)
        reconstruction = _lower_canonical_reconstruction(
            geometry,
            whole_reconstruction,
            whole_faces,
            irregular_faces,
            global_shape=canonical_global_shape,
            shard_index=canonical_shard_index,
            shard_counts=canonical_shard_counts,
            boundary_source_lookup=None,
        )
    reconstruction_active = np.asarray(reconstruction.active, dtype=bool)
    reconstruction_order = np.asarray(
        reconstruction.polynomial_order,
        dtype=np.int32,
    )
    fallback_count = int(
        np.sum(reconstruction_active & (reconstruction_order < 3))
    )
    invalid_count = int(np.sum(~reconstruction_active))
    if fallback_count:
        raise ValueError(
            "shifted-torus control-volume fixture requires cubic "
            f"reconstruction on every active row; found {fallback_count} "
            "lower-order fallbacks"
        )
    if invalid_count:
        raise ValueError(
            "shifted-torus control-volume fixture produced "
            f"{invalid_count} invalid reconstruction rows"
        )
    centroid_points = _sanitize_centroid_metric_points(
        cells.centroid,
        cells.is_active_owner,
    )
    (
        centroid_J,
        _centroid_g_contra,
        centroid_g_cov,
        centroid_B_contra,
        centroid_Bmag,
        _centroid_projector,
    ) = _shifted_torus_metric_payload_numpy(centroid_points)
    centroid_curvature = np.asarray(
        _shifted_torus_curvature_at_logical_points(
            jnp.asarray(centroid_points, dtype=jnp.float64)
        ),
        dtype=np.float64,
    )
    compact_rows = np.flatnonzero(
        np.asarray(irregular_faces.active, dtype=bool)
    )
    target_row = np.asarray(
        reconstruction.target_row_for_cell,
        dtype=np.int32,
    )
    has_plus = np.asarray(irregular_faces.has_plus_owner, dtype=bool)
    for row in compact_rows:
        owners = [
            (
                int(np.asarray(irregular_faces.minus_owner_i)[row]),
                int(np.asarray(irregular_faces.minus_owner_j)[row]),
                int(np.asarray(irregular_faces.minus_owner_k)[row]),
            )
        ]
        if has_plus[row]:
            owners.append(
                (
                    int(np.asarray(irregular_faces.plus_owner_i)[row]),
                    int(np.asarray(irregular_faces.plus_owner_j)[row]),
                    int(np.asarray(irregular_faces.plus_owner_k)[row]),
                )
            )
        if any(target_row[owner] < 0 for owner in owners):
            raise ValueError(
                "each local compact-face owner must have a "
                "cubic reconstruction row"
            )
    if global_topology is None:
        functional_global_shape = tuple(int(value) for value in geometry.owned_shape)
        functional_shard_index = (0, 0, 0)
        functional_shard_counts = (1, 1, 1)
    else:
        functional_global_shape = tuple(int(value) for value in global_topology.shape)
        if local_topology is None:
            raise ValueError("global face functional lowering needs local topology")
        functional_shard_index = tuple(int(value) for value in local_topology.shard_index)
        functional_shard_counts = tuple(int(value) for value in local_topology.shard_counts)
    if global_face_functional_records is None:
        global_face_functional_records = _compile_global_cubic_face_functional_records(
            geometry,
            cells,
            irregular_faces,
            face_functional_boundary_weight_scale=face_functional_boundary_weight_scale,
            face_functional_all_owner_boundary_observations=(
                face_functional_all_owner_boundary_observations
            ),
            face_functional_cell_radius=face_functional_cell_radius,
        )
    if compiled_face_functional_records_out is not None:
        compiled_face_functional_records_out.update(
            global_face_functional_records
        )
    face_functionals = _lower_global_cubic_face_functionals(
        geometry,
        irregular_faces,
        global_face_functional_records,
        global_shape=functional_global_shape,
        shard_index=functional_shard_index,
        shard_counts=functional_shard_counts,
        boundary_source_lookup=boundary_source_lookup,
        defer_unresolved_boundary_sources=defer_unresolved_boundary_sources,
    )
    return LocalEmbeddedControlVolumeGeometry3D(
        cells=cells,
        regular_faces=regular_faces,
        irregular_faces=irregular_faces,
        reconstruction=reconstruction,
        face_functionals=face_functionals,
        centroid_J=jnp.asarray(centroid_J),
        centroid_g_cov=jnp.asarray(centroid_g_cov),
        centroid_B_contra=jnp.asarray(centroid_B_contra),
        centroid_Bmag=jnp.asarray(centroid_Bmag),
        centroid_curvature=jnp.asarray(centroid_curvature),
        regular_boundary_closure=(
            _build_shifted_torus_regular_boundary_closure(
                geometry,
                cells,
            )
        ),
    )



def _pad_control_volume_face_rows(
    rows: LocalControlVolumeFaceRows3D,
    max_rows: int,
) -> LocalControlVolumeFaceRows3D:
    max_rows = int(max_rows)
    pad = max_rows - int(rows.max_rows)
    if pad < 0:
        raise ValueError("max_rows must be at least rows.max_rows")
    if pad == 0:
        return rows

    def row_pad(value: jnp.ndarray, fill_value=0):
        widths = ((0, pad),) + tuple((0, 0) for _ in range(value.ndim - 1))
        return jnp.pad(value, widths, constant_values=fill_value)

    return LocalControlVolumeFaceRows3D(
        layout=rows.layout,
        kind=row_pad(rows.kind),
        minus_owner_i=row_pad(rows.minus_owner_i),
        minus_owner_j=row_pad(rows.minus_owner_j),
        minus_owner_k=row_pad(rows.minus_owner_k),
        plus_owner_i=row_pad(rows.plus_owner_i),
        plus_owner_j=row_pad(rows.plus_owner_j),
        plus_owner_k=row_pad(rows.plus_owner_k),
        has_plus_owner=row_pad(rows.has_plus_owner, False),
        quadrature_points=row_pad(rows.quadrature_points),
        area_covector_weight=row_pad(rows.area_covector_weight),
        J=row_pad(rows.J),
        g_contra=row_pad(rows.g_contra),
        g_cov=row_pad(rows.g_cov),
        B_contra=row_pad(rows.B_contra),
        Bmag=row_pad(rows.Bmag, 1.0),
        projector=row_pad(rows.projector),
        patch_active=row_pad(rows.patch_active, False),
        active=row_pad(rows.active, False),
        max_rows=max_rows,
        max_patches=rows.max_patches,
        has_remote_owner=row_pad(rows.has_remote_owner, False),
        remote_halo_i=row_pad(rows.remote_halo_i),
        remote_halo_j=row_pad(rows.remote_halo_j),
        remote_halo_k=row_pad(rows.remote_halo_k),
        remote_centroid=row_pad(rows.remote_centroid),
        remote_second_moment=row_pad(rows.remote_second_moment),
        remote_third_moment=row_pad(rows.remote_third_moment),
        global_face_id=row_pad(rows.global_face_id, -1),
        has_remote_residual=row_pad(rows.has_remote_residual, False),
        remote_residual_halo_i=row_pad(rows.remote_residual_halo_i),
        remote_residual_halo_j=row_pad(rows.remote_residual_halo_j),
        remote_residual_halo_k=row_pad(rows.remote_residual_halo_k),
    )


def _pad_quadratic_reconstruction(
    rows: LocalMomentReconstruction3D,
    max_rows: int,
) -> LocalMomentReconstruction3D:
    max_rows = int(max_rows)
    pad = max_rows - int(rows.max_rows)
    if pad < 0:
        raise ValueError("max_rows must be at least rows.max_rows")
    if pad == 0:
        return rows

    def row_pad(value: jnp.ndarray, fill_value=0):
        widths = ((0, pad),) + tuple((0, 0) for _ in range(value.ndim - 1))
        return jnp.pad(value, widths, constant_values=fill_value)

    return LocalMomentReconstruction3D(
        layout=rows.layout,
        target_i=row_pad(rows.target_i),
        target_j=row_pad(rows.target_j),
        target_k=row_pad(rows.target_k),
        equation_kind=row_pad(rows.equation_kind),
        sample_i=row_pad(rows.sample_i),
        sample_j=row_pad(rows.sample_j),
        sample_k=row_pad(rows.sample_k),
        boundary_face_row=row_pad(rows.boundary_face_row),
        boundary_patch=row_pad(rows.boundary_patch),
        boundary_quadrature=row_pad(rows.boundary_quadrature),
        equation_active=row_pad(rows.equation_active, False),
        rhs_transform=row_pad(rows.rhs_transform),
        active=row_pad(rows.active, False),
        target_row_for_cell=rows.target_row_for_cell,
        polynomial_order=row_pad(rows.polynomial_order),
        rank=row_pad(rows.rank),
        condition_number=row_pad(rows.condition_number, jnp.inf),
        max_rows=max_rows,
        max_equations=rows.max_equations,
    )


def _pad_face_functionals(
    rows: LocalMomentFittedFaceRows3D,
    *,
    max_rows: int,
    max_equations: int,
) -> LocalMomentFittedFaceRows3D:
    """Pad direct-functional rows with the same static shapes as face rows."""
    row_pad = int(max_rows) - int(rows.max_rows)
    equation_pad = int(max_equations) - int(rows.max_equations)
    if row_pad < 0 or equation_pad < 0:
        raise ValueError("functional padding may only increase static capacities")
    if row_pad == equation_pad == 0:
        return rows
    def pad(value, fill=0):
        widths = ((0, row_pad),) + ((0, equation_pad),) * (value.ndim > 1)
        return jnp.pad(value, widths, constant_values=fill)
    return LocalMomentFittedFaceRows3D(
        layout=rows.layout,
        functional_face_id=pad(rows.functional_face_id, -1),
        observation_kind=pad(rows.observation_kind),
        owned_i=pad(rows.owned_i), owned_j=pad(rows.owned_j), owned_k=pad(rows.owned_k),
        halo_i=pad(rows.halo_i), halo_j=pad(rows.halo_j), halo_k=pad(rows.halo_k),
        boundary_source_shard=pad(rows.boundary_source_shard),
        boundary_face_row=pad(rows.boundary_face_row), boundary_patch=pad(rows.boundary_patch), boundary_quadrature=pad(rows.boundary_quadrature),
        observation_active=pad(rows.observation_active, False),
        projected_flux_weights=pad(rows.projected_flux_weights), parallel_flux_weights=pad(rows.parallel_flux_weights), parallel_gradient_flux_weights=pad(rows.parallel_gradient_flux_weights),
        polynomial_order=pad(rows.polynomial_order), rank=pad(rows.rank),
        condition_number=pad(rows.condition_number, jnp.inf), reproduction_residual=pad(rows.reproduction_residual),
        normalized_projected_weight_norm=pad(rows.normalized_projected_weight_norm), normalized_parallel_weight_norm=pad(rows.normalized_parallel_weight_norm), normalized_parallel_gradient_weight_norm=pad(rows.normalized_parallel_gradient_weight_norm),
        active=pad(rows.active, False), max_rows=max_rows, max_equations=max_equations,
    )




def _pad_embedded_control_volume_geometry(
    control_volume_geometry: LocalEmbeddedControlVolumeGeometry3D,
    *,
    max_face_rows: int,
    max_reconstruction_rows: int,
    max_functional_equations: int,
) -> LocalEmbeddedControlVolumeGeometry3D:
    """Pad only live compact-face and reconstruction payloads for SPMD."""

    return LocalEmbeddedControlVolumeGeometry3D(
        cells=control_volume_geometry.cells,
        regular_faces=control_volume_geometry.regular_faces,
        irregular_faces=_pad_control_volume_face_rows(
            control_volume_geometry.irregular_faces,
            max_face_rows,
        ),
        reconstruction=_pad_quadratic_reconstruction(
            control_volume_geometry.reconstruction,
            max_reconstruction_rows,
        ),
        face_functionals=_pad_face_functionals(
            control_volume_geometry.face_functionals,
            max_rows=max_face_rows,
            max_equations=max_functional_equations,
        ),
        centroid_J=control_volume_geometry.centroid_J,
        centroid_g_cov=control_volume_geometry.centroid_g_cov,
        centroid_B_contra=control_volume_geometry.centroid_B_contra,
        centroid_Bmag=control_volume_geometry.centroid_Bmag,
        centroid_curvature=control_volume_geometry.centroid_curvature,
        regular_boundary_closure=control_volume_geometry.regular_boundary_closure,
    )


def _build_stacked_embedded_control_volume_geometry(
    *,
    global_shape: tuple[int, int, int],
    shard_counts: tuple[int, int, int],
    halo_width: int,
    enable_merging: bool,
    box_translation: tuple[float, float, float] = (0.0, 0.0, 0.0),
    reconstruction_boundary_weight_scale: float = 1.0,
    reconstruction_distance_row_weight_exponent: float = 0.0,
    face_functional_boundary_weight_scale: float = 1.0,
    face_functional_all_owner_boundary_observations: bool = False,
    face_functional_cell_radius: int = 2,
    geometry_cache_dir: str | Path | None = None,
) -> LocalEmbeddedControlVolumeGeometry3D:
    """Precompute compact geometry and reconstruction transforms on the host."""

    reconstruction_boundary_weight_scale = _validate_reconstruction_boundary_weight_scale(
        reconstruction_boundary_weight_scale
    )
    reconstruction_distance_row_weight_exponent = (
        _validate_reconstruction_distance_row_weight_exponent(
            reconstruction_distance_row_weight_exponent
        )
    )
    face_functional_boundary_weight_scale = _validate_face_functional_boundary_weight_scale(
        face_functional_boundary_weight_scale
    )
    face_functional_cell_radius = _validate_face_functional_cell_radius(
        face_functional_cell_radius
    )
    shard_counts = tuple(int(value) for value in shard_counts)
    if shard_counts != (1, 1, 1):
        required_halo_width = int(face_functional_cell_radius) + 1
        if int(halo_width) < required_halo_width:
            raise ValueError(
                "decomposed cubic face functionals require halo_width >= "
                "face_functional_cell_radius + 1; got "
                f"halo_width={int(halo_width)}, "
                f"face_functional_cell_radius={int(face_functional_cell_radius)}"
            )
    phase_start = time_module.perf_counter()
    previous_phase = phase_start

    def report_phase(name: str) -> None:
        nonlocal previous_phase
        now = time_module.perf_counter()
        print(
            "  geometry_phase "
            f"name={name!r} elapsed={now - previous_phase:.3f}s "
            f"total={now - phase_start:.3f}s",
            flush=True,
        )
        previous_phase = now

    owned_shape = tuple(
        int(size) // int(count)
        for size, count in zip(global_shape, shard_counts)
    )
    global_topology, global_raw = _build_global_closed_box_control_volume_topology(
        global_shape=global_shape,
        halo_width=halo_width,
        enable_merging=enable_merging,
        box_translation=box_translation,
    )
    report_phase("raw moments and global topology")
    # Define the compact partition and cubic face functionals once on the
    # unsplit global fixture. Local shards only lower stable references.
    global_geometry = build_shifted_torus_local_geometry(
        global_shape, halo_width, global_shape=global_shape, shard_index=(0, 0, 0),
        x_min=shifted_mms.x_min, x_max=shifted_mms.x_max, r0=shifted_mms.r0,
        alpha_value=shifted_mms.alpha_value, iota=shifted_mms.iota,
        c_phi=shifted_mms.c_phi, sigma=shifted_mms.sigma,
    )
    whole_topology = compile_local_control_volume_geometry(
        global_topology, shard_index=(0, 0, 0), shard_counts=(1, 1, 1),
        raw_volume=global_raw[0], raw_centroid=global_raw[1],
        raw_second_moment=global_raw[2], raw_third_moment=global_raw[3],
    )
    whole_cells = _lower_global_control_volume_cells(global_geometry, whole_topology)
    report_phase("unsplit geometry and cell lowering")
    global_face_functional_records: dict[int, dict[str, object]] = {}
    functional_cache_path: Path | None = None
    functional_cache_hit = False
    functional_cache_key: str | None = None
    if geometry_cache_dir is not None:
        functional_cache_key = _global_face_functional_cache_key(
            global_shape=global_shape,
            shard_counts=shard_counts,
            halo_width=halo_width,
            enable_merging=enable_merging,
            box_translation=box_translation,
            reconstruction_boundary_weight_scale=(
                reconstruction_boundary_weight_scale
            ),
            reconstruction_distance_row_weight_exponent=(
                reconstruction_distance_row_weight_exponent
            ),
            face_functional_boundary_weight_scale=(
                face_functional_boundary_weight_scale
            ),
            face_functional_all_owner_boundary_observations=(
                face_functional_all_owner_boundary_observations
            ),
            face_functional_cell_radius=face_functional_cell_radius,
        )
        functional_cache_path = (
            Path(geometry_cache_dir).expanduser()
            / f"global_face_functionals_{functional_cache_key}.npz"
        )
        if functional_cache_path.is_file():
            try:
                global_face_functional_records = (
                    _load_global_face_functional_records(
                        functional_cache_path,
                        cache_key=functional_cache_key,
                    )
                )
                functional_cache_hit = True
            except (OSError, KeyError, ValueError) as exc:
                print(
                    "  geometry_cache status='invalid' "
                    f"path={str(functional_cache_path)!r} reason={str(exc)!r}",
                    flush=True,
                )
                global_face_functional_records = {}
        print(
            "  geometry_cache "
            f"status={'hit' if functional_cache_hit else 'miss'!r} "
            f"path={str(functional_cache_path)!r}",
            flush=True,
        )
    whole_bundle = _build_closed_box_embedded_control_volume_geometry(
        global_geometry, enable_merging=enable_merging, cells=whole_cells,
        box_translation=box_translation,
        global_topology=global_topology, local_topology=whole_topology,
        global_radial_size=int(global_shape[0]),
        reconstruction_boundary_weight_scale=reconstruction_boundary_weight_scale,
        reconstruction_distance_row_weight_exponent=(
            reconstruction_distance_row_weight_exponent
        ),
        face_functional_boundary_weight_scale=face_functional_boundary_weight_scale,
        face_functional_all_owner_boundary_observations=(
            face_functional_all_owner_boundary_observations
        ),
        face_functional_cell_radius=face_functional_cell_radius,
        global_face_functional_records=(
            global_face_functional_records if functional_cache_hit else None
        ),
        compiled_face_functional_records_out=(
            None if functional_cache_hit else global_face_functional_records
        ),
    )
    if (
        functional_cache_path is not None
        and functional_cache_key is not None
        and not functional_cache_hit
    ):
        _save_global_face_functional_records(
            functional_cache_path,
            global_face_functional_records,
            cache_key=functional_cache_key,
        )
    report_phase("global faces, reconstruction, and direct functionals")
    if tuple(int(value) for value in shard_counts) == (1, 1, 1):
        stacked = stack_local_shard_pytree(
            (1, 1, 1),
            lambda _shard_index: whole_bundle,
        )
        report_phase("one-shard stack")
        return stacked

    whole_ids = np.asarray(whole_bundle.irregular_faces.global_face_id, dtype=np.int64)
    whole_active = np.asarray(whole_bundle.irregular_faces.active, dtype=bool)
    canonical_compact_face_ids = set(int(value) for value in whole_ids[whole_active])
    canonical_reconstruction_target_mask = (
        np.asarray(whole_bundle.reconstruction.target_row_for_cell, dtype=np.int32)
        >= 0
    )
    canonical_reconstruction_row_count = int(
        np.count_nonzero(canonical_reconstruction_target_mask)
    )
    whole_kinds = np.asarray(whole_bundle.irregular_faces.kind, dtype=np.int32)
    whole_minus = np.stack(
        (
            np.asarray(whole_bundle.irregular_faces.minus_owner_i, dtype=np.int32),
            np.asarray(whole_bundle.irregular_faces.minus_owner_j, dtype=np.int32),
            np.asarray(whole_bundle.irregular_faces.minus_owner_k, dtype=np.int32),
        ),
        axis=-1,
    )
    whole_patches = np.asarray(whole_bundle.irregular_faces.patch_active, dtype=bool)
    whole_points = np.asarray(whole_bundle.irregular_faces.quadrature_points, dtype=np.float64)
    whole_area = np.asarray(whole_bundle.irregular_faces.area_covector_weight, dtype=np.float64)
    whole_J = np.asarray(whole_bundle.irregular_faces.J, dtype=np.float64)
    whole_g_contra = np.asarray(whole_bundle.irregular_faces.g_contra, dtype=np.float64)
    whole_g_cov = np.asarray(whole_bundle.irregular_faces.g_cov, dtype=np.float64)
    whole_B_contra = np.asarray(whole_bundle.irregular_faces.B_contra, dtype=np.float64)
    whole_Bmag = np.asarray(whole_bundle.irregular_faces.Bmag, dtype=np.float64)
    whole_projector = np.asarray(whole_bundle.irregular_faces.projector, dtype=np.float64)
    canonical_rows_by_shard: dict[
        tuple[int, int, int], list[dict[str, object]]
    ] = {}
    whole_has_plus = np.asarray(whole_bundle.irregular_faces.has_plus_owner, dtype=bool)
    whole_plus = np.stack(
        (
            np.asarray(whole_bundle.irregular_faces.plus_owner_i, dtype=np.int32),
            np.asarray(whole_bundle.irregular_faces.plus_owner_j, dtype=np.int32),
            np.asarray(whole_bundle.irregular_faces.plus_owner_k, dtype=np.int32),
        ),
        axis=-1,
    )
    whole_cells = whole_bundle.cells
    whole_centroid = np.asarray(whole_cells.centroid, dtype=np.float64)
    whole_second = np.asarray(whole_cells.second_moment, dtype=np.float64)
    whole_third = np.asarray(whole_cells.third_moment, dtype=np.float64)
    for row in np.flatnonzero(whole_active):
        owner = tuple(int(value) for value in whole_minus[row])
        if any(
            owner[axis] < 0 or owner[axis] >= int(global_shape[axis])
            for axis in range(3)
        ):
            raise ValueError("canonical compact face has no valid minus owner")
        shard_index = tuple(
            min(int(owner[axis]) // int(owned_shape[axis]), int(shard_counts[axis]) - 1)
            for axis in range(3)
        )
        shard_start = tuple(
            int(shard_index[axis]) * int(owned_shape[axis]) for axis in range(3)
        )
        local_owner = tuple(int(owner[axis] - shard_start[axis]) for axis in range(3))
        plus = None
        remote_halo = None
        remote_centroid = None
        remote_second_moment = None
        remote_third_moment = None
        remote_residual_halo = None
        if whole_has_plus[row]:
            plus_global = tuple(int(value) for value in whole_plus[row])
            plus_shard = tuple(
                min(int(plus_global[axis]) // int(owned_shape[axis]), int(shard_counts[axis]) - 1)
                for axis in range(3)
            )
            plus_start = tuple(
                int(plus_shard[axis]) * int(owned_shape[axis]) for axis in range(3)
            )
            plus_local = tuple(
                int(plus_global[axis] - plus_start[axis]) for axis in range(3)
            )
            if plus_shard == shard_index:
                plus = plus_local
            else:
                remote_halo = tuple(
                    int(value)
                    for value in remote_owner_halo_coordinate(
                        owner_local=np.asarray(plus_local, dtype=np.int32),
                        owner_shard=np.asarray(plus_shard, dtype=np.int32),
                        local_shard=np.asarray(shard_index, dtype=np.int32),
                        owned_shape=owned_shape,
                        halo_width=int(halo_width),
                        shard_counts=shard_counts,
                        periodic_axes=(False, True, True),
                    )
                )
                remote_centroid = _nearest_periodic_image(
                    whole_centroid[plus_global],
                    whole_centroid[owner],
                )
                remote_second_moment = whole_second[plus_global]
                remote_third_moment = whole_third[plus_global]
                remote_residual_halo = remote_halo
        patches = []
        for patch in range(int(whole_patches.shape[1])):
            if not np.any(whole_patches[row, patch]):
                continue
            patches.append(
                (
                    whole_points[row, patch],
                    whole_area[row, patch],
                    (
                        whole_J[row, patch],
                        whole_g_contra[row, patch],
                        whole_g_cov[row, patch],
                        whole_B_contra[row, patch],
                        whole_Bmag[row, patch],
                        whole_projector[row, patch],
                    ),
                )
            )
        canonical_rows_by_shard.setdefault(shard_index, []).append(
            {
                "kind": int(whole_kinds[row]),
                "minus": local_owner,
                "plus": plus,
                "remote_halo": remote_halo,
                "remote_centroid": remote_centroid,
                "remote_second_moment": remote_second_moment,
                "remote_third_moment": remote_third_moment,
                "remote_residual_halo": remote_residual_halo,
                "global_face_id": int(whole_ids[row]),
                "patches": patches,
            }
        )
    local_geometry_and_cells: dict[
        tuple[int, int, int],
        tuple[LocalFciGeometry3D, LocalControlVolumeCellGeometry3D, LocalControlVolumeGeometry3D | None],
    ] = {}
    for shard_i in range(int(shard_counts[0])):
        for shard_j in range(int(shard_counts[1])):
            for shard_k in range(int(shard_counts[2])):
                shard_index = (shard_i, shard_j, shard_k)
                local_geometry = build_shifted_torus_local_geometry(
                    owned_shape,
                    halo_width,
                    global_shape=global_shape,
                    shard_index=shard_index,
                    x_min=shifted_mms.x_min,
                    x_max=shifted_mms.x_max,
                    r0=shifted_mms.r0,
                    alpha_value=shifted_mms.alpha_value,
                    iota=shifted_mms.iota,
                    c_phi=shifted_mms.c_phi,
                    sigma=shifted_mms.sigma,
                )
                local_topology = compile_local_control_volume_geometry(global_topology, shard_index=shard_index, shard_counts=shard_counts, raw_volume=global_raw[0], raw_centroid=global_raw[1], raw_second_moment=global_raw[2], raw_third_moment=global_raw[3])
                cells = _lower_global_control_volume_cells(local_geometry, local_topology)
                local_geometry_and_cells[shard_index] = (local_geometry, cells, local_topology)
    report_phase("local geometry and cell lowering")

    periodic_axes = (False, True, True)

    def neighbor_index(
        shard_index: tuple[int, int, int],
        axis: int,
        side: int,
    ) -> tuple[int, int, int] | None:
        index = list(shard_index)
        offset = -1 if side == 0 else 1
        candidate = index[axis] + offset
        if 0 <= candidate < int(shard_counts[axis]):
            index[axis] = candidate
            return tuple(index)
        if periodic_axes[axis] and int(shard_counts[axis]) > 1:
            index[axis] = candidate % int(shard_counts[axis])
            return tuple(index)
        return None

    local_bundles: dict[tuple[int, int, int], LocalEmbeddedControlVolumeGeometry3D] = {}
    payload_total = 0.0
    bundle_total = 0.0
    for shard_index, (local_geometry, cells, local_topology) in local_geometry_and_cells.items():
        shard_payload_start = time_module.perf_counter()
        local_touched_storage = _closed_box_irregular_storage_mask(
            local_geometry,
            cells,
            box_translation=box_translation,
        )
        remote_boundary_payloads: dict[
            tuple[int, int],
            tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray],
        ] = {}

        for axis in range(3):
            for side in (0, 1):
                remote_index = neighbor_index(shard_index, axis, side)
                if remote_index is None:
                    continue
                remote_geometry, remote_cells, _remote_topology = local_geometry_and_cells[remote_index]
                remote_raw_volume = np.asarray(
                    remote_cells.raw_volume,
                    dtype=np.float64,
                )
                remote_touched_storage = _closed_box_irregular_storage_mask(
                    remote_geometry,
                    remote_cells,
                    box_translation=box_translation,
                )
                remote_owner_index = (
                    np.asarray(remote_cells.owner_i, dtype=np.int32),
                    np.asarray(remote_cells.owner_j, dtype=np.int32),
                    np.asarray(remote_cells.owner_k, dtype=np.int32),
                )
                remote_storage_centroid = np.asarray(
                    remote_cells.centroid,
                    dtype=np.float64,
                )[remote_owner_index]
                remote_storage_second_moment = np.asarray(
                    remote_cells.second_moment,
                    dtype=np.float64,
                )[remote_owner_index]
                remote_storage_third_moment = np.asarray(
                    remote_cells.third_moment,
                    dtype=np.float64,
                )[remote_owner_index]
                wraps_periodic_boundary = periodic_axes[axis] and (
                    (side == 0 and shard_index[axis] == 0)
                    or (
                        side == 1
                        and shard_index[axis] == int(shard_counts[axis]) - 1
                    )
                )
                if wraps_periodic_boundary:
                    period = 2.0 * np.pi
                    remote_storage_centroid = remote_storage_centroid.copy()
                    remote_storage_centroid[..., axis] += (
                        -period if side == 0 else period
                    )
                remote_boundary_index = (
                    remote_cells.shape[axis] - 1 if side == 0 else 0
                )
                remote_boundary_payloads[(axis, side)] = (
                    np.take(
                        remote_touched_storage,
                        remote_boundary_index,
                        axis=axis,
                    ),
                    np.take(
                        remote_raw_volume > 1.0e-20,
                        remote_boundary_index,
                        axis=axis,
                    ),
                    np.take(
                        remote_storage_centroid,
                        remote_boundary_index,
                        axis=axis,
                    ),
                    np.take(
                        remote_storage_second_moment,
                        remote_boundary_index,
                        axis=axis,
                    ),
                    np.take(
                        remote_storage_third_moment,
                        remote_boundary_index,
                        axis=axis,
                    ),
                )
        payload_elapsed = time_module.perf_counter() - shard_payload_start
        payload_total += payload_elapsed
        shard_bundle_start = time_module.perf_counter()
        local_bundles[shard_index] = (
            _build_closed_box_embedded_control_volume_geometry(
                local_geometry,
                enable_merging=enable_merging,
                cells=cells,
                box_translation=box_translation,
                remote_boundary_payloads=remote_boundary_payloads,
                canonical_reconstruction_source=(
                    whole_bundle.reconstruction,
                    whole_bundle.irregular_faces,
                    tuple(int(value) for value in global_shape),
                    tuple(int(value) for value in shard_index),
                    tuple(int(value) for value in shard_counts),
                ),
                local_periodic_axes=tuple(
                    periodic_axes[axis] and int(shard_counts[axis]) == 1
                    for axis in range(3)
                ),
                global_topology=global_topology,
                local_topology=local_topology,
                canonical_compact_face_ids=canonical_compact_face_ids,
                canonical_rows=tuple(
                    canonical_rows_by_shard.get(shard_index, ())
                ),
                canonical_reconstruction_target_mask=canonical_reconstruction_target_mask[
                    int(shard_index[0]) * int(owned_shape[0]) :
                    (int(shard_index[0]) + 1) * int(owned_shape[0]),
                    int(shard_index[1]) * int(owned_shape[1]) :
                    (int(shard_index[1]) + 1) * int(owned_shape[1]),
                    int(shard_index[2]) * int(owned_shape[2]) :
                    (int(shard_index[2]) + 1) * int(owned_shape[2]),
                ],
                global_radial_size=int(global_shape[0]),
                global_face_functional_records=global_face_functional_records,
                reconstruction_boundary_weight_scale=reconstruction_boundary_weight_scale,
                reconstruction_distance_row_weight_exponent=(
                    reconstruction_distance_row_weight_exponent
                ),
                face_functional_boundary_weight_scale=face_functional_boundary_weight_scale,
                face_functional_all_owner_boundary_observations=(
                    face_functional_all_owner_boundary_observations
                ),
                face_functional_cell_radius=face_functional_cell_radius,
                # Boundary observations may belong to a different evaluator
                # shard.  The first pass only constructs the local geometry;
                # the final source/row mapping is installed below.
                defer_unresolved_boundary_sources=True,
            )
        )
        bundle_elapsed = time_module.perf_counter() - shard_bundle_start
        bundle_total += bundle_elapsed
        print(
            "  geometry_subphase "
            f"name='local bundle shard' shard={shard_index} "
            f"payload={payload_elapsed:.3f}s bundle={bundle_elapsed:.3f}s",
            flush=True,
        )
    print(
        "  geometry_subphase "
        f"name='local bundle lowering totals' payload={payload_total:.3f}s "
        f"bundle={bundle_total:.3f}s",
        flush=True,
    )
    report_phase("local bundle lowering")
    decomposed_reconstruction_row_count = sum(
        int(np.count_nonzero(np.asarray(bundle.reconstruction.active, dtype=bool)))
        for bundle in local_bundles.values()
    )
    if decomposed_reconstruction_row_count != canonical_reconstruction_row_count:
        raise ValueError(
            "decomposed reconstruction target partition differs from canonical "
            f"whole bundle: canonical={canonical_reconstruction_row_count}, "
            f"decomposed={decomposed_reconstruction_row_count}"
        )
    max_face_rows = max(
        (
            int(bundle.irregular_faces.max_rows)
            for bundle in local_bundles.values()
        ),
        default=0,
    )
    max_reconstruction_rows = max(
        (
            int(bundle.reconstruction.max_rows)
            for bundle in local_bundles.values()
        ),
        default=0,
    )
    max_functional_equations = max(
        (int(bundle.face_functionals.max_equations) for bundle in local_bundles.values()),
        default=1,
    )

    # Every physical boundary face has one source shard and one local row.
    # The flattened source index is deliberately x-fastest so it agrees with
    # the runtime all-gather layout: sx + nx * (sy + ny * sz).
    boundary_source_lookup: dict[int, tuple[int, int]] = {}
    for shard_index in local_bundles:
        sx, sy, sz = (int(value) for value in shard_index)
        nx, ny, _nz = (int(value) for value in shard_counts)
        source_shard = sx + nx * (sy + ny * sz)
        rows = local_bundles[shard_index].irregular_faces
        row_ids = np.asarray(rows.global_face_id, dtype=np.int64)
        row_active = np.asarray(rows.active, dtype=bool)
        for local_row in np.flatnonzero(row_active):
            face_id = int(row_ids[local_row])
            if face_id == -1:
                continue
            previous = boundary_source_lookup.get(face_id)
            candidate = (source_shard, int(local_row))
            if previous is not None and previous != candidate:
                raise ValueError(
                    "global boundary face ID has conflicting source rows: "
                    f"face_id={face_id}, previous={previous}, candidate={candidate}"
                )
            boundary_source_lookup[face_id] = candidate

    for face_id, (source_shard, source_row) in boundary_source_lookup.items():
        if not 0 <= int(source_shard) < int(np.prod(shard_counts)):
            raise ValueError(f"boundary source shard is out of range for face {face_id}")
        source_index = int(source_shard)
        sx = source_index % int(shard_counts[0])
        sy = (source_index // int(shard_counts[0])) % int(shard_counts[1])
        sz = source_index // (int(shard_counts[0]) * int(shard_counts[1]))
        source_bundle = local_bundles[(sx, sy, sz)]
        source_ids = np.asarray(source_bundle.irregular_faces.global_face_id, dtype=np.int64)
        source_active = np.asarray(source_bundle.irregular_faces.active, dtype=bool)
        if not 0 <= int(source_row) < len(source_ids) or not source_active[int(source_row)]:
            raise ValueError(f"boundary source row is inactive for face {face_id}")
        if int(source_ids[int(source_row)]) != int(face_id):
            raise ValueError(f"boundary source row ID mismatch for face {face_id}")

    local_face_id_occurrences: list[int] = []
    for bundle in local_bundles.values():
        ids = np.asarray(bundle.irregular_faces.global_face_id, dtype=np.int64)
        active = np.asarray(bundle.irregular_faces.active, dtype=bool)
        local_face_id_occurrences.extend(int(value) for value in ids[active])
    if len(local_face_id_occurrences) != len(set(local_face_id_occurrences)):
        raise ValueError("decomposed compact face IDs are duplicated across shards")
    if set(local_face_id_occurrences) != canonical_compact_face_ids:
        missing = sorted(canonical_compact_face_ids - set(local_face_id_occurrences))
        extra = sorted(set(local_face_id_occurrences) - canonical_compact_face_ids)
        raise ValueError(
            "decomposed compact-face partition differs from canonical whole bundle: "
            f"missing={missing[:4]}, extra={extra[:4]}"
        )

    unresolved_boundary_ids: set[int] = set()
    relowered_bundles: dict[tuple[int, int, int], LocalEmbeddedControlVolumeGeometry3D] = {}
    for shard_index, bundle in local_bundles.items():
        local_geometry, _cells, local_topology = local_geometry_and_cells[shard_index]
        relowered = _lower_global_cubic_face_functionals(
            local_geometry,
            bundle.irregular_faces,
            global_face_functional_records,
            global_shape=tuple(int(value) for value in global_shape),
            shard_index=shard_index,
            shard_counts=shard_counts,
            boundary_source_lookup=boundary_source_lookup,
        )
        # Audit all active Dirichlet references after final lowering.  This
        # catches stale placeholders before any JAX stack or runtime gather.
        metadata_rows = np.asarray(relowered.observation_kind, dtype=np.int32)
        active_obs = np.asarray(relowered.observation_active, dtype=bool)
        source = np.asarray(relowered.boundary_source_shard, dtype=np.int32)
        invalid = (
            (metadata_rows == CV_RECONSTRUCTION_EQUATION_DIRICHLET)
            & active_obs
            & ((source < 0) | (source >= int(np.prod(shard_counts))))
        )
        if np.any(invalid):
            unresolved_boundary_ids.add(-1)
        relowered_bundles[shard_index] = dataclass_replace(
            bundle,
            face_functionals=relowered,
        )
    if unresolved_boundary_ids:
        raise ValueError("active boundary observations have unresolved source shards")
    local_bundles = relowered_bundles
    padded = iter(
        _pad_embedded_control_volume_geometry(
            bundle,
            max_face_rows=max_face_rows,
            max_reconstruction_rows=max_reconstruction_rows,
            max_functional_equations=max_functional_equations,
        )
        for bundle in local_bundles.values()
    )

    def builder(_shard_index):
        return next(padded)

    stacked = stack_local_shard_pytree(shard_counts, builder)
    report_phase("padding and stacking")
    return stacked


def _with_embedded_control_volume_geometry(
    geometry: LocalFciGeometry3D,
    control_volume_geometry: LocalEmbeddedControlVolumeGeometry3D,
) -> LocalFciGeometry3D:
    """Align legacy geometry masks/measures with the authoritative CV cells."""

    cells = control_volume_geometry.cells
    logical_volume = (
        jnp.asarray(geometry.spacing.dx_owned, dtype=jnp.float64)
        * jnp.asarray(geometry.spacing.dy_owned, dtype=jnp.float64)
        * jnp.asarray(geometry.spacing.dz_owned, dtype=jnp.float64)
    )
    base_J = jnp.maximum(
        jnp.asarray(geometry.cell_volume_geometry.volume, dtype=jnp.float64),
        1.0e-30,
    )
    volume_fraction = cells.aggregate_volume / jnp.maximum(
        base_J * logical_volume,
        1.0e-30,
    )
    return dataclass_replace(
        geometry,
        active_cell_mask=cells.is_active_owner,
        cell_volume_geometry=LocalCellVolumeGeometry3D(
            layout=geometry.layout,
            volume=geometry.cell_volume_geometry.volume,
            volume_fraction=volume_fraction,
        ),
    )
def _shifted_torus_metric_payload_jax(
    points: jnp.ndarray,
) -> tuple[
    jnp.ndarray,
    jnp.ndarray,
    jnp.ndarray,
    jnp.ndarray,
    jnp.ndarray,
    jnp.ndarray,
]:
    points = jnp.asarray(points, dtype=jnp.float64)
    x = points[..., 0]
    theta = points[..., 1]
    x_mid = 0.5 * (float(shifted_mms.x_min) + float(shifted_mms.x_max))
    theta_shift = theta + float(shifted_mms.sigma) * (x - x_mid)
    cos_theta = jnp.cos(theta_shift)
    sin_theta = jnp.sin(theta_shift)
    alpha = float(shifted_mms.alpha_value)
    radius = float(shifted_mms.r0) + alpha * x + x * cos_theta
    q_value = 1.0 + alpha * cos_theta
    J = radius * x * q_value
    zeros = jnp.zeros_like(J)
    g_contra = jnp.stack(
        (
            jnp.stack(
                (
                    1.0 / q_value**2,
                    alpha * sin_theta / (x * q_value**2),
                    zeros,
                ),
                axis=-1,
            ),
            jnp.stack(
                (
                    alpha * sin_theta / (x * q_value**2),
                    (1.0 + 2.0 * alpha * cos_theta + alpha**2)
                    / (x**2 * q_value**2),
                    zeros,
                ),
                axis=-1,
            ),
            jnp.stack((zeros, zeros, 1.0 / radius**2), axis=-1),
        ),
        axis=-2,
    )
    g_cov = jnp.stack(
        (
            jnp.stack(
                (
                    1.0 + 2.0 * alpha * cos_theta + alpha**2,
                    -alpha * x * sin_theta,
                    zeros,
                ),
                axis=-1,
            ),
            jnp.stack((-alpha * x * sin_theta, x**2, zeros), axis=-1),
            jnp.stack((zeros, zeros, radius**2), axis=-1),
        ),
        axis=-2,
    )
    B_contra = jnp.stack(
        (
            zeros,
            float(shifted_mms.iota) * float(shifted_mms.c_phi) / J,
            float(shifted_mms.c_phi) / J,
        ),
        axis=-1,
    )
    Bmag = jnp.sqrt(
        jnp.einsum("...i,...ij,...j->...", B_contra, g_cov, B_contra)
    )
    unit_b = B_contra / jnp.maximum(Bmag[..., None], 1.0e-30)
    projector = g_contra - unit_b[..., :, None] * unit_b[..., None, :]
    return J, g_contra, g_cov, B_contra, Bmag, projector


def _shifted_torus_curvature_at_logical_points(
    points: jnp.ndarray,
) -> jnp.ndarray:
    """Evaluate the continuum curvature coefficients at arbitrary points."""

    points = jnp.asarray(points, dtype=jnp.float64)
    x = points[..., 0]
    theta = points[..., 1]

    def covariant_field(
        radial: jnp.ndarray,
        poloidal: jnp.ndarray,
    ) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray, jnp.ndarray, jnp.ndarray]:
        sample = jnp.stack(
            (radial, poloidal, jnp.zeros_like(radial)),
            axis=-1,
        )
        J, _g_contra, g_cov, B_contra, Bmag, _projector = (
            _shifted_torus_metric_payload_jax(sample)
        )
        covariant = jnp.einsum(
            "...ij,...j->...i",
            g_cov,
            B_contra,
        ) / jnp.maximum(Bmag[..., None] ** 2, 1.0e-30)
        return (
            covariant[..., 0],
            covariant[..., 1],
            covariant[..., 2],
            J,
            Bmag,
        )

    ones_x = jnp.ones_like(x)
    ones_theta = jnp.ones_like(theta)

    def component(component: int, radial, poloidal):
        return covariant_field(radial, poloidal)[component]

    _, dA_zeta_dtheta = jax.jvp(
        lambda poloidal: component(2, x, poloidal),
        (theta,),
        (ones_theta,),
    )
    _, dA_zeta_dx = jax.jvp(
        lambda radial: component(2, radial, theta),
        (x,),
        (ones_x,),
    )
    _, dA_theta_dx = jax.jvp(
        lambda radial: component(1, radial, theta),
        (x,),
        (ones_x,),
    )
    _, dA_x_dtheta = jax.jvp(
        lambda poloidal: component(0, x, poloidal),
        (theta,),
        (ones_theta,),
    )
    _A_x, _A_theta, _A_zeta, J, Bmag = covariant_field(x, theta)
    curl = jnp.stack(
        (
            dA_zeta_dtheta,
            -dA_zeta_dx,
            dA_theta_dx - dA_x_dtheta,
        ),
        axis=-1,
    )
    return (
        Bmag[..., None]
        * curl
        / jnp.maximum(2.0 * J[..., None], 1.0e-30)
    )
