# Equation To Code Map

This page maps the main model terms in the documentation to the modules that
implement and test them. It is intended as a developer and reviewer index: use
[physics_models.md](physics_models.md) for the derivation-level description,
[code_structure.md](code_structure.md) for package organization, and the pages
listed here for validation artifacts.

## Core Drift-Reduced Operators

| Model term | Implementation | Validation or tests |
| --- | --- | --- |
| Parallel gradient, divergence, and structured metric factors | [`native/mesh.py`](../src/drbx/native/mesh.py), [`native/metrics.py`](../src/drbx/native/metrics.py) | [`tests/test_native_mesh.py`](../tests/test_native_mesh.py), [`tests/test_native_metrics.py`](../tests/test_native_metrics.py) |
| Density, pressure, and vorticity transport on compact native decks | [`native/fluid_1d.py`](../src/drbx/native/fluid_1d.py), [`native/transport.py`](../src/drbx/native/transport.py), [`native/vorticity.py`](../src/drbx/native/vorticity.py) | [Fluid 1D MMS Convergence](fluid_1d_mms_convergence.md), [`tests/test_native_fluid_1d.py`](../tests/test_native_fluid_1d.py), [`tests/test_native_transport.py`](../tests/test_native_transport.py), [`tests/test_native_vorticity.py`](../tests/test_native_vorticity.py) |
| Elliptic potential/vorticity solve, including local FCI polarization inversion | [`solvax.elliptic`](https://github.com/uwplasma/SOLVAX) (Fourier--Helmholtz operator), [`native/vorticity.py`](../src/drbx/native/vorticity.py), local FCI solver modules | [`tests/test_native_vorticity.py`](../tests/test_native_vorticity.py), [Stellarator FCI Validation](stellarator_fci_validation.md) |

## Non-Axisymmetric And 3D Geometry

| Model term | Implementation | Validation or tests |
| --- | --- | --- |
| Field-line-following interpolation, metric-weighted operators, and 3D selected-field surfaces | [`geometry/fci_geometry.py`](../src/drbx/geometry/fci_geometry.py), local FCI operator modules, and `jax.shard_map` drivers | [Stellarator FCI Validation](stellarator_fci_validation.md) |
| FCI sheath/recycling and local closure gates | [`native/fci_sheath_recycling.py`](../src/drbx/native/fci_sheath_recycling.py), local RHS/solver modules | [Stellarator FCI Validation](stellarator_fci_validation.md) |
| Imported field-line and surface geometry adapters | [`geometry/essos_import.py`](../src/drbx/geometry/essos_import.py), [`geometry/vmec_extender_import.py`](../src/drbx/geometry/vmec_extender_import.py), [`validation/vmec_extender_edge_field_campaign.py`](../src/drbx/validation/vmec_extender_edge_field_campaign.py) | [ESSOS Field-Line Import](essos_fieldline_import.md), [VMEC Extender Edge Fields](vmec_extender_edge_fields.md) |
| 3D profile analysis and validation-gallery plots | [`validation/publication_plotting.py`](../src/drbx/validation/publication_plotting.py) | [Validation Gallery](validation_gallery.md) |

## Runtime, I/O, And Artifacts

| Surface | Implementation | Validation or tests |
| --- | --- | --- |
| TOML/input parsing, precision defaults, output manifests, restart metadata, and live progress estimates | [`config`](../src/drbx/config), [`runtime`](../src/drbx/runtime), [`native/deck_runner.py`](../src/drbx/native/deck_runner.py) | [Inputs And Outputs](input_output_reference.md), [Native Runtime CLI](native_runtime_cli.md), [Restartable Diffusion Tutorial](restartable_diffusion_tutorial.md), [`tests/test_cli_run.py`](../tests/test_cli_run.py), [`tests/test_restartable_diffusion_tutorial.py`](../tests/test_restartable_diffusion_tutorial.py) |
| Portable run summaries and array payloads | [`native/deck_runner.py`](../src/drbx/native/deck_runner.py) | [Native Runtime CLI](native_runtime_cli.md), [`tests/test_cli_run.py`](../tests/test_cli_run.py) |
| Self-contained examples, release-backed media, and artifact restoration | [`examples`](../examples), [`scripts/fetch_example_artifacts.py`](../scripts/fetch_example_artifacts.py) | [Examples And Artifacts](examples.md), [`tests/docs/examples/test_self_contained_example_smoke.py`](../tests/docs/examples/test_self_contained_example_smoke.py) |

## Current Gaps

The most important open implementation gaps remain deliberately separated from
the validated equations above:

- Multi-device GPU speedup is not a release claim until the device-level
  identity check, the real-kernel agreement gate, and a committed timing summary
  all pass.
