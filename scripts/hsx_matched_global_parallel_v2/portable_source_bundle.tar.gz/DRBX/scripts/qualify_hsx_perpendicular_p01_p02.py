#!/usr/bin/env python3
"""Bounded actual-HSX qualification for the P01/P02 perpendicular audit.

Each ``case`` reads one immutable 32/48/64 producer artifact and the fixed
64^3 continuum geometry reference.  High-order quadrature is restricted to a
small, stratified set of real owner cells; full-domain measurements use only
the producer moments and the compiled production prolongation.  ``campaign``
launches one process per resolution so geometry/JAX allocations cannot
accumulate across the refinement sequence.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
from typing import Any, Mapping, Sequence

import jax
import jax.numpy as jnp
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import simulate_hsx_mms as mms  # noqa: E402
from hsx_mms_continuum_reference import (  # noqa: E402
    build_continuum_reference_from_artifact,
)
from drbx.geometry import load_fci_simulation_geometry  # noqa: E402
from drbx.native.fci_rlp_diffusion import (  # noqa: E402
    apply_rlp_cell_average_prolongation,
    compile_rlp_cell_average_prolongation,
)
from drbx.validation.perpendicular_reference import (  # noqa: E402
    manufactured_field_catalogue,
    physical_owner_moment_reference,
    validate_region_masks,
)


SCHEMA = "drbx.actual-hsx-perpendicular-p01-p02-v1"
POLYNOMIAL_FIELDS = (
    "one", "x", "y", "x2", "xy", "y2", "x3", "x2y", "xy2", "y3"
)


def _json_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_value(item) for item in value]
    if isinstance(value, np.ndarray):
        return _json_value(value.tolist())
    if isinstance(value, (np.floating, float)):
        number = float(value)
        return number if np.isfinite(number) else None
    if isinstance(value, (np.integer, int)):
        return int(value)
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    return value


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(_json_value(payload), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _artifact_directory(root: Path, resolution: int) -> Path:
    size = f"{resolution}x{resolution}x{resolution}"
    for candidate in (root / size, root / f"hsx_fci_{size}"):
        if (candidate / "manifest.json").is_file():
            return candidate
    raise FileNotFoundError(f"no immutable {size} geometry artifact under {root}")


def _load(root: Path, resolution: int):
    path = _artifact_directory(root, resolution)
    artifact = load_fci_simulation_geometry(path)
    if tuple(artifact.global_geometry.shape) != (resolution,) * 3:
        raise ValueError(f"artifact shape mismatch for {path}")
    if artifact.owner_geometry is None:
        raise ValueError(f"artifact lacks producer-owned RLP geometry: {path}")
    return path, artifact


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _region_masks(geometry: Any, host: Any) -> dict[str, np.ndarray]:
    selected_wall = np.asarray(geometry.maps.forward_boundary) | np.asarray(
        geometry.maps.backward_boundary
    )
    return {
        name: np.asarray(mask, dtype=bool)
        for name, mask in mms._region_masks(geometry, host, selected_wall).items()
    }


def _stratified_owners(
    masks: Mapping[str, np.ndarray], *, per_region: int = 2
) -> tuple[list[int], dict[str, list[int]]]:
    by_region: dict[str, list[int]] = {}
    chosen: set[int] = set()
    for name, mask in masks.items():
        indices = np.flatnonzero(mask)
        if not indices.size:
            by_region[name] = []
            continue
        positions = np.linspace(0, indices.size - 1, min(per_region, indices.size))
        selected = sorted({int(indices[int(round(position))]) for position in positions})
        by_region[name] = selected
        chosen.update(selected)
    return sorted(chosen), by_region


def _selected_owner_quadrature(
    geometry: Any,
    host: Any,
    reference: Any,
    owner_ids: Sequence[int],
    order: int,
) -> dict[int, dict[str, Any]]:
    nodes, weights = np.polynomial.legendre.leggauss(order)
    offsets = np.stack(np.meshgrid(nodes, nodes, nodes, indexing="ij"), axis=-1)
    offsets = offsets.reshape((-1, 3))
    qweights = np.einsum("i,j,k->ijk", weights, weights, weights).reshape(-1)
    faces = tuple(
        np.asarray(axis.faces, dtype=np.float64)
        for axis in (geometry.grid.x, geometry.grid.y, geometry.grid.z)
    )
    aggregate_id = np.asarray(host.topology.aggregate_id, dtype=np.int64)
    catalogue = manufactured_field_catalogue()
    result: dict[int, dict[str, Any]] = {}

    def logical_derivatives(field: Any, points: np.ndarray):
        """Transform analytic regular-chart derivatives to logical q."""

        u, theta = points[:, 0], points[:, 1]
        cosine, sine = np.cos(theta), np.sin(theta)
        transform = np.zeros((points.shape[0], 3, 3), dtype=np.float64)
        transform[:, 0, 0] = cosine
        transform[:, 0, 1] = -u * sine
        transform[:, 1, 0] = sine
        transform[:, 1, 1] = u * cosine
        transform[:, 2, 2] = 1.0
        second_map = np.zeros((points.shape[0], 3, 3, 3), dtype=np.float64)
        second_map[:, 0, 0, 1] = second_map[:, 0, 1, 0] = -sine
        second_map[:, 1, 0, 1] = second_map[:, 1, 1, 0] = cosine
        second_map[:, 0, 1, 1] = -u * cosine
        second_map[:, 1, 1, 1] = -u * sine
        regular_gradient = np.asarray(field.gradient(points), dtype=np.float64)
        regular_hessian = np.asarray(field.hessian(points), dtype=np.float64)
        gradient = np.einsum("...ai,...a->...i", transform, regular_gradient)
        hessian = np.einsum(
            "...ai,...bj,...ab->...ij",
            transform,
            transform,
            regular_hessian,
        )
        hessian += np.einsum(
            "...aij,...a->...ij", second_map, regular_gradient
        )
        return gradient, hessian

    for owner_id in owner_ids:
        raw_indices = np.argwhere(aggregate_id == int(owner_id))
        volume = 0.0
        field_integrals = {name: 0.0 for name in catalogue}
        source_integrals = {name: 0.0 for name in catalogue}
        for i, j, k in raw_indices:
            low = np.array((faces[0][i], faces[1][j], faces[2][k]))
            high = np.array((faces[0][i + 1], faces[1][j + 1], faces[2][k + 1]))
            center = 0.5 * (low + high)
            half = 0.5 * (high - low)
            points = center + offsets * half
            metric = reference.metric_evaluator.evaluate(
                points, reject_nonpositive_J=False
            )
            perpendicular_tensor, perpendicular_divergence = (
                reference._perpendicular_geometry(points)
            )
            jacobian = np.asarray(metric.signed_J)
            physical_weights = (
                np.prod(half) * qweights * jacobian
            )
            cell_volume = float(np.sum(physical_weights))
            volume += cell_volume
            for name, field in catalogue.items():
                field_integrals[name] += float(
                    np.sum(physical_weights * field.value(points))
                )
                logical_gradient, logical_hessian = logical_derivatives(
                    field, points
                )
                physical_source = (
                    np.einsum(
                        "...j,...j->...",
                        perpendicular_divergence,
                        logical_gradient,
                    )
                    + np.einsum(
                        "...ij,...ij->...",
                        perpendicular_tensor,
                        logical_hessian,
                    )
                ) / np.maximum(np.abs(jacobian), 1.0e-30)
                source_integrals[name] += float(
                    np.sum(physical_weights * physical_source)
                )
        result[int(owner_id)] = {
            "raw_cell_count": int(raw_indices.shape[0]),
            "volume": volume,
            "field": {name: value / volume for name, value in field_integrals.items()},
            "source": {name: value / volume for name, value in source_integrals.items()},
        }
    return result


def _weighted_rms(value: np.ndarray, weight: np.ndarray, mask: np.ndarray) -> float:
    selected = np.asarray(mask, dtype=bool)
    return float(
        np.sqrt(np.sum(weight[selected] * value[selected] ** 2) / np.sum(weight[selected]))
    )


def _orders(resolutions: Sequence[int], values: Sequence[float | None]):
    result = []
    for nc, nf, coarse, fine in zip(
        resolutions[:-1], resolutions[1:], values[:-1], values[1:]
    ):
        if coarse is None or fine is None or coarse <= 1.0e-14 or fine <= 1.0e-14:
            result.append(None)
        else:
            result.append(math.log(coarse / fine) / math.log(nf / nc))
    return result


def _boundary_data(reference: Any) -> dict[str, Any]:
    angles = np.linspace(0.0, 2.0 * np.pi, 8, endpoint=False)
    theta, eta = np.meshgrid(angles, angles, indexing="ij")
    points = np.stack((np.ones(theta.size), theta.ravel(), eta.ravel()), axis=-1)
    metric = reference.metric_evaluator.evaluate(points, reject_nonpositive_J=False)
    gcontra = np.asarray(metric.contravariant_metric)
    catalogue = manufactured_field_catalogue()
    fields = {}
    for name, field in catalogue.items():
        regular_gradient = field.gradient(points)
        u, angle = points[:, 0], points[:, 1]
        logical_gradient = np.stack(
            (
                regular_gradient[:, 0] * np.cos(angle)
                + regular_gradient[:, 1] * np.sin(angle),
                -u * regular_gradient[:, 0] * np.sin(angle)
                + u * regular_gradient[:, 1] * np.cos(angle),
                regular_gradient[:, 2],
            ),
            axis=-1,
        )
        normal_derivative = np.einsum(
            "...j,...j->...", gcontra[:, 0, :], logical_gradient
        ) / np.sqrt(gcontra[:, 0, 0])
        fields[name] = {
            "dirichlet_max_abs": float(np.max(np.abs(field.value(points)))),
            "physical_normal_derivative_max_abs": float(
                np.max(np.abs(normal_derivative))
            ),
            "finite": bool(
                np.all(np.isfinite(field.value(points)))
                and np.all(np.isfinite(normal_derivative))
            ),
        }
    return {
        "surface": "actual-HSX outer radial wall u=1",
        "normal_convention": "n.grad(f)=(g^{u j} d_j f)/sqrt(g^{uu}) from fixed 64^3 metric",
        "point_count": int(points.shape[0]),
        "fields": fields,
    }


def run_case(args: argparse.Namespace) -> dict[str, Any]:
    resolution = int(args.resolution)
    artifact_path, artifact = _load(args.geometry, resolution)
    reference_path, reference_artifact = _load(
        args.geometry, int(args.reference_resolution)
    )
    reference = build_continuum_reference_from_artifact(
        reference_artifact,
        tau=mms.PHYSICAL_PARAMETERS["tau"],
        mi_over_me=mms.PHYSICAL_PARAMETERS["mi_over_me"],
        rho_star=mms.PHYSICAL_PARAMETERS["rho_star"],
        Ve_nu=mms.PHYSICAL_PARAMETERS["Ve_nu"],
        perp_diffusion=mms.PHYSICAL_PARAMETERS["density_D_perp"],
        enable_generalized_potential=True,
    )
    geometry = artifact.global_geometry
    host = artifact.owner_geometry
    active = np.asarray(host.topology.is_active_owner, dtype=bool)
    owner_volume = np.asarray(host.aggregate_chart_volume, dtype=np.float64)
    raw_volume = np.asarray(host.raw_volume, dtype=np.float64)
    aggregate_id = np.asarray(host.topology.aggregate_id, dtype=np.int64)
    masks = _region_masks(geometry, host)
    owner_ids, owners_by_region = _stratified_owners(masks)

    quadrature = {
        order: _selected_owner_quadrature(
            geometry, host, reference, owner_ids, order
        )
        for order in (2, 4, 6)
    }
    catalogue = manufactured_field_catalogue()
    moment_fields: dict[str, np.ndarray] = {}
    field_qualification = {}
    for name in POLYNOMIAL_FIELDS:
        moment_field, moment_source = physical_owner_moment_reference(
            catalogue[name],
            centroid=np.asarray(host.aggregate_chart_centroid),
            second_moment=np.asarray(host.aggregate_chart_second_moment),
            third_moment=np.asarray(host.aggregate_chart_third_moment),
            active_owner=active,
        )
        moment_fields[name] = moment_field
        q2 = np.array([quadrature[2][owner]["field"][name] for owner in owner_ids])
        q4 = np.array([quadrature[4][owner]["field"][name] for owner in owner_ids])
        q6 = np.array([quadrature[6][owner]["field"][name] for owner in owner_ids])
        s2 = np.array([quadrature[2][owner]["source"][name] for owner in owner_ids])
        s4 = np.array([quadrature[4][owner]["source"][name] for owner in owner_ids])
        s6 = np.array([quadrature[6][owner]["source"][name] for owner in owner_ids])
        moments = moment_field.ravel()[owner_ids]
        field_qualification[name] = {
            "family": catalogue[name].family,
            "selected_owner_count": len(owner_ids),
            "q2_to_q6_rms": float(np.sqrt(np.mean((q2 - q6) ** 2))),
            "q4_to_q6_rms": float(np.sqrt(np.mean((q4 - q6) ** 2))),
            "producer_moment_to_q6_rms": float(
                np.sqrt(np.mean((moments - q6) ** 2))
            ),
            "source_q2_to_q6_rms": float(np.sqrt(np.mean((s2 - s6) ** 2))),
            "source_q4_to_q6_rms": float(np.sqrt(np.mean((s4 - s6) ** 2))),
            "producer_moment_source_to_q6_rms": None,
            "reference_convention": (
                "bounded tensor Gauss on selected real HSX raw cells; "
                "producer moments are separately labelled approximations"
            ),
        }

    q6_volumes = np.array([quadrature[6][owner]["volume"] for owner in owner_ids])
    serialized_volumes = owner_volume.ravel()[owner_ids]
    volume_check = {
        "q6_to_serialized_relative_l2": float(
            np.linalg.norm(q6_volumes - serialized_volumes)
            / np.linalg.norm(q6_volumes)
        ),
        "q6_to_serialized_max_relative": float(
            np.max(
                np.abs(q6_volumes - serialized_volumes)
                / np.maximum(np.abs(q6_volumes), np.finfo(float).tiny)
            )
        ),
    }

    prolongation = compile_rlp_cell_average_prolongation(host)
    representation = {}
    for name in POLYNOMIAL_FIELDS:
        owner = moment_fields[name]
        reconstructed = np.asarray(
            apply_rlp_cell_average_prolongation(jnp.asarray(owner), prolongation)
        )
        raw_exact, _ = physical_owner_moment_reference(
            catalogue[name],
            centroid=np.asarray(host.raw_chart_centroid),
            second_moment=np.asarray(host.raw_chart_second_moment),
            third_moment=np.asarray(host.raw_chart_third_moment),
            active_owner=np.ones(active.shape, dtype=bool),
        )
        delta = reconstructed - raw_exact
        representation[name] = {
            "global_physical_rms": _weighted_rms(
                delta, raw_volume, np.ones(active.shape, dtype=bool)
            ),
            "linf": float(np.max(np.abs(delta))),
            "by_region_physical_rms": {
                region: _weighted_rms(delta, raw_volume, mask)
                for region, mask in masks.items()
                if np.any(mask)
            },
        }

    def restrict(raw: np.ndarray) -> np.ndarray:
        sums = np.zeros(raw.size, dtype=np.float64)
        np.add.at(sums, aggregate_id.ravel(), (raw_volume * raw).ravel())
        result = np.zeros(active.shape, dtype=np.float64)
        np.divide(
            sums.reshape(active.shape), owner_volume, out=result, where=active
        )
        return result

    test_owner = np.where(
        active,
        0.3
        + np.asarray(host.aggregate_chart_centroid)[..., 0]
        - 0.2 * np.asarray(host.aggregate_chart_centroid)[..., 1],
        0.0,
    )
    h_owner = np.asarray(
        apply_rlp_cell_average_prolongation(jnp.asarray(test_owner), prolongation)
    )
    rh_identity = float(np.max(np.abs((restrict(h_owner) - test_owner)[active])))
    raw_test = np.sin(np.asarray(host.raw_chart_centroid)[..., 0]) + 0.1 * np.cos(
        np.asarray(host.raw_chart_centroid)[..., 2]
    )
    owner_seed = jnp.zeros(active.shape, dtype=jnp.float64)
    pullback = jax.linear_transpose(
        lambda value: apply_rlp_cell_average_prolongation(value, prolongation),
        owner_seed,
    )
    hstar = np.asarray(pullback(jnp.asarray(raw_volume * raw_test))[0])
    hstar_result = np.zeros(active.shape, dtype=np.float64)
    np.divide(hstar, owner_volume, out=hstar_result, where=active)
    hstar = hstar_result
    lhs = float(np.sum(raw_volume * h_owner * raw_test))
    rhs = float(np.sum(owner_volume[active] * test_owner[active] * hstar[active]))

    raw_centers = np.stack(
        np.meshgrid(
            np.asarray(geometry.grid.x.centers),
            np.asarray(geometry.grid.y.centers),
            np.asarray(geometry.grid.z.centers),
            indexing="ij",
        ),
        axis=-1,
    )
    spot_indices = np.array(
        sorted({int(index) for owner in owner_ids for index in np.flatnonzero(aggregate_id.ravel() == owner)})
    )
    # Cap the metric check while retaining samples from every selected owner.
    if spot_indices.size > 512:
        spot_indices = spot_indices[np.linspace(0, spot_indices.size - 1, 512).astype(int)]
    spot_points = raw_centers.reshape((-1, 3))[spot_indices]
    prepared = reference.prepare(spot_points)
    serialized_J = np.asarray(geometry.cell_metric.J).ravel()[spot_indices]
    serialized_B = np.asarray(geometry.cell_bfield.Bmag).ravel()[spot_indices]
    metric_spot_check = {
        "sample_count": int(spot_indices.size),
        "J_relative_l2": float(
            np.linalg.norm(np.asarray(prepared.J) - serialized_J)
            / np.linalg.norm(serialized_J)
        ),
        "B_relative_l2": float(
            np.linalg.norm(np.asarray(prepared.B) - serialized_B)
            / np.linalg.norm(serialized_B)
        ),
    }

    mask_validation = validate_region_masks(
        active=active,
        diagnostic_masks=masks,
        partition_masks=masks,
    )
    payload = {
        "schema": SCHEMA,
        "resolution": resolution,
        "reference_resolution": int(args.reference_resolution),
        "geometry_artifact": str(artifact_path),
        "geometry_manifest_sha256": _sha256(artifact_path / "manifest.json"),
        "reference_artifact": str(reference_path),
        "reference_manifest_sha256": _sha256(reference_path / "manifest.json"),
        "execution": "one-resolution-per-process; bounded selected-owner quadrature",
        "angular_group_profile": np.asarray(host.angular_group_size),
        "selected_owners_by_region": owners_by_region,
        "selected_owner_count": len(owner_ids),
        "mask_validation": mask_validation,
        "metric_spot_check": metric_spot_check,
        "volume_check": volume_check,
        "field_qualification": field_qualification,
        "boundary_data": _boundary_data(reference),
        "reconstruction": {
            "fields": representation,
            "RH_identity_max_abs": rh_identity,
            "mass_weighted_Hstar_adjoint_absolute_mismatch": abs(lhs - rhs),
            "mass_weighted_Hstar_adjoint_relative_mismatch": abs(lhs - rhs)
            / max(abs(lhs), abs(rhs), np.finfo(float).tiny),
            "maximum_reproduction_residual": float(
                prolongation.diagnostics.maximum_reproduction_residual
            ),
            "maximum_row_weight_l1_norm": float(
                prolongation.diagnostics.maximum_row_weight_l1_norm
            ),
        },
        "scope": {
            "source_control": (
                "independent fixed-64 HSX J^-1 d_i[J P^ij d_j f] from analytic "
                "logical field derivatives and continuum metric derivatives"
            ),
            "face_derivatives": "measured by the companion actual-HSX operator audit",
            "no_formula_changes": True,
        },
    }
    _write_json(args.output, payload)
    return payload


def summarize(cases: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    ordered = sorted(cases, key=lambda item: int(item["resolution"]))
    resolutions = [int(item["resolution"]) for item in ordered]
    series = {}
    for field in POLYNOMIAL_FIELDS:
        for metric in (
            "q4_to_q6_rms",
            "producer_moment_to_q6_rms",
            "source_q4_to_q6_rms",
        ):
            values = [case["field_qualification"][field][metric] for case in ordered]
            series[f"reference/{field}/{metric}"] = {
                "values": values,
                "orders": _orders(resolutions, values),
            }
        values = [
            case["reconstruction"]["fields"][field]["global_physical_rms"]
            for case in ordered
        ]
        series[f"reconstruction/{field}/global_physical_rms"] = {
            "values": values,
            "orders": _orders(resolutions, values),
        }
    qualification = {
        "actual_hsx_all_resolutions": resolutions == [32, 48, 64],
        "fixed_64_reference": all(
            int(case["reference_resolution"]) == 64 for case in ordered
        ),
        "region_partitions_valid": all(
            case["mask_validation"]["partition_is_disjoint_and_complete"]
            for case in ordered
        ),
        "boundary_data_finite": all(
            all(item["finite"] for item in case["boundary_data"]["fields"].values())
            for case in ordered
        ),
        "RH_identity": max(
            case["reconstruction"]["RH_identity_max_abs"] for case in ordered
        ) <= 1.0e-11,
        "Hstar_adjoint_identity": max(
            case["reconstruction"]["mass_weighted_Hstar_adjoint_relative_mismatch"]
            for case in ordered
        ) <= 1.0e-11,
    }
    qualification["overall_algebraic_pass"] = all(qualification.values())
    return {
        "schema": SCHEMA,
        "resolutions": resolutions,
        "series": series,
        "qualification": qualification,
        "cases": ordered,
    }


def run_campaign(args: argparse.Namespace) -> dict[str, Any]:
    args.output.mkdir(parents=True, exist_ok=True)
    script = Path(__file__).resolve()
    paths = []
    for resolution in args.resolutions:
        path = args.output / f"reference_reconstruction_N{resolution}.json"
        subprocess.run(
            [
                sys.executable,
                str(script),
                "case",
                "--geometry",
                str(args.geometry),
                "--resolution",
                str(resolution),
                "--reference-resolution",
                str(args.reference_resolution),
                "--output",
                str(path),
            ],
            check=True,
        )
        paths.append(path)
    cases = [json.loads(path.read_text(encoding="utf-8")) for path in paths]
    payload = summarize(cases)
    payload["campaign"] = {
        "one_resolution_per_process": True,
        "geometry_policy": "immutable-artifact-only-no-rebuild",
    }
    _write_json(args.output / "reference_reconstruction_summary.json", payload)
    return payload


def merge_cases(args: argparse.Namespace) -> dict[str, Any]:
    payload = summarize(
        [json.loads(path.read_text(encoding="utf-8")) for path in args.inputs]
    )
    payload["campaign"] = {
        "one_resolution_per_process": True,
        "geometry_policy": "immutable-artifact-only-no-rebuild",
    }
    _write_json(args.output, payload)
    return payload


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    case = subparsers.add_parser("case")
    case.add_argument("--geometry", type=Path, required=True)
    case.add_argument("--resolution", type=int, required=True)
    case.add_argument("--reference-resolution", type=int, default=64)
    case.add_argument("--output", type=Path, required=True)
    case.set_defaults(handler=run_case)
    campaign = subparsers.add_parser("campaign")
    campaign.add_argument("--geometry", type=Path, required=True)
    campaign.add_argument("--resolutions", type=int, nargs="+", default=(32, 48, 64))
    campaign.add_argument("--reference-resolution", type=int, default=64)
    campaign.add_argument("--output", type=Path, required=True)
    campaign.set_defaults(handler=run_campaign)
    merge = subparsers.add_parser("merge")
    merge.add_argument("inputs", type=Path, nargs="+")
    merge.add_argument("--output", type=Path, required=True)
    merge.set_defaults(handler=merge_cases)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    args.handler(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
