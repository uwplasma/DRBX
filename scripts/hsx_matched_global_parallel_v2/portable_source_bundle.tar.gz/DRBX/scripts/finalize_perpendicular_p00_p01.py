#!/usr/bin/env python3
"""Write immutable P00/P01 provenance and compact baseline tables."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

import jax
import numpy as np


ROOT = Path(__file__).resolve().parents[1]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _git(*arguments: str) -> str:
    return subprocess.check_output(
        ("git", *arguments), cwd=ROOT, text=True
    ).rstrip()


def _status_paths():
    entries = []
    for line in _git("status", "--porcelain=v1").splitlines():
        if not line:
            continue
        status, name = line[:2], line[3:]
        if " -> " in name:
            name = name.split(" -> ", 1)[1]
        path = ROOT / name
        if path.is_file() and not name.startswith("work/"):
            entries.append({"status": status, "path": name, "sha256": _sha256(path)})
    return entries


def _scalar(array):
    value = np.asarray(array)
    return value.item() if value.shape == () else value.tolist()


def _json_value(value):
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    if isinstance(value, (np.integer, int)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        number = float(value)
        return number if np.isfinite(number) else None
    return value


def _baseline_table(data):
    fields = json.loads(str(_scalar(data["field_names_json"])))
    terms = json.loads(str(_scalar(data["rhs_term_names_json"])))
    regions = json.loads(str(_scalar(data["region_names_json"])))
    errors = np.asarray(data["rhs_term_error_norms"], dtype=np.float64)[0]
    regional = np.asarray(data["partitioned_rhs_term_error_norms"], dtype=np.float64)[0]
    shares = np.asarray(
        data["partitioned_rhs_term_squared_error_fraction"], dtype=np.float64
    )[0]

    rows = []
    for family, term_name in (
        ("bracket", "poisson_bracket"),
        ("curvature", "curvature"),
        ("diffusion", "perpendicular_diffusion"),
    ):
        for field_index, field in enumerate(fields):
            if term_name not in terms[field_index]:
                continue
            slot = terms[field_index].index(term_name)
            rows.append({
                "operator": family,
                "field": field,
                "global_volume_weighted_rms_error": float(errors[field_index, slot]),
                "regions": {
                    region: {
                        "volume_weighted_rms_error": float(
                            regional[region_index, field_index, slot]
                        ),
                        "global_squared_error_share": float(
                            shares[region_index, field_index, slot]
                        ),
                    }
                    for region_index, region in enumerate(regions)
                },
            })

    polarization_names = json.loads(
        str(_scalar(data["generalized_potential_error_control_names_json"]))
    )
    polarization_errors = np.asarray(
        data["generalized_potential_control_error_norms"], dtype=np.float64
    )[0]
    polarization_regional = np.asarray(
        data["partitioned_generalized_potential_control_error_norms"],
        dtype=np.float64,
    )[0]
    rows.append({
        "operator": "polarization",
        "field": "generalized_potential",
        "controls": {
            name: {
                "global_volume_weighted_rms_error": float(polarization_errors[index]),
                "regional_volume_weighted_rms_error": {
                    region: float(polarization_regional[region_index, index])
                    for region_index, region in enumerate(regions)
                },
            }
            for index, name in enumerate(polarization_names)
        },
        "reconstructed_phi_residual": _scalar(data["reconstructed_phi_residual"]),
        "phi_reconstruction_difference": _scalar(data["phi_reconstruction_difference"]),
    })
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--qualification", type=Path, required=True)
    parser.add_argument("--geometry-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    geometry = {}
    for resolution in (32, 48, 64):
        directory = args.geometry_root / f"hsx_fci_{resolution}x{resolution}x{resolution}"
        manifest = directory / "manifest.json"
        payload = json.loads(manifest.read_text(encoding="utf-8"))
        validation_path = directory / payload["components"]["producer_validation_report"]
        validation = json.loads(validation_path.read_text(encoding="utf-8"))
        geometry[str(resolution)] = {
            "path": str(directory.resolve()),
            "manifest_sha256": _sha256(manifest),
            "manifest": payload,
            "producer_validation": {
                "valid": validation["valid"],
                "required_checks_pass": all(
                    validation["checks"][name] for name in validation["required"]
                ),
                "diagnostic_only": validation["diagnostic_only"],
                "closure_diagnostics": validation["closure_diagnostics"],
            },
        }

    with np.load(args.baseline, allow_pickle=False) as data:
        configuration = json.loads(str(_scalar(data["production_configuration_json"])))
        baseline = {
            "artifact": str(args.baseline.resolve()),
            "artifact_sha256": _sha256(args.baseline),
            "resolution": _scalar(data["resolutions"]),
            "reference_projection_method": _scalar(data["reference_projection_method"]),
            "reference_projection_order": _scalar(data["reference_projection_order"]),
            "physical_parameters": json.loads(str(_scalar(data["physical_parameters_json"]))),
            "production_configuration": configuration,
            "frozen_execution": _scalar(data["frozen_execution"]),
            "shard_counts": _scalar(data["shard_counts"]),
            "device_count": _scalar(data["device_count"]),
            "counterfactuals_enabled": bool(_scalar(data["counterfactuals_enabled"])),
            "enabled_reconstruction_payloads": {
                "owner_to_raw": "conservative-cubic-regular-chart-H",
                "bracket_direct_faces": "transition transported traces only",
                "curvature_direct_faces": "all interior radial owner fits",
                "curvature_shared_edge_one_form": bool(
                    configuration.get("curvature_edge_one_form")
                    == "direct-continuous-shared-edge"
                ),
                "polarization": "conservative shared perpendicular action",
            },
            "reconstruction_diagnostics": {
                "maximum_row_weight_l1_norm": _scalar(
                    data["rlp_reconstruction_maximum_row_weight_l1_norm"]
                ),
                "row_weight_l1_limit": _scalar(
                    data["rlp_reconstruction_row_weight_l1_limit"]
                ),
                "planar_donor_count": _scalar(
                    data["rlp_reconstruction_planar_donor_count"]
                ),
                "maximum_condition_number": _scalar(
                    data["rlp_reconstruction_maximum_condition_number"]
                ),
                "maximum_reproduction_residual": _scalar(
                    data["rlp_reconstruction_maximum_reproduction_residual"]
                ),
            },
            "results": _baseline_table(data),
            "global_exact_phi_residual": _scalar(data["exact_phi_residual"]),
            "source_total_subtraction_residual": _scalar(
                data["source_total_subtraction_residual"]
            ),
            "phi_converged": _scalar(data["phi_converged"]),
        }

    qualification = json.loads(args.qualification.read_text(encoding="utf-8"))
    manifest = {
        "schema": "drbx.perpendicular-p00-p01-manifest-v1",
        "hypothesis": (
            "freeze current midpoint MMS behavior and qualify cheap independent "
            "owner-reference/measurement controls before operator formula changes"
        ),
        "source": {
            "repository": str(ROOT),
            "head": _git("rev-parse", "HEAD"),
            "branch": _git("branch", "--show-current"),
            "dirty_and_untracked_source_files": _status_paths(),
        },
        "precision": {
            "reference_and_history_dtype": "float64",
            "jax_x64_required_by_driver": True,
            "jax_x64_enabled_during_manifest_capture": bool(jax.config.x64_enabled),
        },
        "runtime": {
            "python": sys.version.split()[0],
            "numpy": np.__version__,
            "jax": jax.__version__,
            "platform": platform.platform(),
            "devices": [str(device) for device in jax.devices()],
        },
        "geometry_artifacts": geometry,
        "continuum_geometry_reference": {
            "fixed_for_all_refinement_levels": True,
            "source_resolution": 64,
            "source_manifest_sha256": geometry["64"]["manifest_sha256"],
            "construction": (
                "cubic periodic tensor interpolant of the finest serialized "
                "cell metric and normalized magnetic field"
            ),
            "qualification": (
                "all producer-required validation checks pass at 32/48/64; "
                "the non-gating field-line closure diagnostic remains visible"
            ),
        },
        "baseline": baseline,
        "p01_qualification": {
            "artifact": str(args.qualification.resolve()),
            "artifact_sha256": _sha256(args.qualification),
            "qualification": qualification["qualification"],
            "max_order4_to_order8_reference_change": qualification[
                "max_order4_to_order8_reference_change"
            ],
            "scope": (
                "small analytic fixture only; routine full-HSX MMS remains "
                "jacobian-weighted midpoint and no full-domain high-order "
                "quadrature dependency was added"
            ),
        },
        "commands": {
            "baseline": (
                "XDG_CACHE_HOME=/tmp/drbx-p00-p01-cache PYTHONPATH=src:.. "
                "conda run -n drb python -c \"import simulate_hsx_mms as m; "
                "m.B0=1.0; m.main([... N=32, t=0.01, final_time=0.01, "
                "shards=1x1x1, --skip-counterfactuals ...])\""
            ),
            "qualification": (
                "PYTHONPATH=src:.. conda run -n drb python "
                "scripts/qualify_perpendicular_references.py --resolution 4 ..."
            ),
            "focused_tests": (
                "PYTHONPATH=src:.. conda run -n drb pytest -q "
                "tests/test_perpendicular_reference.py"
            ),
        },
        "limitations": [
            "P00 is a single-resolution preservation baseline, not a convergence claim.",
            "Routine midpoint projection is qualified as a second-order convention; it is not asserted to have sub-10% amplitude error.",
            "The first direct driver attempt completed numerically but hit the pre-existing undefined B0 serialization bug; the recorded rerun injects normalized B0=1.0 without changing operators.",
            "Regional term Linf is supported by the P01 measurement helper but is not persisted by the existing MMS artifact; later campaigns must wire it into their reports.",
        ],
    }
    output = args.output_dir / "p00_p01_manifest_and_results.json"
    output.write_text(
        json.dumps(_json_value(manifest), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(output)


if __name__ == "__main__":
    main()
