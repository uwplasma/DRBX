#!/usr/bin/env python3
"""Bounded P03 audit for polar geometry, return maps, and closures.

The driver uses the existing cheap polar fixtures.  It does not launch the
six-field HSX MMS and does not change a production numerical formula.
"""

from __future__ import annotations

import argparse
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import jax
import jax.numpy as jnp
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tests"))
sys.path.insert(0, str(ROOT / "scripts"))

from audit_perpendicular_p02 import _host, _poly_average  # noqa: E402
from drbx.geometry import build_local_conservative_stencil_from_field  # noqa: E402
from drbx.native.fci_boundaries import (  # noqa: E402
    CoordinateFaceValues3D,
    FaceGradientStencil3D,
)
from drbx.native.fci_model import inject_owned_field_to_halo  # noqa: E402
from drbx.native.fci_operators import (  # noqa: E402
    aggregate_local_control_volume_average,
    build_local_radial_curvature_face_states,
    local_control_volume_projected_fine_cell_volume,
    local_poisson_bracket_compatible_flux_op,
    restrict_local_control_volume_diffusion_average,
)
from drbx.native.fci_rlp_diffusion import (  # noqa: E402
    apply_rlp_cell_average_prolongation,
)
from drbx.validation.perpendicular_reference import (  # noqa: E402
    error_statistics,
    manufactured_field_catalogue,
    validate_region_masks,
)
from test_fci_poisson_rlp_reconstruction_convergence import (  # noqa: E402
    _case as bracket_case,
    _setup,
)
from test_fci_curvature_rlp_reconstruction_convergence import _smooth_state  # noqa: E402


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _git_snapshot() -> dict[str, object]:
    def run(*args: str) -> str:
        return subprocess.check_output(args, cwd=ROOT, text=True).strip()

    return {
        "revision": run("git", "rev-parse", "HEAD"),
        "branch": run("git", "branch", "--show-current"),
        "dirty_paths": run("git", "status", "--short").splitlines(),
    }


def _field_average(host, name: str, *, owner: bool) -> np.ndarray:
    field = manufactured_field_catalogue()[name]
    if field.powers is None:
        raise ValueError(f"{name} is not a polynomial exact-average control")
    return _poly_average(host, field.powers, owner=owner)


def _face_points(geometry, axis: int) -> np.ndarray:
    coordinates = []
    for component, grid in enumerate((geometry.grid.x, geometry.grid.y, geometry.grid.z)):
        coordinate = np.asarray(grid.faces_owned if component == axis else grid.centers_owned)
        shape = [1, 1, 1]
        shape[component] = coordinate.size
        coordinates.append(coordinate.reshape(shape))
    r, theta, eta = np.broadcast_arrays(*coordinates)
    return np.stack((r * np.cos(theta), r * np.sin(theta), eta), axis=-1)


def _exact_face_payload(geometry, field):
    values = []
    gradients = []
    for axis in range(3):
        points = _face_points(geometry, axis)
        xyz_gradient = np.asarray(field.gradient(points), dtype=np.float64)
        r = np.linalg.norm(points[..., :2], axis=-1)
        theta = np.arctan2(points[..., 1], points[..., 0])
        logical_gradient = np.stack(
            (
                xyz_gradient[..., 0] * np.cos(theta)
                + xyz_gradient[..., 1] * np.sin(theta),
                -r * xyz_gradient[..., 0] * np.sin(theta)
                + r * xyz_gradient[..., 1] * np.cos(theta),
                xyz_gradient[..., 2],
            ),
            axis=-1,
        )
        values.append(jnp.asarray(field.value(points), dtype=jnp.float64))
        gradients.append(jnp.asarray(logical_gradient, dtype=jnp.float64))
    return CoordinateFaceValues3D(*values), FaceGradientStencil3D(*gradients)


def _analytic_halo(coords, field) -> jax.Array:
    r, theta, eta = (np.asarray(value) for value in coords)
    points = np.stack((r * np.cos(theta), r * np.sin(theta), eta), axis=-1)
    return jnp.asarray(field.value(points), dtype=jnp.float64)


def _region_masks(cells, profile: np.ndarray) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray]]:
    active = np.asarray(cells.is_active_owner, dtype=bool)
    oi = np.asarray(cells.owner_i)
    transition_ring = np.zeros(profile.size, dtype=bool)
    changed = np.flatnonzero(profile[:-1] != profile[1:]) + 1
    for face in changed:
        transition_ring[max(face - 1, 0) : min(face + 1, profile.size)] = True
    axis = active & (oi == 0)
    wall = active & (oi == profile.size - 1)
    transition = active & transition_ring[np.clip(oi, 0, profile.size - 1)] & ~axis & ~wall
    interior = active & ~axis & ~wall & ~transition
    partition = {"axis": axis, "transition": transition, "interior": interior, "wall": wall}
    diagnostics = {
        "axis_or_transition": axis | transition,
        "transition_or_wall": transition | wall,
        "all_active": active,
    }
    return partition, diagnostics


def _bracket_cross(n: int, mode: str, f_name: str, g_name: str) -> dict[str, object]:
    geometry, domain, context, coords, cv, _face_bc, _closure = _setup(n, angular_mode=mode)
    host = _host(n, mode)
    cells = cv.cells
    active = np.asarray(cells.is_active_owner, dtype=bool)
    catalogue = manufactured_field_catalogue()
    fields = (catalogue[f_name], catalogue[g_name])
    stencils = []
    exact_stencils = []
    halos = []
    exact_faces = []
    for name, field in zip((f_name, g_name), fields):
        owner = np.where(active, _field_average(host, name, owner=True), 0.0)
        fine = apply_rlp_cell_average_prolongation(
            jnp.asarray(owner), cv.diffusion_prolongation, domain=domain
        )
        halo = inject_owned_field_to_halo(fine, geometry.layout)
        analytic = _analytic_halo(coords, field)
        owned = geometry.layout.owned_slices_cell
        halo = analytic.at[owned].set(fine)
        stencil = build_local_conservative_stencil_from_field(halo, geometry, context)
        face_value, face_gradient = _exact_face_payload(geometry, field)
        stencils.append(stencil)
        exact_stencils.append(
            replace(stencil, face_values=face_value, face_grad=face_gradient)
        )
        halos.append(halo)
        exact_faces.append(face_value)

    common = dict(
        geometry=geometry,
        domain=domain,
        axis_regular_axes=(True, False, False),
        cell_volume=local_control_volume_projected_fine_cell_volume(geometry, cv),
    )

    def action(f_stencil, g_stencil, *, exact_trace: bool, scheme: str):
        kwargs = dict(common)
        kwargs["characteristic_scheme"] = scheme
        if scheme in ("scalar-third-order-upwind", "compatible-third-order-upwind"):
            if exact_trace:
                kwargs["g_direct_face_states"] = (exact_faces[1], exact_faces[1])
            else:
                kwargs["g_field_halo"] = halos[1]
        return local_poisson_bracket_compatible_flux_op(f_stencil, g_stencil, **kwargs)

    variants = {}
    for gradient_label, f_stencil in (("production_gradient", stencils[0]), ("exact_gradient", exact_stencils[0])):
        for trace_label, g_stencil, exact_trace in (
            ("production_trace", stencils[1], False),
            ("exact_trace", exact_stencils[1], True),
        ):
            centered_f = action(f_stencil, g_stencil, exact_trace=exact_trace, scheme="scalar-centered")
            centered_g = action(g_stencil, f_stencil, exact_trace=False, scheme="scalar-centered")
            upwind = action(f_stencil, g_stencil, exact_trace=exact_trace, scheme="scalar-third-order-upwind")
            compatible = action(f_stencil, g_stencil, exact_trace=exact_trace, scheme="compatible-third-order-upwind")
            centered = action(f_stencil, g_stencil, exact_trace=False, scheme="centered")
            owner = {
                "generator_action": aggregate_local_control_volume_average(centered_f, cells, domain),
                "reverse_action": aggregate_local_control_volume_average(centered_g, cells, domain),
                "centered": aggregate_local_control_volume_average(centered, cells, domain),
                "upwind": aggregate_local_control_volume_average(upwind, cells, domain),
                "compatible": aggregate_local_control_volume_average(compatible, cells, domain),
                "correction": aggregate_local_control_volume_average(upwind - centered_f, cells, domain),
            }
            variants[f"{gradient_label}/{trace_label}"] = owner

    reference = variants["exact_gradient/exact_trace"]
    partition, diagnostics = _region_masks(cells, np.asarray(host.angular_group_size))
    mask_validation = validate_region_masks(active=active, diagnostic_masks=diagnostics, partition_masks=partition)
    masks = {**partition, **diagnostics}
    serialized = {}
    volume = np.asarray(cells.aggregate_volume)
    for variant_name, components in variants.items():
        serialized[variant_name] = {}
        for component, value in components.items():
            stats = error_statistics(
                np.asarray(value), np.asarray(reference[component]), volume, masks
            )
            serialized[variant_name][component] = stats

    identity_error = np.max(
        np.abs(
            np.asarray(reference["compatible"])
            - np.asarray(reference["centered"])
            - np.asarray(reference["correction"])
        )
    )
    return {
        "fields": [f_name, g_name],
        "reference": "exact logical face gradients and exact common face traces",
        "completed_owner_contributions": serialized,
        "compatible_decomposition_linf": float(identity_error),
        "mask_validation": mask_validation,
    }


def _return_map_audit(n: int, mode: str) -> dict[str, object]:
    _geometry, domain, _context, _coords, cv, _face_bc, _closure = _setup(n, angular_mode=mode)
    host = _host(n, mode)
    cells = cv.cells
    active = np.asarray(cells.is_active_owner, dtype=bool)
    profile = np.asarray(host.angular_group_size)
    partition, diagnostics = _region_masks(cells, profile)
    masks = {**partition, **diagnostics}
    volume = np.asarray(cells.aggregate_volume)
    fields = {}
    for name in ("x", "xy", "x3"):
        owner = np.where(active, _field_average(host, name, owner=True), 0.0)
        raw = _field_average(host, name, owner=False)
        r_value = aggregate_local_control_volume_average(jnp.asarray(raw), cells, domain)
        hstar_value = restrict_local_control_volume_diffusion_average(jnp.asarray(raw), cv, domain)
        h_value = apply_rlp_cell_average_prolongation(jnp.asarray(owner), cv.diffusion_prolongation, domain=domain)
        rh_value = aggregate_local_control_volume_average(h_value, cells, domain)
        fields[name] = {
            "R_exact_raw": error_statistics(np.asarray(r_value), owner, volume, masks),
            "Hstar_exact_raw": error_statistics(np.asarray(hstar_value), owner, volume, masks),
            "RH_identity_linf": float(np.max(np.abs(np.asarray(rh_value)[active] - owner[active]))),
        }
    diagnostics_h = cv.diffusion_prolongation.diagnostics
    return {
        "profile": profile.astype(int).tolist(),
        "q1_rows_are_identity": bool(
            np.all(
                ~np.asarray(cv.diffusion_prolongation.reconstructed_raw_mask)[
                    np.broadcast_to(
                        profile[:, None, None] == 1,
                        cv.diffusion_prolongation.raw_shape,
                    )
                ]
            )
        ),
        "reconstruction": {
            "degree": int(diagnostics_h.polynomial_degree),
            "eta_degree": int(diagnostics_h.eta_polynomial_degree),
            "maximum_condition": float(diagnostics_h.maximum_condition_number),
            "maximum_row_l1": float(diagnostics_h.maximum_row_weight_l1_norm),
            "row_count": int(cv.diffusion_prolongation.row_count),
            "maximum_observations": int(cv.diffusion_prolongation.max_observations),
            "eta_stencil_radius": int(cv.diffusion_prolongation.eta_radius),
            "maximum_reproduction_residual": float(diagnostics_h.maximum_reproduction_residual),
            "maximum_conservation_residual": float(diagnostics_h.maximum_conservation_residual),
            "fallback": "bounded donor expansion; unsupported/failed rows raise during compilation",
        },
        "fields": fields,
    }


def _geometry_audit(n: int, mode: str) -> dict[str, object]:
    geometry, domain, _context, _coords, cv, _face_bc, closure = _setup(
        n, radial_curvature_faces=True, angular_mode=mode
    )
    host = _host(n, mode)
    cells = cv.cells
    raw = np.asarray(cells.raw_volume)
    aggregate = np.asarray(cells.aggregate_volume)
    active = np.asarray(cells.is_active_owner, dtype=bool)
    owner_sum = np.zeros_like(aggregate)
    np.add.at(
        owner_sum,
        (np.asarray(cells.owner_i), np.asarray(cells.owner_j), np.asarray(cells.owner_k)),
        raw,
    )
    rows = cv.radial_curvature_faces
    qweight = np.asarray(rows.quadrature_weight)
    expected_subface = (2.0 * np.pi / n) * (2.0 * np.pi / 4)
    owner_values = _smooth_state(cells, aggregate=True)
    psi_owner = owner_values[0] + 0.7 * owner_values[2]
    state_stack = jnp.stack((*owner_values, psi_owner), axis=-1)
    state_kwargs = dict(
        owner_values_owned=state_stack,
        geometry=geometry,
        domain=domain,
        control_volume_geometry=cv,
        positive_field_count=3,
        halo_exchange=closure.halo_exchange,
        topology_filler=closure.topology_filler,
    )
    guarded = build_local_radial_curvature_face_states(
        **state_kwargs, positivity_floor=1.0e-12
    )
    unguarded_kwargs = dict(state_kwargs)
    unguarded_kwargs["positive_field_count"] = 0
    unguarded = build_local_radial_curvature_face_states(**unguarded_kwargs)
    positivity_rejections = int(np.count_nonzero(
        np.asarray(unguarded.valid[..., :3]) & ~np.asarray(guarded.valid[..., :3])
    ))
    return {
        "aggregate_volume_sum_linf": float(np.max(np.abs(owner_sum[active] - aggregate[active]))),
        "global_raw_minus_owner_volume": float(np.sum(raw) - np.sum(aggregate[active])),
        "radial_rows": int(rows.max_rows),
        "radial_observation_extent": int(rows.max_equations),
        "radial_active_observations_max": int(np.max(np.sum(np.asarray(rows.observation_active), axis=-1))),
        "radial_weight_l1_max": float(max(
            np.max(np.sum(np.abs(np.asarray(getattr(rows, name))), axis=-1))
            for name in ("centered_weights", "minus_weights", "plus_weights")
        )),
        "radial_reconstruction_degree": 2,
        "smooth_positive_fixture_positivity_rejections": positivity_rejections,
        "smooth_positive_fixture_fallback_active": bool(positivity_rejections),
        "shared_row_owner_pair_distinct": bool(np.all(
            (np.asarray(rows.minus_owner_i) != np.asarray(rows.plus_owner_i))
            | (np.asarray(rows.minus_owner_j) != np.asarray(rows.plus_owner_j))
            | (np.asarray(rows.minus_owner_k) != np.asarray(rows.plus_owner_k))
        )),
        "quadrature_subface_measure_linf": float(
            np.max(np.abs(np.sum(qweight, axis=-1) - expected_subface))
        ),
        "normalization": {
            "return_maps": "raw physical volume / aggregate physical volume",
            "curvature_material": "raw volume/B summed to owner volume/B",
            "lean_radial_quadrature": "logical dtheta*deta weights; radial normal and B are applied separately",
        },
    }


def run(n: int) -> dict[str, object]:
    return {
        "schema": "drbx-perpendicular-p03-resolution-v1",
        "task": "P03",
        "resolution": {"Nr": n // 2, "Ntheta": n, "Neta": 4},
        "git": _git_snapshot(),
        "mms_path_provenance": {
            "driver": "simulate_hsx_mms.py::_runtime compiles compile_radial_curvature_faces=True",
            "rhs": "LocalFciDrbEBRhs builds LocalRadialCurvatureFaceStates3D and passes radial_curvature_face_states",
            "current_material_path": "quadrature-resolved lean all-interior radial direct states",
            "p02_common_quadrature_scope": "matches the current radial material branch on the polar fixture",
            "p02_averaged_state_direct_scope": "alternate diagnostic/legacy collapsed composition; not selected by current repository MMS",
            "potential_remainder": "separate conservative psi=phi+tau*Ti face-value path",
        },
        "bracket_crosses": {
            "x_y": _bracket_cross(n, "automatic", "x", "y"),
            "x2_xy": _bracket_cross(n, "automatic", "x2", "xy"),
            "wall_compatible_smooth": {
                scheme: bracket_case(n, scheme, "automatic")
                for scheme in ("centered", "scalar-third-order-upwind")
            },
        },
        "return_maps": {
            mode: _return_map_audit(n, mode)
            for mode in ("axis_only", "automatic")
        },
        "geometry": {
            mode: _geometry_audit(n, mode)
            for mode in ("axis_only", "automatic")
        },
        "q1_control": {
            "return_maps": "R=H*=I by construction on the ordinary non-agglomerated raw topology",
            "diffusion_context": "P02's separate straight-field (N,N,1) q=1 fixture remains the differentiation/closure control",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--resolution", type=int, required=True, choices=(16, 24, 32))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = run(args.resolution)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
