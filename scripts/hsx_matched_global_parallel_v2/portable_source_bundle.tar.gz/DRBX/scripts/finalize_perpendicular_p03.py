#!/usr/bin/env python3
"""Aggregate isolated P03 records into the durable error-budget artifact."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "work/perpendicular_second_order_p03"
RESOLUTIONS = (16, 24, 32)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def orders(values):
    return [
        math.log(a / b) / math.log(n1 / n0) if a > 1.0e-13 and b > 1.0e-13 else None
        for a, b, n0, n1 in zip(values[:-1], values[1:], RESOLUTIONS[:-1], RESOLUTIONS[1:])
    ]


def series(records, path):
    values = []
    for record in records:
        value = record
        for key in path:
            value = value[key]
        values.append(value)
    return values


def main() -> None:
    records = [json.loads((OUT / f"p03_N{n}.json").read_text()) for n in RESOLUTIONS]
    budget = []

    budget.append({
        "category": "representation_reconstruction",
        "measurement": "P02 exact polynomial owner averages -> H raw averages",
        "result": "passes fitting tolerance through cubic degree",
        "mechanism": "not the earliest polynomial failure",
        "evidence": "../perpendicular_second_order_p02/p02_stage_audit.json",
    })
    budget.append({
        "category": "derivative",
        "measurement": "P02 native first-interior radial derivative for exact f=x averages",
        "result": "8/9 of exact angular-average derivative on axis-only and automatic profiles",
        "mechanism": "proven native representation-to-differentiation inconsistency; present before automatic agglomeration",
        "evidence": "../perpendicular_second_order_p02/p02_stage_audit.json",
    })
    for case in ("x_y", "x2_xy"):
        for variant in (
            "production_gradient/production_trace",
            "production_gradient/exact_trace",
            "exact_gradient/production_trace",
        ):
            values = series(records, (
                "bracket_crosses", case, "completed_owner_contributions", variant,
                "compatible", "all_active", "absolute_rms",
            ))
            budget.append({
                "category": "derivative_or_transported_trace",
                "measurement": f"{case} completed compatible owner action, {variant}",
                "errors": values,
                "orders": orders(values),
                "reference": "exact face gradients + exact common transported traces",
                "gate_role": "diagnostic, not a separate second-order gate",
            })
    budget.append({
        "category": "geometry",
        "measurement": "raw-to-owner volume sums and lean radial subface quadrature measures",
        "result": {
            mode: {
                key: max(abs(record["geometry"][mode][key]) for record in records)
                for key in (
                    "aggregate_volume_sum_linf",
                    "global_raw_minus_owner_volume",
                    "quadrature_subface_measure_linf",
                )
            }
            for mode in ("axis_only", "automatic")
        },
        "mechanism": "no inconsistency resolved in the audited polar volume/measure identities",
    })
    budget.append({
        "category": "flux_quadrature_composition",
        "measurement": "P02 curvature material common-quadrature versus collapsed averaged-state paths",
        "result": {
            "current_lean_common_quadrature": "4.6e-13 to 1.1e-12",
            "alternate_collapsed_axis_only_orders": [0.016, 0.008],
            "alternate_collapsed_automatic_orders": [1.015, -0.460],
            "potential_remainder_orders": [4.03, 4.06],
        },
        "mechanism": "current repository MMS selects the quadrature-resolved lean radial path; the failed collapsed composition is an alternate diagnostic, not the current selector",
        "evidence": "../perpendicular_second_order_p02/p02_stage_audit.json",
    })
    for mode in ("axis_only", "automatic"):
        for field in ("x", "xy", "x3"):
            values = series(records, (
                "return_maps", mode, "fields", field, "Hstar_exact_raw",
                "all_active", "absolute_rms",
            ))
            budget.append({
                "category": "return_map",
                "measurement": f"Hstar exact raw average -> {field} owner average, {mode}",
                "errors": values,
                "orders": orders(values),
                "RH_identity_linf_max": max(series(records, (
                    "return_maps", mode, "fields", field, "RH_identity_linf",
                ))),
                "mechanism": "RH identity is roundoff-exact, but Hstar is an adjoint test map rather than an inverse; x is asymptotically about first order on the final interval",
            })
    budget.append({
        "category": "boundary_closure",
        "measurement": "focused existing contracts",
        "result": "12 passed, 1 skipped",
        "coverage": {
            "axis": "active-face suppression and polar regularity passed",
            "periodic_endpoints": "Fourier material trace and constant control passed",
            "dirichlet": "weighted symmetric Dirichlet nullspace contract passed",
            "nonzero_neumann": "analytic source enters once; oblique physical-normal MMS passed",
            "normal_semantics": "BC value is outward physical-normal derivative; conormal flux remains an operator-derived quantity",
            "eta_shards": "centered bracket invariant test passed; two-device periodic curvature endpoint parity skipped because only one device was available",
            "fallback": "curvature reconstruction order and positivity-fallback metadata passed",
        },
    })

    source_paths = (
        "scripts/audit_perpendicular_p03.py",
        "scripts/finalize_perpendicular_p03.py",
        "tests/test_audit_perpendicular_p03.py",
        "scripts/audit_perpendicular_p02.py",
        "src/drbx/validation/perpendicular_reference.py",
        "simulate_hsx_mms.py",
        "src/drbx/native/fci_drb_EB_rhs.py",
        "src/drbx/native/fci_operators.py",
    )
    aggregate = {
        "schema": "drbx-perpendicular-p03-error-budget-v1",
        "task": "P03",
        "status": "passed-audit-with-diagnostic-failures",
        "acceptance_contract": "P03 is a bounded audit. Later certification requires global volume-weighted operator L2 order >=1.8 on both finest intervals per certified operator/nontrivial field, plus independent elliptic and fixed-time checks.",
        "resolutions": [{"Nr": n // 2, "Ntheta": n, "Neta": 4} for n in RESOLUTIONS],
        "records": {
            f"p03_N{n}.json": sha(OUT / f"p03_N{n}.json") for n in RESOLUTIONS
        },
        "error_budget": budget,
        "proven_mechanisms": [
            "native exact-average radial differentiation has the P02 8/9 first-face defect before automatic RLP transitions",
            "completed bracket crosses separately expose production generator-gradient and transported-trace contributions",
            "RH=I, volume sums, and shared subface measures close at roundoff, so those identities do not explain the first-order diffusion result",
            "Hstar acting on independently exact raw averages is not identity-consistent for all fields; x has final-interval order near one on both axis-only and automatic profiles",
            "current MMS curvature material uses common quadrature states; the failed averaged-state composition is not its active path",
        ],
        "unresolved_hypotheses": [
            "the relative shares of native differentiation, physical boundary closure, and Hstar return in the complete q=1/RLP diffusion residual require P04/P07 candidate comparisons",
            "the bracket cross uses exact face-midpoint traces on the analytic polar fixture; it does not certify all variable-metric HSX face quadrature",
            "theta and eta curvature material directions were separated by the production diagnostic API in P02 but were not supplied independent exact nonzero directional manufactured references here",
            "two-device eta-shard periodic curvature parity could not run on the one-device host",
            "full-HSX producer geometry-reference error remains a P08 budget item",
        ],
        "smallest_justified_p04_changes": [
            "add moment-consistent differentiated owner-to-face rows while preserving the existing owner representation",
            "use common face/subface quadrature for generator gradients and transported traces",
            "retain the current lean radial curvature common-quadrature path and do not replace it because of the alternate collapsed-path failure",
            "carry return-map/closure diagnostics through candidate evaluation; do not assume the 8/9 repair alone fixes diffusion",
        ],
        "focused_tests": "12 passed, 1 skipped in 113.43s",
        "source_sha256": {path: sha(ROOT / path) for path in source_paths},
    }
    (OUT / "p03_error_budget.json").write_text(
        json.dumps(aggregate, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    main()
