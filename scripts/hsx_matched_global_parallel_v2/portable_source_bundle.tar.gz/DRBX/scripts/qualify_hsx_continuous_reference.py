#!/usr/bin/env python3
"""Qualify and freeze the matching continuous HSX MMS reference sidecar."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import simulate_hsx_mms as mms  # noqa: E402
from drbx.geometry.Bfield_evaluator import bfield_evaluator_from_makegrid  # noqa: E402
from drbx.geometry.MetricEvaluator import MetricEvaluator  # noqa: E402
from hsx_mms_continuum_reference import (  # noqa: E402
    ContinuumMmsReference,
    build_continuum_reference_from_artifact,
)
import audit_hsx_poisson_vorticity as base  # noqa: E402


SCHEMA = "drbx.hsx-continuous-mms-reference"


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _stats(value: Any) -> dict[str, float]:
    array = np.asarray(value, dtype=np.float64)
    return {
        "minimum": float(np.min(array)),
        "maximum": float(np.max(array)),
        "mean": float(np.mean(array)),
        "rms": float(np.sqrt(np.mean(array**2))),
        "standard_deviation": float(np.std(array)),
    }


def _logical_centers(geometry: Any) -> np.ndarray:
    axes = tuple(
        np.asarray(axis.centers, dtype=np.float64)
        for axis in (geometry.grid.x, geometry.grid.y, geometry.grid.z)
    )
    return np.stack(np.meshgrid(*axes, indexing="ij"), axis=-1).reshape((-1, 3))


def _jacobian_transform(q: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    u, theta, _eta = np.asarray(q, dtype=np.float64).T
    c, s = np.cos(theta), np.sin(theta)
    forward = np.zeros((len(u), 3, 3), dtype=np.float64)
    forward[:, 0, 0] = c
    forward[:, 0, 1] = -u * s
    forward[:, 1, 0] = s
    forward[:, 1, 1] = u * c
    forward[:, 2, 2] = 1.0
    inverse = np.zeros_like(forward)
    inverse[:, 0, 0] = c
    inverse[:, 0, 1] = s
    inverse[:, 1, 0] = -s / u
    inverse[:, 1, 1] = c / u
    inverse[:, 2, 2] = 1.0
    return forward, inverse


def _sandwich(left: np.ndarray, value: np.ndarray) -> np.ndarray:
    return left @ value @ np.swapaxes(left, -1, -2)


def _q_to_regular(q: np.ndarray) -> np.ndarray:
    return np.stack(
        (q[:, 0] * np.cos(q[:, 1]), q[:, 0] * np.sin(q[:, 1]), q[:, 2]),
        axis=-1,
    )


def _regular_to_q(point: np.ndarray) -> np.ndarray:
    return np.stack(
        (
            np.hypot(point[:, 0], point[:, 1]),
            np.mod(np.arctan2(point[:, 1], point[:, 0]), 2.0 * np.pi),
            point[:, 2],
        ),
        axis=-1,
    )


def _cartesian_flux_omega(
    reference: ContinuumMmsReference,
    q: np.ndarray,
    step: float,
) -> np.ndarray:
    """Independent fourth-order divergence in the regular x/y/eta chart."""

    def flux(point: np.ndarray) -> np.ndarray:
        logical = _regular_to_q(point)
        forward, inverse = _jacobian_transform(logical)
        metric = reference._metric(logical)
        regular_j = metric["J"] / logical[:, 0]
        contra = _sandwich(forward, metric["gcontra"])
        b = np.einsum("nij,nj->ni", forward, metric["b"])
        psi = reference._psi_raw(logical)
        gradient = np.einsum(
            "nji,nj->ni", inverse, np.stack(psi[1:4], axis=-1)
        )
        projector = contra - b[:, :, None] * b[:, None, :]
        return regular_j[:, None] * np.einsum(
            "nij,nj->ni", projector, gradient
        )

    regular = _q_to_regular(q)
    divergence = np.zeros(q.shape[0], dtype=np.float64)
    for axis in range(3):
        delta = np.zeros_like(regular)
        delta[:, axis] = float(step)
        divergence += (
            flux(regular - 2.0 * delta)[:, axis]
            - 8.0 * flux(regular - delta)[:, axis]
            + 8.0 * flux(regular + delta)[:, axis]
            - flux(regular + 2.0 * delta)[:, axis]
        ) / (12.0 * float(step))
    metric = reference._metric(q)
    return divergence / (metric["J"] / q[:, 0])


def _omega(reference: ContinuumMmsReference, points: np.ndarray) -> np.ndarray:
    psi = reference._psi_raw(points)
    return reference._perpendicular_operator(
        points, np.stack(psi[1:4], axis=-1), psi[5]
    )


def run(args: argparse.Namespace) -> dict[str, Any]:
    metric_cache = args.metric_cache.resolve()
    makegrid = args.makegrid.resolve()
    _, artifact = base._load_artifact(args.geometry, 64)
    geometry = artifact.global_geometry
    with np.load(metric_cache, allow_pickle=False) as cached:
        evaluator = MetricEvaluator.from_cache_payload(
            cached, prefix="metric_evaluator_"
        )
        B0 = float(np.asarray(cached["reference_magnetic_field"]).item())
        coefficient = np.asarray(
            cached["metric_evaluator_zernike_coefficients"], dtype=np.float64
        )
        cache_spec = json.loads(str(np.asarray(cached["cache_spec"]).item()))
    currents = np.asarray(args.currents.split(","), dtype=np.float64)
    bfield = bfield_evaluator_from_makegrid(
        makegrid, currents=currents, method="cubic"
    )
    full_eta_period = float(
        np.asarray(geometry.grid.z.faces)[-1]
        - np.asarray(geometry.grid.z.faces)[0]
    )
    reference = ContinuumMmsReference(
        evaluator,
        bfield,
        B0,
        tau=mms.PHYSICAL_PARAMETERS["tau"],
        mi_over_me=mms.PHYSICAL_PARAMETERS["mi_over_me"],
        rho_star=mms.PHYSICAL_PARAMETERS["rho_star"],
        Ve_nu=mms.PHYSICAL_PARAMETERS["Ve_nu"],
        perp_diffusion=mms.PHYSICAL_PARAMETERS["density_D_perp"],
        finite_difference_step=2.0e-4,
        enable_generalized_potential=True,
        eta_period=full_eta_period,
    )
    serialized = build_continuum_reference_from_artifact(
        artifact,
        tau=mms.PHYSICAL_PARAMETERS["tau"],
        mi_over_me=mms.PHYSICAL_PARAMETERS["mi_over_me"],
        rho_star=mms.PHYSICAL_PARAMETERS["rho_star"],
        Ve_nu=mms.PHYSICAL_PARAMETERS["Ve_nu"],
        perp_diffusion=mms.PHYSICAL_PARAMETERS["density_D_perp"],
        enable_generalized_potential=True,
    )
    points_all = _logical_centers(geometry)
    indices = np.linspace(
        0, points_all.shape[0] - 1, min(4096, points_all.shape[0]), dtype=np.int64
    )
    points = points_all[indices]
    position = np.asarray(evaluator.position(points), dtype=np.float64)
    artifact_position = np.asarray(artifact.cell_positions, dtype=np.float64).reshape((-1, 3))[indices]
    metric = evaluator.evaluate(points, reject_nonpositive_J=False)
    magnetic = evaluator.evaluate_magnetic_field(
        points, bfield, reject_nonpositive_J=False
    )
    smooth_bcontra = np.asarray(magnetic.B_contravariant) / B0
    smooth_bmag = np.asarray(magnetic.magnitude) / B0
    artifact_bcontra = np.asarray(geometry.cell_bfield.B_contra).reshape((-1, 3))[indices]
    artifact_bmag = np.asarray(geometry.cell_bfield.Bmag).reshape(-1)[indices]
    artifact_j = np.asarray(geometry.cell_metric.J).reshape(-1)[indices]
    qualification = {
        "sample_count": int(indices.size),
        "position_max_abs": float(np.max(np.abs(position - artifact_position))),
        "position_rms": float(np.sqrt(np.mean((position - artifact_position) ** 2))),
        "J_relative_rms": float(
            np.sqrt(np.mean((np.asarray(metric.signed_J) - artifact_j) ** 2))
            / np.sqrt(np.mean(artifact_j**2))
        ),
        "B_contravariant_relative_rms": float(
            np.sqrt(np.mean((smooth_bcontra - artifact_bcontra) ** 2))
            / np.sqrt(np.mean(artifact_bcontra**2))
        ),
        "Bmag_relative_rms": float(
            np.sqrt(np.mean((smooth_bmag - artifact_bmag) ** 2))
            / np.sqrt(np.mean(artifact_bmag**2))
        ),
    }
    qualification["passed"] = bool(
        qualification["position_max_abs"] < 3.0e-4
        and qualification["J_relative_rms"] < 5.0e-3
        and qualification["B_contravariant_relative_rms"] < 2.0e-3
    )

    eta = float(np.asarray(geometry.grid.z.centers)[27])
    theta = 2.0 * np.pi * (np.arange(96) + 0.371) / 96.0
    radii = (0.125, 0.03125, 0.015625, 0.0078125, 0.00390625)
    rings = []
    for radius in radii:
        ring = np.stack(
            (
                np.full(theta.size, radius),
                theta,
                np.full(theta.size, eta),
            ),
            axis=-1,
        )
        rings.append(
            {
                "u": radius,
                "eta": eta,
                "serialized_polar_interpolation": _stats(_omega(serialized, ring)),
                "continuous_producer_evaluator": _stats(_omega(reference, ring)),
            }
        )

    derivative_points = np.asarray(
        [
            [u, theta_value, eta]
            for u in (0.007, 0.015625, 0.03125, 0.05, 0.2)
            for theta_value in (0.37, 1.21, 3.17, 4.82)
        ],
        dtype=np.float64,
    )
    step_values = {}
    for step in (1.0e-4, 2.0e-4, 4.0e-4):
        reference.finite_difference_step = step
        step_values[str(step)] = _omega(reference, derivative_points)
    reference.finite_difference_step = 2.0e-4
    cartesian = _cartesian_flux_omega(reference, derivative_points, 5.0e-6)
    differentiation = {
        "points": derivative_points,
        "step_1e-4_vs_2e-4_max_abs": float(
            np.max(np.abs(step_values["0.0001"] - step_values["0.0002"]))
        ),
        "step_4e-4_vs_2e-4_max_abs": float(
            np.max(np.abs(step_values["0.0004"] - step_values["0.0002"]))
        ),
        "logical_vs_regular_cartesian_max_abs": float(
            np.max(np.abs(step_values["0.0002"] - cartesian))
        ),
        "logical_vs_regular_cartesian_relative_l2": float(
            np.linalg.norm(step_values["0.0002"] - cartesian)
            / max(np.linalg.norm(cartesian), np.finfo(float).tiny)
        ),
    }

    comparison = None
    if args.comparison_cache is not None:
        with np.load(args.comparison_cache, allow_pickle=False) as other:
            other_coefficient = np.asarray(
                other["metric_evaluator_zernike_coefficients"], dtype=np.float64
            )
        comparison = {
            "path": str(args.comparison_cache.resolve()),
            "sha256": _sha(args.comparison_cache.resolve()),
            "coefficient_max_abs_difference": float(
                np.max(np.abs(coefficient - other_coefficient))
            ),
        }
    artifact_manifest = args.geometry / "64x64x64" / "manifest.json"
    payload = {
        "schema": SCHEMA,
        "version": 1,
        "metric_cache": {
            "path": str(metric_cache),
            "size": metric_cache.stat().st_size,
            "sha256": _sha(metric_cache),
            "declared_producer_checkpoint": json.loads(
                artifact_manifest.read_text(encoding="utf-8")
            )["metadata"]["producer_metric_checkpoint"],
            "cache_spec": cache_spec,
        },
        "makegrid": {
            "path": str(makegrid),
            "size": makegrid.stat().st_size,
            "sha256": _sha(makegrid),
        },
        "makegrid_currents": currents,
        "reference_magnetic_field": B0,
        "continuous_evaluator_period": float(evaluator.period),
        "analytic_mms_eta_period": full_eta_period,
        "eta_period_contract": (
            "continuous evaluator repeats one HSX field period; analytic MMS "
            "harmonics retain the full simulation eta domain"
        ),
        "artifact": {
            "path": str((args.geometry / "64x64x64").resolve()),
            "manifest_sha256": _sha(artifact_manifest),
            "component_checksums": json.loads(
                artifact_manifest.read_text(encoding="utf-8")
            )["checksums"],
        },
        "qualification": qualification,
        "near_axis_vorticity": rings,
        "bounded_differentiation": differentiation,
        "comparison_cache": comparison,
        "scope": (
            "qualified continuous geometry/B reference only; no production "
            "operator or default change"
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(base._json_value(payload), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--geometry", type=Path, required=True)
    parser.add_argument("--metric-cache", type=Path, required=True)
    parser.add_argument("--comparison-cache", type=Path)
    parser.add_argument("--makegrid", type=Path, required=True)
    parser.add_argument("--currents", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    payload = run(args)
    print(
        json.dumps(
            base._json_value({
                "output": str(args.output),
                "qualification": payload["qualification"],
                "bounded_differentiation": payload["bounded_differentiation"],
            }),
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
