#!/usr/bin/env python3
"""Checkpointed N48/N64 workflow for the bounded generator factorization."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
from typing import Sequence


SCRIPT = Path(__file__).with_name("audit_hsx_generator_factorization.py")
SCHEMA = "drbx.hsx-generator-factor-workflow-v1"


def _write(path: Path, payload: dict) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)


def _run(name: str, command: list[str], checkpoint: Path, state: dict) -> None:
    started = time.time()
    print(json.dumps({"event": "workflow", "stage": "stage_start", "name": name, "command": command}), flush=True)
    result = subprocess.run(command, check=False)
    elapsed = time.time() - started
    state.setdefault("stages", {})[name] = {
        "exit_code": int(result.returncode),
        "elapsed_seconds": elapsed,
        "completed_unix_time": time.time(),
    }
    _write(checkpoint, state)
    print(json.dumps({"event": "workflow", "stage": "stage_exit", "name": name, "exit_code": result.returncode, "elapsed_seconds": elapsed}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--geometry", type=Path, required=True)
    parser.add_argument("--reference-sidecar", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--selection-root", type=Path, required=True)
    parser.add_argument("--p04-root", type=Path, required=True)
    parser.add_argument("--prior-root", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    checkpoint = args.output / "workflow_checkpoint.json"
    if checkpoint.is_file():
        state = json.loads(checkpoint.read_text(encoding="utf-8"))
    else:
        state = {"schema": SCHEMA, "status": "running", "stages": {}}
    common = [
        "--geometry", str(args.geometry.resolve()),
        "--reference-sidecar", str(args.reference_sidecar.resolve()),
        "--baseline", str(args.baseline.resolve()),
        "--selection-root", str(args.selection_root.resolve()),
        "--p04-root", str(args.p04_root.resolve()),
        "--prior-root", str(args.prior_root.resolve()),
    ]
    for resolution in (48, 64):
        cache = args.output / f"N{resolution}.factor_cache.npz"
        case = args.output / f"N{resolution}.json"
        extract_name = f"extract_N{resolution}"
        marker = cache.with_suffix(".complete.json")
        if extract_name not in state["stages"] or state["stages"][extract_name]["exit_code"] != 0 or not marker.is_file():
            _run(
                extract_name,
                [sys.executable, "-u", str(SCRIPT), "extract", "--resolution", str(resolution), *common, "--cache", str(cache)],
                checkpoint,
                state,
            )
        _run(
            f"replay_N{resolution}",
            [sys.executable, "-u", str(SCRIPT), "replay", "--cache", str(cache), "--output", str(case)],
            checkpoint,
            state,
        )
    summary = args.output / "summary.json"
    _run(
        "merge",
        [sys.executable, "-u", str(SCRIPT), "merge", str(args.output / "N48.json"), str(args.output / "N64.json"), "--output", str(summary)],
        checkpoint,
        state,
    )
    state["status"] = "extraction_and_replay_complete"
    state["summary"] = str(summary.resolve())
    _write(checkpoint, state)
    print(json.dumps({"event": "workflow", "stage": "workflow_complete", "summary": str(summary.resolve())}), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
