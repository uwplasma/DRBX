#!/usr/bin/env python3
"""Finalize the bounded matched face-and-volume audit without mutating its caches."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


FIELDS = (
    "actual_vorticity",
    "smooth_regular_scalar",
    "smooth_eta_varying_scalar",
)
LABELS = {
    "actual_vorticity": "vorticity",
    "smooth_regular_scalar": "regular",
    "smooth_eta_varying_scalar": "eta-varying",
}
PRIMARY = (
    "analytic_face_q3",
    "analytic_matched_q3",
    "joint_cubic_midpoint_exact_geometry",
    "joint_cubic_face_q3",
    "joint_cubic_matched_q3",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _error(case: dict[str, Any], field: str, candidate: str, action: str = "C") -> float:
    return float(case["results"][field]["candidates"][candidate][action]["absolute_l2"])


def _percent(after: float, before: float) -> float:
    return 100.0 * (after / before - 1.0)


def _fmt(value: float) -> str:
    return f"{value:.7g}"


def finalize(evidence: Path) -> dict[str, Any]:
    source_path = evidence / "summary.json"
    source = json.loads(source_path.read_text(encoding="utf-8"))
    cases = source["cases"]

    primary: dict[str, Any] = {}
    effects: dict[str, Any] = {}
    region_budgets: dict[str, Any] = {}
    for resolution in (48, 64):
        case = cases[str(resolution)]
        primary[str(resolution)] = {
            field: {
                candidate: {
                    action: _error(case, field, candidate, action)
                    for action in ("A", "B", "C")
                }
                for candidate in PRIMARY
            }
            for field in FIELDS
        }
        effects[str(resolution)] = {}
        region_budgets[str(resolution)] = {}
        for field in FIELDS:
            analytic_face = _error(case, field, "analytic_face_q3")
            analytic_matched = _error(case, field, "analytic_matched_q3")
            midpoint = _error(case, field, "joint_cubic_midpoint_exact_geometry")
            face = _error(case, field, "joint_cubic_face_q3")
            matched = _error(case, field, "joint_cubic_matched_q3")
            effects[str(resolution)][field] = {
                "analytic_volume_correction_percent": _percent(analytic_matched, analytic_face),
                "numerical_face_integration_percent": _percent(face, midpoint),
                "numerical_volume_correction_percent": _percent(matched, face),
            }
            regions = case["results"][field]["candidates"]["joint_cubic_matched_q3"]["C"]["regions"]
            region_budgets[str(resolution)][field] = {
                name: float(item["squared_error_fraction"]) for name, item in regions.items()
            }

    final = {
        "schema": "drbx.hsx-matched-face-volume-final-summary-v1",
        "source_summary": {
            "path": str(source_path.resolve()),
            "sha256": _sha256(source_path),
            "schema": source["schema"],
        },
        "scope": {
            "resolutions": [48, 64],
            "owner_count_per_resolution": 28,
            "global_campaign_authorized": False,
            "production_changes": [],
            "material_upwinding_certified": False,
            "global_order_claim": False,
        },
        "decision": {
            "analytical_identity_and_sign_supported": True,
            "smooth_face_integration_material_benefit": True,
            "numerical_volume_correction_is_primary_remaining_smooth_limiter": False,
            "vorticity_benefit_survives_numerical_reconstruction": False,
            "conclusion": (
                "Matched face-and-volume integration is analytically correct and face-product "
                "integration materially reduces both smooth-control errors. The owner-reconstructed "
                "volume correction adds only a modest smooth improvement and regresses vorticity; "
                "the remaining blocker is compatible reconstructed-factor quality, concentrated "
                "for vorticity at the physical boundary and axis."
            ),
            "next_bounded_candidate": (
                "Keep q3 integrated face products and requalify only the axis- and physical-boundary "
                "vorticity volume-factor reconstruction with a one-sided, axis-regular compatible "
                "local polynomial; preserve degree, donor scope, smooth-field path, boundary model, "
                "and the same frozen owners."
            ),
        },
        "primary_errors": primary,
        "signed_effect_percent": effects,
        "matched_q3_region_squared_error_fraction": region_budgets,
        "verification": {
            str(resolution): cases[str(resolution)]["verification"] for resolution in (48, 64)
        },
        "runtime": {
            str(resolution): cases[str(resolution)]["runtime"] for resolution in (48, 64)
        },
    }
    final_path = evidence / "final_summary.json"
    final_path.write_text(json.dumps(final, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    lines = [
        "# HSX bounded matched face-and-volume integration audit",
        "",
        "## Decision",
        "",
        final["decision"]["conclusion"],
        "",
        "The analytical functional supports the sign and normalization of "
        "`H = b_cov / (rho* B)` and `a_g = -H × grad(g)`: adding the matched "
        "volume term reduces analytical q3 centered-C error by 93.6–96.3% for "
        "vorticity and 99.7–99.8% for both smooth controls. With factors from one "
        "balanced cubic fit, q3 face-product integration reduces the two smooth "
        "errors by roughly 45–55%, but it increases vorticity error. The numerical "
        "volume correction supplies only a further 0.9–6.5% smooth reduction and "
        "increases vorticity error by 2.9–5.0%.",
        "",
        "This is bounded 28-owner evidence at N48/N64, not a global order, material-"
        "upwinding, stability, or production-certification claim. No production "
        "source, reconstruction, boundary model, evolved MMS, blob, curvature, or "
        "diffusion/polarization path changed.",
        "",
        "## Corrected prerequisite evidence",
        "",
        "The corrected supervisor replay that motivated this audit is preserved here; "
        "P/G/O labels describe diagnostic transported-value choices, not certified "
        "production methods.",
        "",
        "| Midpoint diagnostic | N48 vorticity C | N64 vorticity C |",
        "|---|---:|---:|",
        "| O2 / Dh | 0.0750412 | 0.0335730 |",
        "| cubic-planar / Dh | 0.121014 | 0.0266833 |",
        "| O2 / analytic derivative | 0.111712 | 0.049318 |",
        "| analytic value / analytic derivative | 0.121491 | 0.050820 |",
        "",
        "Analytical substitution alone therefore did not repair midpoint assembly; "
        "the matched integration test was necessary.",
        "",
        "## A/B/C constituent errors",
        "",
        "| N | Field | Candidate | A | B | C |",
        "|---:|---|---|---:|---:|---:|",
    ]
    for resolution in (48, 64):
        for field in FIELDS:
            for candidate in PRIMARY:
                values = primary[str(resolution)][field][candidate]
                lines.append(
                    f"| {resolution} | {LABELS[field]} | `{candidate}` | "
                    f"{_fmt(values['A'])} | {_fmt(values['B'])} | {_fmt(values['C'])} |"
                )

    lines += [
        "",
        "The A and B columns show that the conclusion is not an artifact of hidden "
        "centered cancellation. Analytical matched q3 errors are at or below the "
        "saved q5−q3 reference shift and should be read as reference-limited, not as "
        "a resolved asymptotic error.",
        "",
        "## Signed integration effects",
        "",
        "| N | Field | analytical volume | numerical face | numerical volume |",
        "|---:|---|---:|---:|---:|",
    ]
    for resolution in (48, 64):
        for field in FIELDS:
            item = effects[str(resolution)][field]
            lines.append(
                f"| {resolution} | {LABELS[field]} | "
                f"{item['analytic_volume_correction_percent']:+.1f}% | "
                f"{item['numerical_face_integration_percent']:+.1f}% | "
                f"{item['numerical_volume_correction_percent']:+.1f}% |"
            )

    lines += [
        "",
        "Negative percentages are improvements. For numerical rows, face integration "
        "is relative to the exact-geometry midpoint and volume integration is relative "
        "to face-only q3.",
        "",
        "## Where the numerical matched error remains",
        "",
        "| N | Field | axis | boundary | agglomerated | size-change | ordinary |",
        "|---:|---|---:|---:|---:|---:|---:|",
    ]
    region_names = (
        "axis_ring", "physical_boundary_footprint", "agglomerated_interior",
        "true_size_change_interface", "ordinary",
    )
    for resolution in (48, 64):
        for field in FIELDS:
            values = region_budgets[str(resolution)][field]
            lines.append(
                f"| {resolution} | {LABELS[field]} | "
                + " | ".join(f"{100.0 * values[name]:.1f}%" for name in region_names)
                + " |"
            )

    lines += [
        "",
        "The vorticity obstruction is boundary/axis dominated (94.5% at N48 and "
        "71.6% at N64), while the smooth controls are dominated by agglomerated and "
        "true size-change rows. This supports a localized vorticity reconstruction "
        "test rather than another global campaign.",
        "",
        "## Verification and cost",
        "",
    ]
    for resolution in (48, 64):
        case = cases[str(resolution)]
        verify = case["verification"]
        shared = verify["shared_incidence"]
        runtime = case["runtime"]
        lines.append(
            f"- N{resolution}: baseline replay `{verify['baseline_action_replay_max_abs']:.3g}`, "
            f"joint midpoint replay `{verify['joint_cubic_midpoint_replay_max_abs']:.3g}`, "
            f"value replay `{verify['joint_cubic_value_replay_max_abs']:.3g}`, gradient replay "
            f"`{verify['joint_cubic_gradient_replay_max_abs']:.3g}`, constant annihilation "
            f"`{verify['constant_annihilation_max_abs']:.3g}`, maximum internal signed incidence "
            f"`{shared['maximum_internal_signed_incidence']}`, runtime "
            f"`{runtime['extraction_seconds']:.1f} s`, peak RSS `{runtime['maximum_rss_gib']:.2f} GiB`."
        )
    lines += [
        "",
        "Fourth-order curl(H) half/base/double-step changes are at roundoff relative "
        "to the measured errors. q5−q3 numerical changes track the separately saved "
        "reference shift, and reference-uncertainty fractions for numerical candidates "
        "remain below 2.6%. Both caches pass implementation/source identity and array-"
        "payload hash validation.",
        "",
        "## Next bounded candidate",
        "",
        final["decision"]["next_bounded_candidate"],
        "",
        "Machine-readable results: [`final_summary.json`](final_summary.json), with the "
        "full candidate, region, uncertainty, curl-step, and quadrature records retained "
        "in [`summary.json`](summary.json), [`N48.json`](N48.json), and [`N64.json`](N64.json).",
    ]
    (evidence / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return final


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("evidence", type=Path)
    args = parser.parse_args()
    final = finalize(args.evidence.resolve())
    print(json.dumps(final["decision"], indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
