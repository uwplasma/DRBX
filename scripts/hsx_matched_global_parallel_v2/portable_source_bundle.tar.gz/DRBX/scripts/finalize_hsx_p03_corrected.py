#!/usr/bin/env python3
"""Merge corrected-reference P03 evidence into the durable HSX error budget."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence


def _load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _sample_l2(field: Mapping[str, Any], stage: str) -> float:
    regions = field["stage_statistics"][stage].values()
    numerator = sum(float(region["squared_error"]) for region in regions)
    denominator = sum(float(region["physical_volume"]) for region in regions)
    return math.sqrt(numerator / denominator)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    args = parser.parse_args(argv)
    bundle = args.bundle

    budget_path = bundle / "hsx_error_budget.json"
    baseline_path = bundle / "continuous_global_baseline/summary.json"
    sidecar_path = bundle / "continuous_reference_sidecar.json"
    matched_path = bundle / "face_candidate_matched_functional_N32.json"
    differentiation_path = bundle / "structured_omega_differentiation.json"
    common_path = bundle / "face_mechanism_continuous_N32.json"
    paths = (baseline_path, sidecar_path, matched_path, differentiation_path, common_path)

    payload = _load(budget_path)
    baseline = _load(baseline_path)
    sidecar = _load(sidecar_path)
    matched = _load(matched_path)
    differentiation = _load(differentiation_path)
    common = _load(common_path)

    fields = {}
    for name, field in baseline["fields"].items():
        production = field["variants"]["pure_scalar_upwind"]
        fields[name] = {
            "absolute_l2": production["absolute_l2"],
            "relative_l2": production["relative_l2"],
            "absolute_orders": field["production_acceptance"]["orders"],
            "passed": field["production_acceptance"]["passed"],
        }

    disjoint = {}
    for case in baseline["cases"]:
        resolution = str(case["resolution"])
        disjoint[resolution] = {}
        for name in fields:
            accounting = case["fields"][name]["variants"]["pure_scalar_upwind"][
                "disjoint_error_accounting"
            ]
            disjoint[resolution][name] = {
                region: values["squared_error_fraction"]
                for region, values in accounting.items()
            }

    comparison = matched["matched_functional_comparison"]
    matched_fields = {}
    for name, field in comparison["midpoint_observation_fields"].items():
        baseline_l2 = _sample_l2(field, "baseline")
        candidate_l2 = _sample_l2(field, "candidate_planar_only")
        matched_fields[name] = {
            "baseline_absolute_l2": baseline_l2,
            "candidate_absolute_l2": candidate_l2,
            "candidate_to_baseline_ratio": candidate_l2 / baseline_l2,
        }

    payload["supersession_notice"] = (
        "Current corrected-reference evidence is authoritative for quantitative "
        "HSX bracket accuracy. Earlier serialized-polar-reference conclusions "
        "remain preserved only as historical diagnostics."
    )
    payload["corrected_reference_update"] = {
        "schema": "drbx.perpendicular-hsx-p03-corrected-update-v1",
        "status": "completed-global-acceptance-failed",
        "all_production_fields_passed": baseline["all_production_fields_passed"],
        "boundary_contract_unchanged": True,
        "production_changes": [],
        "reference": {
            "analytic_mms_eta_period": sidecar["analytic_mms_eta_period"],
            "continuous_evaluator_period": sidecar["continuous_evaluator_period"],
            "metric_cache": sidecar["metric_cache"]["path"],
            "metric_cache_sha256": sidecar["metric_cache"]["sha256"],
            "makegrid": sidecar["makegrid"]["path"],
            "makegrid_sha256": sidecar["makegrid"]["sha256"],
            "qualification": sidecar["qualification"],
            "bounded_differentiation": sidecar["bounded_differentiation"],
        },
        "global_production_baseline": {
            "resolutions": baseline["resolutions"],
            "required_minimum_order": 1.8,
            "fields": fields,
            "disjoint_squared_error_fractions": disjoint,
        },
        "structured_omega_differentiation": {
            "gradient_absolute_orders": differentiation["gradient_absolute_orders"],
            "bracket_source_absolute_orders": differentiation[
                "bracket_source_absolute_orders"
            ],
            "cases": differentiation["cases"],
            "scope": differentiation["scope"],
        },
        "matched_functional_N32": {
            "fixed_contract": comparison["fixed_contract"],
            "support_comparison": comparison["support_comparison"],
            "conditioning": comparison["midpoint_observation_conditioning"],
            "polynomial_reproduction": comparison[
                "midpoint_observation_polynomial_reproduction"
            ],
            "fields": matched_fields,
            "certification": "bounded diagnostic; no global candidate campaign run",
        },
        "collapsed_axis_bookkeeping": matched["scope"][
            "collapsed_axis_record_policy"
        ],
        "focused_tests": "50 passed, 4 non-failing cache-permission warnings",
        "common_face_continuous_record": {
            "path": str(common_path.resolve()),
            "sha256": _sha256(common_path),
        },
        "decision": {
            "P04_ready": False,
            "candidate_global_qualification_authorized": False,
            "reason": (
                "Actual vorticity passes both global order intervals, but both "
                "smooth controls miss the N48-to-N64 order gate. The bounded "
                "matched-functional candidate improves aggregate selected-sample "
                "errors but has no global convergence qualification."
            ),
            "next_step": (
                "Keep P04 pending. Localize the fine-interval smooth-control "
                "transition error and design a representation-consistent owner-to-"
                "face functional before requesting any full-domain candidate run."
            ),
        },
        "records": {
            path.relative_to(bundle).as_posix(): {"sha256": _sha256(path)}
            for path in paths
        },
    }

    temporary = budget_path.with_name(budget_path.name + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(budget_path)
    print(budget_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
