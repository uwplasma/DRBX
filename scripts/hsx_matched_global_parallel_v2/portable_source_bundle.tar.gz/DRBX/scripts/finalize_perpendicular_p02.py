#!/usr/bin/env python3
"""Assemble isolated P02 resolution records into one evidence manifest."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "work" / "perpendicular_second_order_p02"
RESOLUTIONS = (16, 24, 32)


def _orders(values):
    result = []
    for a, b, na, nb in zip(
        values[:-1], values[1:], RESOLUTIONS[:-1], RESOLUTIONS[1:]
    ):
        result.append(
            None
            if min(a, b) <= 1.0e-12
            else math.log(a / b) / math.log(nb / na)
        )
    return result


def _series(rows, *path):
    values = []
    for row in rows:
        value = row
        for key in path:
            value = value[key]
        values.append(float(value))
    return {"errors": values, "orders": _orders(values)}


def main():
    paths = [EVIDENCE / f"p02_N{n}.json" for n in RESOLUTIONS]
    rows = [json.loads(path.read_text()) for path in paths]
    series = {}
    for scheme in ("centered", "scalar-third-order-upwind"):
        for mode, key in (
            ("q1", "q1_no_agglomeration_relative_l2"),
            ("axis_only", "axis_only_relative_l2"),
            ("automatic", "automatic_relative_l2"),
        ):
            series[f"bracket/{scheme}/{mode}/completed_owner_residual"] = _series(
                rows, "operators", "bracket", scheme, key
            )
    for mode in ("q1_no_agglomeration", "axis_only", "automatic"):
        series[f"diffusion_polarization/{mode}/completed_owner_residual"] = _series(
            rows,
            "operators", "diffusion_polarization", mode,
            "owner_residual_absolute_rms",
        )
    for mode in ("axis_only", "automatic"):
        for name in (
            "coupled_baseline", "coupled_direct", "coupled_direct_quadrature",
            "centered_baseline", "centered_direct",
        ):
            series[f"curvature/{mode}/{name}"] = _series(
                rows, "operators", "curvature", mode, name
            )

    files = {
        path.name: {
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "resolution": n,
        }
        for path, n in zip(paths, RESOLUTIONS)
    }
    source_paths = (
        ROOT / "scripts" / "audit_perpendicular_p02.py",
        ROOT / "scripts" / "finalize_perpendicular_p02.py",
        ROOT / "src" / "drbx" / "validation" / "perpendicular_reference.py",
        ROOT / "tests" / "test_fci_poisson_rlp_reconstruction_convergence.py",
        ROOT / "tests" / "test_fci_curvature_rlp_reconstruction_convergence.py",
        ROOT / "tests" / "test_rlp_diffusion_consistency.py",
    )
    payload = {
        "schema": "drbx-perpendicular-p02-aggregate-v1",
        "task": "P02",
        "status": "passed-audit-with-diagnostic-operator-failures",
        "acceptance_contract": (
            "P02 is diagnostic. Later certification requires global volume-weighted "
            "operator L2 order >=1.8 on both finest intervals per certified "
            "operator/nontrivial field, plus independent elliptic and fixed-time checks."
        ),
        "resolutions": list(RESOLUTIONS),
        "records": files,
        "source_sha256": {
            str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in source_paths
        },
        "series": series,
        "stage_findings": {
            "owner_to_raw": (
                "exact-average regular-chart polynomials through degree three are "
                "reproduced to tolerance for axis-only and automatic H"
            ),
            "face_values": (
                "direct moment face rows reproduce the polynomial targets; curvature "
                "potential remainder using them converges above second order"
            ),
            "face_derivatives": (
                "earliest shared defect: exact f=x averages produce the native 8/9 "
                "first-interior radial-face derivative in both axis-only and automatic cases"
            ),
            "integrated_contributions": (
                "curvature material action is exact-to-tolerance when evaluated at common "
                "face quadrature points but nonconvergent after the production averaged-state composition"
            ),
            "completed_owner_residuals": (
                "brackets are approximately second order; diffusion/polarization is about "
                "first order; curvature material path fails while the potential remainder passes"
            ),
        },
        "scope_limits": rows[-1]["known_scope_limits"],
    }
    output = EVIDENCE / "p02_stage_audit.json"
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(output)


if __name__ == "__main__":
    main()
