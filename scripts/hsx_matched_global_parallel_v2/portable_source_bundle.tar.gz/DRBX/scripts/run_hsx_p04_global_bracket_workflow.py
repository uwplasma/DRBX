#!/usr/bin/env python3
"""Checkpointed N32/N48/N64 supervisor for global P/G/O bracket diagnostics."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from typing import Any


CASE_SCHEMA = "drbx.hsx-p04-global-bracket-case-v1"
SUMMARY_SCHEMA = "drbx.hsx-p04-global-bracket-summary-v1"
WORKFLOW_SCHEMA = "drbx.hsx-p04-global-bracket-workflow-v1"


def _atomic(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def _valid(path: Path, schema: str, resolution: int | None = None):
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if payload.get("schema") != schema:
        return None
    if resolution is not None and int(payload.get("resolution", -1)) != resolution:
        return None
    return payload


def _event(stage: str, **details: Any) -> None:
    print(json.dumps({"event": "workflow", "stage": stage, "unix_time": time.time(), **details}, sort_keys=True), flush=True)


def _run(name: str, command: list[str], checkpoint: dict[str, Any], path: Path) -> None:
    _event("stage_start", name=name, command=command)
    started = time.perf_counter()
    result = subprocess.run(command, check=False)
    elapsed = time.perf_counter() - started
    checkpoint.setdefault("stages", {})[name] = {
        "exit_code": int(result.returncode),
        "elapsed_seconds": elapsed,
        "completed_unix_time": time.time(),
    }
    _atomic(path, checkpoint)
    _event("stage_exit", name=name, exit_code=result.returncode, elapsed_seconds=elapsed)
    if result.returncode != 0:
        raise RuntimeError(f"stage {name} failed with exit code {result.returncode}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--geometry", type=Path, required=True)
    parser.add_argument("--reference-sidecar", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--prior-n32", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    checkpoint_path = output / "workflow_checkpoint.json"
    lock_path = output / "workflow.lock"
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"workflow lock already exists: {lock_path}") from error
    os.write(descriptor, f"pid={os.getpid()}\n".encode())
    os.close(descriptor)

    prior = _valid(checkpoint_path, WORKFLOW_SCHEMA)
    checkpoint = prior or {
        "schema": WORKFLOW_SCHEMA,
        "geometry": str(args.geometry.resolve()),
        "reference_sidecar": str(args.reference_sidecar.resolve()),
        "baseline": str(args.baseline.resolve()),
        "prior_n32": str(args.prior_n32.resolve()),
        "stages": {},
    }
    checkpoint["launcher_pid"] = os.getpid()
    checkpoint["status"] = "running"
    checkpoint.pop("error", None)
    _atomic(checkpoint_path, checkpoint)
    audit = Path(__file__).resolve().with_name("audit_hsx_p04_global_bracket.py")
    python = sys.executable
    try:
        case_paths = []
        for resolution in (32, 48, 64):
            case_path = output / f"N{resolution}.json"
            case_paths.append(case_path)
            if _valid(case_path, CASE_SCHEMA, resolution) is None:
                _run(
                    f"case_N{resolution}",
                    [
                        python, "-u", str(audit), "case",
                        "--geometry", str(args.geometry.resolve()),
                        "--reference-sidecar", str(args.reference_sidecar.resolve()),
                        "--baseline", str(args.baseline.resolve()),
                        "--prior-n32", str(args.prior_n32.resolve()),
                        "--resolution", str(resolution),
                        "--time", "1e-6",
                        "--output", str(output),
                    ],
                    checkpoint,
                    checkpoint_path,
                )
            payload = _valid(case_path, CASE_SCHEMA, resolution)
            if payload is None:
                raise RuntimeError(f"N{resolution} did not produce a valid atomic result")
            observed = float(payload["timings_seconds"]["total_before_output"])
            checkpoint.setdefault("observed_case_seconds", {})[str(resolution)] = observed
            checkpoint.setdefault("maximum_rss_gib", {})[str(resolution)] = float(
                payload["resources"]["maximum_rss_gib"]
            )
            if resolution == 32:
                # Face-row count grows approximately quadratically per eta plane
                # and linearly with plane count.  Use the observed N32 wall time
                # only as a transparent provisional envelope; later cases
                # replace it with measured values.
                checkpoint["post_n32_provisional_remaining_seconds"] = {
                    "N48": observed * (48.0 / 32.0) ** 3,
                    "N64": observed * (64.0 / 32.0) ** 3,
                    "interpretation": "cubic face-count scaling envelope; not an idle scheduler delay",
                }
                _event(
                    "n32_preflight_accepted",
                    observed_seconds=observed,
                    maximum_rss_gib=payload["resources"]["maximum_rss_gib"],
                    revised_remaining=checkpoint["post_n32_provisional_remaining_seconds"],
                )
            _atomic(checkpoint_path, checkpoint)

        summary = output / "summary.json"
        _run(
            "merge",
            [
                python, "-u", str(audit), "merge", *(str(path) for path in case_paths),
                "--output", str(summary),
            ],
            checkpoint,
            checkpoint_path,
        )
        if _valid(summary, SUMMARY_SCHEMA) is None:
            raise RuntimeError("merge did not produce a valid summary")
        checkpoint["status"] = "complete"
        checkpoint["summary"] = str(summary)
        checkpoint["report"] = str(summary.with_name("report.md"))
        checkpoint.pop("error", None)
        _atomic(checkpoint_path, checkpoint)
        _event("workflow_complete", summary=str(summary), report=checkpoint["report"])
        return 0
    except Exception as error:
        checkpoint["status"] = "failed"
        checkpoint["error"] = f"{type(error).__name__}: {error}"
        _atomic(checkpoint_path, checkpoint)
        _event("workflow_failed", error=checkpoint["error"])
        return 1
    finally:
        try:
            lock_path.unlink()
        except FileNotFoundError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
