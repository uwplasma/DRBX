#!/usr/bin/env python3
"""Focused P02 stage audit on the analytic polar fixture.

Run one resolution per process.  This research driver deliberately reuses the
fixture-level production harnesses from the focused operator tests; it does not
launch the six-field HSX MMS and it does not alter any numerical formula.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import subprocess
import sys

import jax.numpy as jnp
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tests"))

from drbx.geometry.fci_control_volumes import (  # noqa: E402
    build_polar_angular_agglomeration_geometry,
)
from drbx.native.fci_control_volume_operators import (  # noqa: E402
    control_volume_average_basis,
    monomial_exponents,
)
from drbx.native.fci_rlp_diffusion import (  # noqa: E402
    apply_rlp_cell_average_prolongation,
    compile_rlp_cell_average_prolongation,
)
from drbx.geometry import build_local_conservative_stencil_from_field  # noqa: E402
from drbx.native.fci_halo import LocalHaloClosure3D  # noqa: E402
from drbx.native.fci_model import inject_owned_field_to_halo  # noqa: E402
from drbx.native.fci_operators import (  # noqa: E402
    build_local_perp_laplacian_face_projectors,
    local_perp_laplacian_conservative_op,
)
from drbx.validation.perpendicular_reference import (  # noqa: E402
    first_interior_polar_average_gradient_factor,
    manufactured_field_catalogue,
)
from test_fci_curvature_rlp_reconstruction_convergence import (  # noqa: E402
    _curvature_case,
)
from test_fci_poisson_rlp_reconstruction_convergence import (  # noqa: E402
    _case as bracket_case,
    _setup,
)
from test_rlp_diffusion_consistency import (  # noqa: E402
    _apply as diffusion_apply,
    _build_case as diffusion_case,
    _manufactured_owner_data as diffusion_data,
    _weighted_rms,
)


POLYNOMIAL_FIELDS = (
    "one", "x", "y", "x2", "xy", "y2", "x3", "x2y", "xy2", "y3"
)


def _git_snapshot() -> dict[str, object]:
    def run(*args: str) -> str:
        return subprocess.check_output(args, cwd=ROOT, text=True).strip()

    dirty = run("git", "status", "--short").splitlines()
    return {
        "revision": run("git", "rev-parse", "HEAD"),
        "branch": run("git", "branch", "--show-current"),
        "dirty_paths": dirty,
    }


def _host(n: int, mode: str):
    nr = n // 2
    if mode == "axis_only":
        profile = np.r_[n, np.ones(nr - 1, dtype=np.int32)]
    elif mode == "automatic":
        profile = None
    else:
        raise ValueError(mode)
    return build_polar_angular_agglomeration_geometry(
        np.linspace(0.0, 1.0, nr + 1),
        np.linspace(0.0, 2.0 * np.pi, n + 1),
        np.linspace(0.0, 2.0 * np.pi, 5),
        lambda points: np.maximum(np.asarray(points)[..., 0], 1.0e-14),
        quadrature_order=3,
        angular_group_size=profile,
    )


def _weighted_rms_raw(delta: np.ndarray, volume: np.ndarray) -> float:
    return float(np.sqrt(np.sum(volume * delta**2) / np.sum(volume)))


def _poly_average(host, powers, *, owner: bool) -> np.ndarray:
    exponents = (tuple(powers),)
    if owner:
        centroid = host.aggregate_chart_centroid
        second = host.aggregate_chart_second_moment
        third = host.aggregate_chart_third_moment
    else:
        centroid = host.raw_chart_centroid
        second = host.raw_chart_second_moment
        third = host.raw_chart_third_moment
    return np.asarray(
        control_volume_average_basis(
            centroid, second, third, exponents=exponents
        )[..., 0]
    )


def _representation_audit(n: int, mode: str) -> dict[str, object]:
    host = _host(n, mode)
    prolongation = compile_rlp_cell_average_prolongation(host)
    active = np.asarray(host.topology.is_active_owner, dtype=bool)
    volume = np.asarray(host.raw_volume, dtype=float)
    catalogue = manufactured_field_catalogue()
    fields: dict[str, object] = {}
    for name in POLYNOMIAL_FIELDS:
        field = catalogue[name]
        owner = np.where(active, _poly_average(host, field.powers, owner=True), 0.0)
        exact_raw = _poly_average(host, field.powers, owner=False)
        reconstructed = np.asarray(
            apply_rlp_cell_average_prolongation(jnp.asarray(owner), prolongation)
        )
        fields[name] = {
            "exact_average_input_raw_rms": _weighted_rms_raw(
                reconstructed - exact_raw, volume
            ),
            "exact_to_tolerance": bool(
                np.max(np.abs(reconstructed - exact_raw)) < 5.0e-11
            ),
            "linf": float(np.max(np.abs(reconstructed - exact_raw))),
        }

    # The smooth control is intentionally midpoint-labelled here.  It is not
    # presented as an exact owner-average result.
    centers = np.asarray(host.aggregate_chart_centroid)
    smooth_owner = np.where(
        active,
        np.exp(0.2 * centers[..., 0] - 0.15 * centers[..., 1])
        * np.cos(centers[..., 2]),
        0.0,
    )
    smooth_raw = np.asarray(
        apply_rlp_cell_average_prolongation(smooth_owner, prolongation)
    )
    raw_centers = np.asarray(host.raw_chart_centroid)
    smooth_control = (
        np.exp(0.2 * raw_centers[..., 0] - 0.15 * raw_centers[..., 1])
        * np.cos(raw_centers[..., 2])
    )
    fields["smooth_nonpolynomial"] = {
        "reference_convention": "centroid/midpoint control, not exact average",
        "raw_rms": _weighted_rms_raw(smooth_raw - smooth_control, volume),
    }
    diagnostics = prolongation.diagnostics
    return {
        "profile": np.asarray(host.angular_group_size, dtype=int).tolist(),
        "active_polynomial_degree": int(diagnostics.polynomial_degree),
        "maximum_reproduction_residual": float(
            diagnostics.maximum_reproduction_residual
        ),
        "maximum_row_weight_l1_norm": float(
            diagnostics.maximum_row_weight_l1_norm
        ),
        "fields": fields,
    }


def _native_eight_ninths(n: int, mode: str) -> dict[str, float]:
    geometry, domain, context, _coords, cv, face_bc, closure = _setup(
        n, angular_mode=mode
    )
    host = _host(n, mode)
    owner = np.where(
        np.asarray(host.topology.is_active_owner),
        _poly_average(host, (1, 0, 0), owner=True),
        0.0,
    )
    from drbx.native.fci_drb_EB_rhs import LocalFciDrbEBRhs
    from drbx.geometry import build_local_conservative_stencil_from_field

    class Harness:
        _owner_field = LocalFciDrbEBRhs._owner_field

    harness = Harness()
    harness.geometry = geometry
    harness.domain = domain
    harness.control_volume_geometry = cv
    harness.halo_exchange = closure.halo_exchange
    harness.topology_filler = closure.topology_filler
    harness.physical_ghost_filler = closure.physical_ghost_filler
    prepared = LocalFciDrbEBRhs._prepare_poisson_bracket_halo(
        harness, jnp.asarray(owner), face_bc
    )
    stencil = build_local_conservative_stencil_from_field(
        prepared, geometry, context
    )
    got = np.asarray(stencil.face_grad.x)[1, :, :, 0]
    theta_lo = np.arange(n) * 2.0 * np.pi / n
    theta_hi = theta_lo + 2.0 * np.pi / n
    angular_average = (np.sin(theta_hi) - np.sin(theta_lo)) / (
        theta_hi - theta_lo
    )
    expected = np.broadcast_to(angular_average[:, None], got.shape)
    mask = np.abs(expected) > 0.2
    ratio = got[mask] / expected[mask]
    return {
        "mean_ratio": float(np.mean(ratio)),
        "max_abs_ratio_minus_eight_ninths": float(
            np.max(np.abs(ratio - 8.0 / 9.0))
        ),
    }


def _operators(n: int) -> dict[str, object]:
    bracket: dict[str, object] = {}
    for scheme in ("centered", "scalar-third-order-upwind"):
        auto = bracket_case(n, scheme, "automatic")
        axis = bracket_case(n, scheme, "axis_only")
        bracket[scheme] = {
            "q1_no_agglomeration_relative_l2": auto[
                "unagglomerated_continuum_error"
            ],
            "axis_only_relative_l2": axis["continuum_error"],
            "automatic_relative_l2": auto["continuum_error"],
            "automatic_piecewise_action_relative_l2": auto[
                "piecewise_action_error"
            ],
            "automatic_reconstructed_action_relative_l2": auto[
                "reconstructed_action_error"
            ],
        }

    diffusion: dict[str, object] = {
        "q1_no_agglomeration": _q1_diffusion(n)
    }
    for mode in ("axis_only", "automatic"):
        case = diffusion_case(n, mode)
        field, exact = diffusion_data(case)
        actual = diffusion_apply(case, jnp.asarray(field))
        diffusion[mode] = {
            "owner_residual_absolute_rms": _weighted_rms(actual - exact, case),
            "integrated_owner_error_l2": float(
                np.sqrt(
                    np.sum(
                        ((actual - exact)[case.active] * case.weights[case.active]) ** 2
                    )
                )
            ),
        }

    curvature: dict[str, object] = {}
    for mode in ("axis_only", "automatic"):
        row = _curvature_case(
            n, "H", direct_face_band_radius=n, angular_mode=mode
        )
        curvature[mode] = {
            key: value for key, value in row.items() if key != "coverage"
        }
        curvature[mode]["coverage"] = row["coverage"]
    return {"bracket": bracket, "diffusion_polarization": diffusion, "curvature": curvature}


def _q1_diffusion(n: int) -> dict[str, float]:
    """Ordinary fine-grid polar action using exact raw physical averages."""

    case = diffusion_case(n, "axis_only")
    nodes, node_weights = np.polynomial.legendre.leggauss(6)
    u0 = np.arange(n, dtype=float) / n
    u1 = (np.arange(n, dtype=float) + 1.0) / n
    t0 = np.arange(n, dtype=float) * 2.0 * np.pi / n
    t1 = (np.arange(n, dtype=float) + 1.0) * 2.0 * np.pi / n
    ur = 0.5 * (u1 - u0)[:, None] * nodes[None, :] + 0.5 * (u1 + u0)[:, None]
    tr = 0.5 * (t1 - t0)[:, None] * nodes[None, :] + 0.5 * (t1 + t0)[:, None]
    quadrature = node_weights[:, None] * node_weights[None, :]
    field = np.empty((n, n, 1), dtype=float)
    positive_source = np.empty_like(field)
    for i in range(n):
        rr = ur[i][:, None]
        for j in range(n):
            tt = tr[j][None, :]
            volume = np.sum(quadrature * rr)
            field_integrand = rr**2 * (1.0 - rr**2) ** 4 * np.cos(2.0 * tt) * rr
            lap_integrand = sum(
                (-1) ** k
                * math.comb(4, k)
                * ((2 + 2 * k) ** 2 - 4)
                * rr ** (2 * k)
                * np.cos(2.0 * tt)
                * rr
                for k in range(5)
            )
            field[i, j, 0] = np.sum(quadrature * field_integrand) / volume
            positive_source[i, j, 0] = -np.sum(quadrature * lap_integrand) / volume
    closed = LocalHaloClosure3D(
        physical_ghost_filler=case.solver.physical_ghost_filler,
        halo_exchange=case.exchange,
        topology_filler=case.scalar_filler,
    )(
        inject_owned_field_to_halo(jnp.asarray(field), case.domain.layout),
        case.domain,
        case.face_bc,
    )
    stencil = build_local_conservative_stencil_from_field(
        closed, case.geometry, case.context
    )
    actual = -np.asarray(
        local_perp_laplacian_conservative_op(
            stencil,
            case.geometry,
            case.domain,
            face_projectors=build_local_perp_laplacian_face_projectors(
                case.geometry,
                case.domain,
                axis_regular_axes=(True, False, False),
            ),
            face_bc=case.face_bc,
            axis_regular_axes=(True, False, False),
        )
    )
    volume = np.asarray(case.geometry.cell_volume_geometry.volume)
    error = actual - positive_source
    return {
        "owner_residual_absolute_rms": _weighted_rms_raw(error, volume),
        "integrated_owner_error_l2": float(np.sqrt(np.sum((error * volume) ** 2))),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--resolution", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    n = int(args.resolution)
    if n < 8 or n % 2:
        parser.error("resolution must be even and at least 8")
    payload = {
        "schema": "drbx-perpendicular-p02-stage-audit-v1",
        "scope": "P02 diagnostic only; no numerical formula changes",
        "snapshot": _git_snapshot(),
        "resolution": n,
        "shape": [n // 2, n, 4],
        "physical_mesh_scales": {
            "du": 2.0 / n,
            "dtheta": 2.0 * math.pi / n,
            "deta": 0.5 * math.pi,
        },
        "reference_conventions": {
            "polynomials": "exact physical owner averages from degree-three moments",
            "smooth_nonpolynomial": "labelled centroid/midpoint control",
            "operator_sources": "independent analytic polar expressions in focused fixtures",
            "boundary": "matching homogeneous Neumann controls for complete diffusion; smooth wall-compatible bracket field",
        },
        "analytical_first_face": first_interior_polar_average_gradient_factor(),
        "representation": {
            mode: _representation_audit(n, mode)
            for mode in ("axis_only", "automatic")
        },
        "native_first_face": {
            mode: _native_eight_ninths(n, mode)
            for mode in ("axis_only", "automatic")
        },
        "operators": _operators(n),
        "known_scope_limits": [
            "q=1 is the ordinary fine-grid comparator for brackets; the angular-owner geometry requires q0=Ntheta, so q=1 is not mislabelled as a valid RLP owner topology",
            "the smooth non-polynomial reconstruction row is midpoint-labelled and is not used as exact-average evidence",
            "curvature q=1 is retained as a remaining P03 cross-geometry control; P02 compares its owner representations only for valid axis-only and automatic RLP profiles",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(args.output)


if __name__ == "__main__":
    main()
