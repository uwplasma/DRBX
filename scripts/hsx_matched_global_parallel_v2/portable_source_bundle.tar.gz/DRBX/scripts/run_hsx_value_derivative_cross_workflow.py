#!/usr/bin/env python3
"""Checkpointed N48/N64 value/derivative-cross supervisor."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from typing import Any


SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))
import audit_hsx_value_derivative_cross as audit  # noqa: E402


WORKFLOW_SCHEMA = "drbx.hsx-value-derivative-cross-workflow-v1"


def _atomic(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def _valid_json(path: Path, schema: str, resolution: int | None = None):
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if payload.get("schema") != schema:
        return None
    if resolution is not None and int(payload.get("resolution", -1)) != resolution:
        return None
    return payload


def _event(stage: str, **details: Any) -> None:
    print(json.dumps({"event": "value_derivative_workflow", "stage": stage, "unix_time": time.time(), **details}, sort_keys=True), flush=True)


def _run(name: str, command: list[str], checkpoint: dict[str, Any], checkpoint_path: Path, logs: Path) -> None:
    log = logs / f"{name}.log"
    _event("stage_start", name=name, log=str(log), command=command)
    started = time.perf_counter()
    with log.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps({"event": "stage_start", "unix_time": time.time(), "command": command}) + "\n")
        stream.flush()
        cache_dir = logs.parent / "jax_cache"
        cache_dir.mkdir(exist_ok=True)
        result = subprocess.run(
            command, stdout=stream, stderr=subprocess.STDOUT, check=False,
            env={**os.environ, "DRBX_CACHE_DIR": str(cache_dir.resolve())},
        )
        stream.write(json.dumps({"event": "stage_exit", "unix_time": time.time(), "exit_code": result.returncode}) + "\n")
    elapsed = time.perf_counter() - started
    checkpoint.setdefault("stages", {})[name] = {
        "exit_code": int(result.returncode), "elapsed_seconds": elapsed, "log": str(log.resolve())
    }
    _atomic(checkpoint_path, checkpoint)
    _event("stage_exit", name=name, exit_code=result.returncode, elapsed_seconds=elapsed)
    if result.returncode:
        raise RuntimeError(f"stage {name} failed; see {log}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--geometry", type=Path, required=True)
    parser.add_argument("--reference-sidecar", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--p04-root", type=Path, required=True)
    parser.add_argument("--derivative-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    logs = output / "logs"
    logs.mkdir(exist_ok=True)
    lock = output / "workflow.lock"
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"workflow lock exists: {lock}") from error
    os.write(descriptor, f"pid={os.getpid()}\n".encode())
    os.close(descriptor)
    checkpoint_path = output / "workflow_checkpoint.json"
    checkpoint = _valid_json(checkpoint_path, WORKFLOW_SCHEMA) or {
        "schema": WORKFLOW_SCHEMA, "stages": {}, "output": str(output)
    }
    checkpoint.update({"status": "running", "launcher_pid": os.getpid()})
    checkpoint.pop("error", None)
    _atomic(checkpoint_path, checkpoint)
    script = Path(audit.__file__).resolve()
    python = sys.executable
    try:
        profile = output / "profile.json"
        if _valid_json(profile, audit.PROFILE_SCHEMA, 48) is None:
            _run("profile", [
                python, "-u", str(script), "profile", "--resolution", "48",
                "--geometry", str(args.geometry.resolve()), "--baseline", str(args.baseline.resolve()),
                "--derivative-root", str(args.derivative_root.resolve()), "--rows", "24",
                "--output", str(profile),
            ], checkpoint, checkpoint_path, logs)
        cases = []
        for resolution in (48, 64):
            cache = output / f"N{resolution}.cross_cache.npz"
            selection = output / f"N{resolution}_selection.json"
            cache_valid = False
            try:
                _arrays, metadata = audit._load_npz(cache)
                cache_valid = int(metadata["resolution"]) == resolution
            except (OSError, ValueError, KeyError, json.JSONDecodeError):
                cache_valid = False
            if not cache_valid:
                _run(f"extract_N{resolution}", [
                    python, "-u", str(script), "extract", "--resolution", str(resolution),
                    "--geometry", str(args.geometry.resolve()),
                    "--reference-sidecar", str(args.reference_sidecar.resolve()),
                    "--baseline", str(args.baseline.resolve()),
                    "--p04-root", str(args.p04_root.resolve()),
                    "--derivative-root", str(args.derivative_root.resolve()),
                    "--cache", str(cache), "--selection", str(selection),
                ], checkpoint, checkpoint_path, logs)
            case = output / f"N{resolution}.json"
            cached_hash = audit._sha256(cache)
            prior = _valid_json(case, audit.CASE_SCHEMA, resolution)
            if prior is None or prior.get("cache", {}).get("sha256") != cached_hash:
                _run(f"replay_N{resolution}", [
                    python, "-u", str(script), "replay", "--cache", str(cache), "--output", str(case)
                ], checkpoint, checkpoint_path, logs)
            cases.append(case)
        summary = output / "summary.json"
        _run("merge", [
            python, "-u", str(script), "merge", *(str(path) for path in cases), "--output", str(summary)
        ], checkpoint, checkpoint_path, logs)
        checkpoint.update({
            "status": "complete", "summary": str(summary),
            "report": str(summary.with_name("report.md")), "completed_unix_time": time.time(),
        })
        _atomic(checkpoint_path, checkpoint)
        _event("workflow_complete", summary=str(summary), report=checkpoint["report"])
        return 0
    except Exception as error:
        checkpoint.update({"status": "failed", "error": f"{type(error).__name__}: {error}"})
        _atomic(checkpoint_path, checkpoint)
        _event("workflow_failed", error=checkpoint["error"])
        return 1
    finally:
        try:
            lock.unlink()
        except FileNotFoundError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
