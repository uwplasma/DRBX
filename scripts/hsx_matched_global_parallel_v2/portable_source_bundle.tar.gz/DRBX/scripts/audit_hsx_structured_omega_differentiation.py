#!/usr/bin/env python3
"""Bounded mesh-dependent uncertainty audit for structured HSX omega gradients.

The global corrected-reference campaign differentiates midpoint omega values on
each resolution's structured logical mesh.  This diagnostic compares those
fourth-order mesh derivatives with the continuous reference's independent
local fourth-order differentiation at a fixed, stratified set of actual-HSX
logical points.  It does not change or rerun the production bracket action.
"""

from __future__ import annotations

import argparse
from dataclasses import replace
import hashlib
import json
import math
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = Path(__file__).resolve().parent
for entry in (ROOT, SCRIPTS):
    if str(entry) not in sys.path:
        sys.path.insert(0, str(entry))

import simulate_hsx_mms as mms  # noqa: E402
from hsx_mms_continuum_reference import (  # noqa: E402
    build_continuum_reference_from_sidecar,
)
import audit_hsx_poisson_vorticity as base  # noqa: E402


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _write(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(
        json.dumps(base._json_value(payload), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _l2(values: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.square(np.asarray(values, dtype=np.float64)))))


def _orders(resolutions: Sequence[int], values: Sequence[float]) -> list[float]:
    return [
        float(math.log(left / right) / math.log(n1 / n0))
        for n0, n1, left, right in zip(
            resolutions[:-1], resolutions[1:], values[:-1], values[1:]
        )
    ]


def _sample_indices(artifact: Any) -> tuple[np.ndarray, list[int]]:
    shape = tuple(int(value) for value in artifact.global_geometry.shape)
    nr, nt, ne = shape
    groups = np.asarray(artifact.owner_geometry.angular_group_size, dtype=np.int64)
    changes = np.flatnonzero(groups[1:] != groups[:-1])
    radial = sorted(
        set(
            [0, 1, 2, nr // 4, nr // 2, nr - 2, nr - 1]
            + [
                int(value)
                for index in changes
                for value in (max(index - 1, 0), index, index + 1, min(index + 2, nr - 1))
            ]
        )
    )
    theta = sorted(set([0, nt // 7, nt // 3, nt // 2, 5 * nt // 7]))
    eta = sorted(set([0, ne // 9, ne // 4, ne // 2, 3 * ne // 4]))
    indices = np.asarray(
        [(i, j, k) for i in radial for j in theta for k in eta],
        dtype=np.int64,
    )
    return indices, radial


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--geometry", type=Path, required=True)
    parser.add_argument("--reference-sidecar", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--time", type=float, default=1.0e-6)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)

    reference = build_continuum_reference_from_sidecar(
        args.reference_sidecar,
        verify_hashes=False,
        tau=mms.PHYSICAL_PARAMETERS["tau"],
        mi_over_me=mms.PHYSICAL_PARAMETERS["mi_over_me"],
        rho_star=mms.PHYSICAL_PARAMETERS["rho_star"],
        Ve_nu=mms.PHYSICAL_PARAMETERS["Ve_nu"],
        perp_diffusion=mms.PHYSICAL_PARAMETERS["density_D_perp"],
        enable_generalized_potential=True,
    )

    cases = []
    for resolution in (32, 48, 64):
        artifact_path, artifact = base._load_artifact(args.geometry, resolution)
        geometry = artifact.global_geometry
        u = np.asarray(geometry.grid.x.centers, dtype=np.float64)
        theta = np.asarray(geometry.grid.y.centers, dtype=np.float64)
        eta = np.asarray(geometry.grid.z.centers, dtype=np.float64)
        cache_path = args.baseline / f"N{resolution}.reference.npz"
        with np.load(cache_path, allow_pickle=False) as cache:
            omega = np.asarray(cache["actual_vorticity"], dtype=np.float64)
        structured_gradient, _ = mms._fourth_order_structured_derivatives(
            omega,
            (u, theta, eta),
            periods=(None, float(2.0 * np.pi), float(2.0 * np.pi)),
        )

        indices, radial = _sample_indices(artifact)
        points = np.column_stack(
            (u[indices[:, 0]], theta[indices[:, 1]], eta[indices[:, 2]])
        )
        local_gradient, local_hessian = reference._local_omega_derivatives(points)
        sampled_structured = structured_gradient[
            indices[:, 0], indices[:, 1], indices[:, 2]
        ]
        difference = sampled_structured - local_gradient

        prepared = reference.prepare(points)
        data = reference.evaluate(
            points,
            float(args.time),
            prepared=replace(
                prepared,
                mms_omega_gradient=local_gradient,
                mms_omega_hessian=local_hessian,
            ),
        )
        common = -np.asarray(prepared.bcov, dtype=np.float64) / (
            float(mms.PHYSICAL_PARAMETERS["rho_star"])
            * np.maximum(np.abs(np.asarray(prepared.J, dtype=np.float64)), 1.0e-30)[:, None]
            * np.maximum(np.asarray(prepared.B, dtype=np.float64), 1.0e-30)[:, None]
        )
        phi_gradient = np.asarray(data.gradients["phi"], dtype=np.float64)
        local_source = np.sum(
            common * np.cross(phi_gradient, local_gradient), axis=-1
        )
        structured_source = np.sum(
            common * np.cross(phi_gradient, sampled_structured), axis=-1
        )
        source_difference = structured_source - local_source

        gradient_scale = _l2(local_gradient)
        source_scale = _l2(local_source)
        cases.append(
            {
                "resolution": resolution,
                "geometry_artifact": str(artifact_path.resolve()),
                "geometry_manifest_sha256": _sha256(artifact_path / "manifest.json"),
                "reference_cache": {
                    "path": str(cache_path.resolve()),
                    "sha256": _sha256(cache_path),
                },
                "sample_count": int(indices.shape[0]),
                "sampled_radial_indices": radial,
                "gradient": {
                    "absolute_l2": _l2(difference),
                    "relative_l2": _l2(difference) / max(gradient_scale, 1.0e-30),
                    "max_abs": float(np.max(np.abs(difference))),
                    "reference_l2": gradient_scale,
                },
                "bracket_source": {
                    "absolute_l2": _l2(source_difference),
                    "relative_l2": _l2(source_difference) / max(source_scale, 1.0e-30),
                    "max_abs": float(np.max(np.abs(source_difference))),
                    "reference_l2": source_scale,
                },
            }
        )
        print(
            json.dumps(
                {
                    "event": "case_complete",
                    "resolution": resolution,
                    "samples": int(indices.shape[0]),
                },
                sort_keys=True,
            ),
            flush=True,
        )

    resolutions = [case["resolution"] for case in cases]
    gradient_errors = [case["gradient"]["absolute_l2"] for case in cases]
    source_errors = [case["bracket_source"]["absolute_l2"] for case in cases]
    payload = {
        "schema": "drbx.hsx-structured-omega-differentiation-v1",
        "scope": (
            "bounded stratified actual-HSX midpoint comparison; uncertainty "
            "diagnostic for the corrected reference, not a production operator run"
        ),
        "resolutions": resolutions,
        "cases": cases,
        "gradient_absolute_orders": _orders(resolutions, gradient_errors),
        "bracket_source_absolute_orders": _orders(resolutions, source_errors),
        "eta_period_contract": {
            "analytic_mms": float(reference.eta_period),
            "continuous_evaluator": float(reference.metric_evaluator.period),
            "structured_period": float(2.0 * np.pi),
        },
        "production_changes": [],
    }
    _write(args.output, payload)
    print(args.output, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
