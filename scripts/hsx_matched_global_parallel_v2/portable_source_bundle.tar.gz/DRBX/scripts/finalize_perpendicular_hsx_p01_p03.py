#!/usr/bin/env python3
"""Finalize the supplemental actual-HSX P01--P03 evidence bundle."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def _load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _sha(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    args = parser.parse_args()
    bundle = args.bundle
    reference_path = bundle / "reference_reconstruction_summary.json"
    bracket_path = bundle / "bracket_summary.json"
    rhs_path = bundle / "perpendicular_rhs_summary.json"
    oracle_paths = [bundle / f"common_face_oracle_N{n}.json" for n in (32, 48, 64)]
    mechanism_paths = [
        bundle / "face_candidate_comparison_N32.json",
        bundle / "face_mechanism_controls_N48.json",
        bundle / "face_mechanism_controls_N64.json",
    ]
    candidate_contract_path = bundle / "face_candidate_contracts_N32.json"
    orientation_path = bundle / "face_candidate_orientation_N32_v2.json"
    reference = _load(reference_path)
    bracket = _load(bracket_path)
    rhs = _load(rhs_path) if rhs_path.is_file() else None
    oracles = [_load(path) for path in oracle_paths] if all(
        path.is_file() for path in oracle_paths
    ) else []
    mechanisms = [_load(path) for path in mechanism_paths] if all(
        path.is_file() for path in mechanism_paths
    ) else []
    candidate_contract = (
        _load(candidate_contract_path) if candidate_contract_path.is_file() else None
    )
    orientation = _load(orientation_path) if orientation_path.is_file() else None

    reference_changes = {
        name: max(series["values"])
        for name, series in reference["series"].items()
        if name.endswith("q4_to_q6_rms")
    }
    maximum_reference_name = max(reference_changes, key=reference_changes.get)
    maximum_reference_change = reference_changes[maximum_reference_name]
    pure = bracket["convergence"]["pure_scalar_upwind"]
    hstar = bracket["mass_weighted_H_transpose_convergence"][
        "pure_scalar_upwind"
    ]
    controls = bracket["operand_control_convergence"]
    records = {}
    for path in sorted(bundle.glob("*.json")):
        if path.name == "hsx_error_budget.json":
            continue
        records[path.name] = {"sha256": _sha(path)}
    root = Path(__file__).resolve().parents[1]
    payload = {
        "schema": "drbx.perpendicular-actual-hsx-p01-p03-final-v1",
        "revision": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=root, text=True
        ).strip(),
        "geometry_resolutions": [32, 48, 64],
        "fixed_reference_resolution": 64,
        "execution": "one substantial resolution per process",
        "boundary_contract": {
            "executed_physical_wall_model": "legacy-velocity-trace",
            "executed_selector_source": "frozen MMS production manifest",
            "pinned_roadmap_physical_wall_model": "legacy-velocity-trace",
            "parallel_velocity_wall_bc": "neumann",
            "neumann_ghost_scheme": "physical",
            "parallel_boundary_pairing": "characteristic-sat",
            "parallel_characteristic_wall_law": "energy-absorbing",
            "resolved_parallel_velocity_behavior": "owner-extrapolated Vi/Ve",
            "boundary_contract_identity_matches": True,
            "certification_reuse_status": "boundary selector identity preserved",
            "classification": "bounded diagnostic evidence",
            "note": (
                "This is the exact frozen MMS configuration. It is neither "
                "the no-flow wall nor the simple conducting sheath. Preserve "
                "the effective operator-specific closures and do not infer "
                "Bohm or exponential sheath traces from another rung label."
            ),
        },
        "records": records,
        "P01": {
            "status": "in progress",
            "actual_hsx": True,
            "qualification": reference["qualification"],
            "maximum_selected_q4_to_q6_change": maximum_reference_change,
            "maximum_selected_q4_to_q6_quantity": maximum_reference_name,
            "matched_reference_budget_status": "unresolved",
            "matched_reference_budget_reason": (
                "the selected source-quadrature change and the bracket error "
                "do not share a field, operator, units, weighting, or norm"
            ),
            "metric_spot_checks": [
                case["metric_spot_check"] for case in reference["cases"]
            ],
            "volume_spot_checks": [
                case["volume_check"] for case in reference["cases"]
            ],
        },
        "P02": {
            "status": "in progress",
            "reconstruction_max_global_physical_rms": [
                max(
                    field["global_physical_rms"]
                    for field in case["reconstruction"]["fields"].values()
                )
                for case in reference["cases"]
            ],
            "ordinary_bulk_relative_orders": pure["ordinary_bulk"][
                "relative_order"
            ],
            "raw_raw_transition_relative_order_32_to_64": controls[
                "raw_phi_raw_omega"
            ]["rlp_transition_rings"]["relative_order"][0],
            "earliest_unresolved_stage": (
                "near-axis advected-state owner-to-coordinate-face evaluation: "
                "the completed-residual 2x2 crosses improve sharply when only "
                "the advected face state is replaced"
            ),
            "required_next_reproducer": (
                "a bounded design review of the nonuniform degree-two candidate "
                "followed, only if justified, by full-domain physical-volume-"
                "weighted operator qualification; no production change is yet "
                "supported"
            ),
            "common_face_oracle": (
                {
                    "resolutions": [item["resolution"] for item in oracles],
                    "production_assembly_replay_max_abs": max(
                        item["quadrature_summary"][
                            "production_assembly_replay_max_abs"
                        ]
                        for item in oracles
                    ),
                    "maximum_q2_to_q4_effective_residual_change": [
                        item["quadrature_summary"][
                            "maximum_q2_to_q4_effective_residual_change"
                        ]
                        for item in oracles
                    ],
                    "production_minus_q4_absolute_rms": [
                        item["quadrature_summary"][
                            "production_minus_q4_absolute_rms"
                        ]
                        for item in oracles
                    ],
                    "weighted_flux_relative_rms": {
                        region: [
                            item["face_errors"][region][
                                "weighted_flux_relative_rms"
                            ]
                            for item in oracles
                        ]
                        for region in (
                            "radial_ring_0",
                            "radial_ring_1",
                            "radial_ring_2",
                            "radial_ring_3",
                            "non_axis_transition",
                            "ordinary_control",
                        )
                    },
                    "certification": (
                        "bounded sampled mechanism diagnostic, not a "
                        "full-domain qualification"
                    ),
                }
                if oracles else None
            ),
            "completed_residual_face_mechanism": (
                {
                    "resolutions": [item["resolution"] for item in mechanisms],
                    "regions": {
                        region: {
                            "production_baseline_relative_l2": [
                                item["completed_residual_cross_statistics"][
                                    "velocity_production__advected_production__center_production"
                                ][region]["relative_l2"]
                                for item in mechanisms
                            ],
                            "reference_velocity_only_relative_l2": [
                                item["completed_residual_cross_statistics"][
                                    "velocity_reference__advected_production__center_production"
                                ][region]["relative_l2"]
                                for item in mechanisms
                            ],
                            "reference_advected_state_only_relative_l2": [
                                item["completed_residual_cross_statistics"][
                                    "velocity_production__advected_reference__center_production"
                                ][region]["relative_l2"]
                                for item in mechanisms
                            ],
                            "reference_center_only_relative_l2": [
                                item["completed_residual_cross_statistics"][
                                    "velocity_production__advected_production__center_reference"
                                ][region]["relative_l2"]
                                for item in mechanisms
                            ],
                        }
                        for region in (
                            "radial_ring_0",
                            "radial_ring_1",
                            "radial_ring_2",
                            "radial_ring_3",
                            "non_axis_transition",
                            "ordinary_control",
                        )
                    },
                    "candidate_disabled_for_N48_N64": True,
                    "certification": (
                        "eight selected owners per resolution; causal mechanism "
                        "diagnostic, not a global operator norm or convergence order"
                    ),
                }
                if mechanisms else None
            ),
            "diagnostic_degree_two_face_candidate": (
                {
                    "contract_gate": candidate_contract[
                        "diagnostic_owner_polynomial_candidate"
                    ],
                    "N32_comparison": mechanisms[0][
                        "diagnostic_owner_polynomial_candidate"
                    ],
                    "decision": (
                        "basic contracts pass, but sampled MMS and smooth-scalar "
                        "residual changes are regionally mixed; retain as a "
                        "diagnostic candidate and do not promote"
                    ),
                }
                if candidate_contract is not None and mechanisms else None
            ),
            "candidate_orientation_followup": (
                {
                    "resolution": orientation["resolution"],
                    "scope": orientation["scope"],
                    "candidate_conditioning": orientation[
                        "candidate_conditioning"
                    ],
                    "maximum_axis_change_closure": {
                        name: field["maximum_axis_change_closure"]
                        for name, field in orientation["fields"].items()
                    },
                    "stage_statistics": {
                        name: field["stage_statistics"]
                        for name, field in orientation["fields"].items()
                    },
                    "signed_change_by_orientation": {
                        name: field["signed_change_by_orientation"]
                        for name, field in orientation["fields"].items()
                    },
                    "decision": (
                        "not promising: stop before full-domain qualification; "
                        "planar-only candidate leaves the first three omega ring "
                        "errors near unity and has mixed smooth-control regressions"
                    ),
                    "full_domain_runs_started": False,
                }
                if orientation is not None else None
            ),
        },
        "P03": {
            "status": "in progress",
            "production_transition_relative_orders": pure[
                "rlp_transition_rings"
            ]["relative_order"],
            "mass_weighted_Hstar_transition_relative_orders": hstar[
                "rlp_transition_rings"
            ]["relative_order"],
            "RH_identity_max_abs": max(
                case["reconstruction"]["RH_identity_max_abs"]
                for case in reference["cases"]
            ),
            "Hstar_adjoint_relative_mismatch": max(
                case["reconstruction"][
                    "mass_weighted_Hstar_adjoint_relative_mismatch"
                ]
                for case in reference["cases"]
            ),
            "constant_advected_state_max_abs": bracket["qualification"][
                "constant_advected_state_max_abs"
            ],
            "transition_direct_invalid_fraction": [
                case["contracts"]["transition_direct_invalid_fraction"]
                for case in bracket["cases"]
            ],
            "upwind_fallback_fraction": [
                case["contracts"]["upwind_fallback_fraction"]
                for case in bracket["cases"]
            ],
            "matched_frozen_rhs_term_series": (
                rhs["series"] if rhs is not None else None
            ),
            "matched_frozen_rhs_contract": (
                rhs["cases"][-1]["production_contract"]
                if rhs is not None else None
            ),
            "unresolved": [
                "bounded common-face oracle is sampled rather than full-domain",
                "degree-two diagnostic face candidate has mixed regional residual behavior and is not production-qualified",
                "orientation-correct planar candidate failed the bounded gate; no full-domain 32/48/64 qualification was launched",
                "curvature material/remainder and radial/theta/eta component split not exposed by the lean term ledger",
                "eta-shard endpoint parity not measured on this one-device host",
            ],
        },
        "P04_readiness": {
            "ready": False,
            "decision": (
                "Do not start P04 in this audit. Completed-residual crosses "
                "causally isolate the selected near-axis advected face state, "
                "but the orientation-correct degree-two planar candidate fails "
                "the bounded material-improvement/regression gate. The eta-plane "
                "mismatch is measured but does not dominate the selected omega "
                "residual. P01 lacks a matched full-domain "
                "reference budget, and P03 retains open certification gates."
            ),
        },
        "formula_changes": [],
    }
    output = bundle / "hsx_error_budget.json"
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
