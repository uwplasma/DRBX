#!/usr/bin/env python3
"""Emit P01 qualification evidence for perpendicular reference helpers."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np

from drbx.validation.perpendicular_reference import (
    error_statistics,
    geometry_reference_id,
    manufactured_field_catalogue,
    matching_boundary_data,
    physical_owner_reference,
    validate_region_masks,
)


def _json_value(value):
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    if isinstance(value, np.ndarray):
        return _json_value(value.tolist())
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    if isinstance(value, (np.integer, int)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        number = float(value)
        return number if np.isfinite(number) else None
    return value


def qualify(*, resolution: int = 12):
    faces = (
        np.linspace(0.0, 1.0, resolution + 1),
        np.linspace(0.0, 2.0 * np.pi, 2 * resolution + 1),
        np.linspace(0.0, 2.0 * np.pi, resolution + 1),
    )
    shape = tuple(len(face) - 1 for face in faces)
    aggregate_id = np.arange(np.prod(shape), dtype=np.int64).reshape(shape)
    active = np.ones(shape, dtype=bool)
    geometry_metadata = {
        "kind": "analytic_smooth_polar",
        "jacobian": "u*(1+0.1*u*cos(theta))",
        "domain": [[0.0, 1.0], [0.0, 2.0 * np.pi], [0.0, 2.0 * np.pi]],
        "periodic_axes": [False, True, True],
    }
    geometry_id = geometry_reference_id(geometry_metadata)

    def jacobian(points):
        u, theta = points[:, 0], points[:, 1]
        return u * (1.0 + 0.1 * u * np.cos(theta))

    fields = {}
    max_reference_change = 0.0
    for name, field in manufactured_field_catalogue().items():
        references = [
            physical_owner_reference(
                faces=faces,
                aggregate_id=aggregate_id,
                active_owner=active,
                jacobian=jacobian,
                field=field.value,
                source=field.laplacian_xy,
                quadrature_order=order,
                geometry_id=geometry_id,
            )
            for order in (2, 4, 8)
        ]
        volume = references[-1].volume

        def rms(attribute, left, right):
            difference = getattr(left, attribute) - getattr(right, attribute)
            return float(np.sqrt(
                np.sum(volume[active] * difference[active] ** 2)
                / np.sum(volume[active])
            ))

        field_2_8 = rms("field", references[0], references[2])
        field_4_8 = rms("field", references[1], references[2])
        source_2_8 = rms("source", references[0], references[2])
        source_4_8 = rms("source", references[1], references[2])
        max_reference_change = max(max_reference_change, field_4_8, source_4_8)
        fields[name] = {
            "family": field.family,
            "orders": [2, 4, 8],
            "field_rms_change_2_to_8": field_2_8,
            "field_rms_change_4_to_8": field_4_8,
            "source_rms_change_2_to_8": source_2_8,
            "source_rms_change_4_to_8": source_4_8,
            "field_refinement_ratio": (
                field_4_8 / field_2_8 if field_2_8 > 1.0e-30 else 0.0
            ),
            "source_refinement_ratio": (
                source_4_8 / source_2_8 if source_2_8 > 1.0e-30 else 0.0
            ),
            "midpoint_field_rms_difference": rms(
                "field",
                references[-1],
                type("Midpoint", (), {"field": references[-1].midpoint_field_control})(),
            ),
            "geometry_reference_ids": sorted({
                reference.geometry_reference_id for reference in references
            }),
        }

    wall_points = np.stack(
        (
            np.ones(16),
            np.linspace(0.0, 2.0 * np.pi, 16, endpoint=False),
            np.linspace(0.0, 2.0 * np.pi, 16, endpoint=False),
        ),
        axis=-1,
    )
    theta = wall_points[:, 1]
    wall_normals = np.stack((np.cos(theta), np.sin(theta), np.zeros_like(theta)), axis=-1)
    boundary = {
        name: {
            key: float(np.max(np.abs(value)))
            for key, value in matching_boundary_data(field, wall_points, wall_normals).items()
        }
        for name, field in manufactured_field_catalogue().items()
    }

    axis = np.zeros(shape, dtype=bool); axis[0] = True
    wall = np.zeros(shape, dtype=bool); wall[-1] = True
    seam = np.zeros(shape, dtype=bool); seam[:, 0] = True
    ordinary = active & ~axis & ~wall & ~seam
    partition = {
        "axis": axis,
        "physical_wall": wall & ~axis,
        "seam": seam & ~axis & ~wall,
        "ordinary_interior": ordinary,
    }
    mask_validation = validate_region_masks(
        active=active,
        diagnostic_masks={"axis": axis, "wall": wall, "seam": seam},
        partition_masks=partition,
    )
    synthetic_error = np.indices(shape).sum(axis=0) / float(sum(shape))
    region_statistics = error_statistics(
        synthetic_error,
        np.zeros(shape),
        np.ones(shape),
        partition,
    )

    midpoint_refinement = {}
    for field_name in ("x", "x2", "smooth_nonpolynomial"):
        field = manufactured_field_catalogue()[field_name]
        errors = []
        resolutions = (4, 8, 16)
        for count in resolutions:
            local_faces = (
                np.linspace(0.0, 1.0, count + 1),
                np.linspace(0.0, 2.0 * np.pi, 2 * count + 1),
                np.linspace(0.0, 2.0 * np.pi, count + 1),
            )
            local_shape = tuple(len(face) - 1 for face in local_faces)
            local_ids = np.arange(np.prod(local_shape), dtype=np.int64).reshape(
                local_shape
            )
            local_active = np.ones(local_shape, dtype=bool)
            reference = physical_owner_reference(
                faces=local_faces,
                aggregate_id=local_ids,
                active_owner=local_active,
                jacobian=lambda q: q[:, 0],
                field=field.value,
                source=field.laplacian_xy,
                quadrature_order=4,
                geometry_id="identity-polar-fixed",
            )
            difference = reference.midpoint_field_control - reference.field
            errors.append(float(np.sqrt(
                np.sum(reference.volume[local_active] * difference[local_active] ** 2)
                / np.sum(reference.volume[local_active])
            )))
        orders = [
            math.log(errors[index] / errors[index + 1])
            / math.log(resolutions[index + 1] / resolutions[index])
            for index in range(len(errors) - 1)
        ]
        midpoint_refinement[field_name] = {
            "resolutions": list(resolutions),
            "rms_difference_from_physical_average": errors,
            "observed_orders": orders,
        }
    return {
        "schema": "drbx.perpendicular-reference-qualification-v1",
        "hypothesis": (
            "tensor Gauss integration of independently supplied fields and "
            "sources converges while midpoint controls remain separately labelled"
        ),
        "geometry_reference": geometry_metadata,
        "geometry_reference_id": geometry_id,
        "resolution": resolution,
        "fields": fields,
        "matching_boundary_max_abs": boundary,
        "mask_validation": mask_validation,
        "regional_error_example": region_statistics,
        "midpoint_refinement": midpoint_refinement,
        "max_order4_to_order8_reference_change": max_reference_change,
        "later_spatial_error_required_for_ten_percent_budget": 10.0 * max_reference_change,
        "qualification": {
            "single_geometry_reference": all(
                len(item["geometry_reference_ids"]) == 1 for item in fields.values()
            ),
            "quadrature_converged": all(
                item["field_refinement_ratio"] < 0.1
                and item["source_refinement_ratio"] < 0.1
                for item in fields.values()
            ),
            "partition_valid": mask_validation["partition_is_disjoint_and_complete"],
            "midpoint_controls_are_labelled_only": True,
            "midpoint_difference_is_second_order": all(
                min(item["observed_orders"]) >= 1.8
                for item in midpoint_refinement.values()
            ),
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--resolution", type=int, default=4,
        help="Small analytic fixture only; this is not a full-HSX quadrature lane.",
    )
    args = parser.parse_args()
    payload = qualify(resolution=args.resolution)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(_json_value(payload), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(payload["qualification"], sort_keys=True))


if __name__ == "__main__":
    main()
