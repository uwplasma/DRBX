#!/usr/bin/env python3
"""Checkpointed launcher for the authorized corrected-reference P03 workflow."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from typing import Any


COMMON_SCHEMA = "hsx-poisson-common-face-oracle-v2"
BASELINE_SCHEMA = "drbx.hsx-poisson-continuous-baseline-v1"
MATCHED_SCHEMA = "hsx-face-candidate-orientation-v1"


def _atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def _load_valid(path: Path, schema: str, *, resolution: int | None = None) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if payload.get("schema") != schema:
        return None
    if resolution is not None and int(payload.get("resolution", -1)) != resolution:
        return None
    return payload


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _event(stage: str, **details: Any) -> None:
    print(
        json.dumps(
            {"event": "workflow", "stage": stage, "unix_time": time.time(), **details},
            sort_keys=True,
        ),
        flush=True,
    )


def _run(stage: str, command: list[str], checkpoint: dict[str, Any], checkpoint_path: Path) -> None:
    _event("stage_start", name=stage, command=command)
    started = time.perf_counter()
    result = subprocess.run(command, check=False)
    elapsed = time.perf_counter() - started
    checkpoint.setdefault("stages", {})[stage] = {
        "exit_code": int(result.returncode),
        "elapsed_seconds": elapsed,
        "completed_unix_time": time.time(),
    }
    _atomic_json(checkpoint_path, checkpoint)
    _event("stage_exit", name=stage, exit_code=result.returncode, elapsed_seconds=elapsed)
    if result.returncode != 0:
        raise RuntimeError(f"stage {stage!r} failed with exit code {result.returncode}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--current-pid", type=int, required=True)
    parser.add_argument("--geometry", type=Path, required=True)
    parser.add_argument("--reference-sidecar", type=Path, required=True)
    parser.add_argument("--common-output", type=Path, required=True)
    parser.add_argument("--saved-selection", type=Path, required=True)
    parser.add_argument("--geometric-artifact", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    checkpoint_path = output / "workflow_checkpoint.json"
    lock_path = output / "workflow.lock"
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"workflow lock already exists: {lock_path}") from error
    os.write(descriptor, f"pid={os.getpid()}\n".encode())
    os.close(descriptor)

    checkpoint: dict[str, Any] = {
        "schema": "drbx.hsx-p03-corrected-workflow-v1",
        "launcher_pid": os.getpid(),
        "waited_process_pid": int(args.current_pid),
        "geometry": str(args.geometry.resolve()),
        "reference_sidecar": str(args.reference_sidecar.resolve()),
        "stages": {},
    }
    _atomic_json(checkpoint_path, checkpoint)
    python = sys.executable
    baseline = Path(__file__).resolve().with_name(
        "audit_hsx_poisson_continuous_baseline.py"
    )
    matched = Path(__file__).resolve().with_name(
        "audit_hsx_face_candidate_orientation.py"
    )
    try:
        _event("wait_existing_common_face", pid=args.current_pid)
        while _alive(args.current_pid):
            time.sleep(30.0)
        common = _load_valid(args.common_output, COMMON_SCHEMA, resolution=32)
        if common is None:
            raise RuntimeError(
                "existing common-face process exited without a valid atomic output"
            )
        checkpoint["stages"]["common_face"] = {
            "reused_completed_output": str(args.common_output.resolve()),
            "completed_unix_time": time.time(),
        }
        _atomic_json(checkpoint_path, checkpoint)
        _event("common_face_validated", output=str(args.common_output))

        preflight_path = output / "preflight.json"
        if _load_valid(preflight_path, "drbx.hsx-poisson-continuous-preflight-v1") is None:
            _run(
                "preflight",
                [
                    python,
                    "-u",
                    str(baseline),
                    "preflight",
                    "--geometry",
                    str(args.geometry.resolve()),
                    "--reference-sidecar",
                    str(args.reference_sidecar.resolve()),
                    "--time",
                    "1e-6",
                    "--output",
                    str(preflight_path),
                ],
                checkpoint,
                checkpoint_path,
            )

        case_paths: dict[int, Path] = {}
        for resolution in (32,):
            case_path = output / f"N{resolution}.json"
            cache_path = output / f"N{resolution}.reference.npz"
            case_paths[resolution] = case_path
            if _load_valid(case_path, BASELINE_SCHEMA, resolution=resolution) is None:
                _run(
                    f"baseline_N{resolution}",
                    [
                        python,
                        "-u",
                        str(baseline),
                        "case",
                        "--geometry",
                        str(args.geometry.resolve()),
                        "--reference-sidecar",
                        str(args.reference_sidecar.resolve()),
                        "--resolution",
                        str(resolution),
                        "--time",
                        "1e-6",
                        "--reference-cache",
                        str(cache_path),
                        "--output",
                        str(case_path),
                    ],
                    checkpoint,
                    checkpoint_path,
                )
            case = _load_valid(case_path, BASELINE_SCHEMA, resolution=resolution)
            if case is None or not cache_path.is_file():
                raise RuntimeError("N32 baseline/cache checkpoint validation failed")
            timing = case.get("timings_seconds", {})
            observed = float(timing.get("total_before_json_output", 0.0))
            checkpoint["provisional_estimate_seconds"] = {
                "N48_from_N32_cubic": observed * (48.0 / 32.0) ** 3,
                "N64_from_N32_cubic": observed * (64.0 / 32.0) ** 3,
                "uncertainty": "provisional cubic workload scaling; compilation and cache reuse are noncubic",
            }
            _atomic_json(checkpoint_path, checkpoint)

        matched_path = output.parent / "face_candidate_matched_functional_N32.json"
        if _load_valid(matched_path, MATCHED_SCHEMA, resolution=32) is None:
            _run(
                "matched_functional_N32",
                [
                    python,
                    "-u",
                    str(matched),
                    "--geometry",
                    str(args.geometry.resolve()),
                    "--saved-n32",
                    str(args.saved_selection.resolve()),
                    "--reference-sidecar",
                    str(args.reference_sidecar.resolve()),
                    "--reference-cache",
                    str(output / "N32.reference.npz"),
                    "--reuse-geometric-artifact",
                    str(args.geometric_artifact.resolve()),
                    "--compare-midpoint-functional",
                    "--time",
                    "1e-6",
                    "--output",
                    str(matched_path),
                ],
                checkpoint,
                checkpoint_path,
            )

        for resolution in (48, 64):
            case_path = output / f"N{resolution}.json"
            cache_path = output / f"N{resolution}.reference.npz"
            case_paths[resolution] = case_path
            if _load_valid(case_path, BASELINE_SCHEMA, resolution=resolution) is None:
                _run(
                    f"baseline_N{resolution}",
                    [
                        python,
                        "-u",
                        str(baseline),
                        "case",
                        "--geometry",
                        str(args.geometry.resolve()),
                        "--reference-sidecar",
                        str(args.reference_sidecar.resolve()),
                        "--resolution",
                        str(resolution),
                        "--time",
                        "1e-6",
                        "--reference-cache",
                        str(cache_path),
                        "--output",
                        str(case_path),
                    ],
                    checkpoint,
                    checkpoint_path,
                )

        summary_path = output / "summary.json"
        _run(
            "baseline_summary",
            [
                python,
                "-u",
                str(baseline),
                "merge",
                str(case_paths[32]),
                str(case_paths[48]),
                str(case_paths[64]),
                "--output",
                str(summary_path),
            ],
            checkpoint,
            checkpoint_path,
        )
        checkpoint["status"] = "complete"
        _atomic_json(checkpoint_path, checkpoint)
        _event("workflow_complete", summary=str(summary_path), matched=str(matched_path))
        return 0
    except Exception as error:
        checkpoint["status"] = "failed"
        checkpoint["error"] = f"{type(error).__name__}: {error}"
        _atomic_json(checkpoint_path, checkpoint)
        _event("workflow_failed", error=checkpoint["error"])
        return 1
    finally:
        try:
            lock_path.unlink()
        except FileNotFoundError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
