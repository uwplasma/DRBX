#!/usr/bin/env python3
"""One-resolution actual-HSX frozen perpendicular RHS/curvature audit.

The production MMS driver normally chooses its continuum reference from the
largest requested resolution.  This wrapper deliberately runs one resolution
per process while always loading the immutable 64^3 reference artifact.  It
serializes compact term and regional diagnostics only; no formula is changed.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
from typing import Any, Mapping, Sequence

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import simulate_hsx_blob as blob  # noqa: E402
import simulate_hsx_mms as mms  # noqa: E402
from hsx_mms_continuum_reference import (  # noqa: E402
    build_continuum_reference_from_artifact,
)


SCHEMA = "drbx.actual-hsx-perpendicular-frozen-rhs-v1"


def _json_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_value(item) for item in value]
    if isinstance(value, np.ndarray):
        return _json_value(value.tolist())
    if isinstance(value, (np.floating, float)):
        number = float(value)
        return number if np.isfinite(number) else None
    if isinstance(value, (np.integer, int)):
        return int(value)
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    return value


def _write(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(_json_value(payload), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _orders(resolutions, values):
    result = []
    for nc, nf, coarse, fine in zip(
        resolutions[:-1], resolutions[1:], values[:-1], values[1:]
    ):
        if coarse is None or fine is None or coarse <= 0.0 or fine <= 0.0:
            result.append(None)
        else:
            result.append(float(np.log(coarse / fine) / np.log(nf / nc)))
    return result


def run_case(args: argparse.Namespace) -> dict[str, Any]:
    selector_args = mms._production_selector_args()
    blob._validate_flux_framework(selector_args)
    blob._configure_runtime_selectors(selector_args)
    artifact = mms._load_geometry_for_resolution(args.geometry, args.resolution)
    reference_artifact = mms._load_geometry_for_resolution(
        args.geometry, args.reference_resolution
    )
    reference = build_continuum_reference_from_artifact(
        reference_artifact,
        tau=mms.PHYSICAL_PARAMETERS["tau"],
        mi_over_me=mms.PHYSICAL_PARAMETERS["mi_over_me"],
        rho_star=mms.PHYSICAL_PARAMETERS["rho_star"],
        Ve_nu=mms.PHYSICAL_PARAMETERS["Ve_nu"],
        perp_diffusion=mms.PHYSICAL_PARAMETERS["density_D_perp"],
        enable_generalized_potential=True,
    )
    case_args = SimpleNamespace(
        shard_counts=(1, 1, 1),
        curvature_edge_one_form=(
            getattr(artifact, "curvature_edge_one_form", None) is not None
        ),
        reference=reference,
        metric_context=SimpleNamespace(
            metric_evaluator=reference.metric_evaluator,
            bfield=reference.bfield_evaluator,
            nfp=int(reference_artifact.nfp),
        ),
        time=float(args.time),
        dt=1.0e-6,
        output=args.output.with_suffix(".scratch.npz"),
        advance_execution="compiled",
        skip_counterfactuals=True,
        _owner_geometry=artifact.owner_geometry,
    )
    result = mms._audit_one(
        artifact.global_geometry,
        artifact.cell_positions,
        int(artifact.nfp),
        case_args,
        curvature_edge_one_form=getattr(
            artifact, "curvature_edge_one_form", None
        ),
        simulation_geometry=artifact,
    )
    term_names = [list(names) for names in blob.RHS_TERM_NAMES]
    field_names = list(blob.RHS_TERM_FIELD_NAMES)
    term_errors = np.asarray(result["rhs_term_error_norms"])
    selected_terms: dict[str, Any] = {}
    for field_index, field in enumerate(field_names):
        selected_terms[field] = {
            name: float(term_errors[field_index, slot])
            for slot, name in enumerate(term_names[field_index])
            if name in {"poisson_bracket", "curvature", "perpendicular_diffusion"}
        }
    regional_selected: dict[str, Any] = {}
    for region, values in result["partitioned_rhs_term_error_norms"].items():
        array = np.asarray(values)
        regional_selected[region] = {
            field: {
                name: float(array[field_index, slot])
                for slot, name in enumerate(term_names[field_index])
                if name
                in {"poisson_bracket", "curvature", "perpendicular_diffusion"}
            }
            for field_index, field in enumerate(field_names)
        }
    payload = {
        "schema": SCHEMA,
        "resolution": int(args.resolution),
        "reference_resolution": int(args.reference_resolution),
        "geometry_artifact": str(args.geometry),
        "execution": "single-device; one resolution per process; frozen production RHS",
        "counterfactuals_enabled": bool(result["counterfactuals_enabled"]),
        "frozen_stage_graph_contract": result["frozen_stage_graph_contract"],
        "field_names": field_names,
        "term_names": term_names,
        "selected_global_term_error_norms": selected_terms,
        "selected_regional_term_error_norms": regional_selected,
        "region_cell_counts": result["region_cell_counts"],
        "region_volumes": result["region_volumes"],
        "region_volume_fractions": result["region_volume_fractions"],
        "representation_error": result["representation_error"],
        "rlp_reconstruction_diagnostics": result[
            "rlp_reconstruction_diagnostics"
        ],
        "exact_phi_residual": result["exact_phi_residual"],
        "source_increment": result["source_increment"],
        "phi_reconstruction_difference": result[
            "phi_reconstruction_difference"
        ],
        "phi_converged": result["phi_converged"],
        "phi_failed": result["phi_failed"],
        "production_contract": mms._production_configuration(
            (1, 1, 1),
            1,
            curvature_edge_one_form=bool(case_args.curvature_edge_one_form),
            geometry_metadata=artifact.metadata,
        ),
        "scope": {
            "common_quadrature_curvature": (
                "current lean production radial payload; no collapsed averaged-state substitution"
            ),
            "counterfactual_crosses": (
                "companion operator-only bracket audit; omitted here to bound memory"
            ),
            "no_formula_changes": True,
        },
    }
    _write(args.output, payload)
    return payload


def summarize(cases: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    ordered = sorted(cases, key=lambda item: int(item["resolution"]))
    resolutions = [int(item["resolution"]) for item in ordered]
    series = {}
    for field in ordered[0]["field_names"]:
        names = sorted(
            set.intersection(
                *(
                    set(case["selected_global_term_error_norms"][field])
                    for case in ordered
                )
            )
        )
        for name in names:
            values = [
                case["selected_global_term_error_norms"][field][name]
                for case in ordered
            ]
            series[f"{field}/{name}"] = {
                "errors": values,
                "orders": _orders(resolutions, values),
            }
    return {
        "schema": SCHEMA,
        "resolutions": resolutions,
        "series": series,
        "cases": ordered,
    }


def run_campaign(args: argparse.Namespace) -> dict[str, Any]:
    args.output.mkdir(parents=True, exist_ok=True)
    paths = []
    for resolution in args.resolutions:
        path = args.output / f"perpendicular_rhs_N{resolution}.json"
        subprocess.run(
            [
                sys.executable,
                str(Path(__file__).resolve()),
                "case",
                "--geometry",
                str(args.geometry),
                "--resolution",
                str(resolution),
                "--reference-resolution",
                str(args.reference_resolution),
                "--time",
                str(args.time),
                "--output",
                str(path),
            ],
            check=True,
        )
        paths.append(path)
    payload = summarize(
        [json.loads(path.read_text(encoding="utf-8")) for path in paths]
    )
    payload["campaign"] = {"one_resolution_per_process": True}
    _write(args.output / "perpendicular_rhs_summary.json", payload)
    return payload


def merge_cases(args: argparse.Namespace) -> dict[str, Any]:
    payload = summarize(
        [json.loads(path.read_text(encoding="utf-8")) for path in args.inputs]
    )
    payload["campaign"] = {"one_resolution_per_process": True}
    _write(args.output, payload)
    return payload


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="command", required=True)
    case = subs.add_parser("case")
    case.add_argument("--geometry", type=Path, required=True)
    case.add_argument("--resolution", type=int, required=True)
    case.add_argument("--reference-resolution", type=int, default=64)
    case.add_argument("--time", type=float, default=1.0e-6)
    case.add_argument("--output", type=Path, required=True)
    case.set_defaults(handler=run_case)
    campaign = subs.add_parser("campaign")
    campaign.add_argument("--geometry", type=Path, required=True)
    campaign.add_argument("--resolutions", type=int, nargs="+", default=(32, 48, 64))
    campaign.add_argument("--reference-resolution", type=int, default=64)
    campaign.add_argument("--time", type=float, default=1.0e-6)
    campaign.add_argument("--output", type=Path, required=True)
    campaign.set_defaults(handler=run_campaign)
    merge = subs.add_parser("merge")
    merge.add_argument("inputs", type=Path, nargs="+")
    merge.add_argument("--output", type=Path, required=True)
    merge.set_defaults(handler=merge_cases)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    args.handler(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
