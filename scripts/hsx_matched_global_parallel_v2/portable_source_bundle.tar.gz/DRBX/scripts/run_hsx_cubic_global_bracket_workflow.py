#!/usr/bin/env python3
"""Checkpointed N32/N48/N64 balanced-cubic global bracket workflow."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from typing import Any


WORKFLOW_SCHEMA = "drbx.hsx-balanced-cubic-global-workflow-v1"
CASE_SCHEMA = "drbx.hsx-balanced-cubic-global-bracket-case-v2"
SUMMARY_SCHEMA = "drbx.hsx-balanced-cubic-global-bracket-summary-v2"
DERIVATIVE_SCHEMA = "drbx.hsx-balanced-cubic-global-derivative-v1"


def _atomic(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def _valid(path: Path, schema: str, *, resolution: int | None = None, status: str | None = None):
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if payload.get("schema") != schema:
        return None
    if resolution is not None and int(payload.get("resolution", payload.get("identity", {}).get("resolution", -1))) != resolution:
        return None
    if status is not None and payload.get("status") != status:
        return None
    return payload


def _event(stage: str, **details: Any) -> None:
    print(json.dumps({"event": "cubic_workflow", "stage": stage, "unix_time": time.time(), **details}, sort_keys=True), flush=True)


def _run(
    name: str,
    command: list[str],
    checkpoint: dict[str, Any],
    checkpoint_path: Path,
    log_root: Path,
) -> None:
    log_path = log_root / f"{name}.log"
    _event("stage_start", name=name, command=command, log=str(log_path))
    started = time.perf_counter()
    with log_path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps({"event": "stage_start", "command": command, "unix_time": time.time()}) + "\n")
        stream.flush()
        cache_dir = log_root.parent / "jax_cache"
        cache_dir.mkdir(exist_ok=True)
        environment = {**os.environ, "DRBX_CACHE_DIR": str(cache_dir.resolve())}
        result = subprocess.run(
            command,
            stdout=stream,
            stderr=subprocess.STDOUT,
            check=False,
            env=environment,
        )
        stream.write(json.dumps({"event": "stage_exit", "exit_code": result.returncode, "unix_time": time.time()}) + "\n")
    elapsed = time.perf_counter() - started
    checkpoint.setdefault("stages", {})[name] = {
        "exit_code": int(result.returncode),
        "elapsed_seconds": elapsed,
        "log": str(log_path.resolve()),
        "completed_unix_time": time.time(),
    }
    _atomic(checkpoint_path, checkpoint)
    _event("stage_exit", name=name, exit_code=result.returncode, elapsed_seconds=elapsed)
    if result.returncode != 0:
        raise RuntimeError(f"stage {name} failed with exit code {result.returncode}; see {log_path}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--geometry", type=Path, required=True)
    parser.add_argument("--reference-sidecar", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--p04-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=256)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    log_root = output / "logs"
    log_root.mkdir(exist_ok=True)
    checkpoint_path = output / "workflow_checkpoint.json"
    lock_path = output / "workflow.lock"
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"workflow lock already exists: {lock_path}") from error
    os.write(descriptor, f"pid={os.getpid()}\n".encode())
    os.close(descriptor)
    prior = _valid(checkpoint_path, WORKFLOW_SCHEMA)
    checkpoint = prior or {
        "schema": WORKFLOW_SCHEMA,
        "geometry": str(args.geometry.resolve()),
        "reference_sidecar": str(args.reference_sidecar.resolve()),
        "baseline": str(args.baseline.resolve()),
        "p04_root": str(args.p04_root.resolve()),
        "output": str(output),
        "stages": {},
    }
    checkpoint.update({"status": "running", "launcher_pid": os.getpid()})
    checkpoint.pop("error", None)
    _atomic(checkpoint_path, checkpoint)
    derivative = Path(__file__).resolve().with_name("audit_hsx_cubic_derivative_global.py")
    bracket = Path(__file__).resolve().with_name("audit_hsx_cubic_global_bracket.py")
    python = sys.executable
    derivative_root = output / "derivatives"
    try:
        case_paths = []
        for resolution in (32, 48, 64):
            derivative_case = derivative_root / f"N{resolution}"
            derivative_manifest = derivative_case / "manifest.json"
            if _valid(derivative_manifest, DERIVATIVE_SCHEMA, resolution=resolution, status="complete") is None:
                _run(
                    f"derivative_N{resolution}",
                    [
                        python, "-u", str(derivative), "build",
                        "--resolution", str(resolution),
                        "--geometry", str(args.geometry.resolve()),
                        "--baseline", str(args.baseline.resolve()),
                        "--output", str(derivative_case),
                        "--batch-size", str(args.batch_size),
                    ],
                    checkpoint, checkpoint_path, log_root,
                )
            derivative_payload = _valid(
                derivative_manifest, DERIVATIVE_SCHEMA,
                resolution=resolution, status="complete",
            )
            if derivative_payload is None:
                raise RuntimeError(f"N{resolution} derivative build is incomplete")
            checkpoint.setdefault("derivative", {})[str(resolution)] = {
                "manifest": str(derivative_manifest.resolve()),
                "statistics": derivative_payload["statistics"],
                "total_seconds": derivative_payload["total_seconds"],
            }
            _atomic(checkpoint_path, checkpoint)

            case_path = output / f"N{resolution}.json"
            case_paths.append(case_path)
            if _valid(case_path, CASE_SCHEMA, resolution=resolution) is None:
                _run(
                    f"case_N{resolution}",
                    [
                        python, "-u", str(bracket), "case",
                        "--geometry", str(args.geometry.resolve()),
                        "--reference-sidecar", str(args.reference_sidecar.resolve()),
                        "--baseline", str(args.baseline.resolve()),
                        "--p04-root", str(args.p04_root.resolve()),
                        "--derivative-root", str(derivative_root),
                        "--resolution", str(resolution),
                        "--time", "1e-6",
                        "--output", str(output),
                    ],
                    checkpoint, checkpoint_path, log_root,
                )
            case_payload = _valid(case_path, CASE_SCHEMA, resolution=resolution)
            if case_payload is None:
                raise RuntimeError(f"N{resolution} bracket case is incomplete")
            checkpoint.setdefault("case", {})[str(resolution)] = {
                "path": str(case_path.resolve()),
                "timings_seconds": case_payload["timings_seconds"],
                "maximum_rss_gib": case_payload["resources"]["maximum_rss_gib"],
            }
            _atomic(checkpoint_path, checkpoint)

        summary = output / "summary.json"
        _run(
            "merge",
            [
                python, "-u", str(bracket), "merge",
                *(str(path) for path in case_paths),
                "--output", str(summary),
            ],
            checkpoint, checkpoint_path, log_root,
        )
        if _valid(summary, SUMMARY_SCHEMA) is None:
            raise RuntimeError("merge did not produce a valid summary")
        checkpoint.update({
            "status": "complete",
            "summary": str(summary.resolve()),
            "report": str(summary.with_name("report.md").resolve()),
            "completed_unix_time": time.time(),
        })
        _atomic(checkpoint_path, checkpoint)
        _event("workflow_complete", summary=str(summary), report=checkpoint["report"])
        return 0
    except Exception as error:
        checkpoint.update({
            "status": "failed",
            "error": f"{type(error).__name__}: {error}",
            "failed_unix_time": time.time(),
        })
        _atomic(checkpoint_path, checkpoint)
        _event("workflow_failed", error=checkpoint["error"])
        return 1
    finally:
        try:
            lock_path.unlink()
        except FileNotFoundError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
