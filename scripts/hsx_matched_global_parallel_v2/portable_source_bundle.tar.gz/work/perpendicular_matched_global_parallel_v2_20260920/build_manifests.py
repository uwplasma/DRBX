#!/usr/bin/env python3
"""Build content-addressed source and input manifests for portable transfer."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def atomic(path: Path, value: Any) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def files_under(root: Path, relative: str) -> list[tuple[str, Path]]:
    logical = root / relative
    actual = logical.resolve()
    if actual.is_file():
        return [(relative, actual)]
    return [
        ((Path(relative) / path.relative_to(actual)).as_posix(), path)
        for path in sorted(actual.rglob("*"))
        if path.is_file() and "__pycache__" not in path.parts and not path.name.endswith((".pyc", ".pyo"))
    ]


def record(logical: str, path: Path, *, known_sha256: str | None = None) -> dict[str, Any]:
    return {
        "path": logical,
        "bytes": path.stat().st_size,
        "sha256": known_sha256 or sha256(path),
        "hash_verification": "qualified-sidecar" if known_sha256 else "computed-full",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    source_groups = [
        "DRBX/src/drbx", "DRBX/scripts", "DRBX/simulate_hsx_blob.py",
        "DRBX/simulate_hsx_mms.py", "DRBX/hsx_mms_continuum_reference.py",
        "DRBX/pyproject.toml",
    ]
    numerical_sources = []
    for group in source_groups:
        numerical_sources.extend(record(logical, path) for logical, path in files_under(root, group))
    frozen = HERE / "frozen_numerics_v2.py"
    numerical_sources.append(record((Path("work") / HERE.name / frozen.name).as_posix(), frozen))
    orchestration_sources = []
    for name in (
        "parallel_runner.py", "portable_configuration.json", "build_manifests.py",
        "environment.yml", "README.md", "qualification_summary.json",
    ):
        path = HERE / name
        if path.is_file():
            orchestration_sources.append(record((Path("work") / HERE.name / name).as_posix(), path))
    numerical_sources = sorted(numerical_sources, key=lambda item: item["path"])
    orchestration_sources = sorted(orchestration_sources, key=lambda item: item["path"])
    source_content = {
        "files_sha256": digest(numerical_sources), "file_count": len(numerical_sources),
        "bytes": sum(x["bytes"] for x in numerical_sources),
    }
    execution_content = {
        "files_sha256": digest(numerical_sources + orchestration_sources),
        "file_count": len(numerical_sources) + len(orchestration_sources),
        "bytes": sum(x["bytes"] for x in numerical_sources + orchestration_sources),
    }
    atomic(HERE / "source_manifest.json", {
        "schema": "drbx.hsx-matched-cubic-source-manifest-v2",
        "git_commit": "6c2b005d81d353280cdaed7b5bf0dd67cb9d1035",
        "dirty_snapshot": True,
        "content_identity": source_content,
        "execution_content_identity": execution_content,
        "numerical_files": numerical_sources,
        "orchestration_files": orchestration_sources,
    })

    sidecar_path = root / "DRBX/work/perpendicular_second_order_hsx_p01_p03/continuous_reference_sidecar.json"
    sidecar = json.loads(sidecar_path.read_text())
    input_groups = [
        "geometry_artifacts/rlp_convergence_32_48_64_20260917/32x32x32",
        "geometry_artifacts/rlp_convergence_32_48_64_20260917/48x48x48",
        "geometry_artifacts/rlp_convergence_32_48_64_20260917/64x64x64",
        "DRBX/work/perpendicular_second_order_hsx_p01_p03/continuous_global_baseline",
        "DRBX/work/perpendicular_second_order_hsx_p01_p03/continuous_reference_sidecar.json",
        "work/perpendicular_cubic_global_qualification_20260920/derivatives",
        "work/perpendicular_bracket_reference_requalification_20260920",
        "work/perpendicular_matched_face_volume_20260920",
        "work/perpendicular_face_factor_audit_20260920",
        "work/perpendicular_value_derivative_cross_20260920",
        "hsx_metric_d58d392545fd3917efeb83b6.npz",
    ]
    inputs = []
    for group in input_groups:
        inputs.extend(record(logical, path) for logical, path in files_under(root, group))
    makegrid = root / "mgrid_res2p5cm_180pln.nc"
    if makegrid.stat().st_size != int(sidecar["makegrid"]["size"]):
        raise ValueError("MAKEGRID size differs from qualified sidecar")
    inputs.append(record("mgrid_res2p5cm_180pln.nc", makegrid, known_sha256=sidecar["makegrid"]["sha256"]))
    inputs = sorted(inputs, key=lambda item: item["path"])
    input_content = {"files_sha256": digest(inputs), "file_count": len(inputs), "bytes": sum(x["bytes"] for x in inputs)}
    atomic(HERE / "input_manifest.json", {
        "schema": "drbx.hsx-matched-cubic-input-manifest-v2",
        "content_identity": input_content,
        "notes": {"makegrid_hash": "full SHA-256 inherited from the qualified reference sidecar; size rechecked locally"},
        "files": inputs,
    })
    print(json.dumps({"source": source_content, "inputs": input_content}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
