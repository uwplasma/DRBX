# Q07 compact C3 integration with regenerated traces

**Decision:** C3 is suitable for a larger matched operator qualification, with explicit localized accuracy exceptions retained. This bounded comparison is not production promotion or a global convergence-order result.

46 complete owners at N32/N48/N64: all 42 prior core/first-ring/inner/last-aggregate/transition/bulk/hotspot-neighbor/wall sites plus four unique N48 owners nearest the six predetermined native-phi knots/seam in physical Cartesian distance. Two knot requests share owners and were deduplicated. Selected raw IDs and physical owner anchors were saved before evaluating errors; `selected_raw_coordinates.npz` expands the immutable IDs to all member coordinates. All 22 manufactured states, five fields, four uniform/mixed D/physical-normal-N combinations and h/32,h/128 are included.

Each method has its own fresh CPU-x64 RK4-64 endpoints and all nine trace diagnostics. Inner total separation is h/d, delta=h/(2d); outer separation is 2h/d and slots are (-2,-1,0,1,2)delta. Candidate C3 reads identical raw MAKEGRID bytes/current values with R/Z-only filtering. The old evaluator retains its baseline coefficient arrays through a type-container adapter. Imports record the new library magnetic class and unchanged portable frozen Q classes separately. The fixed vendored metric/JAX metric map is shared.

N reconstructs actual complete-owner state averages and prescribed boundary data. O uses exact manufactured slots at those same evaluator-specific points with the same algebra and magnetic factors. R is the corresponding complete-owner continuum midpoint restriction using the same evaluator. The correction continuum target is zero. B, b, b_eta, caps, characteristic factors, div(b)/balanced tube factors and physical-normal wall data are recomputed; div(B) is measured and retained. Each evaluator’s R and R_C3−R_old are saved because the backgrounds differ numerically.

## Smooth hotspot: actual reconstructed error

N48 native hotspot, uniform D, combined absolute N−R:

| Evaluator / span | n | Te | Ti | Vi | Ve |
|---|---:|---:|---:|---:|---:|
| spline, h/32 | 0.039829 | 0.0488525 | 0.0233547 | 0.000724759 | 0.588971 |
| spline, h/128 | 0.00150724 | 0.00185852 | 0.000884027 | 5.53418e-05 | 0.168385 |
| compact_c3, h/32 | 6.88286e-05 | 9.29167e-05 | 4.07008e-05 | 9.42586e-05 | 0.197188 |
| compact_c3, h/128 | 3.82795e-07 | 1.04491e-06 | 2.45851e-07 | 6.00664e-06 | 0.0124967 |

Signed smooth hotspot N−O / O−R / N−R for density and electron velocity:

| Method / span / field | N−O | O−R | N−R |
|---|---:|---:|---:|
| spline h/32 n | -3.61592e-09 | -0.039829 | -0.039829 |
| spline h/32 Ve | 0.000163188 | -0.589134 | -0.588971 |
| spline h/128 n | -4.40395e-09 | -0.00150723 | -0.00150724 |
| spline h/128 Ve | 0.00016275 | 0.168223 | 0.168385 |
| compact_c3 h/32 n | -4.99411e-09 | -6.88236e-05 | -6.88286e-05 |
| compact_c3 h/32 Ve | 0.000163237 | 0.197025 | 0.197188 |
| compact_c3 h/128 n | -4.25356e-09 | -3.78541e-07 | -3.82795e-07 |
| compact_c3 h/128 Ve | 0.000162825 | 0.0123339 | 0.0124967 |

The background continuum targets also change. Maximum sampled |R_C3−R_old| by field (centered/combined) is n: 0.0807903, Te: 0.0558172, Ti: 0.0472804, Vi: 0.0719406, Ve: 87.9038. At the smooth N48 hotspot the changes are n: +0.0666601, Te: +0.0313993, Ti: +0.0390959, Vi: +0.00112984, Ve: +0.866771. These differences belong to the numerical background representations; the comparison is internal consistency of each representation, not a common independent physical-B truth.

## Selected-owner physical-volume norms

All tables below weight selected owners by their complete physical volumes and weight cases equally within each family. This panel deliberately enriches hotspots and is not a global norm. Uniform D is displayed; the CSV/JSON retain each BC separately. Repeated non-wall BC cases are correlated. Ratios below are C3/old combined RMS; <1 improves.

| Region / state group / span / error | n | Te | Ti | Vi | Ve |
|---|---:|---:|---:|---:|---:|
| all smooth h/32 N-O | 1.00269 | 1.00022 | 1.00279 | 0.999999 | 0.999999 |
| all smooth h/32 O-R | 0.0535425 | 0.053253 | 0.0535779 | 0.611211 | 0.704057 |
| all smooth h/32 N-R | 0.0535276 | 0.0530823 | 0.0535637 | 0.650359 | 0.730251 |
| all smooth h/128 N-O | 1.00006 | 1 | 1.00006 | 1 | 1 |
| all smooth h/128 O-R | 0.0187416 | 0.0183125 | 0.0187134 | 0.212644 | 0.193313 |
| all smooth h/128 N-R | 0.0184526 | 0.017947 | 0.0184385 | 0.677719 | 0.528346 |
| fresh_controls smooth h/32 N-O | 1.00017 | 1.00001 | 1.00018 | 1 | 1 |
| fresh_controls smooth h/32 O-R | 0.0687173 | 0.0686336 | 0.0687142 | 0.542589 | 0.591395 |
| fresh_controls smooth h/32 N-R | 0.0687185 | 0.0686479 | 0.0687154 | 0.655588 | 0.66045 |
| fresh_controls smooth h/128 N-O | 0.999908 | 0.999998 | 0.999903 | 1 | 1 |
| fresh_controls smooth h/128 O-R | 0.0169455 | 0.0173909 | 0.0169414 | 0.117001 | 0.125307 |
| fresh_controls smooth h/128 N-R | 0.0169554 | 0.0209294 | 0.0169518 | 0.65835 | 0.538935 |
| all waves h/32 N-O | 0.999578 | 0.999038 | 0.999815 | 1.00062 | 1.00082 |
| all waves h/32 O-R | 0.0816351 | 0.0818371 | 0.0828789 | 0.87139 | 0.925604 |
| all waves h/32 N-R | 0.500081 | 0.526428 | 0.546472 | 0.999921 | 0.999624 |
| all waves h/128 N-O | 1.00042 | 1.00042 | 1.00044 | 1.00053 | 1.00067 |
| all waves h/128 O-R | 0.026187 | 0.0264049 | 0.027689 | 0.377136 | 0.390852 |
| all waves h/128 N-R | 0.996734 | 0.997111 | 0.997504 | 1.00047 | 1.00055 |
| all short_waves h/32 N-O | 0.999578 | 0.999037 | 0.999814 | 1.00062 | 1.00082 |
| all short_waves h/32 O-R | 0.0828258 | 0.0829979 | 0.0842216 | 0.879064 | 0.931861 |
| all short_waves h/32 N-R | 0.510035 | 0.536884 | 0.557754 | 0.999935 | 0.999652 |
| all short_waves h/128 N-O | 1.00042 | 1.00042 | 1.00044 | 1.00053 | 1.00067 |
| all short_waves h/128 O-R | 0.0265698 | 0.0267501 | 0.0281433 | 0.387531 | 0.397632 |
| all short_waves h/128 N-R | 0.996895 | 0.997258 | 0.997642 | 1.00047 | 1.00056 |
| all heldout h/32 N-O | 1.00104 | 1.00014 | 0.999172 | 1.00059 | 1.00063 |
| all heldout h/32 O-R | 0.0759201 | 0.0776327 | 0.0771138 | 0.899748 | 0.895428 |
| all heldout h/32 N-R | 0.730257 | 0.7863 | 0.763973 | 1.00048 | 1.0005 |
| all heldout h/128 N-O | 1.00007 | 1.00008 | 1.00009 | 1.00054 | 1.00057 |
| all heldout h/128 O-R | 0.0293113 | 0.0306579 | 0.0303445 | 0.460778 | 0.424139 |
| all heldout h/128 N-R | 0.999468 | 0.999535 | 0.999774 | 1.00049 | 1.00051 |
| wall smooth h/32 N-O | 1.45374 | 1.06064 | 1.47059 | 0.999977 | 1.00003 |
| wall smooth h/32 O-R | 0.0676944 | 0.0675592 | 0.067639 | 0.384674 | 0.4693 |
| wall smooth h/32 N-R | 0.0676955 | 0.0675656 | 0.0676402 | 0.385634 | 0.470358 |
| wall smooth h/128 N-O | 1.01932 | 1.00229 | 1.02012 | 0.99998 | 0.999952 |
| wall smooth h/128 O-R | 0.0167486 | 0.0171727 | 0.0167217 | 0.0773663 | 0.0916043 |
| wall smooth h/128 N-R | 0.0167599 | 0.0172691 | 0.0167325 | 0.0814013 | 0.095367 |
| wall short_waves h/32 N-O | 1.01225 | 1.0131 | 1.01145 | 0.998721 | 0.998441 |
| wall short_waves h/32 O-R | 0.0686117 | 0.0688768 | 0.0685016 | 0.802512 | 0.885835 |
| wall short_waves h/32 N-R | 0.0897662 | 0.0854142 | 0.0902907 | 0.993667 | 1.00032 |
| wall short_waves h/128 N-O | 0.997987 | 0.997222 | 0.998561 | 0.998688 | 0.998623 |
| wall short_waves h/128 O-R | 0.0178481 | 0.0179549 | 0.0177504 | 0.120649 | 0.121698 |
| wall short_waves h/128 N-R | 0.429532 | 0.447197 | 0.414856 | 1.00545 | 1.00979 |
| wall heldout h/32 N-O | 0.995143 | 0.913252 | 0.963591 | 0.998884 | 0.998997 |
| wall heldout h/32 O-R | 0.0292475 | 0.029547 | 0.0311044 | 0.811559 | 0.613708 |
| wall heldout h/32 N-R | 0.0217055 | 0.0301829 | 0.0313508 | 0.991952 | 0.990133 |
| wall heldout h/128 N-O | 1.00124 | 0.991156 | 0.997629 | 0.998834 | 0.998848 |
| wall heldout h/128 O-R | 0.00786854 | 0.00844621 | 0.00924828 | 0.155156 | 0.157994 |
| wall heldout h/128 N-R | 0.346851 | 0.16837 | 0.185609 | 1.00092 | 0.999672 |
| knots smooth h/32 N-O | 0.999938 | 1 | 0.999934 | 1 | 1 |
| knots smooth h/32 O-R | 1.0002 | 0.999664 | 1.00044 | 1.02784 | 1.03622 |
| knots smooth h/32 N-R | 1.0002 | 0.99938 | 1.00045 | 1.01583 | 1.02207 |
| knots smooth h/128 N-O | 0.999903 | 0.999996 | 0.999893 | 1 | 1 |
| knots smooth h/128 O-R | 0.993256 | 0.996256 | 0.995586 | 1.02073 | 1.03183 |
| knots smooth h/128 N-R | 0.993832 | 0.983064 | 0.996184 | 1.00122 | 1.00184 |
| knots heldout h/32 N-O | 0.999999 | 0.999999 | 0.999999 | 0.999999 | 0.999999 |
| knots heldout h/32 O-R | 0.999609 | 0.999677 | 0.99946 | 1.00007 | 1.00009 |
| knots heldout h/32 N-R | 0.999939 | 0.99995 | 0.999943 | 0.999998 | 0.999998 |
| knots heldout h/128 N-O | 0.999999 | 0.999999 | 0.999999 | 0.999999 | 0.999999 |
| knots heldout h/128 O-R | 1.00083 | 1.00081 | 1.00075 | 1.0001 | 1.00011 |
| knots heldout h/128 N-R | 0.999998 | 0.999998 | 0.999998 | 0.999999 | 0.999999 |

Absolute RMS is in `summary.csv`; all centered/correction/combined signed values, per-site absolute/relative errors and maximizing grid/owner/state are preserved. Point-relative errors are blank where |R|≤max(1e−12,1e−10 times the largest same-action/field reference across both backgrounds); correction R is zero. Sample-relative RMS uses that evaluator’s reference RMS.

## Cancellation and localized regressions

Reducing O−R does not guarantee a smaller N−R when N−O initially canceled it. Counts below use all nonconstant complete-owner×BC×field combinations; correlated BC copies are not independent trials.

| Span | Improved >0.1% | Worsened >0.1% | Unchanged | Total |
|---|---:|---:|---:|---:|
| h/32 | 8963 | 7100 | 3257 | 19320 |
| h/128 | 6315 | 4342 | 8663 | 19320 |

Representative largest continuum-scaled total-error increases (preserved signed channels):

| Grid / owner / span / BC / state / field | old N−O | old O−R | old N−R | C3 N−O | C3 O−R | C3 N−R |
|---|---:|---:|---:|---:|---:|---:|
| N32 22925 h/32 DDDDD_phiD wave_l0.35_a75_p0 n | -0.00289012 | 0.00741448 | 0.00452437 | 0.000225669 | -0.0151499 | -0.0149242 |
| N32 22925 h/32 DNDND_phiN wave_l0.35_a75_p0 n | -0.00289012 | 0.00741448 | 0.00452437 | 0.000225669 | -0.0151499 | -0.0149242 |
| N32 22925 h/32 NNNNN_phiN wave_l0.35_a75_p0 n | -0.00289012 | 0.00741448 | 0.00452437 | 0.000225669 | -0.0151499 | -0.0149242 |
| N32 22925 h/32 NDNDN_phiD wave_l0.35_a75_p0 n | -0.00289012 | 0.00741448 | 0.00452437 | 0.000225669 | -0.0151499 | -0.0149242 |
| N32 25005 h/128 DDDDD_phiD wave_l0.5_a75_p0 Ti | -0.0005542 | 0.0002282 | -0.000326001 | -0.000552885 | -4.74125e-05 | -0.000600298 |
| N32 25005 h/128 DNDND_phiN wave_l0.5_a75_p0 Ti | -0.000561199 | 0.0002282 | -0.000333 | -0.000553668 | -4.74125e-05 | -0.000601081 |
| N48 80563 h/128 NNNNN_phiN wave_l0.35_a75_p0 Te | 0.0281291 | -0.0189642 | 0.00916493 | 0.0279342 | 1.28654e-05 | 0.0279471 |
| N48 80563 h/128 NDNDN_phiD wave_l0.35_a75_p0 Te | 0.0281291 | -0.0189642 | 0.00916493 | 0.0279342 | 1.28654e-05 | 0.0279471 |

Explicit lost-cancellation examples with smaller |O−R| but larger |N−R|:

| Grid / site / span / state / field | old N−O | old O−R | old N−R | C3 N−O | C3 O−R | C3 N−R |
|---|---:|---:|---:|---:|---:|---:|
| N48 hotspot h/32 wave_l0.35_a75_p0 Ve | -22.9932 | 21.8203 | -1.17291 | -22.5783 | -2.76329 | -25.3416 |
| N48 hotspot h/32 heldout_l0.35_a110.0 Ve | 126.593 | -20.643 | 105.95 | 124.073 | 1.79162 | 125.865 |
| N48 outermost_wall h/128 wave_l0.35_a75_p0 Ve | -9.39457 | 5.56151 | -3.83306 | -9.2074 | -0.226952 | -9.43436 |
| N48 hot_radial_minus h/128 wave_l0.35_a75_p1 Ve | -41.8661 | 5.25784 | -36.6083 | -42.2502 | 0.171621 | -42.0786 |

Some regressions reflect a larger oracle error as well as changed cancellation. At the four knot owners, smooth h/32 velocity RMS increases about 1.6% (Vi) and 2.2% (Ve), while h/128 is nearly unchanged. Wall short-wave h/128 velocity RMS increases about 0.55% (Vi) and 0.98% (Ve). These are accuracy outcomes. Electron-velocity and wall exceptions remain explicit; none triggers support/degree/span/BC tuning. The earlier short-wave reconstruction floor is not removed by C3. At h/128 the held-out C3 sample-relative combined RMS remains about 26.4%/30.4%/27.3% for n/Te/Ti and 24.9%/28.5% for Vi/Ve; these intentionally difficult selected-owner statistics are not domain-wide errors. The six knot targets map to four unique owners: this covers their nearest canonical owner neighborhoods, not exact knot-crossing query paths or a full knot sweep.

## Reconstruction, BC and numerical validation

- Exact donor IDs and geometry-only repair choices agree across both evaluators and both spans. Rebuilt value/gradient rows and diagnostic ranks/reproduction/condition/support details are saved per raw member. C3/old row-amplification ratios range 0.952223–1.07533 across value/G/boundary-G norms. No new unsupported rank, exterior query or trace failure occurred.
- Both physical-normal D/N wall row systems are used at every wall site, even though the traces stay interior. 16 evaluator×wall-owner receipts record boundary rows used. No radial-coordinate Neumann approximation was introduced.
- Same-action replay against the prior bounded baseline: max N 2.39334e-09, O 1.27966e-09, R 6.16978e-12; unchanged replay gate 1e−8. Center-b replay passes 1e−10.
- Constant N−O maxima at h/32,h/128: 4.08015e-09, 1.51809e-08; unchanged gates 1e−7,4e−7. All state slots are finite and thermodynamically positive; characteristic splits admissible.
- N−R=(N−O)+(O−R) closes to 2.27374e-13. No trace stages cross/reenter the wall.
- Continuum reference uses kernel.center_reference with fourth-order finite differences at 1e−4 and sensitivity checks at 5e−5,2.5e−5. Max all-field sensitivity old/C3: 5.12703e-08/4.37421e-09. The original step is retained for parity. These sensitivities bound numerical reference uncertainty; they are not interpreted as magnetic interpolation improvement.

| Evaluator / RK audit owner | Endpoint max 64−128 | N action max | O action max |
|---|---:|---:|---:|
| spline N48 transition1 | 8.88178e-16 | 6.48757e-09 | 1.27824e-09 |
| spline N48 bulk | 7.77156e-16 | 5.54198e-09 | 1.29578e-09 |
| spline N48 hotspot | 1.65201e-13 | 1.47064e-07 | 1.47168e-07 |
| spline N48 outermost_wall | 1.30562e-13 | 1.11176e-07 | 1.12296e-07 |
| compact_c3 N48 transition1 | 4.44089e-16 | 5.44975e-09 | 2.24601e-09 |
| compact_c3 N48 bulk | 6.66134e-16 | 3.73409e-09 | 1.86762e-09 |
| compact_c3 N48 hotspot | 8.88178e-16 | 8.95454e-09 | 4.2071e-09 |
| compact_c3 N48 outermost_wall | 8.88178e-16 | 1.43934e-08 | 3.46995e-09 |

RK4-128 is an independent audit at N48 hotspot, transition1, bulk, and wall owners at both spans. Its action sensitivity is reported separately from the unchanged same-method replay gate; no trace steps or tolerances were silently changed.

Measured selected-point div(B), complete raw-member arrays, are in each result NPZ. A cheap supplemental `scalar_actions_errors.npz` reports traced G and balanced scalar tube D with analytic continuum first derivatives, separately from the material system. It makes no claim about diffusion composition.

## Decision and remaining qualification

The bounded smooth hotspot improvement survives actual Q reconstruction and prescribed D/physical-normal N/mixed rows. Frozen N−O remains controlled relative to its existing reconstruction floor and row amplification, while C3 removes the earlier severe smooth scalar O−R spike. Larger matched qualification is justified for domain-wide distributions and exceptions, keeping the old evaluator and both paired spans. No global order or uniform improvement follows from this deliberately selected panel.

Remaining gaps: longer legs, actual wall exits/reentries and exterior ghost rows, exact native-knot crossings, current–phi/SAT compatibility, conservation, evolved stability, diffusion composition, full-grid operator errors and an independent physical magnetic reference. Changed cancellation and background continuum differences must stay separate from physical-field accuracy. Production defaults, canonical artifacts, frozen remote campaign, accepted donors/degrees/BC formulas/spans and all P work remain unchanged.

## Runtime and reproduction

The full sequential bounded comparison took 474.8 s with peak process RSS 3.320 GiB. Pilot: 79.94 s, 2.477 GiB (cold core/wall compilation for both modes). CPU x64, one BLAS thread, one worker. The full run reuses the validated pilot core; wall was rerun for RK128 auditing. Frozen source identity `0a16837968506693afdbc530216dc24911821cb8c7b4558589c870f833bbc659`; run/source identity `bdd26a6427d3bb73a9e2a070dc3be1c6177bb7a84f6f6182dcc1270f7bef1493`; exact source/input/current/import hashes are in `provenance.json`.

```bash
cd "/Users/yxie/Desktop/HSX drbx"
/opt/homebrew/Caskroom/miniforge/base/envs/drb/bin/python work/q_c3_regenerated_trace_bounded_20261001/run.py --pilot
/opt/homebrew/Caskroom/miniforge/base/envs/drb/bin/python work/q_c3_regenerated_trace_bounded_20261001/prepare_full.py
/opt/homebrew/Caskroom/miniforge/base/envs/drb/bin/python work/q_c3_regenerated_trace_bounded_20261001/run.py
/opt/homebrew/Caskroom/miniforge/base/envs/drb/bin/python work/q_c3_regenerated_trace_bounded_20261001/analyze.py
/opt/homebrew/Caskroom/miniforge/base/envs/drb/bin/python work/q_c3_regenerated_trace_bounded_20261001/scalar_references.py
/opt/homebrew/Caskroom/miniforge/base/envs/drb/bin/python work/q_c3_regenerated_trace_bounded_20261001/selected_coordinates.py
/opt/homebrew/Caskroom/miniforge/base/envs/drb/bin/python work/q_c3_regenerated_trace_bounded_20261001/report.py
/opt/homebrew/Caskroom/miniforge/base/envs/drb/bin/python work/q_c3_regenerated_trace_bounded_20261001/validate.py
```

Resume validates implementation, selected raw IDs, mode, currents, span, step count and file hashes. Artifacts: `selection.json`, `provenance.json`, `pilot.json`, `completion_run.json`, `results/`, `traces/`, `donors/`, `actions_errors.npz`, `scalar_actions_errors.npz`, `analysis.json`, `summary.csv`, `per_site_errors.csv`, `validation.json`, `completion.json`. Each result receipt includes row diagnostics, trace identity and baseline replay/RK audit where applicable.
