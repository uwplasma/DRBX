from pathlib import Path
import json,math,csv,sys
import numpy as np
from run import P,CAM,OLD,identity,verify_inputs,sha,read,save,checked

def main():
 ident=verify_inputs()
 if '--validate' in sys.argv:
  receipt=read(P/'analysis_receipt.json');assert receipt['identity']==ident and receipt['complete']
  for rel,h in receipt['outputs'].items():checked(P/rel,h)
  a=read(P/'analysis.json');assert len(a['validation'])==3 and all(x['passed'] for x in a['validation']);assert a['fields']==read(CAM/'design.json')['fields'];assert len(a['series'])==3*2*2*11*29*3*2
  print('Analysis outputs and complete schema validated');return
 fields=read(CAM/'design.json')['fields'];waves=[i for i,f in enumerate(fields) if f.startswith(('x_','y_','wave_'))];fresh=list(range(18,26));sets=[(f,[i]) for i,f in enumerate(fields)]+[('original12',waves),('fresh8',fresh),('waves20',waves+fresh)]
 rows=[];comparison=[];rings=[];hotspots=[];activation=[];validation=[]
 for n in (32,48,64):
  rec=read(P/f'validation_N{n}.json');assert rec['identity']==ident and rec['passed'];checked(P/f'results_N{n}.npz',rec['result_sha256']);validation.append(rec)
  d={k:v for k,v in np.load(P/f'results_N{n}.npz').items()};base={k:v for k,v in np.load(CAM/f'results_N{n}.npz').items()};rad=d['radial'];last=read(CAM/'plan.json')[str(n)]['last_aggregate'];vol=d['volume'];count=len(vol)
  for key in ('O','R','R_half','owners','volume','radial','fields'):assert np.array_equal(d[key],base[key]),key
  regions={'global':np.ones(count,bool),'core':rad==0,'first_ring':rad==1,'inner':rad<=last,'middle':(rad>=2)&(rad<last-1),'inner_join':(rad>=last-1)&(rad<=last),'aggregate_join':(rad>=last-1)&(rad<=last+2),'outer':(rad>last)&(rad<n-2),'wall':rad>=n-2,'wall_join':(rad>=n-4)&(rad<=n-2),'without_core_first':rad>=2}
  methods={'compact':d['compact'],'guard':d['N'],'balanced':base['N']};OR=d['O']-d['R'][:,None]
  from frozen import model
  _,t=model.context(n,P.parent.parent,physical=False,magnetic=False)
  for region,mask in regions.items():
   rr=np.flatnonzero(np.isin(t.ro,np.flatnonzero(mask)));ch=d['choice'][rr];eligible=ch>=0
   activation.append(dict(n=n,region=region,raw_count=len(rr),inner_raw=int(eligible.sum()),counts=[int(np.sum(ch==mi)) for mi in range(3)],volume_fraction=[float(t.rv[rr][ch==mi].sum()/t.rv[rr].sum()) for mi in range(3)]))
   w=vol[mask]/vol[mask].sum()
   for bi,bc in enumerate(('D','N')):
    for si,span in enumerate((16,32)):
     before=methods['compact'][mask,bi,si]-d['O'][mask,si]
     for method,N in methods.items():
      ee={'NO':N[mask,bi,si]-d['O'][mask,si],'OR':OR[mask,si],'NR':N[mask,bi,si]-d['R'][mask]}
      for channel,e in ee.items():
       l2s=w@(abs(e)**2);maxs=abs(e).max(axis=0)
       for label,fi in sets:
        rms=float(np.sqrt(np.mean(l2s[fi])));mx=float(maxs[fi].max());rows.append(dict(n=n,bc=bc,span=span,region=region,field=label,method=method,channel=channel,rms=rms,maximum=mx))
        if channel=='NO':
         old=float(np.sqrt(np.mean(w@abs(before[:,fi])**2)));oldmax=float(abs(before[:,fi]).max());worse=abs(e[:,fi])>abs(before[:,fi])*(1+1e-8)+1e-12
         comparison.append(dict(n=n,bc=bc,span=span,region=region,field=label,method=method,rms=rms,compact_rms=old,ratio=rms/max(old,1e-300),maximum=mx,compact_maximum=oldmax,max_ratio=mx/max(oldmax,1e-300),worse_fraction=float(worse.mean())))
  for ring in range(n):
   mask=rad==ring;w=vol[mask]/vol[mask].sum()
   for bi,bc in enumerate(('D','N')):
    for si,span in enumerate((16,32)):
     for label,fi in [('original12',waves),('fresh8',fresh),('waves20',waves+fresh),('fB',[8]),('homogeneous_D',[1])]:
      entry=dict(n=n,ring=ring,bc=bc,span=span,field=label)
      for method,N in methods.items():
       err=N[mask,bi,si][:,fi]-d['O'][mask,si][:,fi];entry[method+'_rms']=float(np.sqrt(np.mean(w@abs(err)**2)));entry[method+'_maximum']=float(abs(err).max())
      rings.append(entry)
  # Save top changes and explicitly retain previously discussed hotspots.
  e={m:np.sqrt(np.mean(abs(N[:,0,0][:,waves]-d['O'][:,0][:,waves])**2,axis=1)) for m,N in methods.items()};change=e['guard']-e['compact'];ids=set(map(int,np.argsort(change)[-30:]))|set(map(int,np.argsort(change)[:30]));ids.update({32:[1928],48:[8579],64:[24064,26609]}[n])
  for o in sorted(ids):hotspots.append(dict(n=n,owner=o,radial=int(rad[o]),**{m:float(q[o]) for m,q in e.items()},increase=float(change[o])))
  print('ANALYZED',n,flush=True)
 lookup={(x['n'],x['bc'],x['span'],x['region'],x['field'],x['method'],x['channel']):x for x in rows};series=[]
 for bc in ('D','N'):
  for span in (16,32):
   for region in regions:
    for field,_ in sets:
     for method in methods:
      for channel in ('NO','OR','NR'):
       entries=[lookup[n,bc,span,region,field,method,channel] for n in (32,48,64)]
       for norm in ('rms','maximum'):
        values=[q[norm] for q in entries];orders=[math.log(max(values[i],1e-300)/max(values[i+1],1e-300))/math.log((48/32,64/48)[i]) for i in (0,1)]
        series.append(dict(bc=bc,span=span,region=region,field=field,method=method,channel=channel,norm=norm,values=values,orders=orders))
 save(P/'analysis.json',dict(identity=ident,validation=validation,fields=fields,rows=rows,series=series,comparison=comparison,rings=rings,hotspots=hotspots,activation=activation))
 with (P/'orders.csv').open('w') as f:
  wr=csv.writer(f);wr.writerow(['method','BC','span','region','field','channel','norm','E32','E48','E64','p32_48','p48_64'])
  for x in series:wr.writerow([x['method'],x['bc'],x['span'],x['region'],x['field'],x['channel'],x['norm'],*x['values'],*(['',''] if x['field']=='constant' else x['orders'])])
 with (P/'comparison.csv').open('w') as f:
  wr=csv.DictWriter(f,fieldnames=list(comparison[0]));wr.writeheader();wr.writerows(comparison)
 text=['# Global selective-repair comparison','',f'Identity: `{ident}`. Computation and invariants passed for all three resolutions. Scientific acceptance remains an interpretation of the comparisons below; no implementation has been promoted.','',
 'Every owner is represented. New compact and guard actions were computed for all inner owners; unchanged outer/wall actions and all O/R/R_half arrays were reused. The26 fields, both spans, and both boundary conditions are included. No new tracing or continuum-reference calculation was performed.','',
 '## N−O global and regional comparison','',
 'Pooled20 waves, h/16. Ratios are guard/compact; below1 is better. Inner results are common to both BCs.','',
 '| Region | BC | N32 ratio | N48 ratio | N64 ratio | Guard order32→48 | Guard order48→64 |','|---|---|---:|---:|---:|---:|---:|']
 for region,bc in [('global','D'),('global','N'),('core','D'),('first_ring','D'),('middle','D'),('inner','D'),('inner_join','D'),('aggregate_join','D'),('outer','D'),('wall','D')]:
  cs=[next(x for x in comparison if x['n']==n and x['bc']==bc and x['span']==16 and x['region']==region and x['field']=='waves20' and x['method']=='guard') for n in (32,48,64)];ss=next(x for x in series if x['bc']==bc and x['span']==16 and x['region']==region and x['field']=='waves20' and x['method']=='guard' and x['channel']=='NO' and x['norm']=='rms');text.append(f"| {region} | {bc} | "+' | '.join(f"{x['ratio']:.4f}" for x in cs)+' | '+' | '.join(f'{v:.3f}' for v in ss['orders'])+' |')
 text+=['','## RMS and maximum convergence exceptions','', 'Counts below concern individual nonconstant fields across both BCs/spans; pooled series excluded. Rebounds are positive increases beyond1e−8 relative plus1e−12 absolute. Subsecond-order includes rates below2 without interpreting them as an automatic failure.','', '| Method | Region | Norm | Rebounding intervals | Intervals with p<2 |','|---|---|---|---:|---:|']
 for method in methods:
  for region in ('global','inner','inner_join','aggregate_join','wall'):
   for norm in ('rms','maximum'):
    ss=[x for x in series if x['method']==method and x['region']==region and x['norm']==norm and x['channel']=='NO' and x['field'] in fields and x['field']!='constant'];rebound=sum(x['values'][i+1]>x['values'][i]*(1+1e-8)+1e-12 for x in ss for i in (0,1));below=sum(p<2 for x in ss for p in x['orders']);text.append(f'| {method} | {region} | {norm} | {rebound} | {below} |')
 text+=['','## Previously discussed hotspots','', 'Pooled original12-wave N−O RMS, h/16, D (inner action identical for N).','', '| N | Owner | Ring | Compact | Guard | Balanced |','|---|---|---|---:|---:|---:|']
 for n,o in ((32,1928),(48,8579),(64,24064),(64,26609)):
  q=next(x for x in hotspots if x['n']==n and x['owner']==o);text.append(f"| {n} | {o} | {q['radial']} | {q['compact']:.6g} | {q['guard']:.6g} | {q['balanced']:.6g} |")
 text+=['','## Selection and verification','', '| N | Inner raw anchors | Kept compact | Selected broad balanced | Selected local40 | Compact replay max |','|---|---:|---:|---:|---:|---:|']
 for q in validation:text.append(f"| {q['n']} | {q['inner_raw']} | "+' | '.join(str(c) for c in q['choice_counts'])+f" | {q['compact_replay']:.3g} |")
 text+=['','All three policies share O−R exactly; changing donor support cannot repair the separate reference/discrete-action discrepancy. See orders.csv for all N−R, N−O and O−R rates, individual fields, both spans and boundary cases. Analysis.json includes perring metrics, increased/decreased owner hotspots, activation fractions, maxima, and proportions of owner/field cases worsened. These static MMS results are not timestep stability or turbulent damping validation.']
 (P/'report.md').write_text('\n'.join(text)+'\n');save(P/'analysis_receipt.json',dict(identity=ident,complete=True,outputs={f:sha(P/f) for f in ['analysis.json','orders.csv','comparison.csv','report.md']}))
 print('REPORT',P/'report.md',flush=True)
if __name__=='__main__':main()
