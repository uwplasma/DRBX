"""Frozen geometry-only gradient guard from the bounded investigation."""
import math
import numpy as np
from scipy.linalg import qr
from frozen import primitives as r
from frozen.support import Hybrid,BalancedHybrid,Balanced,good,quality
class LocalBalanced(Balanced):
    def select(self,pool,order,xy,scale):
        ids=pool[order[:40]];ft=r.fit(self.t,ids,xy,scale,np.eye(15));A,U,root=ft[:3];candidates=[]
        for name,M in (('weighted',A),('uniform',U)):
            pv=qr((root[:,None]*M).T,mode='economic',pivoting=True)[2][:15];take=list(map(int,pv));take += [z for z in range(len(ids)) if z not in take][:28-len(take)];take=np.array(sorted(take));sub=r.fit(self.t,ids[take],xy,scale,np.eye(15))
            if len(take)==28 and good(sub):candidates.append((quality(*sub[:3]),name,take,sub))
        if candidates:
            _,name,take,sub=max(candidates,key=lambda x:x[0]);return ids[take],sub,dict(radius=2,angular=0,pool_size=len(ids),selection='nearest40_'+name)
        don,sub,info=super().select(pool,order,xy,scale);info['selection']='fallback_'+info['selection'];return don,sub,info
class LocalHybrid(BalancedHybrid):
    def __init__(self,t):super().__init__(t);self.inner=LocalBalanced(t)
def indicators(t,rr,p,b,maps):
    caps=np.array([0,1,3,4]);xy=t.xy[rr];scores=np.empty((3,2));noise=np.empty(3)
    for mi,(ids,V,D) in enumerate(maps):
        pg=np.einsum('si,sid->sd',b,D);noise[mi]=np.linalg.norm(np.sum(abs(pg[caps]),axis=1))
        for di,degree in enumerate((5,6)):
            exp=np.array([(a,degree-a) for a in range(degree+1)]);factor=np.array([math.sqrt(math.comb(degree,int(a)))/math.factorial(degree) for a,_ in exp]);mm=[r.members(t,o) for o in ids];M=np.array([(t.rv[v]/t.vol[o])@r.basis(t.xy[v],xy,1.,exp) for o,v in zip(ids,mm)]);_,du,dt=r.planar(p,xy,1.,exp);eg=np.stack((du,dt,np.zeros_like(du)),axis=1);exact_pg=np.einsum('si,sif->sf',b,eg)
            response=(pg@M-exact_pg)*factor;scores[mi,di]=np.linalg.norm(response[caps])
    best=1.;pick=0
    for mi in (2,1):
        ratio=scores[mi]/np.maximum(scores[0],1e-30)
        if np.max(ratio)<.9 and noise[mi]<=noise[0]*(1+1e-12) and np.max(ratio)<best:best=float(np.max(ratio));pick=mi
    return pick,scores,noise
