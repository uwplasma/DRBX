import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
os.environ['JAX_PLATFORMS']='cpu';os.environ['JAX_ENABLE_X64']='true'
from pathlib import Path
import sys,json,time,hashlib,argparse,multiprocessing as mp,resource,fcntl
import numpy as np
P=Path(__file__).resolve().parent;W=P.parent.parent
CAM=W/'work/q-fci-balanced28-dacf15f1-20260929T171025Z';OLD=W/'work/q-fci-layered-ad54c332-20260929T144546Z';BOUND=W/'work/q_fci_support_indicator_20260929'
read=lambda p:json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(8*1024**2):h.update(b)
 return h.hexdigest()
def save(p,data):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+f'.{os.getpid()}.tmp');tmp.write_text(json.dumps(data,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else x.tolist())+'\n');os.replace(tmp,p)
def arrays(p,**data):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+f'.{os.getpid()}.tmp')
 with tmp.open('wb') as f:np.savez_compressed(f,**data)
 os.replace(tmp,p)
def source_paths():return sorted([P/'run.py',P/'policy.py',P/'analyze.py',P/'design.md',*list((P/'frozen').rglob('*.py')),*list((P/'frozen').glob('*.json'))])
def identity():
 d=read(P/'identity.json')
 for rel,h in d['sources'].items():assert sha(P/rel)==h,('changed source',rel)
 return sha(P/'identity.json')
def checked(p,h):assert sha(p)==h,('input checksum',str(p))
def freeze():
 assert not (P/'identity.json').exists(),'identity already frozen'
 design=read(CAM/'design.json');old=read(OLD/'design.json');assert design['inputs']==old['inputs']
 for rel,h in design['sources'].items():
  src=W/'DRBX/scripts/q_fci_layered_global'/rel;checked(src,h);dst=P/'frozen'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
 inputs={}
 for q in design['inputs']['files']:
  path=W/q['path'];checked(path,q['sha256']);inputs[str(path)]=q['sha256']
 files=[CAM/'design.json',CAM/'plan.json',OLD/'design.json',BOUND/'run.py',BOUND/'design.md',BOUND/'receipt.json']
 for n in (32,48,64):files += [CAM/f'results_N{n}.npz',OLD/f'results_N{n}.npz',BOUND/f'data_N{n}.npz',BOUND/f'metadata_N{n}.json']
 for f in files:inputs[str(f)]=sha(f)
 traces={}
 for n in (32,48,64):
  for f in sorted((CAM/'global'/f'N{n}').glob('trace_*.json')):
   rec=read(f);assert rec['identity']==sha(CAM/'design.json');traces[str(f.with_suffix('.npz'))]=rec['sha256']
 save(P/'identity.json',dict(schema='q-selective-gradient-guard-global-v1',sources={str(p.relative_to(P)):sha(p) for p in source_paths()},inputs=inputs,traces=traces,policy='frozen gradient_guard from bounded test; no tuning',new_traces=0,reference_recalculation=False))
 print('FROZEN',identity(),flush=True)
def verify_inputs():
 ident=identity();d=read(P/'identity.json')
 for path,h in d['inputs'].items():checked(path,h)
 return ident
CTX=T=OBJECTS=STATE=IDENT=None

def init(n):
 global CTX,T,OBJECTS,STATE,IDENT
 from frozen import model
 from policy import Hybrid,BalancedHybrid,LocalHybrid
 IDENT=identity();CTX,T=model.context(n,W);OBJECTS=[Hybrid(T),BalancedHybrid(T),LocalHybrid(T)];STATE=model.states(T)

def coefficients(raw,ends):
 """Same action coefficients as frozen model; skip both continuum MMS references."""
 from frozen import model
 points=T.pts[raw];slots=np.stack((ends[:,0],ends[:,1],points,ends[:,2],ends[:,3],points),axis=1)
 J,b,B=model.geom(CTX,slots.reshape(-1,3));J=J.reshape(-1,6);b=b.reshape(-1,6,3);B=B.reshape(-1,6)
 step=1e-4;pp=np.broadcast_to(points[:,None,None,:],(len(points),3,4,3)).copy()
 for a in range(3):pp[:,a,:,a]+=np.array([-2,-1,1,2])*step
 jj,bb,BB=model.geom(CTX,pp.reshape(-1,3));jj=jj.reshape(-1,3,4);bb=bb.reshape(-1,3,4,3);BB=BB.reshape(-1,3,4);wt=np.array([1,-8,8,-1])/(12*step)
 db=sum(np.einsum('pq,q->p',jj[:,a]*bb[:,a,:,a]*BB[:,a],wt) for a in range(3))/J[:,2]
 L=np.zeros((len(raw),2,6));scale=B[:,2]*b[:,2,2]
 for ai,a in enumerate(model.ALPHAS):
  s=ai*3;L[:,ai,s]=-scale/(a*T.g.deta*B[:,s]);L[:,ai,s+1]=scale/(a*T.g.deta*B[:,s+1]);L[:,ai,s+2]=db/B[:,2]
 return slots,b,L

def calc(raw,ends):
 from frozen import primitives as r
 from policy import indicators
 start=time.monotonic();slots,b,L=coefficients(raw,ends);coefficient_seconds=time.monotonic()-start
 actions=np.empty((2,len(raw),2,26),complex);choices=np.zeros(len(raw),np.int8);scores=np.empty((len(raw),3,2));noise=np.empty((len(raw),3));setup=np.zeros(3);constant=0.;maxcondition=0.;fallback=0
 for pos,rr in enumerate(raw):
  ijk=np.array(np.unravel_index(rr,(T.n,)*3));assert ijk[0]<=OBJECTS[0].last;p=slots[pos];maps=[]
  for mi,obj in enumerate(OBJECTS):
   tick=time.perf_counter();ids,V,D,m=obj.rows(ijk,p);setup[mi]+=time.perf_counter()-tick;maps.append((ids,V,D));maxcondition=max(maxcondition,m['condition'])
   assert all(len(pl['donors'])==28 and pl['rank']==15 for pl in m['planes']),('invalid support',int(rr),mi)
   ce=float(abs(D.sum(axis=-1)*np.array([T.g.dr,T.g.dtheta,T.g.deta])).max());constant=max(constant,ce);assert ce<1e-8
   if mi==2:fallback+=sum(pl.get('selection',{}).get('selection','').startswith('fallback_') for pl in m['planes'])
  pick,scores[pos],noise[pos]=indicators(T,rr,p,b[pos],maps);choices[pos]=pick
  for out,mi in enumerate((0,pick)):
   if out==1 and mi==0:actions[1,pos]=actions[0,pos];continue
   ids,V,D=maps[mi];actions[out,pos]=L[pos]@np.einsum('si,sid->sd',b[pos],D)@STATE[ids]
 assert np.isfinite(actions).all() and np.isfinite(scores).all() and np.isfinite(noise).all()
 owners=np.unique(T.ro[raw]);projected=np.empty((2,len(owners),2,26),complex)
 for oi,o in enumerate(owners):
  hit=np.flatnonzero(T.ro[raw]==o);members=r.members(T,o);assert np.array_equal(raw[hit],members);w=T.rv[members]/T.vol[o];assert abs(w.sum()-1)<1e-12
  projected[:,oi]=np.einsum('r,mraf->maf',w,actions[:,hit])
 for obj in OBJECTS:obj.clear()
 rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**3
 if rss>3.0:raise RuntimeError(('worker RSS budget exceeded',rss))
 meta=dict(raw=len(raw),owners=len(owners),wall_seconds=time.monotonic()-start,coefficient_seconds=coefficient_seconds,setup_seconds=setup.tolist(),constant_row_max=constant,max_condition=maxcondition,local_fallback_plane_visits=fallback,peak_rss_gib=rss,choices=np.bincount(choices,minlength=3).tolist())
 return dict(owners=owners,raw=raw,N=projected,choice=choices,indicator=scores,noise=noise),meta

def load_trace(n,block):
 p=CAM/'global'/f'N{n}'/f'trace_{block:06d}.npz';checked(p,read(P/'identity.json')['traces'][str(p)])
 with np.load(p) as z:return z['raw'],z['ends']
def complete(dest):
 rec=dest.with_suffix('.json')
 if not rec.exists():return False
 q=read(rec);assert q['identity']==identity();checked(dest,q['sha256']);return True

def task(job):
 n,block,owners=job;dest=P/'chunks'/f'N{n}'/f'score_{block:06d}.npz'
 if complete(dest):return read(dest.with_suffix('.json'))
 raw,ends=load_trace(n,block);mask=np.isin(T.ro[raw],owners);data,meta=calc(raw[mask],ends[mask]);assert np.array_equal(data['owners'],owners)
 arrays(dest,**data);rec=dict(identity=IDENT,sha256=sha(dest),block=block,n=n,**meta);save(dest.with_suffix('.json'),rec);return rec

def jobs(n):
 plan=read(CAM/'plan.json')[str(n)]
 with np.load(CAM/f'results_N{n}.npz') as z:rad=z['radial']
 out=[]
 for block,owners in enumerate(plan['global_']):
  owners=np.array(owners);owners=owners[rad[owners]<=plan['last_aggregate']]
  if len(owners):out.append((n,block,owners))
 return out

def preflight():
 ident=verify_inputs();checks=[]
 for n in (32,48,64):
  init(n);owners=np.load(BOUND/f'data_N{n}.npz')['owners'];last=OBJECTS[0].last;owners=owners[np.array([T.pts[T.order[T.starts[o]],0]*n for o in owners]).astype(int)<=last]
  raw=[];ends=[]
  for nn,block,oo in jobs(n):
   if not np.isin(oo,owners).any():continue
   rr,ee=load_trace(n,block);mask=np.isin(T.ro[rr],owners);raw.extend(rr[mask]);ends.extend(ee[mask])
  raw=np.array(raw);ends=np.array(ends);order=np.argsort(raw);raw=raw[order];ends=ends[order]
  # Direct coefficient replay against original function on a few anchors only.
  from frozen import model
  sp,b,L=coefficients(raw[:8],ends[:8]);sp0,b0,L0,*_=model.slots_and_action(CTX,T,raw[:8],ends[:8]);assert np.array_equal(sp,sp0) and np.array_equal(b,b0);ldiff=float(abs(L-L0).max());assert ldiff<1e-10,ldiff
  data,meta=calc(raw,ends)
  with np.load(BOUND/f'data_N{n}.npz') as z:
   lookup={int(o):i for i,o in enumerate(z['owners'])};rrlookup={int(rr):i for i,rr in enumerate(z['raw'])};ix=[lookup[int(o)] for o in data['owners']];rix=[rrlookup[int(rr)] for rr in data['raw']];expected_error=z['error'][[0,4]][:,ix,:,:26];expected_choice=z['choice'][1,rix];expected_scores=z['indicator'][:,rix,1].transpose(1,0,2);expected_noise=z['noise'][:,rix,1].T
  with np.load(CAM/f'results_N{n}.npz') as z:oracle=z['O'][data['owners']]
  diff=float(abs(data['N']-oracle[None]-expected_error).max());assert diff<1e-8,(n,diff);assert np.array_equal(data['choice'],expected_choice),(n,'choice mismatch');assert np.allclose(data['indicator'],expected_scores,rtol=1e-12,atol=1e-20);assert np.allclose(data['noise'],expected_noise,rtol=1e-12)
  arrays(P/f'preflight_N{n}.npz',**data);checks.append(dict(n=n,coefficient_difference=ldiff,bounded_replay=diff,choices_exact=True,**meta));print('PREFLIGHT',checks[-1],flush=True)
 save(P/'preflight.json',dict(identity=ident,passed=True,checks=checks,total_global_inner_raw=sum(sum(len(o) for o in []) for n in [])))

def run_stage(n,workers):
 ident=verify_inputs();pre=read(P/'preflight.json');assert pre['identity']==ident and pre['passed'];alljobs=jobs(n);start=time.monotonic();done=[];progress=P/f'progress_N{n}.json'
 def update():save(progress,dict(identity=ident,stage=f'N{n}',completed=len(done),total=len(alljobs),raw_completed=sum(x['raw'] for x in done),elapsed_seconds=time.monotonic()-start,updated_unix=time.time(),peak_worker_rss_gib=max((x['peak_rss_gib'] for x in done),default=0)))
 update()
 with mp.get_context('spawn').Pool(workers,initializer=init,initargs=(n,),maxtasksperchild=24) as pool:
  for result in pool.imap_unordered(task,alljobs,chunksize=1):done.append(result);update()
 save(P/f'stage_N{n}.json',dict(identity=ident,complete=True,workers=workers,chunks=len(done),wall_seconds=time.monotonic()-start,raw=sum(x['raw'] for x in done),peak_worker_rss_gib=max(x['peak_rss_gib'] for x in done)))
 print('STAGE DONE',n,flush=True)

def validate_stage(n,merge=False):
 ident=verify_inputs();from frozen import model
 _,t=model.context(n,W,physical=False,magnetic=False);base={k:v for k,v in np.load(CAM/f'results_N{n}.npz').items()};old={k:v for k,v in np.load(OLD/f'results_N{n}.npz').items()};alljobs=jobs(n);seen=[];rawseen=[];replay=0.;constant=0.;choices=np.full(n**3,-1,np.int8)
 compact=base['N'].copy();candidate=base['N'].copy()
 for _,block,expected in alljobs:
  dest=P/'chunks'/f'N{n}'/f'score_{block:06d}.npz';assert complete(dest),dest
  with np.load(dest) as z:
   oo=z['owners'];rr=z['raw'];assert np.array_equal(oo,expected);assert np.array_equal(rr,np.concatenate([t.order[t.starts[o]:t.starts[o+1]] for o in oo]));assert z['N'].shape==(2,len(oo),2,26);assert np.isfinite(z['N']).all();assert set(z['choice'].tolist())<={0,1,2}
   compact[oo]=z['N'][0,:,None];candidate[oo]=z['N'][1,:,None];choices[rr]=z['choice'];seen.extend(oo.tolist());rawseen.extend(rr.tolist());replay=max(replay,float(abs(z['N'][0,:,:,:18]-old['N'][oo,0]).max()));constant=max(constant,float(abs(z['N'][:,:,:,6]).max()))
 last=read(CAM/'plan.json')[str(n)]['last_aggregate'];want=np.flatnonzero(base['radial']<=last);assert np.array_equal(np.sort(seen),want) and len(set(seen))==len(seen);expectedraw=np.flatnonzero(np.isin(t.ro,want));assert np.array_equal(np.sort(rawseen),expectedraw) and len(set(rawseen))==len(rawseen);assert replay<1e-8 and constant<1e-7,(replay,constant)
 assert np.array_equal(candidate[base['radial']>last],base['N'][base['radial']>last]);outer_replay=float(abs(compact[base['radial']>last,:,:,:18]-old['N'][base['radial']>last]).max());assert outer_replay<2e-9
 q=dict(identity=ident,passed=True,n=n,owners=len(base['owners']),inner_owners=len(seen),inner_raw=len(rawseen),compact_replay=replay,outer_replay=outer_replay,constant_max=constant,choice_counts=np.bincount(choices[choices>=0],minlength=3).tolist())
 if merge:
  arrays(P/f'results_N{n}.npz',N=candidate,compact=compact,O=base['O'],R=base['R'],R_half=base['R_half'],owners=base['owners'],volume=base['volume'],radial=base['radial'],fields=base['fields'],choice=choices)
  q['result_sha256']=sha(P/f'results_N{n}.npz');save(P/f'validation_N{n}.json',q)
 print('VALIDATED',q,flush=True)
 return q

def main():
 ap=argparse.ArgumentParser();ap.add_argument('command',choices=['freeze','preflight','run','validate','merge']);ap.add_argument('--n',type=int);ap.add_argument('--workers',type=int,default=3);args=ap.parse_args()
 if args.command=='freeze':freeze()
 elif args.command=='preflight':preflight()
 elif args.command=='run':
  lock=P/f'N{args.n}.lock'
  with lock.open('a+') as f:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);run_stage(args.n,args.workers)
 elif args.command in ('validate','merge'):validate_stage(args.n,merge=args.command=='merge')
if __name__=='__main__':main()
