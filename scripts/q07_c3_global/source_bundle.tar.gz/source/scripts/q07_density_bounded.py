"""Actual-HSX bounded Q07 -D(n Ve), primitive cap products and physical BCs.

Run from DRBX with CPU/x64 and one BLAS thread. Reuses 21 complete Q05 owners
at h/32; no new tracing, support selection or global qualification.
"""
from pathlib import Path
import hashlib,json,time
import numpy as np
import jax
from q05_bounded_matrix import CASES
from q05_replay_identity import write_json,digest
import q05_traced_replay as replay
from drbx.stencils.q_parallel import load_chunk,raw_members,sha256_array
from drbx.stencils.q_parallel_transport import prepare_density_transport
from drbx.stencils.q_parallel_divergence import prepare_tube_divergence,prepare_kappa
from drbx.native.q_parallel import QBoundaryData
from drbx.native.q_parallel_transport import stage_density_transport,apply_density_transport,apply_raw_density_flux
from drbx.native.q_parallel_divergence import apply_parallel_divergence,stage_parallel_divergence
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'work/q07_density_bounded_20260930'
Q05=ROOT/'work/q05_traced_extraction_20260929/review_v2/chunks'
KINDS=(('D','D'),('N','N'),('D','N'),('N','D'))
# name, n baseline/amplitude/mode, Ve baseline/amplitude/mode.
FIELDS=(('constant_flux',1.2,0.,'sx',.2,0.,'sy'),
 ('constant_density',1.2,0.,'sx',.2,.12,'sy'),
 ('constant_velocity',1.,.15,'sx',.25,0.,'sy'),
 ('coupled_smooth',1.,.15,'sx',.2,.12,'sy'),
 ('coupled_wave',1.,.1,'wave30',.2,.1,'wave75'),
 ('counterflow_wave',1.,.1,'wave75',0.,.15,'wave30'),
 ('radial_envelope',1.,.12,'r2',.2,.12,'sx'),
 ('zero_velocity',1.,.15,'sx',0.,0.,'sy'))

def primitive_modes(points,mode):
 p=np.asarray(points);u,th,e=np.moveaxis(p,-1,0);x=u*np.cos(th);y=u*np.sin(th)
 dx=np.stack((np.cos(th),-y,np.zeros_like(u)),axis=-1);dy=np.stack((np.sin(th),x,np.zeros_like(u)),axis=-1)
 if mode=='sx':
  v=x*np.cos(e);g=dx*np.cos(e)[...,None];g[...,2]=-x*np.sin(e)
 elif mode=='sy':
  v=y*np.sin(2*e);g=dy*np.sin(2*e)[...,None];g[...,2]=2*y*np.cos(2*e)
 elif mode=='r2':v=u*u;g=np.stack((2*u,np.zeros_like(u),np.zeros_like(u)),axis=-1)
 else:
  angle=np.deg2rad(30 if mode=='wave30' else 75);k=2*np.pi/(.5 if mode=='wave30' else .35);m=1 if mode=='wave30' else 2
  phase=k*(np.cos(angle)*x+np.sin(angle)*y)+m*e
  dp=k*(np.cos(angle)*dx+np.sin(angle)*dy);dp[...,2]+=m
  v=np.cos(phase);g=-np.sin(phase)[...,None]*dp
 return v,g

def fields(points):
 ns=[];vs=[];ng=[];vg=[]
 for name,n0,na,nm,v0,va,vm in FIELDS:
  n,dn=primitive_modes(points,nm);v,dv=primitive_modes(points,vm)
  ns.append(n0+na*n);vs.append(v0+va*v);ng.append(na*dn);vg.append(va*dv)
 return np.stack(ns,axis=-1),np.stack(vs,axis=-1),np.stack(ng,axis=-2),np.stack(vg,axis=-2)

def boundary(q):
 nf=len(FIELDS);nr=len(q.raw)
 bn=[np.zeros((nf,nr,35)),np.zeros((nf,nr,3)),np.zeros((nf,nr,3,2)),np.zeros((nf,nr,35))];bv=[x.copy() for x in bn]
 for r in np.flatnonzero(q.raw//q.metadata['n']**2>=q.metadata['n']-2):
  n,v,gn,gv=fields(q.boundary_wall_nodes[r]);bn[0][:,r]=n.T;bv[0][:,r]=v.T
  bn[3][:,r]=np.einsum('qa,qfa->fq',q.boundary_wall_normal[r],gn);bv[3][:,r]=np.einsum('qa,qfa->fq',q.boundary_wall_normal[r],gv)
  n,v,gn,gv=fields(q.boundary_wall_queries[r]);bn[1][:,r]=n.T;bv[1][:,r]=v.T
  bn[2][:,r]=gn[:,:,1:].transpose(1,0,2);bv[2][:,r]=gv[:,:,1:].transpose(1,0,2)
 return QBoundaryData(*bn),QBoundaryData(*bv)

def project(q,raw):return np.sum(raw[:,q.owner_raw]*q.owner_weight[None,:,:],axis=-1)
def finite(*xs):
 if not all(np.isfinite(x).all() for x in xs):raise ValueError('nonfinite campaign data')
def checked(a,b,tol=1e-8):
 finite(a,b);e=float(np.max(abs(np.asarray(a)-np.asarray(b))))
 if e>tol:raise ValueError(f'replay mismatch {e} > {tol}')
 return e

def main():
 start=time.perf_counter();OUT.mkdir(parents=True,exist_ok=True)
 if jax.default_backend()!='cpu' or not jax.config.jax_enable_x64:raise RuntimeError('CPU/x64 required')
 paths=[Path(__file__),Path(replay.__file__),ROOT/'DRBX/scripts/q05_bounded_matrix.py',ROOT/'DRBX/scripts/q05_replay_identity.py']
 paths+=list((ROOT/'DRBX/src/drbx/stencils').glob('q_*.py'))+list((ROOT/'DRBX/src/drbx/native').glob('q_*.py'))
 sources={str(p):replay.sha(p) for p in paths}
 design=dict(fields=FIELDS,cases=CASES,kinds=KINDS,span=1/32,sources=sources,product='primitive-slot-product',reference='analytic midpoint -div(b*n*Ve)',characteristic=False,limiter=False)
 identity=digest(design);write_json(OUT/'design.json',design)
 ctx=None;last_n=None;records=[];receipts=[];Ns=[];Os=[];Rs=[];deltas=[];sites=[];performance=[]
 for n,block,offset in CASES:
  owners,tp=replay.preflight(n,block);owner=int(owners[offset])
  if n!=last_n:
   if ctx is None:ctx,t=replay.model.context(n,ROOT)
   else:_,t=replay.model.context(n,ROOT,physical=False,magnetic=False)
   nn,vv,_,_=fields(t.pts)
   observe=lambda a:np.stack([np.bincount(t.ro,weights=t.rv*a[:,j],minlength=len(t.vol))/t.vol for j in range(len(FIELDS))])
   sn,sv,sprod=observe(nn),observe(vv),observe(nn*vv);assert sn.min()>0
   covariance=sprod-sn*sv;last_n=n
  raw=raw_members(t,[owner])
  with np.load(tp) as z:hit=np.isin(z['raw'],raw);ends=z['ends'][hit];assert np.array_equal(raw,z['raw'][hit])
  path=Q05/f'N{n}'/f'q_{block:06d}_1_owners{offset}_1.npz'
  q=load_chunk(path,span=1/32,source_identity=replay.sha(tp),geometry_identity=replay.geometry_identity(n),topology_hash=sha256_array(t.ro)+':'+sha256_array(t.rv),trace_hash=sha256_array(raw)+':'+sha256_array(ends))
  assert np.array_equal(q.owners,[owner]);bn,bv=boundary(q)
  tick=time.perf_counter();host=prepare_density_transport(q);view=stage_density_transport(host);prep=time.perf_counter()-tick
  tube=stage_parallel_divergence(prepare_tube_divergence(q));audit=prepare_kappa(q,lambda p:replay.model.geom(ctx,p))
  en,ev,gn,gv=fields(q.slot_points);exactflux=en*ev
  O=project(q,-np.einsum('rs,rsf->fr',q.magnetic_L,exactflux))
  gradient=ev[:,2,:,None]*gn[:,2]+en[:,2,:,None]*gv[:,2]
  refraw=-(np.einsum('ra,rfa->fr',q.magnetic_b[:,2],gradient)+audit.kappa[None,:]*exactflux[:,2].T)
  R=project(q,refraw);siteN=[];site_delta=[];max_replay=0.;max_zero=0.;factor_error=0.;minslot=np.inf
  for nk,vk in KINDS:
   fn=lambda a,b,c,d:apply_density_transport(view,a,b,c,d,density_kind=nk,velocity_kind=vk)
   N=np.asarray(fn(sn,sv,bn,bv));siteN.append(N[:,0])
   # Explicit primitive value assembly, product, divergence, projection.
   def slots(state,bc,kind):
    val=np.einsum('frd,rsd->frs',state[:,q.donor],q.row_value_D if kind=='D' else q.row_value_N)
    if kind=='D':val+=np.einsum('frj,rsj->frs',bc.dirichlet_trace,q.boundary_value_D_trace)+bc.dirichlet_query_value*(q.raw//n**2>=n-2)[None,:,None]
    else:val+=np.einsum('frj,rsj->frs',bc.neumann_normal,q.boundary_value_N_normal)
    return val
   ns,vs=slots(sn,bn,nk),slots(sv,bv,vk);minslot=min(minslot,float(ns.min()))
   explicit=project(q,-np.einsum('rs,frs->fr',q.magnetic_L,ns*vs));max_replay=max(max_replay,checked(N,explicit))
   NO=N-O;OR=O-R;NR=N-R;checked(NR,NO+OR,tol=1e-12);max_zero=max(max_zero,float(abs(N[-1]).max()));assert max_zero==0
   # Constant-factor controls must reduce to accepted D, including div(b).
   dn=np.asarray(apply_parallel_divergence(tube,sn,bn,kind=nk));dv=np.asarray(apply_parallel_divergence(tube,sv,bv,kind=vk))
   factor_error=max(factor_error,checked(N[1],-1.2*dv[1]),checked(N[2],-.25*dn[2]),checked(N[0],project(q,-.24*np.sum(q.magnetic_L,axis=1)[None,:])[0]))
   # Diagnostic only: exact product wall data and products of owner observations.
   # For N these boundary values are analytic MMS data, not available from a
   # normal derivative alone. This alternative is not selected for runtime.
   bp=QBoundaryData(bn.dirichlet_trace*bv.dirichlet_trace,bn.dirichlet_query_value*bv.dirichlet_query_value,
    bn.dirichlet_tangent*bv.dirichlet_query_value[...,None]+bv.dirichlet_tangent*bn.dirichlet_query_value[...,None],
    bn.neumann_normal*bv.dirichlet_trace+bv.neumann_normal*bn.dirichlet_trace)
   alt=-np.asarray(apply_parallel_divergence(tube,sn*sv,bp,kind=nk)) if nk==vk else np.full_like(N,np.nan)
   # Store finite placeholder plus explicit availability for mixed cases.
   difference=alt-N if nk==vk else np.zeros_like(N);site_delta.append(difference[:,0])
   for j,f in enumerate(FIELDS):
    rec=dict(n=n,owner=owner,radial=int(raw[0]//n**2),family=q.metadata['row_diagnostics'][0]['family'],field=f[0],density_kind=nk,velocity_kind=vk,reference_abs=float(abs(R[j,0])),N_minus_O=float(abs(NO[j,0])),O_minus_R=float(abs(OR[j,0])),N_minus_R=float(abs(NR[j,0])),owner_product_comparison_available=nk==vk,
      owner_product_delta=float(abs(difference[j,0])) if nk==vk else None,owner_observation_product_defect=float(abs(covariance[j,owner])),signed_local_volume_residual=float(t.vol[owner]*NR[j,0]))
    records.append(rec)
   if (n,block,offset)==CASES[0] and nk==vk=='D':
    tic=time.perf_counter();jf=jax.jit(fn);got=jf(sn,sv,bn,bv);got.block_until_ready();compile_seconds=time.perf_counter()-tic;checked(got,N)
    tic=time.perf_counter()
    for _ in range(10):jf(sn,sv,bn,bv).block_until_ready()
    performance.append(dict(n=n,owner=owner,compile_and_first_seconds=compile_seconds,warm_seconds=(time.perf_counter()-tic)/10,host_runtime_bytes=host.nbytes,prepare_stage_seconds=prep))
  finite(siteN,O,R,site_delta);assert minslot>0 and replay.rss()<3
  Ns.append(np.stack(siteN));Os.append(O[:,0]);Rs.append(R[:,0]);deltas.append(np.stack(site_delta));sites.append(dict(n=n,owner=owner,radial=int(raw[0]//n**2),family=q.metadata['row_diagnostics'][0]['family']))
  receipts.append(dict(n=n,owner=owner,identity=identity,runtime_identity=host.metadata['identity'],q_path=str(path),q_sha256=replay.sha(path),trace_path=str(tp),trace_sha256=replay.sha(tp),geometry_identity=replay.geometry_identity(n),runtime_replay_max=max_replay,constant_factor_max=factor_error,zero_velocity_max=max_zero,min_reconstructed_density=minslot,kappa_step_sensitivity=float(audit.step_sensitivity.max()),exterior_caps=int(np.count_nonzero(q.slot_points[:,:2,0]>1)),choices=np.unique(q.choice).tolist()))
  print(n,owner,sites[-1]['family'],'N-O max',float(abs(np.stack(siteN)-O[:,0]).max()),flush=True)
 N,O,R,delta=map(np.stack,(Ns,Os,Rs,deltas));finite(N,O,R,delta)
 assert sources=={p:replay.sha(p) for p in sources}
 np.savez_compressed(OUT/'arrays.npz',N=N,O=O,R=R,owner_product_delta=delta)
 validation=dict(identity=identity,sites=len(sites),records=len(records),fields=[f[0] for f in FIELDS],kinds=KINDS,
  arrays_sha256=replay.sha(OUT/'arrays.npz'),runtime_replay_max=max(r['runtime_replay_max'] for r in receipts),constant_factor_max=max(r['constant_factor_max'] for r in receipts),zero_velocity_max=max(r['zero_velocity_max'] for r in receipts),minimum_density=min(r['min_reconstructed_density'] for r in receipts),exterior_caps=sum(r['exterior_caps'] for r in receipts),elapsed_seconds=time.perf_counter()-start,peak_rss_gib=replay.rss(),scope='fixed complete-owner sample; no global orders or global conservation claims',passed=True)
 for name,obj in [('validation',validation),('records',records),('receipts',receipts),('sites',sites),('performance',performance)]:write_json(OUT/(name+'.json'),obj)
 lines=['# Q07 centered density transport: bounded HSX test','',
 'Selected action: reconstruct primitive n and Ve at the same h/32 caps and center, multiply, apply unchanged tube weights, negate and project complete owners. Eight field pairs, four primitive BC combinations, 21 complete owners. No limiter or characteristic correction.','',
 '| N | BC n/Ve | pooled N-O RMS | pooled O-R RMS | pooled N-R RMS | maximum N-O |','|---|---|---:|---:|---:|---:|']
 for n in (32,48,64):
  ix=np.array([s['n']==n for s in sites]);oo,rr=O[ix],R[ix]
  for k,(nk,vk) in enumerate(KINDS):
   nn=N[ix,k];rms=lambda a:float(np.sqrt(np.mean(abs(a)**2)))
   lines.append(f'| {n} | {nk}/{vk} | {rms(nn-oo):.8e} | {rms(oo-rr):.8e} | {rms(nn-rr):.8e} | {abs(nn-oo).max():.8e} |')
 lines+=['','These are unweighted fixed-site summaries with different site selections at each N, not global convergence orders. Signed local volume residuals in records.json are diagnostics, not a complete-domain conservation measurement.','',json.dumps(validation,indent=2)]
 (OUT/'report.md').write_text('\n'.join(lines)+'\n');print(json.dumps(validation,indent=2))
if __name__=='__main__':main()
