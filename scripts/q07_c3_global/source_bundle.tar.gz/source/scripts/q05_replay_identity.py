"""Portable identity and checkpoint validation for Q05 saved-action replay."""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path

SCHEMA = 'q05.action-replay.v2'


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False,
                                     separators=(',', ':')).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4 << 20), b''):
            h.update(block)
    return h.hexdigest()


def make_request(context, *, n, block, span, owners, trace_hash,
                 jit=False, compare_rows=False, bench_prep=False, save_artifact=False):
    return dict(schema=SCHEMA, context=context, context_digest=digest(context),
                n=int(n), block=int(block), span=float(span),
                owner_ids=[int(o) for o in owners], trace_sha256=trace_hash,
                validation=dict(jit=bool(jit), compare_rows=bool(compare_rows),
                                bench_prep=bool(bench_prep), save_artifact=bool(save_artifact)))


def finite_below(value, limit):
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and 0 <= value <= limit)


def receipt_matches(receipt, request):
    """Fail closed for stale, incomplete, malformed or nonfinite evidence."""
    try:
        if (receipt['replay_request'] != request or
                receipt['replay_digest'] != digest(request) or
                receipt['owners'] != len(request['owner_ids']) or
                any(receipt[k] != request[k] for k in ('n', 'block', 'span', 'trace_sha256')) or
                receipt['campaign_identity'] != request['context']['campaign_identity'] or
                receipt['selection_exact'] is not True or receipt['volume_exact'] is not True):
            return False
        if not all(finite_below(receipt[k], limit) for k, limit in
                   (('max_abs', 1e-8), ('weighted_rms', 1e-8),
                    ('constant_D', 1e-7), ('constant_N', 1e-7),
                    ('affine_D', 1e-8), ('affine_N', 1e-8))):
            return False
        if set(receipt['per_field']) != set(request['context']['fields']):
            return False
        if not all(finite_below(v['max_abs'], 1e-8) for v in receipt['per_field'].values()):
            return False
        mode = request['validation']
        if mode['compare_rows'] and not finite_below(receipt['source_row_max'], 1e-10):
            return False
        if mode['jit'] and (not finite_below(receipt['jit_first_seconds'], 1e9)
                            or receipt['jit_cache_unchanged'] is False):
            return False
        if mode['bench_prep'] and not finite_below(receipt['warm_preparation_seconds'], 1e9):
            return False
        if mode['save_artifact']:
            artifact = receipt['artifact']
            if file_hash(artifact['path']) != artifact['sha256']:
                return False
        return True
    except (KeyError, TypeError, ValueError, OSError):
        return False


def read_matching(path, request):
    try:
        receipt = json.loads(Path(path).read_text())
    except (OSError, ValueError):
        return None
    return receipt if receipt_matches(receipt, request) else None


def write_json(path, value):
    """Atomic replacement, retaining previous evidence by content hash."""
    path = Path(path)
    data = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        old = path.read_bytes()
        if old != data:
            archive = path.parent / 'superseded'
            archive.mkdir(exist_ok=True)
            backup = archive / (path.stem + '.' + hashlib.sha256(old).hexdigest() + path.suffix)
            backup.write_bytes(old)
    tmp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    tmp.write_bytes(data)
    os.replace(tmp, path)
