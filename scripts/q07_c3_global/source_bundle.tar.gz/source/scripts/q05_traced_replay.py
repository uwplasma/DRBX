"""Resumable complete-owner replay of the accepted frozen Q actions.

Research adapter only: frozen source supplies canonical HSX inputs and analytic
MMS boundary data. Package code never imports the frozen campaign. Run from the
DRBX root with PYTHONPATH=src and BLAS threads capped at one.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time
import numpy as np
from functools import lru_cache
from q05_replay_identity import digest, make_request, read_matching, receipt_matches, write_json

ROOT=Path(__file__).resolve().parents[2]
FROZEN=ROOT/'work/q_fci_diffusion_freeze_20260929/source'
CAM=ROOT/'work/q-fci-balanced28-dacf15f1-20260929T171025Z'
SELECTIVE=ROOT/'work/q_fci_selective_global_20260929'
OUT=ROOT/'work/q05_traced_extraction_20260929/review_v2'
model = FIELDS = all_fields = None
from drbx.stencils.q_parallel import prepare_chunk,save_chunk,load_chunk,raw_members,FROZEN_IDENTITY
from drbx.native.q_parallel import QBoundaryData,apply_q,stage_q


def file_signature(path):
    s=Path(path).stat()
    return s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns


@lru_cache(maxsize=256)
def _sha_snapshot(path,signature):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(4<<20),b''):h.update(b)
    if file_signature(path)!=signature:
        raise RuntimeError('file changed during checksum: '+str(path))
    return h.hexdigest()


def sha(path):
    """Hash once per unchanged inode/size/mtime/ctime within this process.

    The immutable makegrid alone is 5.8GB. Rehashing it several times for every
    patch dominated replay. Content hashes remain the receipt identity; stat
    signatures only control reuse of a hash already computed in this process.
    """
    path=str(Path(path).resolve())
    signature=file_signature(path)
    result=_sha_snapshot(path,signature)
    if file_signature(path)!=signature:raise RuntimeError('file changed during checksum: '+path)
    return result


def rss():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1024**3 if sys.platform=='darwin' else 1024**2)


@lru_cache(maxsize=1)
def replay_inputs(n, context_digest):
    """Reuse immutable observations/evaluators within one pinned grid replay.

    This avoids reevaluating all26 fields over the whole domain per tiny patch.
    Cache identity includes code and input content; a changed identity cannot
    reuse observations. Retain at most one resolution's inputs.
    """
    ctx,t=model.context(n,ROOT)
    state=model.states(t).T
    state.flags.writeable=False
    return ctx,t,state


def preflight(n,block):
    global model, FIELDS, all_fields
    frozen=json.loads((ROOT/'work/q_fci_diffusion_freeze_20260929/freeze.json').read_text())
    if frozen['campaign_identity']!=FROZEN_IDENTITY:raise ValueError('freeze identity mismatch')
    for rel,digest in frozen['sources'].items():
        if sha(FROZEN/rel)!=digest:raise ValueError('frozen source checksum mismatch: '+rel)
    if sha(ROOT/'work/q_fci_diffusion_freeze_20260929/frozen_source.tar.gz')!=frozen['source_archive']['sha256']:
        raise ValueError('source archive checksum mismatch')
    manifest=json.loads((ROOT/'work/q_fci_diffusion_freeze_20260929/campaign_identity.json').read_text())
    for path,digest in canonical_inputs(manifest,n).items():
        if sha(path)!=digest:raise ValueError('canonical geometry/magnetic input mismatch: '+path)
    plan=json.loads((CAM/'plan.json').read_text())[str(n)]['global_']
    if block<0 or block>=len(plan):raise ValueError('block outside plan')
    trace=CAM/'global'/f'N{n}'/f'trace_{block:06d}.npz'
    record=json.loads(trace.with_suffix('.json').read_text())
    digest=sha(trace)
    if digest!=record['sha256'] or digest!=manifest['traces'].get(str(trace)):
        raise ValueError('saved trace checksum mismatch')
    if record['identity']!=sha(CAM/'design.json'):raise ValueError('saved trace design mismatch')
    # Import the oracle only after its frozen source checks pass.
    if model is None:
        sys.path.insert(0,str(FROZEN))
        from frozen import model
        from frozen.fields import FIELDS,all_fields
    return np.array(plan[block],int),trace


def replay_context(n):
    """Content identity of the code, oracle and inputs actually being replayed."""
    import importlib.metadata
    import platform
    import jax
    preflight(n,0)
    freeze_path=ROOT/'work/q_fci_diffusion_freeze_20260929/freeze.json'
    freeze=json.loads(freeze_path.read_text())
    validation=SELECTIVE/f'validation_N{n}.json'
    rel=str(validation.relative_to(ROOT))
    if sha(validation)!=freeze['evidence'][rel]:
        raise ValueError('accepted result validation receipt mismatch')
    result=SELECTIVE/f'results_N{n}.npz'
    result_sha=sha(result)
    if result_sha!=json.loads(validation.read_text())['result_sha256']:
        raise ValueError('accepted result checksum mismatch')
    package=Path(__file__).resolve().parents[1]
    paths=[*sorted((package/'src/drbx/stencils').glob('q_parallel*.py')),
           package/'src/drbx/native/q_parallel.py',
           *sorted((package/'scripts').glob('q05_*.py'))]
    manifest=json.loads((ROOT/'work/q_fci_diffusion_freeze_20260929/campaign_identity.json').read_text())
    return dict(campaign_identity=FROZEN_IDENTITY,n=n,fields=list(FIELDS),
                implementation={str(p.relative_to(package)):sha(p) for p in paths},
                canonical_inputs=canonical_inputs(manifest,n),
                freeze=sha(freeze_path),frozen_sources=freeze['sources'],
                campaign_manifest=digest(manifest),plan=sha(CAM/'plan.json'),
                design=sha(CAM/'design.json'),accepted_result=result_sha,
                environment=dict(python=platform.python_version(),system=platform.system(),
                                 machine=platform.machine(),
                                 backend=jax.default_backend(),x64=bool(jax.config.jax_enable_x64),
                                 packages={k:importlib.metadata.version(k) for k in
                                           ('numpy','scipy','jax','jaxlib')}))


def expected_request(n,block,span,*,context=None,owner_offset=0,owner_count=None,**mode):
    if owner_offset<0 or (owner_count is not None and owner_count<=0):
        raise ValueError('invalid owner subset')
    owners,trace=preflight(n,block)
    selected=owners[owner_offset:] if owner_count is None else owners[owner_offset:owner_offset+owner_count]
    if len(selected)==0 or (owner_count is not None and len(selected)!=owner_count):
        raise ValueError('empty or truncated owner subset')
    return make_request(replay_context(n) if context is None else context,
                        n=n,block=block,span=span,owners=selected,trace_hash=sha(trace),**mode)


def receipt_path(n,block,span,owner_offset=0,owner_count=None):
    ai=(1/16,1/32).index(span)
    suffix='' if owner_offset==0 and owner_count is None else f'_owners{owner_offset}_{owner_count}'
    return OUT/'receipts'/f'N{n}'/f'block_{block:06d}_span{ai}{suffix}.json'


def canonical_inputs(manifest,n):
    return {path:digest for path,digest in manifest['inputs'].items()
            if path.endswith(('.nc','.npz')) and
            (f'/{n}x{n}x{n}/' in path or path.endswith('hsx_metric_d58d392545fd3917efeb83b6.npz')
             or path.endswith('mgrid_res2p5cm_180pln.nc'))}


def geometry_identity(n):
    manifest=json.loads((ROOT/'work/q_fci_diffusion_freeze_20260929/campaign_identity.json').read_text())
    return hashlib.sha256(json.dumps(canonical_inputs(manifest,n),sort_keys=True).encode()).hexdigest()


def preflight_complete_grid(n):
    """Read-only full plan/trace audit and conservative storage estimate."""
    preflight(n,0)
    manifest=json.loads((ROOT/'work/q_fci_diffusion_freeze_20260929/campaign_identity.json').read_text())
    plan=json.loads((CAM/'plan.json').read_text())[str(n)]['global_']
    _,t=model.context(n,ROOT,physical=False,magnetic=False)
    seen=[];raw_counts=[];outside_caps=0
    for block,unit in enumerate(plan):
        owners=np.asarray(unit,int);seen.extend(owners.tolist())
        trace=CAM/'global'/f'N{n}'/f'trace_{block:06d}.npz'
        rec=json.loads(trace.with_suffix('.json').read_text());digest=sha(trace)
        if digest!=rec['sha256'] or digest!=manifest['traces'].get(str(trace)):
            raise ValueError(f'trace chunk {block} checksum mismatch')
        if rec['identity']!=sha(CAM/'design.json'):
            raise ValueError(f'trace chunk {block} design mismatch')
        with np.load(trace) as z:
            raw=z['raw'].copy();ends=z['ends'].copy()
        if not np.array_equal(raw,raw_members(t,owners)) or ends.shape!=(len(raw),4,3):
            raise ValueError(f'trace chunk {block} incomplete owner coverage')
        raw_counts.append(len(raw))
        outside_caps+=int(np.count_nonzero(ends[:,:,0]>1))
    if not np.array_equal(np.sort(seen),np.arange(len(t.vol))) or sum(raw_counts)!=n**3:
        raise ValueError('global owner/raw plan incomplete')
    # Measured bounded v1 payload is about 39.2 kB/raw; use 40 kB
    # to include the directional rows. Runtime view is about 3.43 kB/raw.
    receipt=dict(campaign_identity=FROZEN_IDENTITY,n=n,blocks=len(plan),owners=len(t.vol),
                 raw=n**3,max_unit_raw=max(raw_counts),max_unit_owners=max(map(len,plan)),
                 saved_outside_cap_endpoints=outside_caps,
                 all_trace_checksums=True,complete_owner_coverage=True,
                 directional_bytes_per_raw_bound=40000,runtime_bytes_per_raw_bound=3500,
                 directional_bytes_per_span_estimate=40000*n**3,
                 runtime_bytes_per_span_estimate=3500*n**3)
    OUT.mkdir(parents=True,exist_ok=True);dest=OUT/f'preflight_N{n}.json'
    tmp=dest.with_suffix('.tmp');tmp.write_text(json.dumps(receipt,indent=2)+'\n');os.replace(tmp,dest)
    print(json.dumps(receipt),flush=True)
    return receipt


def boundary(prepared):
    nr=len(prepared.raw);nd=len(FIELDS)
    trace=np.zeros((nd,nr,35),complex);qvalue=np.zeros((nd,nr,3),complex)
    tangent=np.zeros((nd,nr,3,2),complex);normal=np.zeros((nd,nr,35),complex)
    wall=np.flatnonzero(np.any(prepared.boundary_wall_normal!=0,axis=(1,2)))
    for i in wall:
        v,g=all_fields(prepared.boundary_wall_nodes[i]);trace[:,i]=v.T
        normal[:,i]=np.einsum('si,sif->sf',prepared.boundary_wall_normal[i],g).T
        vq,gq=all_fields(prepared.boundary_wall_queries[i]);qvalue[:,i]=vq.T;tangent[:,i]=gq[:,1:,:].transpose(2,0,1)
    return QBoundaryData(trace,qvalue,tangent,normal)


def source_row_difference(ctx,t,prepared):
    """Compare one row for every support choice present in this chunk."""
    positions=[int(np.flatnonzero(prepared.choice==choice)[0]) for choice in np.unique(prepared.choice)]
    return max(source_row_difference_one(ctx,t,prepared,pos) for pos in positions)


def source_row_difference_one(ctx,t,prepared,pos):
    from frozen.support import Hybrid,BalancedHybrid
    from frozen.wall import Wall
    from policy import LocalHybrid
    rr=int(prepared.raw[pos]);ijk=np.array(np.unravel_index(rr,(t.n,)*3))
    if ijk[0]>=t.n-2:
        w=Wall(ctx,t,*ijk);W,I,GW,GI=w.basis(prepared.slot_points[pos]);VN,BN,DN,EN=w.maps(prepared.slot_points[pos])
        ids=w.ids;vD=I;gD=GI;vN=VN;gN=DN
        sidecar=max(np.max(np.abs(prepared.boundary_value_D_trace[pos]+I.reshape(3,4,35).sum(axis=1))),
                    np.max(np.abs(prepared.boundary_gradient_D_trace[pos]+GI.reshape(3,3,4,35).sum(axis=2))),
                    np.max(np.abs(prepared.boundary_value_N_normal[pos]-BN)),
                    np.max(np.abs(prepared.boundary_gradient_N_normal[pos]-EN)))
    else:
        sidecar=0.
        h=Hybrid(t)
        if ijk[0]<=h.last:
            # Frozen indicator requires both spans; use the trace points from
            # the package only for direct row comparison of the chosen policy.
            kind=int(prepared.choice[pos]);obj=(h,BalancedHybrid(t),LocalHybrid(t))[kind]
        else:obj=h
        ids,vD,gD,_=obj.rows(ijk,prepared.slot_points[pos]);vN=vD;gN=gD
    count=int(prepared.row_count[pos]);got=prepared.donor[pos,:count]
    if not np.array_equal(ids,got):raise AssertionError(('donor mismatch',rr))
    return float(max(sidecar,np.max(np.abs(vD-prepared.row_value_D[pos,:,:count])),
                     np.max(np.abs(gD-prepared.row_gradient_D[pos,:,:,:count])),
                     np.max(np.abs(vN-prepared.row_value_N[pos,:,:count])),
                     np.max(np.abs(gN-prepared.row_gradient_N[pos,:,:,:count]))))


def run(n,block,span,save_artifact=False,jit=False,owner_offset=0,owner_count=None,
        compare_rows=False,bench_prep=False):
    import jax
    request=expected_request(n,block,span,owner_offset=owner_offset,owner_count=owner_count,
                             jit=jit,compare_rows=compare_rows,bench_prep=bench_prep,
                             save_artifact=save_artifact)
    owners,tracepath=preflight(n,block)
    selected=owners[owner_offset:] if owner_count is None else owners[owner_offset:owner_offset+owner_count]
    if len(selected)==0:raise ValueError('empty owner selection')
    t0=time.perf_counter();ctx,t,state=replay_inputs(n,request['context_digest'])
    init=time.perf_counter()-t0
    with np.load(tracepath) as z:raw=z['raw'].copy();ends=z['ends'].copy()
    if not np.array_equal(raw,raw_members(t,owners)):raise ValueError('trace not complete owner block')
    mask=np.isin(t.ro[raw],selected);raw=raw[mask];ends=ends[mask];owners=selected
    def jacobian(p):return ctx['evaluator']._position_and_jacobian(p)[1]
    t1=time.perf_counter()
    prepared=prepare_chunk(t,owners,ends,lambda p:model.geom(ctx,p),jacobian,
                           span=span,source_identity=sha(tracepath),geometry_identity=geometry_identity(n),raw=raw)
    prep=time.perf_counter()-t1
    warm_prep=None
    if bench_prep:
        t_warm=time.perf_counter()
        repeated=prepare_chunk(t,owners,ends,lambda p:model.geom(ctx,p),jacobian,
                               span=span,source_identity=sha(tracepath),geometry_identity=geometry_identity(n),raw=raw)
        warm_prep=time.perf_counter()-t_warm
        if not np.array_equal(repeated.donor,prepared.donor) or not np.array_equal(repeated.diffusion_D,prepared.diffusion_D):
            raise AssertionError('repeated preparation mismatch')
    row_difference=source_row_difference(ctx,t,prepared) if compare_rows else None
    if row_difference is not None and row_difference>1e-10:raise AssertionError(('source row difference',row_difference))
    bc=boundary(prepared)
    view=prepared.runtime_view()
    stage=time.perf_counter()
    view=stage_q(view)
    staging_seconds=time.perf_counter()-stage
    t2=time.perf_counter()
    d=np.asarray(apply_q(view,state,bc,kind='D'));nn=np.asarray(apply_q(view,state,bc,kind='N'))
    warm_eager=time.perf_counter()-t2
    zeros=QBoundaryData(*(np.zeros_like(v) for v in bc))
    one=np.ones(len(t.vol))
    nr=len(prepared.raw)
    compatible_D=QBoundaryData(np.ones((nr,35)),np.ones((nr,3)),
                               np.zeros((nr,3,2)),np.zeros((nr,35)))
    zeros_scalar=QBoundaryData(np.zeros((nr,35)),np.zeros((nr,3)),
                               np.zeros((nr,3,2)),np.zeros((nr,35)))
    constant_D=float(np.max(np.abs(np.asarray(apply_q(view,one,compatible_D,kind='D')))))
    constant_N=float(np.max(np.abs(np.asarray(apply_q(view,one,zeros_scalar,kind='N')))))
    if max(constant_D,constant_N)>1e-7:raise AssertionError(('constant action',constant_D,constant_N))
    affine_D=float(np.max(np.abs(d-np.asarray(apply_q(view,state,zeros,kind='D'))-
                                np.asarray(apply_q(view,np.zeros_like(state),bc,kind='D')))))
    affine_N=float(np.max(np.abs(nn-np.asarray(apply_q(view,state,zeros,kind='N'))-
                                 np.asarray(apply_q(view,np.zeros_like(state),bc,kind='N')))))
    if max(affine_D,affine_N)>1e-8:raise AssertionError(('boundary affine split',affine_D,affine_N))
    jit_first=None;jit_warm=None;jit_changed_boundary=None;jit_cache_unchanged=None
    if jit:
        fd=jax.jit(lambda x,b:apply_q(view,x,b,kind='D'))
        t3=time.perf_counter();j=np.asarray(fd(state,bc).block_until_ready());jit_first=time.perf_counter()-t3
        if not np.allclose(j,d,atol=1e-8,rtol=0):raise AssertionError('JIT D mismatch')
        t3=time.perf_counter();fd(state,bc).block_until_ready();jit_warm=time.perf_counter()-t3
        changed=QBoundaryData(bc.dirichlet_trace+0.125,bc.dirichlet_query_value,
                              bc.dirichlet_tangent+0.03125,bc.neumann_normal)
        cache_before=fd._cache_size() if hasattr(fd,'_cache_size') else None
        t3=time.perf_counter();changed_jit=np.asarray(fd(state,changed).block_until_ready())
        jit_changed_boundary=time.perf_counter()-t3
        if not np.allclose(changed_jit,apply_q(view,state,changed,kind='D'),atol=1e-8,rtol=0):
            raise AssertionError('changing boundary values changed JIT result')
        cache_after=fd._cache_size() if hasattr(fd,'_cache_size') else None
        jit_cache_unchanged=cache_before==cache_after if cache_before is not None else None
        if jit_cache_unchanged is False:raise AssertionError('boundary-only change recompiled JIT')
        jvp=jax.jvp(lambda x:fd(x,bc),(state,),(np.ones_like(state),))[1]
        if not np.allclose(jvp,apply_q(view,np.ones_like(state),zeros,kind='D'),atol=1e-8,rtol=0):
            raise AssertionError('state JVP mismatch')
    with np.load(SELECTIVE/f'results_N{n}.npz') as z:
        if tuple(z['fields'])!=FIELDS:raise ValueError('accepted field order mismatch')
        ai=0 if span==1/16 else 1
        reference=z['N'][owners,:,ai,:].copy();oracle=z['O'][owners].copy()
        vol=z['volume'][owners].copy();radial=z['radial'][owners].copy()
        choice_reference=z['choice'][raw].copy()
    if not np.array_equal(prepared.choice,choice_reference):raise AssertionError('frozen selection mismatch')
    if not np.allclose(t.vol[owners],vol,rtol=0,atol=1e-12):raise AssertionError('frozen volume mismatch')
    diff=np.stack((d,nn),axis=1).transpose(2,1,0)-reference
    if not np.isfinite(diff).all():raise AssertionError('nonfinite Q action replay')
    absolute=np.abs(diff)
    max_abs=float(absolute.max());weighted=float(np.sqrt(np.sum(vol[:,None,None]*absolute**2)/np.sum(vol)/absolute.shape[1]/absolute.shape[2]))
    scale=float(np.max(np.abs(reference)))
    field_error=absolute.max(axis=(0,1))
    field_scale=np.maximum(1e-12,np.maximum(np.abs(reference).max(axis=(0,1)),np.abs(oracle).max(axis=(0,1))))
    spatial=np.abs(reference-oracle)
    spatial_weighted=float(np.sqrt(np.sum(vol[:,None,None]*spatial**2)/np.sum(vol)/spatial.shape[1]/spatial.shape[2]))
    if max_abs>1e-8:raise AssertionError(('Q action replay',n,block,span,max_abs,absolute.max(axis=(0,2)),
                                        np.unravel_index(np.argmax(absolute),absolute.shape)))
    receipt=dict(replay_request=request,replay_digest=digest(request),
                 n=n,block=block,span=span,owner_offset=owner_offset,owner_count=owner_count,
                 owners=len(owners),raw=len(raw),campaign_identity=FROZEN_IDENTITY,
                 trace_sha256=sha(tracepath),max_abs=max_abs,weighted_rms=weighted,
                 scale_aware_relative=max_abs/max(1e-12,scale),
                 archived_spatial_weighted_rms=spatial_weighted,
                 difference_over_spatial_error=weighted/max(1e-12,spatial_weighted),
                 per_bc_max=absolute.max(axis=(0,2)).tolist(),
                 field_scale_floor=1e-12,
                 per_field={name:dict(max_abs=float(field_error[i]),scale=float(field_scale[i]),
                                      scale_aware_relative=float(field_error[i]/field_scale[i]))
                            for i,name in enumerate(FIELDS)},
                 region_max={str(int(r)):float(absolute[radial==r].max()) for r in np.unique(radial)},
                 choice_counts=np.bincount(prepared.choice[prepared.choice>=0],minlength=3).tolist(),
                 source_row_max=row_difference,selection_exact=True,volume_exact=True,
                 constant_D=constant_D,constant_N=constant_N,affine_D=affine_D,affine_N=affine_N,
                 source_seconds=init,preparation_seconds=prep,apply_eager_seconds=warm_eager,
                 warm_preparation_seconds=warm_prep,
                 magnetic_seconds=prepared.metadata['magnetic_seconds'],
                 rows_seconds=prepared.metadata['rows_seconds'],
                 packing_seconds=prepared.metadata['packing_seconds'],staging_seconds=staging_seconds,
                 jit_first_seconds=jit_first,jit_warm_seconds=jit_warm,
                 jit_changed_boundary_seconds=jit_changed_boundary,jit_cache_unchanged=jit_cache_unchanged,
                 payload_bytes=prepared.nbytes,runtime_bytes=view.nbytes,peak_rss_gib=rss(),max_donors=int(prepared.donor.shape[1]),
                 artifact_saved=bool(save_artifact))
    if save_artifact:
        suffix='' if owner_offset==0 and owner_count is None else f'_owners{owner_offset}_{owner_count}'
        path=OUT/'chunks'/f'N{n}'/f'q_{block:06d}_{ai}{suffix}.npz';start=time.perf_counter();save_chunk(prepared,path)
        receipt['save_seconds']=time.perf_counter()-start;receipt['disk_bytes']=path.stat().st_size
        receipt['artifact']=dict(path=str(path),sha256=sha(path))
        start=time.perf_counter();reload=load_chunk(path,source_identity=sha(tracepath),
                                                  geometry_identity=geometry_identity(n),span=span,
                                                  topology_hash=prepared.metadata['topology_hash'],
                                                  trace_hash=prepared.metadata['trace_hash'])
        receipt['load_seconds']=time.perf_counter()-start
        if reload.nbytes!=prepared.nbytes:raise AssertionError('round trip payload')
    if replay_context(n)!=request['context']:
        raise RuntimeError('replay source/input identity changed during execution')
    if not receipt_matches(receipt,request):raise AssertionError('incomplete replay receipt')
    dest=receipt_path(n,block,span,owner_offset,owner_count)
    write_json(dest,receipt)
    print(json.dumps(receipt),flush=True)
    return receipt


def main():
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,choices=(32,48,64),required=True)
    p.add_argument('--block',type=int);p.add_argument('--span',type=float,choices=(1/16,1/32))
    p.add_argument('--owner-offset',type=int,default=0);p.add_argument('--owner-count',type=int)
    p.add_argument('--all',action='store_true');p.add_argument('--save-artifact',action='store_true');p.add_argument('--jit',action='store_true')
    p.add_argument('--preflight-only',action='store_true')
    p.add_argument('--compare-rows',action='store_true');p.add_argument('--bench-prep',action='store_true')
    a=p.parse_args()
    if a.preflight_only:
        if a.all or a.block is not None:p.error('--preflight-only accepts only --n')
        preflight_complete_grid(a.n)
    elif a.all:
        if a.block is not None or a.span is not None or a.owner_count is not None or a.owner_offset:
            p.error('--all cannot be combined with a block or owner subset')
        if a.save_artifact:
            p.error('full directional artifacts exceed the local 2 GiB disk budget; stream receipts only')
        preflight(a.n,0)
        plan=json.loads((CAM/'plan.json').read_text())[str(a.n)]['global_']
        _,topology=model.context(a.n,ROOT,physical=False,magnetic=False)
        planned=np.array([o for unit in plan for o in unit],int)
        if not np.array_equal(np.sort(planned),np.arange(len(topology.vol))):
            raise ValueError('global plan does not cover each owner exactly once')
        context=replay_context(a.n)
        receipts=[]
        for block in range(len(plan)):
            for ai,span in enumerate((1/16,1/32)):
                dest=receipt_path(a.n,block,span)
                request=expected_request(a.n,block,span,context=context,jit=a.jit,
                                         compare_rows=a.compare_rows,bench_prep=a.bench_prep)
                rec=read_matching(dest,request)
                if rec is not None:
                    receipts.append(rec);continue
                receipts.append(run(a.n,block,span,a.save_artifact,a.jit,
                                    compare_rows=a.compare_rows,bench_prep=a.bench_prep))
                if not receipt_matches(receipts[-1],request):
                    raise RuntimeError('mixed replay identities')
        if replay_context(a.n)!=context:raise RuntimeError('identity changed during global replay')
        coverage=dict(campaign_identity=FROZEN_IDENTITY,n=a.n,blocks=len(plan),
                      replay_context=context,context_digest=digest(context),
                      receipt_digests=[digest(r) for r in receipts],
                      spans=(1/16,1/32),owners=len(topology.vol),
                      max_abs=max(r['max_abs'] for r in receipts),
                      peak_rss_gib=max(r['peak_rss_gib'] for r in receipts),
                      receipts=len(receipts),complete=True)
        write_json(OUT/f'coverage_N{a.n}.json',coverage)
    else:
        if a.block is None or a.span is None:p.error('single replay needs --block and --span')
        run(a.n,a.block,a.span,a.save_artifact,a.jit,a.owner_offset,a.owner_count,a.compare_rows,a.bench_prep)
if __name__=='__main__':main()
