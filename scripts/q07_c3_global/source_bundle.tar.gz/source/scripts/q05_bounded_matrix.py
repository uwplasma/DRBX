"""Run fixed complete-owner HSX replay patches sequentially, under one worker."""
from __future__ import annotations
import sys
from q05_traced_replay import OUT, expected_request, receipt_path, replay_context, run
from q05_replay_identity import read_matching

MODE = dict(jit=True, compare_rows=True, bench_prep=False, save_artifact=True)

CASES=[(32,0,0),(32,2,0),(32,14,104),(32,20,0),(32,22,0),(32,63,0),
       (48,28,104),(48,52,48),(48,57,195),(48,67,192),(48,72,64),(48,216,0),
       (64,120,0),(64,122,88),(64,128,0),(64,130,88),
       (64,151,192),(64,161,177),(64,168,4),(64,176,0),(64,511,0)]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    contexts = {n: replay_context(n) for n in (32,48,64)}
    for n,block,offset in CASES:
        for ai,span in enumerate((1/16,1/32)):
            dest=receipt_path(n,block,span,offset,1)
            request=expected_request(n,block,span,context=contexts[n],
                                     owner_offset=offset,owner_count=1,**MODE)
            if read_matching(dest,request) is not None:continue
            run(n,block,span,owner_offset=offset,owner_count=1,**MODE)
            q=read_matching(dest,request)
            if q is None:raise RuntimeError('new receipt did not match bounded request')
            print('PASS',n,block,offset,span,q['max_abs'],q['preparation_seconds'],
                  q['peak_rss_gib'],flush=True)
    return 0


if __name__=='__main__':sys.exit(main())
